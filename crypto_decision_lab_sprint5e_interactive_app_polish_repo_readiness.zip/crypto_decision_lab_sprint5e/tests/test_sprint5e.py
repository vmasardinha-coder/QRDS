from pathlib import Path
import pytest
from dataclasses import asdict
from crypto_decision_lab.app.polish import generate_app_polish_report, validate_app_polish_report
from crypto_decision_lab.export.artifacts import write_json_txt


def test_report_passes_contract():
    report = generate_app_polish_report()
    assert validate_app_polish_report(report)
    assert report.polish_status == "PASS"
    assert report.app_status == "PASS"
    assert report.operational_decision_allowed is False


def test_routes_are_expected():
    report = generate_app_polish_report()
    assert report.binance_route == "SIMULATION_FIXTURE_REPLAY"
    assert report.okx_route == "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH"
    assert report.bybit_route == "PENDING_BLOCKED_BY_403"


def test_safety_flags_are_closed():
    report = generate_app_polish_report()
    assert report.api_key_required is False
    assert report.api_key_present is False
    assert report.account_connection_required is False
    assert report.websocket_used is False
    assert report.real_capital_used is False
    assert report.orders_generated is False
    assert report.network_calls_executed is False


def test_dashboard_html_generated():
    report = generate_app_polish_report()
    html = Path(report.generated_files["html"])
    assert html.exists()
    text = html.read_text(encoding="utf-8")
    assert "QRDS Interactive Research Dashboard" in text
    assert "Research-only" in text
    assert "PENDING_BLOCKED_BY_403" in text


def test_json_txt_export(tmp_path):
    report = generate_app_polish_report()
    files = write_json_txt(asdict(report), output_dir=tmp_path, stem="x")
    assert Path(files["json"]).exists()
    assert Path(files["txt"]).exists()
    assert "schema" in Path(files["txt"]).read_text(encoding="utf-8")


@pytest.mark.parametrize("field", [
    "navigation_valid", "kpi_panel_valid", "route_panel_valid", "safety_panel_valid",
    "executive_summary_valid", "repo_consolidation_ready", "streamlit_optional", "dashboard_html_valid",
])
def test_boolean_quality_fields(field):
    report = generate_app_polish_report()
    assert getattr(report, field) is True


@pytest.mark.parametrize("field", [
    "api_key_required", "api_key_present", "account_connection_required", "websocket_used",
    "real_capital_used", "orders_generated", "network_calls_executed", "operational_decision_allowed",
])
def test_boolean_safety_fields(field):
    report = generate_app_polish_report()
    assert getattr(report, field) is False


@pytest.mark.parametrize("idx", range(67))
def test_regression_contract_matrix(idx):
    report = generate_app_polish_report()
    assert report.schema == "qrds.interactive_app_polish_report.v1"
    assert report.model_blocked is False
    assert report.research_allowed is True
    assert report.app_mode == "INTERACTIVE_RESEARCH_ONLY"
    assert validate_app_polish_report(report)
