# Crypto Decision Lab - Sprint 3D

Paper Trading Validation Offline.

This sprint validates the simulated paper trading ledger generated after the risk engine gate. It remains fully offline and does not connect to any exchange, API key, authenticated WebSocket, real account, or real capital.

## Run

```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_paper_trading_validation.py
```

Expected: 36 tests passed and a PASS validation report for the clean fixture.
