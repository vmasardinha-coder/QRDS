from pathlib import Path
import json

from crypto_decision_lab.paper.fixtures import build_clean_paper_trading_report, build_dirty_paper_trading_report
from crypto_decision_lab.paper.models import PaperTradingReport, PaperTradingValidationReport
from crypto_decision_lab.validation.paper_validation import (
    SOURCE_SCHEMA,
    VALIDATION_SCHEMA,
    MAX_ALLOWED_DRAWDOWN_PCT,
    calculate_validation_score,
    capital_safety_confirmed,
    collect_validation_issues,
    drawdown_within_limit,
    exchange_safety_confirmed,
    fill_consistency,
    is_pass,
    ledger_consistency,
    validate_paper_trading_report,
)
from crypto_decision_lab.exporting.artifacts import export_json, export_txt, export_validation_artifacts


def test_01_clean_fixture_type():
    assert isinstance(build_clean_paper_trading_report(), PaperTradingReport)


def test_02_dirty_fixture_type():
    assert isinstance(build_dirty_paper_trading_report(), PaperTradingReport)


def test_03_source_schema_constant():
    assert SOURCE_SCHEMA == "qrds.paper_trading_report.v1"


def test_04_validation_schema_constant():
    assert VALIDATION_SCHEMA == "qrds.paper_trading_validation_report.v1"


def test_05_drawdown_limit_constant():
    assert MAX_ALLOWED_DRAWDOWN_PCT == 0.05


def test_06_is_pass_true():
    assert is_pass("PASS")


def test_07_is_pass_false():
    assert not is_pass("BLOCKED")


def test_08_clean_fill_consistency():
    assert fill_consistency(build_clean_paper_trading_report())


def test_09_dirty_fill_consistency_false():
    assert not fill_consistency(build_dirty_paper_trading_report())


def test_10_clean_ledger_consistency():
    assert ledger_consistency(build_clean_paper_trading_report())


def test_11_dirty_ledger_consistency_false():
    assert not ledger_consistency(build_dirty_paper_trading_report())


def test_12_clean_capital_safety():
    assert capital_safety_confirmed(build_clean_paper_trading_report())


def test_13_dirty_capital_safety_false():
    assert not capital_safety_confirmed(build_dirty_paper_trading_report())


def test_14_clean_exchange_safety():
    assert exchange_safety_confirmed(build_clean_paper_trading_report())


def test_15_dirty_exchange_safety_false():
    assert not exchange_safety_confirmed(build_dirty_paper_trading_report())


def test_16_clean_drawdown_within_limit():
    assert drawdown_within_limit(build_clean_paper_trading_report())


def test_17_dirty_drawdown_exceeds_limit():
    assert not drawdown_within_limit(build_dirty_paper_trading_report())


def test_18_clean_collect_issues_none():
    assert collect_validation_issues(build_clean_paper_trading_report()) == []


def test_19_dirty_collect_issues_many():
    issues = collect_validation_issues(build_dirty_paper_trading_report())
    assert "paper_status:BLOCKED" in issues
    assert "real_capital_used" in issues
    assert "exchange_or_real_order_exposure" in issues


def test_20_clean_validation_score_expected():
    report = build_clean_paper_trading_report()
    assert calculate_validation_score(report, []) == 0.9875


def test_21_dirty_validation_score_low():
    report = build_dirty_paper_trading_report()
    assert calculate_validation_score(report, collect_validation_issues(report)) < 0.5


def test_22_clean_validation_type():
    result = validate_paper_trading_report(build_clean_paper_trading_report())
    assert isinstance(result, PaperTradingValidationReport)


def test_23_clean_validation_pass():
    result = validate_paper_trading_report(build_clean_paper_trading_report())
    assert result.validation_status == "PASS"


def test_24_clean_model_not_blocked():
    result = validate_paper_trading_report(build_clean_paper_trading_report())
    assert result.model_blocked is False


def test_25_clean_research_allowed():
    result = validate_paper_trading_report(build_clean_paper_trading_report())
    assert result.research_allowed is True


def test_26_clean_paper_validated():
    result = validate_paper_trading_report(build_clean_paper_trading_report())
    assert result.paper_trading_validated is True


def test_27_clean_operational_decision_never_allowed():
    result = validate_paper_trading_report(build_clean_paper_trading_report())
    assert result.operational_decision_allowed is False


def test_28_clean_action_no_live_trade():
    result = validate_paper_trading_report(build_clean_paper_trading_report())
    assert result.action == "NO_LIVE_TRADE_PAPER_VALIDATION_RESEARCH_ONLY"


def test_29_clean_next_gate_public_data_connector():
    result = validate_paper_trading_report(build_clean_paper_trading_report())
    assert result.next_required_gate == "PUBLIC_MARKET_DATA_CONNECTOR_REQUIRED"


def test_30_dirty_validation_blocked():
    result = validate_paper_trading_report(build_dirty_paper_trading_report())
    assert result.validation_status == "BLOCKED"


def test_31_dirty_action_blocked():
    result = validate_paper_trading_report(build_dirty_paper_trading_report())
    assert result.action == "NO_PAPER_VALIDATION_BLOCKED"


def test_32_dirty_model_blocked():
    result = validate_paper_trading_report(build_dirty_paper_trading_report())
    assert result.model_blocked is True


def test_33_to_dict_contains_schema():
    result = validate_paper_trading_report(build_clean_paper_trading_report())
    assert result.to_dict()["schema"] == VALIDATION_SCHEMA


def test_34_export_json(tmp_path):
    result = validate_paper_trading_report(build_clean_paper_trading_report())
    path = export_json(result, tmp_path / "x.json")
    data = json.loads(Path(path).read_text())
    assert data["validation_status"] == "PASS"


def test_35_export_txt(tmp_path):
    result = validate_paper_trading_report(build_clean_paper_trading_report())
    path = export_txt(result, tmp_path / "x.txt")
    text = Path(path).read_text()
    assert "validation_status: PASS" in text


def test_36_export_validation_artifacts(tmp_path):
    result = validate_paper_trading_report(build_clean_paper_trading_report())
    exported = export_validation_artifacts(result, tmp_path)
    assert Path(exported.generated_files["json"]).exists()
    assert Path(exported.generated_files["txt"]).exists()
