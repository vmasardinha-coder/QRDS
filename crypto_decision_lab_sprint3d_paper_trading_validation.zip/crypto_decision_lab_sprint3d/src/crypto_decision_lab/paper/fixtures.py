from crypto_decision_lab.paper.models import PaperTradingReport


def build_clean_paper_trading_report() -> PaperTradingReport:
    return PaperTradingReport(
        schema="qrds.paper_trading_report.v1",
        paper_status="PASS",
        model_blocked=False,
        research_allowed=True,
        paper_trading_allowed=True,
        operational_decision_allowed=False,
        paper_stage="PAPER_RESEARCH_ONLY",
        action="NO_LIVE_TRADE_PAPER_RESEARCH_ONLY",
        initial_equity=10000.0,
        final_equity=9875.0,
        total_return_pct=-0.0125,
        max_drawdown_pct=0.0125,
        paper_orders=47,
        paper_fills=47,
        rejected_orders=0,
        order_ledger_rows=47,
        real_capital_used=False,
        exchange_connected=False,
        real_orders_generated=False,
        orders_generated=False,
        paper_orders_generated=True,
        next_required_gate="PAPER_TRADING_VALIDATION_REQUIRED",
        issues=[],
    )


def build_dirty_paper_trading_report() -> PaperTradingReport:
    return PaperTradingReport(
        schema="qrds.paper_trading_report.v1",
        paper_status="BLOCKED",
        model_blocked=True,
        research_allowed=False,
        paper_trading_allowed=False,
        operational_decision_allowed=True,
        paper_stage="INVALID",
        action="LIVE_TRADE_INVALID",
        initial_equity=10000.0,
        final_equity=8000.0,
        total_return_pct=-0.20,
        max_drawdown_pct=0.20,
        paper_orders=47,
        paper_fills=41,
        rejected_orders=5,
        order_ledger_rows=40,
        real_capital_used=True,
        exchange_connected=True,
        real_orders_generated=True,
        orders_generated=True,
        paper_orders_generated=False,
        next_required_gate="INVALID",
        issues=["risk_status:BLOCKED", "research_not_allowed"],
    )
