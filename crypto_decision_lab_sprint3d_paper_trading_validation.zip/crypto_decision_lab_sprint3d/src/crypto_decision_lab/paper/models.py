from dataclasses import dataclass, asdict
from typing import Any, Dict, List


@dataclass(frozen=True)
class PaperTradingReport:
    schema: str
    paper_status: str
    model_blocked: bool
    research_allowed: bool
    paper_trading_allowed: bool
    operational_decision_allowed: bool
    paper_stage: str
    action: str
    initial_equity: float
    final_equity: float
    total_return_pct: float
    max_drawdown_pct: float
    paper_orders: int
    paper_fills: int
    rejected_orders: int
    order_ledger_rows: int
    real_capital_used: bool
    exchange_connected: bool
    real_orders_generated: bool
    orders_generated: bool
    paper_orders_generated: bool
    next_required_gate: str
    issues: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class PaperTradingValidationReport:
    schema: str
    source_schema: str
    paper_status: str
    validation_status: str
    model_blocked: bool
    research_allowed: bool
    paper_trading_validated: bool
    operational_decision_allowed: bool
    validation_stage: str
    action: str
    validation_score: float
    paper_orders: int
    paper_fills: int
    rejected_orders: int
    order_ledger_rows: int
    fill_consistency: bool
    ledger_consistency: bool
    capital_safety_confirmed: bool
    exchange_safety_confirmed: bool
    max_drawdown_pct: float
    max_allowed_drawdown_pct: float
    drawdown_within_limit: bool
    real_capital_used: bool
    exchange_connected: bool
    real_orders_generated: bool
    orders_generated: bool
    paper_orders_generated: bool
    next_required_gate: str
    issues: List[str]
    generated_files: Dict[str, str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
