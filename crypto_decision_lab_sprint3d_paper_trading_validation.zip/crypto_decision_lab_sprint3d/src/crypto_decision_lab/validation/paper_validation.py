from __future__ import annotations

from crypto_decision_lab.paper.models import PaperTradingReport, PaperTradingValidationReport

VALIDATION_SCHEMA = "qrds.paper_trading_validation_report.v1"
SOURCE_SCHEMA = "qrds.paper_trading_report.v1"
MAX_ALLOWED_DRAWDOWN_PCT = 0.05


def is_pass(value: str) -> bool:
    return value == "PASS"


def fill_consistency(report: PaperTradingReport) -> bool:
    return report.paper_orders == report.paper_fills + report.rejected_orders


def ledger_consistency(report: PaperTradingReport) -> bool:
    return report.order_ledger_rows == report.paper_orders


def capital_safety_confirmed(report: PaperTradingReport) -> bool:
    return not report.real_capital_used


def exchange_safety_confirmed(report: PaperTradingReport) -> bool:
    return not report.exchange_connected and not report.real_orders_generated and not report.orders_generated


def drawdown_within_limit(report: PaperTradingReport, max_allowed_drawdown_pct: float = MAX_ALLOWED_DRAWDOWN_PCT) -> bool:
    return report.max_drawdown_pct <= max_allowed_drawdown_pct


def collect_validation_issues(report: PaperTradingReport, max_allowed_drawdown_pct: float = MAX_ALLOWED_DRAWDOWN_PCT) -> list[str]:
    issues: list[str] = []
    if report.schema != SOURCE_SCHEMA:
        issues.append(f"unexpected_source_schema:{report.schema}")
    if not is_pass(report.paper_status):
        issues.append(f"paper_status:{report.paper_status}")
    if report.model_blocked:
        issues.append("paper_model_blocked")
    if not report.research_allowed:
        issues.append("research_not_allowed")
    if not report.paper_trading_allowed:
        issues.append("paper_trading_not_allowed")
    if report.operational_decision_allowed:
        issues.append("operational_decision_unexpectedly_allowed")
    if report.paper_stage != "PAPER_RESEARCH_ONLY":
        issues.append(f"unexpected_paper_stage:{report.paper_stage}")
    if report.action != "NO_LIVE_TRADE_PAPER_RESEARCH_ONLY":
        issues.append(f"unexpected_action:{report.action}")
    if report.paper_orders <= 0:
        issues.append("no_paper_orders")
    if not fill_consistency(report):
        issues.append("fill_consistency_failed")
    if not ledger_consistency(report):
        issues.append("ledger_consistency_failed")
    if report.rejected_orders > 0:
        issues.append("rejected_orders_present")
    if not report.paper_orders_generated:
        issues.append("paper_orders_not_generated")
    if not capital_safety_confirmed(report):
        issues.append("real_capital_used")
    if not exchange_safety_confirmed(report):
        issues.append("exchange_or_real_order_exposure")
    if not drawdown_within_limit(report, max_allowed_drawdown_pct):
        issues.append("drawdown_limit_exceeded")
    if report.next_required_gate != "PAPER_TRADING_VALIDATION_REQUIRED":
        issues.append(f"unexpected_next_gate:{report.next_required_gate}")
    return issues


def calculate_validation_score(report: PaperTradingReport, issues: list[str]) -> float:
    # A conservative research-only score. Passing papers can score high even with a losing result,
    # because this sprint validates simulation integrity and safety, not profitability.
    checks = [
        report.schema == SOURCE_SCHEMA,
        is_pass(report.paper_status),
        not report.model_blocked,
        report.research_allowed,
        report.paper_trading_allowed,
        not report.operational_decision_allowed,
        fill_consistency(report),
        ledger_consistency(report),
        report.rejected_orders == 0,
        report.paper_orders_generated,
        capital_safety_confirmed(report),
        exchange_safety_confirmed(report),
        drawdown_within_limit(report),
        report.next_required_gate == "PAPER_TRADING_VALIDATION_REQUIRED",
    ]
    passed = sum(1 for item in checks if item)
    base = passed / len(checks)
    # Small drawdown penalty inside the allowed limit.
    penalty = min(0.05, max(0.0, report.max_drawdown_pct))
    score = max(0.0, base - penalty)
    return round(score, 4)


def validate_paper_trading_report(report: PaperTradingReport) -> PaperTradingValidationReport:
    issues = collect_validation_issues(report)
    score = calculate_validation_score(report, issues)
    status = "PASS" if not issues and score >= 0.90 else "BLOCKED"
    blocked = status != "PASS"
    return PaperTradingValidationReport(
        schema=VALIDATION_SCHEMA,
        source_schema=report.schema,
        paper_status=report.paper_status,
        validation_status=status,
        model_blocked=blocked,
        research_allowed=(not blocked and report.research_allowed),
        paper_trading_validated=(not blocked),
        operational_decision_allowed=False,
        validation_stage="PAPER_VALIDATION_RESEARCH_ONLY" if not blocked else "PAPER_VALIDATION_BLOCKED",
        action="NO_LIVE_TRADE_PAPER_VALIDATION_RESEARCH_ONLY" if not blocked else "NO_PAPER_VALIDATION_BLOCKED",
        validation_score=score,
        paper_orders=report.paper_orders,
        paper_fills=report.paper_fills,
        rejected_orders=report.rejected_orders,
        order_ledger_rows=report.order_ledger_rows,
        fill_consistency=fill_consistency(report),
        ledger_consistency=ledger_consistency(report),
        capital_safety_confirmed=capital_safety_confirmed(report),
        exchange_safety_confirmed=exchange_safety_confirmed(report),
        max_drawdown_pct=report.max_drawdown_pct,
        max_allowed_drawdown_pct=MAX_ALLOWED_DRAWDOWN_PCT,
        drawdown_within_limit=drawdown_within_limit(report),
        real_capital_used=report.real_capital_used,
        exchange_connected=report.exchange_connected,
        real_orders_generated=report.real_orders_generated,
        orders_generated=report.orders_generated,
        paper_orders_generated=report.paper_orders_generated,
        next_required_gate="PUBLIC_MARKET_DATA_CONNECTOR_REQUIRED" if not blocked else "PAPER_VALIDATION_REQUIRED",
        issues=issues,
        generated_files={},
    )
