from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass, replace
from pathlib import Path
from typing import Any


def to_plain(obj: Any) -> Any:
    if is_dataclass(obj):
        return asdict(obj)
    return obj


def export_json(obj: Any, path: str | Path) -> str:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(to_plain(obj), indent=2, sort_keys=True), encoding="utf-8")
    return str(path)


def export_txt(obj: Any, path: str | Path) -> str:
    data = to_plain(obj)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    for key, value in data.items():
        lines.append(f"{key}: {value}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(path)


def export_validation_artifacts(report, out_dir: str | Path = "reports/sprint3d"):
    out_dir = Path(out_dir)
    json_path = export_json(report, out_dir / "paper_trading_validation_report.json")
    txt_path = export_txt(report, out_dir / "paper_trading_validation_report.txt")
    return replace(report, generated_files={"json": json_path, "txt": txt_path})
