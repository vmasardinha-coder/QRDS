import json
from pathlib import Path

from crypto_decision_lab.backtest.engine import (
    calculate_max_drawdown_pct,
    compute_trade_cost,
    export_backtest_report,
    filter_valid_rows,
    prediction_to_position,
    run_backtest,
    validate_rows,
)
from crypto_decision_lab.backtest.fixtures import (
    make_clean_readiness_gate,
    make_dirty_readiness_gate,
    make_dirty_research_rows,
    make_integrated_research_rows,
)
from crypto_decision_lab.backtest.models import BacktestConfig, ResearchRow


def test_fixture_has_144_rows():
    assert len(make_integrated_research_rows()) == 144


def test_clean_readiness_gate_is_research_only():
    gate = make_clean_readiness_gate()
    assert gate.readiness_status == "PASS"
    assert gate.research_allowed is True
    assert gate.operational_decision_allowed is False


def test_dirty_readiness_gate_blocks():
    gate = make_dirty_readiness_gate()
    assert gate.readiness_status == "BLOCKED"
    assert gate.model_blocked is True


def test_prediction_to_position_up():
    assert prediction_to_position("up") == 1


def test_prediction_to_position_down():
    assert prediction_to_position("down") == -1


def test_prediction_to_position_flat():
    assert prediction_to_position("flat") == 0


def test_prediction_to_position_down_without_short():
    assert prediction_to_position("down", allow_short=False) == 0


def test_trade_cost_for_position():
    assert compute_trade_cost(1, 0.0004, 0.0002) == 0.0006


def test_trade_cost_for_no_position():
    assert compute_trade_cost(0, 0.0004, 0.0002) == 0.0


def test_max_drawdown_zero_when_monotonic():
    assert calculate_max_drawdown_pct([100, 101, 102]) == 0.0


def test_max_drawdown_positive_when_drawdown_exists():
    assert calculate_max_drawdown_pct([100, 120, 90]) == 0.25


def test_validate_rows_clean():
    assert validate_rows(make_integrated_research_rows()) == []


def test_validate_rows_empty():
    assert validate_rows([]) == ["empty_research_dataset"]


def test_validate_rows_bad_prediction():
    row = make_integrated_research_rows()[0]
    bad = ResearchRow(row.timestamp_index, row.horizon, row.regime_code, row.feature_quality_status, row.target_label, row.future_return, "bad", row.target_valid)
    assert "invalid_prediction_label" in validate_rows([bad])


def test_validate_rows_bad_target():
    row = make_integrated_research_rows()[0]
    bad = ResearchRow(row.timestamp_index, row.horizon, row.regime_code, row.feature_quality_status, "bad", row.future_return, row.predicted_label, row.target_valid)
    assert "invalid_target_label" in validate_rows([bad])


def test_filter_valid_rows_horizon_1():
    rows = filter_valid_rows(make_integrated_research_rows(), 1)
    assert len(rows) == 47


def test_filter_valid_rows_horizon_3():
    rows = filter_valid_rows(make_integrated_research_rows(), 3)
    assert len(rows) == 45


def test_filter_valid_rows_horizon_6():
    rows = filter_valid_rows(make_integrated_research_rows(), 6)
    assert len(rows) == 42


def test_backtest_pass_status():
    report = run_backtest(make_integrated_research_rows(), make_clean_readiness_gate())
    assert report.backtest_status == "PASS"


def test_backtest_schema():
    report = run_backtest(make_integrated_research_rows(), make_clean_readiness_gate())
    assert report.schema == "qrds.backtest_report.v1"


def test_backtest_research_only():
    report = run_backtest(make_integrated_research_rows(), make_clean_readiness_gate())
    assert report.decision_stage == "BACKTEST_RESEARCH_ONLY"
    assert report.action == "NO_TRADE_BACKTEST_RESEARCH_ONLY"


def test_backtest_never_allows_operational_decision():
    report = run_backtest(make_integrated_research_rows(), make_clean_readiness_gate())
    assert report.operational_decision_allowed is False


def test_backtest_never_uses_real_capital():
    report = run_backtest(make_integrated_research_rows(), make_clean_readiness_gate())
    assert report.real_capital_used is False


def test_backtest_never_connects_exchange():
    report = run_backtest(make_integrated_research_rows(), make_clean_readiness_gate())
    assert report.exchange_connected is False


def test_backtest_never_generates_orders():
    report = run_backtest(make_integrated_research_rows(), make_clean_readiness_gate())
    assert report.orders_generated is False


def test_backtest_has_trades_and_coverage():
    report = run_backtest(make_integrated_research_rows(), make_clean_readiness_gate())
    assert report.trades == 47
    assert report.prediction_coverage == 1.0


def test_backtest_metrics_are_bounded():
    report = run_backtest(make_integrated_research_rows(), make_clean_readiness_gate())
    assert 0.0 <= report.win_rate <= 1.0
    assert report.max_drawdown_pct >= 0.0


def test_dirty_readiness_blocks_backtest():
    report = run_backtest(make_integrated_research_rows(), make_dirty_readiness_gate())
    assert report.backtest_status == "BLOCKED"
    assert report.model_blocked is True


def test_leverage_above_limit_blocks():
    report = run_backtest(make_integrated_research_rows(), make_clean_readiness_gate(), BacktestConfig(max_leverage=2.0))
    assert report.backtest_status == "BLOCKED"
    assert "leverage_above_research_limit" in report.issues


def test_export_report_json_and_txt(tmp_path):
    report = run_backtest(make_integrated_research_rows(), make_clean_readiness_gate())
    paths = export_backtest_report(report, tmp_path)
    assert Path(paths["json"]).exists()
    assert Path(paths["txt"]).exists()
    payload = json.loads(Path(paths["json"]).read_text())
    assert payload["schema"] == "qrds.backtest_report.v1"
