# QRDS Core - Sprint 3A - Backtest Skeleton Offline

Sprint 3A introduces a research-only backtest skeleton.

## Scope

- Offline only
- No exchange connection
- No API key
- No real orders
- No real capital
- No leverage
- No operational Long/Short decision

## Outputs

- `reports/sprint3a/backtest_report.json`
- `reports/sprint3a/backtest_report.txt`

## Validate

```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_backtest_skeleton.py
```
