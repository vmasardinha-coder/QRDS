from __future__ import annotations

from typing import List
from crypto_decision_lab.backtest.models import ResearchRow, ReadinessGate


def make_clean_readiness_gate() -> ReadinessGate:
    return ReadinessGate(
        readiness_status="PASS",
        model_blocked=False,
        research_allowed=True,
        operational_decision_allowed=False,
        decision_stage="RESEARCH_ONLY",
        action="NO_TRADE_RESEARCH_ONLY",
        next_required_gate="BACKTEST_REQUIRED",
    )


def make_dirty_readiness_gate() -> ReadinessGate:
    return ReadinessGate(
        readiness_status="BLOCKED",
        model_blocked=True,
        research_allowed=False,
        operational_decision_allowed=False,
        decision_stage="BLOCKED",
        action="NO_DECISION_BLOCKED",
        next_required_gate="DATA_GATE_REPAIR_REQUIRED",
    )


def _actual_label(value: float) -> str:
    if value > 0.00025:
        return "up"
    if value < -0.00025:
        return "down"
    return "flat"


def _prediction_from_past(i: int) -> str:
    # Deterministic toy predictor: no target lookup, only a cycle based on index.
    if i % 11 in {0, 1, 2, 3}:
        return "up"
    if i % 11 in {4, 5, 6}:
        return "down"
    return "flat"


def make_integrated_research_rows() -> List[ResearchRow]:
    rows: List[ResearchRow] = []
    horizons = [1, 3, 6]
    for h in horizons:
        for i in range(48):
            if i >= 48 - h:
                future_return = None
                label = "unknown"
                target_valid = False
            else:
                wave = ((i * 7 + h * 3) % 17) - 8
                drift = 0.00018 if i % 5 in {0, 1, 2} else -0.00008
                future_return = round((wave * 0.00012 * h) + drift, 8)
                label = _actual_label(future_return)
                target_valid = True
            rows.append(
                ResearchRow(
                    timestamp_index=i,
                    horizon=h,
                    regime_code="normal_volatility|upward_drift|normal_volume|balanced_candle",
                    feature_quality_status="PASS",
                    target_label=label,
                    future_return=future_return,
                    predicted_label=_prediction_from_past(i),
                    target_valid=target_valid,
                )
            )
    return rows


def make_dirty_research_rows() -> List[ResearchRow]:
    rows = make_integrated_research_rows()[:10]
    return [
        ResearchRow(
            timestamp_index=r.timestamp_index,
            horizon=r.horizon,
            regime_code=r.regime_code,
            feature_quality_status="BLOCKED",
            target_label="unknown",
            future_return=None,
            predicted_label="flat",
            target_valid=False,
        )
        for r in rows
    ]
