from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, List, Optional


@dataclass(frozen=True)
class ResearchRow:
    timestamp_index: int
    horizon: int
    regime_code: str
    feature_quality_status: str
    target_label: str
    future_return: Optional[float]
    predicted_label: str
    target_valid: bool = True


@dataclass(frozen=True)
class ReadinessGate:
    readiness_status: str
    model_blocked: bool
    research_allowed: bool
    operational_decision_allowed: bool
    decision_stage: str
    action: str
    next_required_gate: str


@dataclass(frozen=True)
class BacktestConfig:
    initial_equity: float = 10_000.0
    fee_rate: float = 0.0004
    slippage_rate: float = 0.0002
    max_leverage: float = 1.0
    allow_short: bool = True
    horizon: int = 1


@dataclass(frozen=True)
class BacktestTrade:
    timestamp_index: int
    horizon: int
    predicted_label: str
    actual_label: str
    position: int
    gross_return: float
    cost: float
    net_return: float
    equity_after: float


@dataclass(frozen=True)
class BacktestReport:
    schema: str
    backtest_status: str
    model_blocked: bool
    research_allowed: bool
    operational_decision_allowed: bool
    decision_stage: str
    action: str
    edge_status: str
    initial_equity: float
    final_equity: float
    total_return: float
    total_return_pct: float
    max_drawdown_pct: float
    trades: int
    win_rate: float
    avg_net_return: float
    prediction_coverage: float
    horizon: int
    fee_rate: float
    slippage_rate: float
    max_leverage: float
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    next_required_gate: str
    issues: List[str]
    metrics: Dict[str, float]

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)
