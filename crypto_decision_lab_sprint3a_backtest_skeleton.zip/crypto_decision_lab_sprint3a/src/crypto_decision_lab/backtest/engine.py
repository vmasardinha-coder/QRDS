from __future__ import annotations

import json
import math
from dataclasses import asdict
from pathlib import Path
from typing import Iterable, List, Sequence

from crypto_decision_lab.backtest.models import (
    BacktestConfig,
    BacktestReport,
    BacktestTrade,
    ReadinessGate,
    ResearchRow,
)

VALID_PREDICTIONS = {"up", "down", "flat"}
VALID_TARGETS = {"up", "down", "flat", "unknown"}


def prediction_to_position(predicted_label: str, allow_short: bool = True) -> int:
    if predicted_label == "up":
        return 1
    if predicted_label == "down":
        return -1 if allow_short else 0
    return 0


def compute_trade_cost(position: int, fee_rate: float, slippage_rate: float) -> float:
    if position == 0:
        return 0.0
    return round(abs(position) * (fee_rate + slippage_rate), 10)


def calculate_max_drawdown_pct(equity_curve: Sequence[float]) -> float:
    if not equity_curve:
        return 0.0
    peak = equity_curve[0]
    max_dd = 0.0
    for equity in equity_curve:
        peak = max(peak, equity)
        if peak > 0:
            max_dd = min(max_dd, (equity - peak) / peak)
    return round(abs(max_dd), 8)


def validate_rows(rows: Iterable[ResearchRow]) -> List[str]:
    issues: List[str] = []
    materialized = list(rows)
    if not materialized:
        return ["empty_research_dataset"]
    for r in materialized:
        if r.predicted_label not in VALID_PREDICTIONS:
            issues.append("invalid_prediction_label")
            break
    for r in materialized:
        if r.target_label not in VALID_TARGETS:
            issues.append("invalid_target_label")
            break
    return issues


def filter_valid_rows(rows: Iterable[ResearchRow], horizon: int) -> List[ResearchRow]:
    return [
        r
        for r in rows
        if r.horizon == horizon
        and r.target_valid
        and r.future_return is not None
        and r.target_label != "unknown"
    ]


def run_backtest(
    rows: Sequence[ResearchRow],
    readiness: ReadinessGate,
    config: BacktestConfig | None = None,
) -> BacktestReport:
    config = config or BacktestConfig()
    issues = validate_rows(rows)
    if config.max_leverage > 1.0:
        issues.append("leverage_above_research_limit")
    if readiness.readiness_status != "PASS":
        issues.append(f"readiness_status:{readiness.readiness_status}")
    if readiness.model_blocked:
        issues.append("readiness_model_blocked")
    if readiness.operational_decision_allowed:
        issues.append("unexpected_operational_permission")

    if issues:
        return BacktestReport(
            schema="qrds.backtest_report.v1",
            backtest_status="BLOCKED",
            model_blocked=True,
            research_allowed=False,
            operational_decision_allowed=False,
            decision_stage="BLOCKED",
            action="NO_BACKTEST_BLOCKED",
            edge_status="BLOCKED_BY_GATE",
            initial_equity=config.initial_equity,
            final_equity=config.initial_equity,
            total_return=0.0,
            total_return_pct=0.0,
            max_drawdown_pct=0.0,
            trades=0,
            win_rate=0.0,
            avg_net_return=0.0,
            prediction_coverage=0.0,
            horizon=config.horizon,
            fee_rate=config.fee_rate,
            slippage_rate=config.slippage_rate,
            max_leverage=config.max_leverage,
            real_capital_used=False,
            exchange_connected=False,
            orders_generated=False,
            next_required_gate="BACKTEST_INPUT_REPAIR_REQUIRED",
            issues=issues,
            metrics={},
        )

    valid_rows = filter_valid_rows(rows, config.horizon)
    if not valid_rows:
        return run_backtest([], ReadinessGate("BLOCKED", True, False, False, "BLOCKED", "NO_DECISION_BLOCKED", "DATA_GATE_REPAIR_REQUIRED"), config)

    equity = config.initial_equity
    equity_curve = [equity]
    trades: List[BacktestTrade] = []
    covered = 0
    wins = 0

    for r in valid_rows:
        position = prediction_to_position(r.predicted_label, config.allow_short)
        if r.predicted_label in VALID_PREDICTIONS:
            covered += 1
        gross_return = position * float(r.future_return)
        cost = compute_trade_cost(position, config.fee_rate, config.slippage_rate)
        net_return = gross_return - cost
        equity = equity * (1.0 + net_return)
        equity = round(equity, 8)
        equity_curve.append(equity)
        if net_return > 0:
            wins += 1
        trades.append(
            BacktestTrade(
                timestamp_index=r.timestamp_index,
                horizon=r.horizon,
                predicted_label=r.predicted_label,
                actual_label=r.target_label,
                position=position,
                gross_return=round(gross_return, 8),
                cost=round(cost, 8),
                net_return=round(net_return, 8),
                equity_after=equity,
            )
        )

    total_return = round(equity - config.initial_equity, 8)
    total_return_pct = round(total_return / config.initial_equity, 8)
    avg_net_return = round(sum(t.net_return for t in trades) / len(trades), 8)
    prediction_coverage = round(covered / len(valid_rows), 8)
    win_rate = round(wins / len(trades), 8)
    max_drawdown_pct = calculate_max_drawdown_pct(equity_curve)
    edge_status = "RESEARCH_BACKTEST_ONLY"

    return BacktestReport(
        schema="qrds.backtest_report.v1",
        backtest_status="PASS",
        model_blocked=False,
        research_allowed=True,
        operational_decision_allowed=False,
        decision_stage="BACKTEST_RESEARCH_ONLY",
        action="NO_TRADE_BACKTEST_RESEARCH_ONLY",
        edge_status=edge_status,
        initial_equity=round(config.initial_equity, 8),
        final_equity=round(equity, 8),
        total_return=total_return,
        total_return_pct=total_return_pct,
        max_drawdown_pct=max_drawdown_pct,
        trades=len(trades),
        win_rate=win_rate,
        avg_net_return=avg_net_return,
        prediction_coverage=prediction_coverage,
        horizon=config.horizon,
        fee_rate=config.fee_rate,
        slippage_rate=config.slippage_rate,
        max_leverage=config.max_leverage,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        next_required_gate="RISK_ENGINE_REQUIRED",
        issues=[],
        metrics={
            "wins": float(wins),
            "losses_or_flat": float(len(trades) - wins),
            "equity_points": float(len(equity_curve)),
        },
    )


def export_backtest_report(report: BacktestReport, out_dir: str | Path) -> dict:
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    json_path = out_path / "backtest_report.json"
    txt_path = out_path / "backtest_report.txt"
    payload = report.to_dict()
    json_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    txt_lines = [
        "QRDS Sprint 3A - Backtest Report",
        f"Schema: {report.schema}",
        f"Backtest status: {report.backtest_status}",
        f"Research allowed: {report.research_allowed}",
        f"Operational decision allowed: {report.operational_decision_allowed}",
        f"Decision stage: {report.decision_stage}",
        f"Action: {report.action}",
        f"Initial equity: {report.initial_equity:.2f}",
        f"Final equity: {report.final_equity:.2f}",
        f"Total return pct: {report.total_return_pct:.6f}",
        f"Max drawdown pct: {report.max_drawdown_pct:.6f}",
        f"Trades: {report.trades}",
        f"Win rate: {report.win_rate:.4f}",
        f"Prediction coverage: {report.prediction_coverage:.4f}",
        f"Real capital used: {report.real_capital_used}",
        f"Exchange connected: {report.exchange_connected}",
        f"Orders generated: {report.orders_generated}",
        f"Next required gate: {report.next_required_gate}",
        f"Issues: {report.issues if report.issues else 'none'}",
    ]
    txt_path.write_text("\n".join(txt_lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
