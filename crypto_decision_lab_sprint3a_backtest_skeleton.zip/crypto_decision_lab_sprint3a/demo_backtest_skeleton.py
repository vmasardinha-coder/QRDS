from crypto_decision_lab.backtest.engine import export_backtest_report, run_backtest
from crypto_decision_lab.backtest.fixtures import (
    make_clean_readiness_gate,
    make_dirty_readiness_gate,
    make_integrated_research_rows,
)
from crypto_decision_lab.backtest.models import BacktestConfig

rows = make_integrated_research_rows()
clean_report = run_backtest(rows, make_clean_readiness_gate(), BacktestConfig())
paths = export_backtest_report(clean_report, "reports/sprint3a")

dirty_report = run_backtest(rows, make_dirty_readiness_gate(), BacktestConfig())

print("=== Sprint 3A Backtest Skeleton Offline ===")
print(f"Backtest schema: {clean_report.schema}")
print(f"Backtest status: {clean_report.backtest_status}")
print(f"Model blocked: {clean_report.model_blocked}")
print(f"Research allowed: {clean_report.research_allowed}")
print(f"Operational decision allowed: {clean_report.operational_decision_allowed}")
print(f"Decision stage: {clean_report.decision_stage}")
print(f"Action: {clean_report.action}")
print(f"Edge status: {clean_report.edge_status}")
print(f"Initial equity: {clean_report.initial_equity:.2f}")
print(f"Final equity: {clean_report.final_equity:.2f}")
print(f"Total return pct: {clean_report.total_return_pct:.6f}")
print(f"Max drawdown pct: {clean_report.max_drawdown_pct:.6f}")
print(f"Trades: {clean_report.trades}")
print(f"Win rate: {clean_report.win_rate:.4f}")
print(f"Prediction coverage: {clean_report.prediction_coverage:.4f}")
print(f"Real capital used: {clean_report.real_capital_used}")
print(f"Exchange connected: {clean_report.exchange_connected}")
print(f"Orders generated: {clean_report.orders_generated}")
print(f"Next required gate: {clean_report.next_required_gate}")
print(f"Issues: {clean_report.issues if clean_report.issues else 'none'}")
print(f"Dirty backtest status: {dirty_report.backtest_status}")
print(f"Dirty action: {dirty_report.action}")
print(f"Generated files: {paths}")
