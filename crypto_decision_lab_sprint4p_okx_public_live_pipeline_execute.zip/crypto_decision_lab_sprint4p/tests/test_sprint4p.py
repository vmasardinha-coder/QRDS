import json
from pathlib import Path

import pytest

from crypto_decision_lab.okx_public_live_pipeline import (
    APPROVAL_PHRASE,
    build_okx_candles_url,
    execute_okx_public_live_pipeline,
    fixture_okx_candles_response,
    has_forbidden_api_env,
    ohlcv_contract_valid,
    parse_okx_candles,
    timestamp_order_valid,
    write_report,
)


@pytest.mark.parametrize("phrase,expected", [(APPROVAL_PHRASE, True), (APPROVAL_PHRASE.lower(), False), ("", False)])
def test_approval_phrase_effect(phrase, expected):
    r = execute_okx_public_live_pipeline(True, phrase, use_fixture=True, env={})
    assert r.manual_approval_granted is expected


@pytest.mark.parametrize("key", ["OKX_API_KEY", "OKX_SECRET_KEY", "OKX_PASSPHRASE", "QRDS_OKX_API_KEY", "QRDS_OKX_SECRET_KEY"])
def test_forbidden_api_env_detected(key):
    assert has_forbidden_api_env({key: "x"}) is True


@pytest.mark.parametrize("part", ["https://www.okx.com/api/v5/market/candles", "instId=BTC-USDT", "bar=1H", "limit=5", "?"])
def test_build_url_contains_expected_parts(part):
    assert part in build_okx_candles_url()


def test_parse_fixture_count():
    candles = parse_okx_candles(fixture_okx_candles_response())
    assert len(candles) == 5


def test_parse_fixture_sorted():
    candles = parse_okx_candles(fixture_okx_candles_response())
    assert timestamp_order_valid(candles) is True


@pytest.mark.parametrize("idx", [0, 1, 2, 3, 4])
def test_each_fixture_candle_ohlcv_valid(idx):
    candles = parse_okx_candles(fixture_okx_candles_response())
    candle = candles[idx]
    assert candle.exchange == "okx"
    assert candle.low <= candle.open <= candle.high
    assert candle.low <= candle.close <= candle.high
    assert candle.volume >= 0


@pytest.mark.parametrize(
    "payload",
    [
        fixture_okx_candles_response(),
        {"code": "0", "msg": "", "data": fixture_okx_candles_response()["data"][:1]},
        {"code": "0", "msg": "", "data": list(reversed(fixture_okx_candles_response()["data"]))},
        {"code": "0", "msg": "", "data": fixture_okx_candles_response()["data"][:3]},
        {"code": "0", "msg": "", "data": fixture_okx_candles_response()["data"][2:]},
        {"code": "0", "msg": "", "data": [fixture_okx_candles_response()["data"][0]]},
    ],
)
def test_valid_payloads_parse(payload):
    candles = parse_okx_candles(payload)
    assert len(candles) >= 1
    assert ohlcv_contract_valid(candles) is True


@pytest.mark.parametrize(
    "field,expected",
    [
        ("pipeline_status", "PASS"),
        ("model_blocked", False),
        ("manual_approval_required", True),
        ("manual_approval_granted", True),
        ("explicit_approval_phrase_valid", True),
        ("okx_public_live_pipeline_authorized", True),
        ("live_pipeline_enabled", True),
        ("fixture_replay_used", True),
        ("network_calls_executed", False),
        ("authenticated_connection_used", False),
        ("api_key_required", False),
        ("api_key_present", False),
        ("account_connection_required", False),
        ("orders_generated", False),
        ("candles_normalized", 5),
    ],
)
def test_fixture_report_safety_flags(field, expected):
    r = execute_okx_public_live_pipeline(True, APPROVAL_PHRASE, use_fixture=True, env={})
    assert getattr(r, field) == expected


@pytest.mark.parametrize(
    "field,expected",
    [
        ("simulation_exchange", "binance"),
        ("binance_route", "SIMULATION_FIXTURE_REPLAY"),
        ("okx_route", "PUBLIC_HTTP_LIVE_FIXTURE_REPLAY"),
        ("bybit_route", "PENDING_BLOCKED_BY_403"),
        ("next_required_gate", "OKX_PUBLIC_HTTP_LIVE_PIPELINE_RESULT_REVIEW_REQUIRED"),
    ],
)
def test_route_fields(field, expected):
    r = execute_okx_public_live_pipeline(True, APPROVAL_PHRASE, use_fixture=True, env={})
    assert getattr(r, field) == expected


@pytest.mark.parametrize("key", ["OKX_API_KEY", "OKX_SECRET_KEY", "QRDS_OKX_API_KEY", "QRDS_OKX_SECRET_KEY"])
def test_block_when_api_key_env_present(key):
    r = execute_okx_public_live_pipeline(True, APPROVAL_PHRASE, use_fixture=True, env={key: "secret"})
    assert r.pipeline_status == "BLOCKED"
    assert r.api_key_present is True
    assert "api_key_present_forbidden" in r.issues


def test_export_report_files(tmp_path):
    r = execute_okx_public_live_pipeline(True, APPROVAL_PHRASE, use_fixture=True, env={})
    files = write_report(r, tmp_path)
    assert Path(files["json"]).exists()
    assert Path(files["txt"]).exists()
    payload = json.loads(Path(files["json"]).read_text())
    assert payload["schema"] == r.schema


@pytest.mark.parametrize(
    "bad_payload",
    [
        {"code": "1", "msg": "err", "data": []},
        {"code": "0", "msg": "", "data": []},
        {"code": "0", "msg": "", "data": [["1", "2"]]},
        ["not", "a", "dict"],
    ],
)
def test_bad_payloads_raise(bad_payload):
    with pytest.raises(ValueError):
        parse_okx_candles(bad_payload)
