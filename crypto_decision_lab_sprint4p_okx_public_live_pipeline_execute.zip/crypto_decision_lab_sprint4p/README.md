# QRDS Sprint 4P — OKX Public HTTP Live Pipeline Execute

Executes one public OKX HTTP market-data request after explicit approval.

Safety policy:
- no API key
- no real account
- no authenticated connection
- no WebSocket
- no orders
- no real capital
- Binance remains simulation route
- Bybit remains pending by 403

Run:

```bash
PYTHONPATH="$(pwd)/src" pytest -q tests/
QRDS_OKX_PUBLIC_HTTP_LIVE_PIPELINE_ENABLED=1 \
QRDS_OKX_PUBLIC_HTTP_LIVE_PIPELINE_APPROVAL="APROVO OKX PUBLIC HTTP LIVE PIPELINE SEM API KEY, SEM CONTA REAL, SEM ORDEM E SEM CAPITAL REAL." \
PYTHONPATH="$(pwd)/src" python demo_okx_public_live_pipeline_execute.py
```
