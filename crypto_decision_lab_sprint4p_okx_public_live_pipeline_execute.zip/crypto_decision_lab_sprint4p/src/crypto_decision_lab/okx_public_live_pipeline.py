from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import json
import os
from pathlib import Path
from typing import Any
from urllib.parse import urlencode
from urllib.request import Request, urlopen

APPROVAL_PHRASE = "APROVO OKX PUBLIC HTTP LIVE PIPELINE SEM API KEY, SEM CONTA REAL, SEM ORDEM E SEM CAPITAL REAL."
SCHEMA = "qrds.okx_public_live_pipeline_execute_report.v1"
OKX_CANDLES_URL = "https://www.okx.com/api/v5/market/candles"

FORBIDDEN_API_ENV_KEYS = {
    "OKX_API_KEY",
    "OKX_SECRET_KEY",
    "OKX_API_SECRET",
    "OKX_PASSPHRASE",
    "QRDS_OKX_API_KEY",
    "QRDS_OKX_SECRET_KEY",
    "QRDS_OKX_API_SECRET",
    "QRDS_OKX_PASSPHRASE",
}


@dataclass(frozen=True)
class NormalizedCandle:
    exchange: str
    symbol: str
    timeframe: str
    timestamp: str
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass
class OkxPublicLivePipelineReport:
    schema: str = SCHEMA
    pipeline_status: str = "BLOCKED"
    model_blocked: bool = True
    manual_approval_required: bool = True
    manual_approval_granted: bool = False
    explicit_approval_phrase_valid: bool = False
    okx_public_live_pipeline_authorized: bool = False
    live_pipeline_enabled: bool = False
    fixture_replay_used: bool = True
    network_calls_executed: bool = False
    authenticated_connection_used: bool = False
    api_key_required: bool = False
    api_key_present: bool = False
    account_connection_required: bool = False
    websocket_used: bool = False
    real_capital_used: bool = False
    exchange_connected: bool = False
    orders_generated: bool = False
    simulation_exchange: str = "binance"
    binance_route: str = "SIMULATION_FIXTURE_REPLAY"
    okx_route: str = "PUBLIC_HTTP_LIVE_NOT_EXECUTED"
    bybit_route: str = "PENDING_BLOCKED_BY_403"
    real_base_target_exchanges: list[str] = field(default_factory=lambda: ["okx", "bybit"])
    real_base_active_now: list[str] = field(default_factory=lambda: ["okx"])
    real_base_pending: list[str] = field(default_factory=lambda: ["bybit"])
    endpoint: str = OKX_CANDLES_URL
    instrument: str = "BTC-USDT"
    bar: str = "1H"
    limit: int = 5
    public_endpoint_reached: bool = False
    candles_normalized: int = 0
    timestamp_order_valid: bool = False
    ohlcv_contract_valid: bool = False
    response_shape_valid: bool = False
    safety_policy: str = "OKX_PUBLIC_HTTP_LIVE_PIPELINE_NO_AUTH_NO_ORDERS"
    next_required_gate: str = "OKX_PUBLIC_HTTP_LIVE_PIPELINE_RESULT_REVIEW_REQUIRED"
    issues: list[str] = field(default_factory=list)
    action: str = "NO_OKX_PUBLIC_LIVE_PIPELINE_BLOCKED"
    normalized_candles: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def has_forbidden_api_env(env: dict[str, str] | None = None) -> bool:
    env = env or os.environ
    return any(bool(env.get(key)) for key in FORBIDDEN_API_ENV_KEYS)


def approval_is_valid(approval_phrase: str | None) -> bool:
    return (approval_phrase or "").strip() == APPROVAL_PHRASE


def live_enabled_is_true(value: str | None) -> bool:
    return (value or "").strip() == "1"


def build_okx_candles_url(inst_id: str = "BTC-USDT", bar: str = "1H", limit: int = 5) -> str:
    params = urlencode({"instId": inst_id, "bar": bar, "limit": str(limit)})
    return f"{OKX_CANDLES_URL}?{params}"


def fixture_okx_candles_response() -> dict[str, Any]:
    # OKX public candle shape: [ts, open, high, low, close, vol, volCcy, volCcyQuote, confirm]
    return {
        "code": "0",
        "msg": "",
        "data": [
            ["1704081600000", "50350", "50500", "50300", "50450", "104", "104", "5246800", "1"],
            ["1704078000000", "50250", "50400", "50200", "50350", "103", "103", "5186050", "1"],
            ["1704074400000", "50150", "50300", "50100", "50250", "102", "102", "5125500", "1"],
            ["1704070800000", "50050", "50200", "50000", "50150", "101", "101", "5065150", "1"],
            ["1704067200000", "50000", "50100", "49900", "50050", "100", "100", "5005000", "1"],
        ],
    }


def fetch_okx_public_candles(inst_id: str = "BTC-USDT", bar: str = "1H", limit: int = 5, timeout: int = 10) -> dict[str, Any]:
    url = build_okx_candles_url(inst_id, bar, limit)
    req = Request(
        url,
        headers={
            "User-Agent": "QRDS-QOS-PublicLiveData/1.0",
            "Accept": "application/json",
        },
        method="GET",
    )
    with urlopen(req, timeout=timeout) as response:
        body = response.read().decode("utf-8")
    return json.loads(body)


def _timestamp_ms_to_iso(ms: str | int) -> str:
    dt = datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")


def parse_okx_candles(payload: dict[str, Any], symbol: str = "BTC-USDT", timeframe: str = "1H") -> list[NormalizedCandle]:
    if not isinstance(payload, dict):
        raise ValueError("okx_response_not_dict")
    if payload.get("code") != "0":
        raise ValueError(f"okx_response_code_not_zero:{payload.get('code')}")
    rows = payload.get("data")
    if not isinstance(rows, list) or not rows:
        raise ValueError("okx_response_data_missing_or_empty")

    candles: list[NormalizedCandle] = []
    for row in rows:
        if not isinstance(row, list) or len(row) < 6:
            raise ValueError("okx_candle_row_shape_invalid")
        ts, o, h, l, c, v = row[:6]
        candle = NormalizedCandle(
            exchange="okx",
            symbol=symbol,
            timeframe=timeframe,
            timestamp=_timestamp_ms_to_iso(ts),
            open=float(o),
            high=float(h),
            low=float(l),
            close=float(c),
            volume=float(v),
        )
        candles.append(candle)
    candles.sort(key=lambda x: x.timestamp)
    return candles


def timestamp_order_valid(candles: list[NormalizedCandle]) -> bool:
    return all(candles[i].timestamp > candles[i - 1].timestamp for i in range(1, len(candles)))


def ohlcv_contract_valid(candles: list[NormalizedCandle]) -> bool:
    if not candles:
        return False
    for c in candles:
        if not (c.low <= c.open <= c.high and c.low <= c.close <= c.high):
            return False
        if not all(value > 0 for value in [c.open, c.high, c.low, c.close]):
            return False
        if c.volume < 0:
            return False
    return True


def execute_okx_public_live_pipeline(
    live_enabled: bool,
    approval_phrase: str | None,
    use_fixture: bool = False,
    inst_id: str = "BTC-USDT",
    bar: str = "1H",
    limit: int = 5,
    env: dict[str, str] | None = None,
) -> OkxPublicLivePipelineReport:
    report = OkxPublicLivePipelineReport(instrument=inst_id, bar=bar, limit=limit)
    report.live_pipeline_enabled = bool(live_enabled)
    report.manual_approval_granted = approval_is_valid(approval_phrase)
    report.explicit_approval_phrase_valid = report.manual_approval_granted
    report.api_key_present = has_forbidden_api_env(env)

    if report.api_key_present:
        report.pipeline_status = "BLOCKED"
        report.model_blocked = True
        report.okx_route = "BLOCKED_API_KEY_PRESENT"
        report.issues.append("api_key_present_forbidden")
        report.action = "NO_OKX_PUBLIC_LIVE_PIPELINE_BLOCKED"
        return report

    if not (report.live_pipeline_enabled and report.manual_approval_granted):
        report.pipeline_status = "PASS"
        report.model_blocked = False
        report.fixture_replay_used = True
        report.network_calls_executed = False
        report.okx_route = "PUBLIC_HTTP_LIVE_AWAITING_EXPLICIT_APPROVAL"
        report.action = "NO_OKX_PUBLIC_LIVE_PIPELINE_AWAITING_EXPLICIT_APPROVAL"
        payload = fixture_okx_candles_response()
        candles = parse_okx_candles(payload, inst_id, bar)
        report.candles_normalized = len(candles)
        report.timestamp_order_valid = timestamp_order_valid(candles)
        report.ohlcv_contract_valid = ohlcv_contract_valid(candles)
        report.response_shape_valid = True
        report.normalized_candles = [asdict(c) for c in candles]
        return report

    report.okx_public_live_pipeline_authorized = True
    report.fixture_replay_used = bool(use_fixture)

    try:
        if use_fixture:
            payload = fixture_okx_candles_response()
            report.network_calls_executed = False
        else:
            payload = fetch_okx_public_candles(inst_id, bar, limit)
            report.network_calls_executed = True
            report.public_endpoint_reached = True
        candles = parse_okx_candles(payload, inst_id, bar)
        report.candles_normalized = len(candles)
        report.timestamp_order_valid = timestamp_order_valid(candles)
        report.ohlcv_contract_valid = ohlcv_contract_valid(candles)
        report.response_shape_valid = True
        report.normalized_candles = [asdict(c) for c in candles]
        if report.candles_normalized >= 1 and report.timestamp_order_valid and report.ohlcv_contract_valid:
            report.pipeline_status = "PASS"
            report.model_blocked = False
            report.okx_route = "PUBLIC_HTTP_LIVE_EXECUTED_NO_AUTH" if not use_fixture else "PUBLIC_HTTP_LIVE_FIXTURE_REPLAY"
            report.action = "OKX_PUBLIC_LIVE_PIPELINE_REVIEW_REQUIRED"
        else:
            report.pipeline_status = "BLOCKED"
            report.model_blocked = True
            report.issues.append("okx_public_live_pipeline_contract_invalid")
            report.action = "NO_OKX_PUBLIC_LIVE_PIPELINE_BLOCKED"
    except Exception as exc:  # noqa: BLE001 - deliberately captured for safety report
        report.pipeline_status = "BLOCKED"
        report.model_blocked = True
        report.network_calls_executed = True if not use_fixture else False
        report.fixture_replay_used = bool(use_fixture)
        report.okx_route = "PUBLIC_HTTP_LIVE_FAILED"
        report.issues.append(f"okx_public_live_http_failed:{type(exc).__name__}:{exc}")
        report.action = "NO_OKX_PUBLIC_LIVE_PIPELINE_BLOCKED"
    return report


def write_report(report: OkxPublicLivePipelineReport, out_dir: str | Path = "reports/sprint4p") -> dict[str, str]:
    path = Path(out_dir)
    path.mkdir(parents=True, exist_ok=True)
    json_path = path / "okx_public_live_pipeline_execute_report.json"
    txt_path = path / "okx_public_live_pipeline_execute_report.txt"
    json_path.write_text(json.dumps(report.to_dict(), indent=2, sort_keys=True), encoding="utf-8")
    lines = [f"{k}: {v}" for k, v in report.to_dict().items() if k != "normalized_candles"]
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
