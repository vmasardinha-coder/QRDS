import os
from crypto_decision_lab.okx_public_live_pipeline import execute_okx_public_live_pipeline, write_report

live_enabled = os.environ.get("QRDS_OKX_PUBLIC_HTTP_LIVE_PIPELINE_ENABLED") == "1"
approval = os.environ.get("QRDS_OKX_PUBLIC_HTTP_LIVE_PIPELINE_APPROVAL")

report = execute_okx_public_live_pipeline(
    live_enabled=live_enabled,
    approval_phrase=approval,
    use_fixture=False,
)
files = write_report(report)

issues = report.issues if report.issues else "none"
print("=== Sprint 4P OKX Public HTTP Live Pipeline Execute ===")
print(f"Pipeline schema: {report.schema}")
print(f"Pipeline status: {report.pipeline_status}")
print(f"Model blocked: {report.model_blocked}")
print(f"Manual approval required: {report.manual_approval_required}")
print(f"Manual approval granted: {report.manual_approval_granted}")
print(f"Explicit approval phrase valid: {report.explicit_approval_phrase_valid}")
print(f"OKX public live pipeline authorized: {report.okx_public_live_pipeline_authorized}")
print(f"Live pipeline enabled: {report.live_pipeline_enabled}")
print(f"Fixture replay used: {report.fixture_replay_used}")
print(f"Network calls executed: {report.network_calls_executed}")
print(f"Authenticated connection used: {report.authenticated_connection_used}")
print(f"API key required: {report.api_key_required}")
print(f"API key present: {report.api_key_present}")
print(f"Account connection required: {report.account_connection_required}")
print(f"WebSocket used: {report.websocket_used}")
print(f"Real capital used: {report.real_capital_used}")
print(f"Exchange connected: {report.exchange_connected}")
print(f"Orders generated: {report.orders_generated}")
print(f"Simulation exchange: {report.simulation_exchange}")
print(f"Binance route: {report.binance_route}")
print(f"OKX route: {report.okx_route}")
print(f"Bybit route: {report.bybit_route}")
print(f"Real base target exchanges: {report.real_base_target_exchanges}")
print(f"Real base active now: {report.real_base_active_now}")
print(f"Real base pending: {report.real_base_pending}")
print(f"Endpoint: {report.endpoint}")
print(f"Instrument: {report.instrument}")
print(f"Bar: {report.bar}")
print(f"Public endpoint reached: {report.public_endpoint_reached}")
print(f"Candles normalized: {report.candles_normalized}")
print(f"Timestamp order valid: {report.timestamp_order_valid}")
print(f"OHLCV contract valid: {report.ohlcv_contract_valid}")
print(f"Response shape valid: {report.response_shape_valid}")
print(f"Safety policy: {report.safety_policy}")
print(f"Next required gate: {report.next_required_gate}")
print(f"Issues: {issues}")
print(f"Action: {report.action}")
print(f"Generated files: {files}")
