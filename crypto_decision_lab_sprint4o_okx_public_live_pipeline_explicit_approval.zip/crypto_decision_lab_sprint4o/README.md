# Sprint 4O - OKX Public HTTP Live Pipeline Explicit Approval Gate

Safety gate for explicit approval before any OKX public HTTP live pipeline execution.

Default behavior: fixture/replay only, no network, no API key, no account, no orders, no capital.
