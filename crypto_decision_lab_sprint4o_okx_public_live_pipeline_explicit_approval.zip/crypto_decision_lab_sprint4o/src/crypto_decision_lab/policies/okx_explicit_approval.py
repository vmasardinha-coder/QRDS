from dataclasses import dataclass, asdict
from typing import List, Dict
import json
from pathlib import Path

EXACT_APPROVAL_PHRASE = "APROVO OKX PUBLIC HTTP LIVE PIPELINE SEM API KEY, SEM CONTA REAL, SEM ORDEM E SEM CAPITAL REAL."

@dataclass(frozen=True)
class OKXExplicitApprovalReport:
    schema: str
    approval_status: str
    model_blocked: bool
    manual_approval_required: bool
    manual_approval_granted: bool
    explicit_approval_phrase_valid: bool
    okx_public_live_pipeline_authorized: bool
    live_pipeline_enabled: bool
    fixture_replay_used: bool
    network_calls_executed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    simulation_exchange: str
    binance_route: str
    okx_route: str
    bybit_route: str
    real_base_target_exchanges: List[str]
    real_base_active_now: List[str]
    real_base_pending: List[str]
    safety_policy: str
    next_required_gate: str
    issues: List[str]
    action: str


def evaluate_okx_explicit_approval(approval_phrase: str = "", live_opt_in: bool = False, *,
                                   api_key_present: bool = False,
                                   account_connection_required: bool = False,
                                   network_calls_executed: bool = False,
                                   orders_generated: bool = False,
                                   real_capital_used: bool = False,
                                   websocket_used: bool = False) -> OKXExplicitApprovalReport:
    phrase_valid = (approval_phrase or "").strip() == EXACT_APPROVAL_PHRASE
    manual_required = True
    manual_granted = phrase_valid
    security_exposure = any([
        api_key_present,
        account_connection_required,
        orders_generated,
        real_capital_used,
        websocket_used,
    ])
    # This gate authorizes only the NEXT step when approval and opt-in are present.
    # It still does not execute network calls by default.
    authorized = bool(manual_granted and live_opt_in and not security_exposure)
    issues: List[str] = []
    if security_exposure:
        issues.append("security_exposure_detected")
    if network_calls_executed and not authorized:
        issues.append("network_called_without_okx_explicit_authorization")
    if not phrase_valid:
        action = "NO_OKX_PUBLIC_LIVE_PIPELINE_AWAITING_EXPLICIT_APPROVAL"
        next_gate = "OKX_PUBLIC_HTTP_LIVE_PIPELINE_EXPLICIT_APPROVAL_REQUIRED"
        status = "PASS"
        model_blocked = False
    elif phrase_valid and not live_opt_in:
        action = "NO_OKX_PUBLIC_LIVE_PIPELINE_AWAITING_LIVE_OPT_IN"
        next_gate = "OKX_PUBLIC_HTTP_LIVE_PIPELINE_OPT_IN_REQUIRED"
        status = "PASS"
        model_blocked = False
    elif authorized:
        action = "OKX_PUBLIC_LIVE_PIPELINE_AUTHORIZED_NOT_EXECUTED"
        next_gate = "OKX_PUBLIC_HTTP_LIVE_PIPELINE_EXECUTION_REQUIRED"
        status = "PASS"
        model_blocked = False
    else:
        action = "NO_OKX_PUBLIC_LIVE_PIPELINE_BLOCKED"
        next_gate = "SECURITY_REVIEW_REQUIRED"
        status = "BLOCKED"
        model_blocked = True

    return OKXExplicitApprovalReport(
        schema="qrds.okx_public_live_pipeline_explicit_approval_report.v1",
        approval_status=status,
        model_blocked=model_blocked,
        manual_approval_required=manual_required,
        manual_approval_granted=manual_granted,
        explicit_approval_phrase_valid=phrase_valid,
        okx_public_live_pipeline_authorized=authorized,
        live_pipeline_enabled=False,
        fixture_replay_used=True,
        network_calls_executed=network_calls_executed,
        authenticated_connection_used=False,
        api_key_required=False,
        api_key_present=api_key_present,
        account_connection_required=account_connection_required,
        websocket_used=websocket_used,
        real_capital_used=real_capital_used,
        exchange_connected=False,
        orders_generated=orders_generated,
        simulation_exchange="binance",
        binance_route="SIMULATION_FIXTURE_REPLAY",
        okx_route="PUBLIC_HTTP_LIVE_EXPLICIT_APPROVAL_GATE",
        bybit_route="PENDING_BLOCKED_BY_403",
        real_base_target_exchanges=["okx", "bybit"],
        real_base_active_now=["okx"],
        real_base_pending=["bybit"],
        safety_policy="OKX_PUBLIC_HTTP_LIVE_PIPELINE_EXPLICIT_APPROVAL_NO_AUTH_NO_ORDERS",
        next_required_gate=next_gate,
        issues=issues,
        action=action,
    )


def to_dict(report: OKXExplicitApprovalReport) -> Dict:
    return asdict(report)


def write_report(report: OKXExplicitApprovalReport, out_dir: str = "reports/sprint4o") -> Dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = to_dict(report)
    json_path = out/'okx_public_live_pipeline_explicit_approval_report.json'
    txt_path = out/'okx_public_live_pipeline_explicit_approval_report.txt'
    json_path.write_text(json.dumps(data, indent=2), encoding='utf-8')
    lines = [f"{k}: {v}" for k, v in data.items()]
    txt_path.write_text("\n".join(lines) + "\n", encoding='utf-8')
    return {"json": str(json_path), "txt": str(txt_path)}
