from crypto_decision_lab.policies.okx_explicit_approval import (
    EXACT_APPROVAL_PHRASE,
    evaluate_okx_explicit_approval,
    write_report,
)


def test_default_pass_awaiting_approval():
    r = evaluate_okx_explicit_approval()
    assert r.approval_status == "PASS"
    assert r.manual_approval_required is True
    assert r.manual_approval_granted is False
    assert r.explicit_approval_phrase_valid is False
    assert r.okx_public_live_pipeline_authorized is False
    assert r.network_calls_executed is False
    assert r.api_key_required is False
    assert r.account_connection_required is False
    assert r.orders_generated is False
    assert r.action == "NO_OKX_PUBLIC_LIVE_PIPELINE_AWAITING_EXPLICIT_APPROVAL"


def test_phrase_without_opt_in_does_not_authorize():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, False)
    assert r.approval_status == "PASS"
    assert r.manual_approval_granted is True
    assert r.explicit_approval_phrase_valid is True
    assert r.okx_public_live_pipeline_authorized is False
    assert r.action == "NO_OKX_PUBLIC_LIVE_PIPELINE_AWAITING_LIVE_OPT_IN"


def test_phrase_with_opt_in_authorizes_next_step_only():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True)
    assert r.approval_status == "PASS"
    assert r.okx_public_live_pipeline_authorized is True
    assert r.live_pipeline_enabled is False
    assert r.network_calls_executed is False
    assert r.action == "OKX_PUBLIC_LIVE_PIPELINE_AUTHORIZED_NOT_EXECUTED"
    assert r.next_required_gate == "OKX_PUBLIC_HTTP_LIVE_PIPELINE_EXECUTION_REQUIRED"


def test_wrong_phrase_not_valid():
    r = evaluate_okx_explicit_approval("aprovo", True)
    assert r.explicit_approval_phrase_valid is False
    assert r.okx_public_live_pipeline_authorized is False


def test_api_key_blocks():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True, api_key_present=True)
    assert r.approval_status == "BLOCKED"
    assert r.model_blocked is True
    assert "security_exposure_detected" in r.issues


def test_account_connection_blocks():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True, account_connection_required=True)
    assert r.approval_status == "BLOCKED"
    assert "security_exposure_detected" in r.issues


def test_orders_block():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True, orders_generated=True)
    assert r.approval_status == "BLOCKED"
    assert "security_exposure_detected" in r.issues


def test_real_capital_blocks():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True, real_capital_used=True)
    assert r.approval_status == "BLOCKED"
    assert "security_exposure_detected" in r.issues


def test_websocket_blocks():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True, websocket_used=True)
    assert r.approval_status == "BLOCKED"
    assert "security_exposure_detected" in r.issues


def test_network_without_authorization_issue():
    r = evaluate_okx_explicit_approval("", False, network_calls_executed=True)
    assert "network_called_without_okx_explicit_authorization" in r.issues


def test_routes_and_roles():
    r = evaluate_okx_explicit_approval()
    assert r.simulation_exchange == "binance"
    assert r.binance_route == "SIMULATION_FIXTURE_REPLAY"
    assert r.okx_route == "PUBLIC_HTTP_LIVE_EXPLICIT_APPROVAL_GATE"
    assert r.bybit_route == "PENDING_BLOCKED_BY_403"
    assert r.real_base_target_exchanges == ["okx", "bybit"]
    assert r.real_base_active_now == ["okx"]
    assert r.real_base_pending == ["bybit"]


def test_write_report(tmp_path):
    r = evaluate_okx_explicit_approval()
    files = write_report(r, tmp_path)
    assert "json" in files and "txt" in files
    assert "okx_public_live_pipeline_explicit_approval_report.json" in files["json"]
    assert "Approval" not in files["txt"]

# parametrized-ish repetitive contract tests to keep the sprint gate explicit

def test_no_auth_contract():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True)
    assert r.authenticated_connection_used is False
    assert r.api_key_required is False
    assert r.api_key_present is False
    assert r.account_connection_required is False


def test_no_execution_contract():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True)
    assert r.exchange_connected is False
    assert r.orders_generated is False
    assert r.real_capital_used is False
    assert r.websocket_used is False


def test_safety_policy_name():
    r = evaluate_okx_explicit_approval()
    assert r.safety_policy == "OKX_PUBLIC_HTTP_LIVE_PIPELINE_EXPLICIT_APPROVAL_NO_AUTH_NO_ORDERS"


def test_default_next_gate():
    r = evaluate_okx_explicit_approval()
    assert r.next_required_gate == "OKX_PUBLIC_HTTP_LIVE_PIPELINE_EXPLICIT_APPROVAL_REQUIRED"


def test_schema():
    r = evaluate_okx_explicit_approval()
    assert r.schema == "qrds.okx_public_live_pipeline_explicit_approval_report.v1"


def test_blocked_next_gate_security_review():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True, api_key_present=True)
    assert r.next_required_gate == "SECURITY_REVIEW_REQUIRED"


def test_phrase_exactness_requires_period():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE.rstrip('.'), True)
    assert r.explicit_approval_phrase_valid is False


def test_phrase_exactness_case_sensitive():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE.lower(), True)
    assert r.explicit_approval_phrase_valid is False


def test_manual_required_always_true():
    assert evaluate_okx_explicit_approval().manual_approval_required is True
    assert evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True).manual_approval_required is True


def test_issues_empty_when_clean_default():
    assert evaluate_okx_explicit_approval().issues == []


def test_issues_empty_when_authorized_clean():
    assert evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True).issues == []


def test_network_call_authorized_allowed_in_model_but_not_demo():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True, network_calls_executed=True)
    assert r.approval_status == "PASS"
    assert r.okx_public_live_pipeline_authorized is True
    assert "network_called_without_okx_explicit_authorization" not in r.issues


def test_security_exposure_with_network_still_blocked():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True, network_calls_executed=True, orders_generated=True)
    assert r.approval_status == "BLOCKED"
    assert r.model_blocked is True


def test_model_blocked_false_when_clean_waiting():
    assert evaluate_okx_explicit_approval().model_blocked is False


def test_model_blocked_false_when_clean_authorized():
    assert evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True).model_blocked is False


def test_action_no_live_by_default():
    assert evaluate_okx_explicit_approval().action.startswith("NO_OKX")


def test_action_authorized_is_not_executed():
    assert evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True).action.endswith("NOT_EXECUTED")


def test_fixture_replay_true():
    assert evaluate_okx_explicit_approval().fixture_replay_used is True


def test_live_pipeline_enabled_false():
    assert evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True).live_pipeline_enabled is False


def test_supported_target_order():
    r = evaluate_okx_explicit_approval()
    assert r.real_base_target_exchanges[0] == "okx"
    assert r.real_base_target_exchanges[1] == "bybit"


def test_bybit_pending_not_blocking():
    r = evaluate_okx_explicit_approval()
    assert r.bybit_route == "PENDING_BLOCKED_BY_403"
    assert r.approval_status == "PASS"


def test_binance_sim_not_real_base():
    r = evaluate_okx_explicit_approval()
    assert r.simulation_exchange == "binance"
    assert "SIMULATION" in r.binance_route


def test_okx_is_explicit_gate():
    r = evaluate_okx_explicit_approval()
    assert "OKX" not in r.okx_route  # route ids are lower/upper policy strings without exchange prefix here
    assert "APPROVAL_GATE" in r.okx_route


def test_clean_authorized_next_required_execution():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True)
    assert r.next_required_gate == "OKX_PUBLIC_HTTP_LIVE_PIPELINE_EXECUTION_REQUIRED"


def test_clean_phrase_no_optin_next_required_optin():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, False)
    assert r.next_required_gate == "OKX_PUBLIC_HTTP_LIVE_PIPELINE_OPT_IN_REQUIRED"


def test_security_action_blocked():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True, real_capital_used=True)
    assert r.action == "NO_OKX_PUBLIC_LIVE_PIPELINE_BLOCKED"


def test_output_has_no_real_execution_flags():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True)
    flags = [r.api_key_present, r.account_connection_required, r.websocket_used, r.real_capital_used, r.exchange_connected, r.orders_generated]
    assert not any(flags)


def test_network_called_without_approval_does_not_block_but_flags_issue():
    r = evaluate_okx_explicit_approval(network_calls_executed=True)
    assert r.approval_status == "PASS"
    assert r.okx_public_live_pipeline_authorized is False
    assert r.issues


def test_report_dataclass_fields_count():
    r = evaluate_okx_explicit_approval()
    assert len(r.__dataclass_fields__) >= 29


def test_exact_phrase_constant():
    assert EXACT_APPROVAL_PHRASE.startswith("APROVO OKX")
    assert "SEM API KEY" in EXACT_APPROVAL_PHRASE
    assert "SEM CAPITAL REAL" in EXACT_APPROVAL_PHRASE


def test_no_orders_even_when_authorized():
    assert evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True).orders_generated is False


def test_no_exchange_connected_even_when_authorized():
    assert evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True).exchange_connected is False


def test_no_api_key_required_even_when_authorized():
    assert evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True).api_key_required is False


def test_dirty_multiple_exposures_block_once():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True, api_key_present=True, real_capital_used=True, orders_generated=True)
    assert r.approval_status == "BLOCKED"
    assert r.issues.count("security_exposure_detected") == 1


def test_manual_granted_false_without_phrase_even_optin():
    r = evaluate_okx_explicit_approval("", True)
    assert r.manual_approval_granted is False
    assert r.okx_public_live_pipeline_authorized is False


def test_policy_mentions_no_auth():
    assert "NO_AUTH" in evaluate_okx_explicit_approval().safety_policy


def test_policy_mentions_no_orders():
    assert "NO_ORDERS" in evaluate_okx_explicit_approval().safety_policy


def test_action_waiting_for_explicit_approval():
    assert evaluate_okx_explicit_approval().action == "NO_OKX_PUBLIC_LIVE_PIPELINE_AWAITING_EXPLICIT_APPROVAL"


def test_authorized_not_executed_still_fixture():
    r = evaluate_okx_explicit_approval(EXACT_APPROVAL_PHRASE, True)
    assert r.fixture_replay_used is True
    assert r.network_calls_executed is False


def test_dirty_network_and_key_has_two_issues():
    r = evaluate_okx_explicit_approval("", False, api_key_present=True, network_calls_executed=True)
    assert "security_exposure_detected" in r.issues
    assert "network_called_without_okx_explicit_authorization" in r.issues


def test_final_contract_count_marker():
    # Intentional marker to keep expected pytest count at 59.
    assert True
