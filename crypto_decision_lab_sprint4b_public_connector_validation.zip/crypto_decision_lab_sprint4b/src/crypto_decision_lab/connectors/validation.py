from dataclasses import asdict, dataclass
from pathlib import Path
import json
import math

from crypto_decision_lab.connectors.public_market_data import (
    SUPPORTED_EXCHANGES,
    build_normalized_fixture_map,
    generate_public_connector_report,
)

@dataclass(frozen=True)
class PublicConnectorValidationReport:
    schema: str
    connector_schema: str
    connector_status: str
    validation_status: str
    model_blocked: bool
    public_market_data_allowed: bool
    adapter_contract_valid: bool
    timestamp_order_valid: bool
    ohlcv_contract_valid: bool
    exchange_coverage_valid: bool
    authenticated_connection_used: bool
    api_key_required: bool
    account_connection_required: bool
    network_calls_executed: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    supported_exchanges: list
    normalized_candles_per_exchange: dict
    next_required_gate: str
    action: str
    issues: list


def _is_finite_number(value) -> bool:
    return isinstance(value, (int, float)) and math.isfinite(value)


def validate_normalized_candle_contract(candle) -> list:
    issues = []
    if candle.exchange not in SUPPORTED_EXCHANGES:
        issues.append("unsupported_exchange")
    if candle.symbol != "BTCUSDT":
        issues.append("unexpected_symbol")
    if candle.timeframe != "1h":
        issues.append("unexpected_timeframe")
    for field in ["open", "high", "low", "close", "volume"]:
        if not _is_finite_number(getattr(candle, field)):
            issues.append(f"non_finite_{field}")
    if not (candle.low <= candle.open <= candle.high and candle.low <= candle.close <= candle.high):
        issues.append("invalid_ohlc")
    if candle.open <= 0 or candle.high <= 0 or candle.low <= 0 or candle.close <= 0:
        issues.append("invalid_price")
    if candle.volume < 0:
        issues.append("invalid_volume")
    return issues


def validate_timestamp_order(candles) -> bool:
    return all(candles[i].timestamp > candles[i - 1].timestamp for i in range(1, len(candles)))


def generate_public_connector_validation_report(fixtures=None, force_dirty: bool = False) -> PublicConnectorValidationReport:
    connector = generate_public_connector_report(fixtures=fixtures, force_dirty=force_dirty)
    issues = list(connector.issues)

    if connector.connector_status != "PASS":
        issues.append(f"connector_status:{connector.connector_status}")
    if connector.model_blocked:
        issues.append("connector_model_blocked")
    if connector.authenticated_connection_used:
        issues.append("authenticated_connection_used")
    if connector.api_key_required:
        issues.append("api_key_required")
    if connector.account_connection_required:
        issues.append("account_connection_required")
    if connector.network_calls_executed:
        issues.append("network_calls_executed")
    if connector.real_capital_used:
        issues.append("real_capital_used")
    if connector.exchange_connected:
        issues.append("exchange_connected")
    if connector.orders_generated:
        issues.append("orders_generated")

    normalized = {} if force_dirty else build_normalized_fixture_map(fixtures)
    exchange_coverage_valid = set(normalized.keys()) == set(SUPPORTED_EXCHANGES)
    if not exchange_coverage_valid:
        issues.append("exchange_coverage_invalid")

    timestamp_order_valid = True
    ohlcv_contract_valid = True
    for exchange, candles in normalized.items():
        if len(candles) < 5:
            issues.append(f"insufficient_candles:{exchange}")
        if not validate_timestamp_order(candles):
            timestamp_order_valid = False
            issues.append(f"timestamp_order_invalid:{exchange}")
        for candle in candles:
            candle_issues = validate_normalized_candle_contract(candle)
            if candle_issues:
                ohlcv_contract_valid = False
                issues.extend([f"{issue}:{exchange}" for issue in candle_issues])

    adapter_contract_valid = exchange_coverage_valid and timestamp_order_valid and ohlcv_contract_valid
    validation_status = "PASS" if connector.connector_status == "PASS" and adapter_contract_valid and not issues else "BLOCKED"
    return PublicConnectorValidationReport(
        schema="qrds.public_market_data_connector_validation_report.v1",
        connector_schema=connector.schema,
        connector_status=connector.connector_status,
        validation_status=validation_status,
        model_blocked=validation_status != "PASS",
        public_market_data_allowed=validation_status == "PASS",
        adapter_contract_valid=adapter_contract_valid,
        timestamp_order_valid=timestamp_order_valid,
        ohlcv_contract_valid=ohlcv_contract_valid,
        exchange_coverage_valid=exchange_coverage_valid,
        authenticated_connection_used=connector.authenticated_connection_used,
        api_key_required=connector.api_key_required,
        account_connection_required=connector.account_connection_required,
        network_calls_executed=connector.network_calls_executed,
        real_capital_used=connector.real_capital_used,
        exchange_connected=connector.exchange_connected,
        orders_generated=connector.orders_generated,
        supported_exchanges=SUPPORTED_EXCHANGES,
        normalized_candles_per_exchange=connector.normalized_candles_per_exchange,
        next_required_gate="PUBLIC_HTTP_MARKET_DATA_CONNECTOR_REQUIRED" if validation_status == "PASS" else "NO_PUBLIC_CONNECTOR_VALIDATION_BLOCKED",
        action="NO_AUTH_PUBLIC_CONNECTOR_VALIDATED" if validation_status == "PASS" else "NO_PUBLIC_CONNECTOR_VALIDATION_BLOCKED",
        issues=[] if validation_status == "PASS" else sorted(set(issues)),
    )


def export_report(report: PublicConnectorValidationReport, out_dir: str | Path = "reports/sprint4b") -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = asdict(report)
    json_path = out / "public_market_data_connector_validation_report.json"
    txt_path = out / "public_market_data_connector_validation_report.txt"
    json_path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    txt_path.write_text(report_to_text(report), encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}


def report_to_text(report: PublicConnectorValidationReport) -> str:
    lines = [
        "Public Market Data Connector Validation Report",
        f"Schema: {report.schema}",
        f"Connector status: {report.connector_status}",
        f"Validation status: {report.validation_status}",
        f"Model blocked: {report.model_blocked}",
        f"Public market data allowed: {report.public_market_data_allowed}",
        f"Adapter contract valid: {report.adapter_contract_valid}",
        f"Timestamp order valid: {report.timestamp_order_valid}",
        f"OHLCV contract valid: {report.ohlcv_contract_valid}",
        f"Supported exchanges: {report.supported_exchanges}",
        f"Normalized candles per exchange: {report.normalized_candles_per_exchange}",
        f"Next required gate: {report.next_required_gate}",
        f"Issues: {report.issues if report.issues else 'none'}",
    ]
    return "\n".join(lines) + "\n"
