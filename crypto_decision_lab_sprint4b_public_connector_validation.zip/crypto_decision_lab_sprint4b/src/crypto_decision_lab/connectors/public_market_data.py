from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List

from crypto_decision_lab.domain.models import MarketCandle

SUPPORTED_EXCHANGES = ["binance", "bybit", "okx"]

@dataclass(frozen=True)
class PublicConnectorReport:
    schema: str
    connector_status: str
    model_blocked: bool
    public_market_data_allowed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    account_connection_required: bool
    network_calls_executed: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    supported_exchanges: list
    normalized_candles_per_exchange: dict
    next_required_gate: str
    issues: list


def _ts(ms: int):
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc)


def raw_public_fixtures() -> Dict[str, list]:
    # Deliberately different raw shapes by exchange, simulating public OHLCV payloads.
    base_ts = 1704067200000
    return {
        "binance": [
            [base_ts + i * 3600000, 50000 + i * 10, 50100 + i * 10, 49900 + i * 10, 50050 + i * 10, 100 + i]
            for i in range(5)
        ],
        "bybit": [
            {
                "start": str(base_ts + i * 3600000),
                "open": str(50000 + i * 10),
                "high": str(50100 + i * 10),
                "low": str(49900 + i * 10),
                "close": str(50050 + i * 10),
                "volume": str(100 + i),
            }
            for i in range(5)
        ],
        "okx": [
            [str(base_ts + i * 3600000), str(50000 + i * 10), str(50100 + i * 10), str(49900 + i * 10), str(50050 + i * 10), str(100 + i)]
            for i in range(5)
        ],
    }


def normalize_public_candles(exchange: str, raw_rows: list, symbol: str = "BTCUSDT", timeframe: str = "1h") -> List[MarketCandle]:
    exchange = exchange.lower()
    if exchange not in SUPPORTED_EXCHANGES:
        raise ValueError(f"unsupported_exchange:{exchange}")
    candles: List[MarketCandle] = []
    for row in raw_rows:
        if exchange == "binance":
            ts, open_, high, low, close, volume = row[:6]
        elif exchange == "bybit":
            ts, open_, high, low, close, volume = row["start"], row["open"], row["high"], row["low"], row["close"], row["volume"]
        else:  # okx
            ts, open_, high, low, close, volume = row[:6]
        candles.append(MarketCandle(
            timestamp=_ts(int(ts)),
            open=float(open_),
            high=float(high),
            low=float(low),
            close=float(close),
            volume=float(volume),
            symbol=symbol,
            timeframe=timeframe,
            exchange=exchange,
        ))
    return candles


def build_normalized_fixture_map(fixtures: dict | None = None) -> Dict[str, List[MarketCandle]]:
    fixtures = fixtures or raw_public_fixtures()
    return {exchange: normalize_public_candles(exchange, rows) for exchange, rows in fixtures.items()}


def generate_public_connector_report(fixtures: dict | None = None, force_dirty: bool = False) -> PublicConnectorReport:
    if force_dirty:
        return PublicConnectorReport(
            schema="qrds.public_market_data_connector_report.v1",
            connector_status="BLOCKED",
            model_blocked=True,
            public_market_data_allowed=False,
            authenticated_connection_used=True,
            api_key_required=True,
            account_connection_required=True,
            network_calls_executed=True,
            real_capital_used=True,
            exchange_connected=True,
            orders_generated=True,
            supported_exchanges=SUPPORTED_EXCHANGES,
            normalized_candles_per_exchange={},
            next_required_gate="NO_PUBLIC_CONNECTOR_BLOCKED",
            issues=["authenticated_connection_used", "api_key_required", "real_capital_used", "orders_generated"],
        )
    normalized = build_normalized_fixture_map(fixtures)
    counts = {k: len(v) for k, v in normalized.items()}
    issues = []
    for ex in SUPPORTED_EXCHANGES:
        if ex not in counts:
            issues.append(f"missing_exchange:{ex}")
        elif counts[ex] == 0:
            issues.append(f"empty_exchange:{ex}")
    status = "PASS" if not issues else "BLOCKED"
    return PublicConnectorReport(
        schema="qrds.public_market_data_connector_report.v1",
        connector_status=status,
        model_blocked=status != "PASS",
        public_market_data_allowed=status == "PASS",
        authenticated_connection_used=False,
        api_key_required=False,
        account_connection_required=False,
        network_calls_executed=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        supported_exchanges=SUPPORTED_EXCHANGES,
        normalized_candles_per_exchange=counts,
        next_required_gate="PUBLIC_MARKET_DATA_CONNECTOR_VALIDATION_REQUIRED" if status == "PASS" else "NO_PUBLIC_CONNECTOR_BLOCKED",
        issues=issues,
    )
