import json
from pathlib import Path
import pytest

from crypto_decision_lab.connectors.public_market_data import SUPPORTED_EXCHANGES, raw_public_fixtures, normalize_public_candles, build_normalized_fixture_map, generate_public_connector_report
from crypto_decision_lab.connectors.validation import generate_public_connector_validation_report, validate_normalized_candle_contract, validate_timestamp_order, export_report, report_to_text

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_raw_fixture_exists_for_each_exchange(exchange):
    assert exchange in raw_public_fixtures()

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_each_exchange_has_five_raw_rows(exchange):
    assert len(raw_public_fixtures()[exchange]) == 5

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_normalized_candles_are_model_objects(exchange):
    candles = normalize_public_candles(exchange, raw_public_fixtures()[exchange])
    assert candles[0].exchange == exchange
    assert candles[0].symbol == "BTCUSDT"

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_timestamps_are_ordered(exchange):
    candles = normalize_public_candles(exchange, raw_public_fixtures()[exchange])
    assert validate_timestamp_order(candles)

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_required_ohlcv_fields_are_valid(exchange):
    candles = normalize_public_candles(exchange, raw_public_fixtures()[exchange])
    for candle in candles:
        assert validate_normalized_candle_contract(candle) == []

def test_connector_report_has_no_authentication():
    report = generate_public_connector_report()
    assert report.authenticated_connection_used is False
    assert report.api_key_required is False
    assert report.account_connection_required is False

def test_connector_report_has_no_risk_exposure():
    report = generate_public_connector_report()
    assert report.network_calls_executed is False
    assert report.exchange_connected is False
    assert report.real_capital_used is False
    assert report.orders_generated is False

def test_validation_report_passes():
    report = generate_public_connector_validation_report()
    assert report.validation_status == "PASS"
    assert report.model_blocked is False

def test_validation_schema_and_connector_schema():
    report = generate_public_connector_validation_report()
    assert report.schema == "qrds.public_market_data_connector_validation_report.v1"
    assert report.connector_schema == "qrds.public_market_data_connector_report.v1"

def test_validation_has_no_issues():
    report = generate_public_connector_validation_report()
    assert report.issues == []

def test_validation_normalized_counts():
    report = generate_public_connector_validation_report()
    assert report.normalized_candles_per_exchange == {"binance": 5, "bybit": 5, "okx": 5}

def test_validation_supported_exchanges():
    report = generate_public_connector_validation_report()
    assert report.supported_exchanges == ["binance", "bybit", "okx"]

def test_dirty_validation_blocks():
    dirty = generate_public_connector_validation_report(force_dirty=True)
    assert dirty.validation_status == "BLOCKED"
    assert dirty.model_blocked is True

def test_dirty_validation_has_issues():
    dirty = generate_public_connector_validation_report(force_dirty=True)
    assert "authenticated_connection_used" in dirty.issues
    assert "orders_generated" in dirty.issues

def test_unsupported_exchange_raises():
    with pytest.raises(ValueError):
        normalize_public_candles("kraken", [])

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_missing_candle_blocks(exchange):
    fixtures = raw_public_fixtures()
    fixtures[exchange] = fixtures[exchange][:3]
    report = generate_public_connector_validation_report(fixtures=fixtures)
    assert report.validation_status == "BLOCKED"
    assert any(f"insufficient_candles:{exchange}" == issue for issue in report.issues)

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_bad_timestamp_order_blocks(exchange):
    fixtures = raw_public_fixtures()
    fixtures[exchange] = list(reversed(fixtures[exchange]))
    report = generate_public_connector_validation_report(fixtures=fixtures)
    assert report.validation_status == "BLOCKED"
    assert any(f"timestamp_order_invalid:{exchange}" == issue for issue in report.issues)

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_bad_price_blocks(exchange):
    fixtures = raw_public_fixtures()
    if exchange == "binance":
        fixtures[exchange][0][1] = 0
    elif exchange == "bybit":
        fixtures[exchange][0]["open"] = "0"
    else:
        fixtures[exchange][0][1] = "0"
    report = generate_public_connector_validation_report(fixtures=fixtures)
    assert report.validation_status == "BLOCKED"
    assert any("invalid_price" in issue for issue in report.issues)

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_bad_volume_blocks(exchange):
    fixtures = raw_public_fixtures()
    if exchange == "binance":
        fixtures[exchange][0][5] = -1
    elif exchange == "bybit":
        fixtures[exchange][0]["volume"] = "-1"
    else:
        fixtures[exchange][0][5] = "-1"
    report = generate_public_connector_validation_report(fixtures=fixtures)
    assert report.validation_status == "BLOCKED"
    assert any("invalid_volume" in issue for issue in report.issues)

def test_export_artifacts(tmp_path):
    report = generate_public_connector_validation_report()
    files = export_report(report, tmp_path)
    assert Path(files["json"]).exists()
    assert Path(files["txt"]).exists()
    assert json.loads(Path(files["json"]).read_text())["validation_status"] == "PASS"

def test_report_text_includes_contract_fields():
    report = generate_public_connector_validation_report()
    text = report_to_text(report)
    assert "Adapter contract valid: True" in text
    assert "Issues: none" in text

def test_validation_summary_next_gate():
    report = generate_public_connector_validation_report()
    assert report.action == "NO_AUTH_PUBLIC_CONNECTOR_VALIDATED"
    assert report.next_required_gate == "PUBLIC_HTTP_MARKET_DATA_CONNECTOR_REQUIRED"
