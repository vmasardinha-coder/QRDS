# Crypto Decision Lab - Sprint 4B

Public Market Data Connector Validation Offline.

This sprint validates the public market data connector contracts created in Sprint 4A for Binance, Bybit and OKX, without API keys, authenticated account access, network calls, exchange connection, capital, or orders.

Expected validation:

```bash
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_public_market_data_connector_validation.py
```

Expected result: 40 tests passed and validation status PASS.
