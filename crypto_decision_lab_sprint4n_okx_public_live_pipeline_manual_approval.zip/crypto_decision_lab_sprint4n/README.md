# Sprint 4N - OKX Public HTTP Live Pipeline Manual Approval Gate

This sprint validates the manual approval gate before enabling an OKX public HTTP live data pipeline.

Default mode is fixture/replay only.

No API key. No real account. No authenticated websocket. No orders. No real capital.
Binance remains simulation/public-data benchmark only. Bybit remains pending due to HTTP 403 in Codespaces.
