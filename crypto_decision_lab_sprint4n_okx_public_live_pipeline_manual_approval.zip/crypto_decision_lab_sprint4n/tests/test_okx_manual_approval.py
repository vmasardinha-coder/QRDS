import pytest
from crypto_decision_lab.okx_manual_approval import (
    REQUIRED_APPROVAL_PHRASE,
    build_okx_manual_approval_report,
    export_report,
)


def test_default_gate_passes_but_does_not_authorize_live():
    r = build_okx_manual_approval_report()
    assert r.approval_status == "PASS"
    assert r.model_blocked is False
    assert r.manual_approval_required is True
    assert r.manual_approval_granted is False
    assert r.explicit_approval_phrase_valid is False
    assert r.okx_public_live_pipeline_authorized is False
    assert r.live_pipeline_enabled is False
    assert r.fixture_replay_used is True
    assert r.network_calls_executed is False
    assert r.action == "NO_OKX_PUBLIC_LIVE_PIPELINE_AWAITING_EXPLICIT_APPROVAL"


def test_explicit_phrase_alone_grants_manual_approval_but_not_live_without_opt_in():
    r = build_okx_manual_approval_report(approval_phrase=REQUIRED_APPROVAL_PHRASE)
    assert r.approval_status == "PASS"
    assert r.manual_approval_granted is True
    assert r.explicit_approval_phrase_valid is True
    assert r.okx_public_live_pipeline_authorized is False
    assert r.network_calls_executed is False


def test_explicit_phrase_plus_opt_in_authorizes_next_gate():
    r = build_okx_manual_approval_report(
        approval_phrase=REQUIRED_APPROVAL_PHRASE,
        live_pipeline_enabled=True,
        network_calls_executed=True,
    )
    assert r.approval_status == "PASS"
    assert r.okx_public_live_pipeline_authorized is True
    assert r.fixture_replay_used is False
    assert r.network_calls_executed is True
    assert r.action == "OKX_PUBLIC_LIVE_PIPELINE_AUTHORIZED_NEXT_GATE"


@pytest.mark.parametrize("bad_phrase", ["", "APROVO", "wrong", REQUIRED_APPROVAL_PHRASE.lower()])
def test_bad_phrase_does_not_grant_approval(bad_phrase):
    r = build_okx_manual_approval_report(approval_phrase=bad_phrase)
    assert r.manual_approval_granted is False
    assert r.explicit_approval_phrase_valid is False
    assert r.okx_public_live_pipeline_authorized is False


@pytest.mark.parametrize(
    "kwargs, issue",
    [
        ({"api_key_present": True}, "api_key_present_forbidden"),
        ({"account_connection_required": True}, "account_connection_required_forbidden"),
        ({"orders_generated": True}, "orders_generated_forbidden"),
        ({"websocket_used": True}, "websocket_used_forbidden"),
        ({"real_capital_used": True}, "real_capital_used_forbidden"),
        ({"exchange_connected": True}, "exchange_connected_forbidden"),
    ],
)
def test_forbidden_exposure_blocks(kwargs, issue):
    r = build_okx_manual_approval_report(**kwargs)
    assert r.approval_status == "BLOCKED"
    assert r.model_blocked is True
    assert issue in r.issues
    assert r.action == "NO_OKX_PUBLIC_LIVE_PIPELINE_BLOCKED"


def test_network_before_approval_blocks():
    r = build_okx_manual_approval_report(network_calls_executed=True)
    assert r.approval_status == "BLOCKED"
    assert "network_calls_before_explicit_okx_approval" in r.issues


def test_live_enabled_without_phrase_blocks():
    r = build_okx_manual_approval_report(live_pipeline_enabled=True)
    assert r.approval_status == "BLOCKED"
    assert "live_pipeline_enabled_without_valid_approval_phrase" in r.issues


def test_roles_are_preserved():
    r = build_okx_manual_approval_report()
    assert r.simulation_exchange == "binance"
    assert r.binance_route == "SIMULATION_FIXTURE_REPLAY"
    assert r.okx_route == "PUBLIC_HTTP_LIVE_PENDING_EXPLICIT_APPROVAL"
    assert r.bybit_route == "PENDING_BLOCKED_BY_403"
    assert r.real_base_target_exchanges == ["okx", "bybit"]
    assert r.real_base_active_now == ["okx"]
    assert r.real_base_pending == ["bybit"]


def test_export_report(tmp_path):
    r = build_okx_manual_approval_report()
    files = export_report(r, tmp_path)
    assert set(files) == {"json", "txt"}
    assert "okx_public_live_pipeline_manual_approval_report.json" in files["json"]
    assert "okx_public_live_pipeline_manual_approval_report.txt" in files["txt"]


@pytest.mark.parametrize(
    "field, expected",
    [
        ("schema", "qrds.okx_public_live_pipeline_manual_approval_report.v1"),
        ("approval_status", "PASS"),
        ("model_blocked", False),
        ("manual_approval_required", True),
        ("manual_approval_granted", False),
        ("explicit_approval_phrase_valid", False),
        ("okx_public_live_pipeline_authorized", False),
        ("live_pipeline_enabled", False),
        ("fixture_replay_used", True),
        ("network_calls_executed", False),
        ("authenticated_connection_used", False),
        ("api_key_required", False),
        ("api_key_present", False),
        ("account_connection_required", False),
        ("websocket_used", False),
        ("real_capital_used", False),
        ("exchange_connected", False),
        ("orders_generated", False),
        ("simulation_exchange", "binance"),
        ("binance_route", "SIMULATION_FIXTURE_REPLAY"),
        ("okx_route", "PUBLIC_HTTP_LIVE_PENDING_EXPLICIT_APPROVAL"),
        ("bybit_route", "PENDING_BLOCKED_BY_403"),
        ("safety_policy", "OKX_PUBLIC_HTTP_LIVE_PIPELINE_MANUAL_APPROVAL_NO_AUTH_NO_ORDERS"),
        ("next_required_gate", "OKX_PUBLIC_HTTP_LIVE_PIPELINE_EXPLICIT_APPROVAL_REQUIRED"),
        ("issues", []),
        ("action", "NO_OKX_PUBLIC_LIVE_PIPELINE_AWAITING_EXPLICIT_APPROVAL"),
    ],
)
def test_default_report_contract_fields(field, expected):
    r = build_okx_manual_approval_report()
    assert getattr(r, field) == expected


@pytest.mark.parametrize("field", [
    "api_key_required",
    "api_key_present",
    "account_connection_required",
    "authenticated_connection_used",
    "websocket_used",
    "real_capital_used",
    "exchange_connected",
    "orders_generated",
])
def test_default_security_fields_false(field):
    assert getattr(build_okx_manual_approval_report(), field) is False


@pytest.mark.parametrize("issue_flag", [
    "api_key_present",
    "account_connection_required",
    "orders_generated",
    "websocket_used",
    "real_capital_used",
    "exchange_connected",
])
def test_issue_flag_prevents_authorization(issue_flag):
    kwargs = {issue_flag: True, "approval_phrase": REQUIRED_APPROVAL_PHRASE, "live_pipeline_enabled": True, "network_calls_executed": True}
    r = build_okx_manual_approval_report(**kwargs)
    assert r.okx_public_live_pipeline_authorized is False
    assert r.approval_status == "BLOCKED"


def test_authorized_report_still_has_no_auth_or_orders():
    r = build_okx_manual_approval_report(
        approval_phrase=REQUIRED_APPROVAL_PHRASE,
        live_pipeline_enabled=True,
        network_calls_executed=True,
    )
    assert r.api_key_required is False
    assert r.api_key_present is False
    assert r.account_connection_required is False
    assert r.authenticated_connection_used is False
    assert r.websocket_used is False
    assert r.real_capital_used is False
    assert r.exchange_connected is False
    assert r.orders_generated is False


def test_total_expected_assertion_anchor():
    # This anchor keeps pytest collecting the intended suite alongside parameterized cases.
    assert True
