from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json

REQUIRED_APPROVAL_PHRASE = (
    "APROVO PIPELINE PUBLICO HTTP LIVE OKX SEM API KEY, SEM CONTA REAL, SEM ORDEM E SEM CAPITAL REAL."
)

@dataclass(frozen=True)
class OKXManualApprovalReport:
    schema: str
    approval_status: str
    model_blocked: bool
    manual_approval_required: bool
    manual_approval_granted: bool
    explicit_approval_phrase_valid: bool
    okx_public_live_pipeline_authorized: bool
    live_pipeline_enabled: bool
    fixture_replay_used: bool
    network_calls_executed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    simulation_exchange: str
    binance_route: str
    okx_route: str
    bybit_route: str
    real_base_target_exchanges: list[str]
    real_base_active_now: list[str]
    real_base_pending: list[str]
    safety_policy: str
    next_required_gate: str
    issues: list[str]
    action: str


def build_okx_manual_approval_report(
    approval_phrase: str | None = None,
    live_pipeline_enabled: bool = False,
    api_key_present: bool = False,
    account_connection_required: bool = False,
    orders_generated: bool = False,
    network_calls_executed: bool = False,
    websocket_used: bool = False,
    real_capital_used: bool = False,
    exchange_connected: bool = False,
) -> OKXManualApprovalReport:
    phrase_valid = approval_phrase == REQUIRED_APPROVAL_PHRASE
    manual_required = True
    manual_granted = phrase_valid

    issues: list[str] = []
    if api_key_present:
        issues.append("api_key_present_forbidden")
    if account_connection_required:
        issues.append("account_connection_required_forbidden")
    if orders_generated:
        issues.append("orders_generated_forbidden")
    if websocket_used:
        issues.append("websocket_used_forbidden")
    if real_capital_used:
        issues.append("real_capital_used_forbidden")
    if exchange_connected:
        issues.append("exchange_connected_forbidden")
    if network_calls_executed and not (live_pipeline_enabled and phrase_valid):
        issues.append("network_calls_before_explicit_okx_approval")
    if live_pipeline_enabled and not phrase_valid:
        issues.append("live_pipeline_enabled_without_valid_approval_phrase")

    authorized = bool(live_pipeline_enabled and phrase_valid and not issues)

    if issues:
        status = "BLOCKED"
        action = "NO_OKX_PUBLIC_LIVE_PIPELINE_BLOCKED"
    elif authorized:
        status = "PASS"
        action = "OKX_PUBLIC_LIVE_PIPELINE_AUTHORIZED_NEXT_GATE"
    else:
        status = "PASS"
        action = "NO_OKX_PUBLIC_LIVE_PIPELINE_AWAITING_EXPLICIT_APPROVAL"

    model_blocked = bool(issues)
    return OKXManualApprovalReport(
        schema="qrds.okx_public_live_pipeline_manual_approval_report.v1",
        approval_status=status,
        model_blocked=model_blocked,
        manual_approval_required=manual_required,
        manual_approval_granted=manual_granted,
        explicit_approval_phrase_valid=phrase_valid,
        okx_public_live_pipeline_authorized=authorized,
        live_pipeline_enabled=live_pipeline_enabled,
        fixture_replay_used=not authorized,
        network_calls_executed=network_calls_executed if authorized else False,
        authenticated_connection_used=False,
        api_key_required=False,
        api_key_present=api_key_present,
        account_connection_required=account_connection_required,
        websocket_used=websocket_used,
        real_capital_used=real_capital_used,
        exchange_connected=exchange_connected,
        orders_generated=orders_generated,
        simulation_exchange="binance",
        binance_route="SIMULATION_FIXTURE_REPLAY",
        okx_route="PUBLIC_HTTP_LIVE_PENDING_EXPLICIT_APPROVAL",
        bybit_route="PENDING_BLOCKED_BY_403",
        real_base_target_exchanges=["okx", "bybit"],
        real_base_active_now=["okx"],
        real_base_pending=["bybit"],
        safety_policy="OKX_PUBLIC_HTTP_LIVE_PIPELINE_MANUAL_APPROVAL_NO_AUTH_NO_ORDERS",
        next_required_gate="OKX_PUBLIC_HTTP_LIVE_PIPELINE_EXPLICIT_APPROVAL_REQUIRED",
        issues=issues,
        action=action,
    )


def export_report(report: OKXManualApprovalReport, out_dir: str | Path = "reports/sprint4n") -> dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = asdict(report)
    json_path = out / "okx_public_live_pipeline_manual_approval_report.json"
    txt_path = out / "okx_public_live_pipeline_manual_approval_report.txt"
    json_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    lines = [f"{k}: {v}" for k, v in data.items()]
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
