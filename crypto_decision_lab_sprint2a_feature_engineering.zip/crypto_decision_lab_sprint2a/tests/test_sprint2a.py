from dataclasses import replace
from pathlib import Path
from crypto_decision_lab.dql.report import clean_candles, dirty_candles, generate_report
from crypto_decision_lab.features.engineering import generate_basic_features, build_features_if_allowed, feature_matrix_artifact
from crypto_decision_lab.artifacts.export import write_json, write_txt_summary


def test_clean_report_pass():
    r = generate_report("clean-48", clean_candles())
    assert r.status == "PASS"
    assert r.model_blocked is False


def test_dirty_report_blocked():
    r = generate_report("issues-48", dirty_candles())
    assert r.status == "BLOCKED"
    assert r.model_blocked is True


def test_feature_count_matches_candles():
    candles = clean_candles()
    features = generate_basic_features(candles)
    assert len(features) == len(candles) == 48


def test_first_row_has_no_prior_return():
    first = generate_basic_features(clean_candles())[0]
    assert first.simple_return_1 is None
    assert first.log_return_1 is None


def test_second_row_has_return():
    second = generate_basic_features(clean_candles())[1]
    assert second.simple_return_1 is not None
    assert second.log_return_1 is not None


def test_range_features_are_bounded():
    rows = generate_basic_features(clean_candles())
    assert rows[-1].high_low_range_pct > 0
    assert 0 <= rows[-1].close_position_in_range <= 1


def test_rolling_features_require_window():
    rows = generate_basic_features(clean_candles(), lookback_window=6)
    assert rows[0].rolling_volatility is None
    assert rows[4].rolling_volatility is None
    assert rows[6].rolling_volatility is not None


def test_volume_zscore_requires_window():
    rows = generate_basic_features(clean_candles(), lookback_window=6)
    assert rows[4].volume_zscore is None
    assert rows[5].volume_zscore is not None


def test_dql_gate_allows_clean():
    candles = clean_candles()
    r = generate_report("clean-48", candles)
    assert len(build_features_if_allowed(candles, r)) == 48


def test_dql_gate_blocks_dirty():
    candles = dirty_candles()
    r = generate_report("issues-48", candles)
    try:
        build_features_if_allowed(candles, r)
    except ValueError as exc:
        assert "blocked by DQL" in str(exc)
    else:
        raise AssertionError("dirty dataset should be blocked")


def test_feature_artifact_schema_and_guardrails():
    candles = clean_candles()
    r = generate_report("clean-48", candles)
    artifact = feature_matrix_artifact("clean-features", r, build_features_if_allowed(candles, r))
    assert artifact["schema"] == "qrds.feature_matrix.v1"
    assert artifact["feature_count"] == 48
    assert "no_trading_signal" in artifact["scope_guardrails"]


def test_no_future_leakage_for_prior_feature():
    candles = clean_candles()
    base_rows = generate_basic_features(candles, lookback_window=6)
    mutated = list(candles)
    mutated[-1] = replace(mutated[-1], close=999999, volume=999999)
    mutated_rows = generate_basic_features(mutated, lookback_window=6)
    assert mutated_rows[10].to_dict() == base_rows[10].to_dict()


def test_write_json_and_txt(tmp_path):
    candles = clean_candles()
    r = generate_report("clean-48", candles)
    artifact = feature_matrix_artifact("clean-features", r, build_features_if_allowed(candles, r))
    p1 = write_json(tmp_path / "feature.json", artifact)
    p2 = write_txt_summary(tmp_path / "feature.txt", artifact)
    assert p1.exists()
    assert p2.exists()
    assert "qrds.feature_matrix.v1" in p2.read_text()


def test_invalid_window_is_rejected():
    try:
        generate_basic_features(clean_candles(), lookback_window=1)
    except ValueError as exc:
        assert "lookback_window" in str(exc)
    else:
        raise AssertionError("window < 2 should fail")
