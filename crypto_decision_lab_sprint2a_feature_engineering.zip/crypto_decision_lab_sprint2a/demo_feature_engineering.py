from crypto_decision_lab.dql.report import clean_candles, dirty_candles, generate_report
from crypto_decision_lab.features.engineering import build_features_if_allowed, feature_matrix_artifact
from crypto_decision_lab.artifacts.export import write_json, write_txt_summary

OUT = "reports/sprint2a"

clean = clean_candles()
clean_report = generate_report("clean-48", clean)
features = build_features_if_allowed(clean, clean_report, lookback_window=6)
artifact = feature_matrix_artifact("clean-48-features", clean_report, features)
write_json(f"{OUT}/feature_matrix_clean.json", artifact)
write_txt_summary(f"{OUT}/feature_matrix_clean.txt", artifact)

dirty = dirty_candles()
dirty_report = generate_report("issues-48", dirty)
blocked_message = None
try:
    build_features_if_allowed(dirty, dirty_report, lookback_window=6)
except ValueError as exc:
    blocked_message = str(exc)

print("=== Sprint 2A Feature Engineering Offline ===")
print(f"Schema: {artifact['schema']}")
print(f"Source status: {clean_report.status}")
print(f"Source DQS: {clean_report.dqs:.4f}")
print(f"Feature rows: {len(features)}")
print(f"First simple_return_1: {features[0].simple_return_1}")
print(f"Last rolling_volatility: {features[-1].rolling_volatility}")
print(f"Last volume_zscore: {features[-1].volume_zscore}")
print(f"Dirty dataset status: {dirty_report.status}")
print(f"Dirty dataset model_blocked: {dirty_report.model_blocked}")
print(f"Dirty feature gate: {blocked_message}")
print(f"Generated files: {OUT}/")
