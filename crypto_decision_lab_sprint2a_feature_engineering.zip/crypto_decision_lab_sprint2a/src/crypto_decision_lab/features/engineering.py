import math
from statistics import mean, pstdev
from crypto_decision_lab.domain.models import MarketCandle, FeatureRow
from crypto_decision_lab.dql.report import DataQualityReport

FEATURE_SCHEMA = "qrds.feature_matrix.v1"

def _safe_div(a: float, b: float):
    if b == 0:
        return None
    return a / b

def _round(x):
    return None if x is None else round(float(x), 8)

def generate_basic_features(candles: list[MarketCandle], lookback_window: int = 6) -> list[FeatureRow]:
    if lookback_window < 2:
        raise ValueError("lookback_window must be >= 2")
    rows: list[FeatureRow] = []
    simple_returns: list[float | None] = []
    for i, c in enumerate(candles):
        prev_close = candles[i - 1].close if i > 0 else None
        simple_return = None if prev_close is None else _safe_div(c.close - prev_close, prev_close)
        log_return = None if prev_close is None or prev_close <= 0 or c.close <= 0 else math.log(c.close / prev_close)
        simple_returns.append(simple_return)

        range_pct = _safe_div(c.high - c.low, c.close) if c.close > 0 else None
        close_pos = _safe_div(c.close - c.low, c.high - c.low)

        valid_recent_returns = [r for r in simple_returns[max(0, i - lookback_window + 1): i + 1] if r is not None]
        if len(valid_recent_returns) >= lookback_window:
            rolling_mean = mean(valid_recent_returns)
            rolling_vol = pstdev(valid_recent_returns)
        else:
            rolling_mean = None
            rolling_vol = None

        recent_volumes = [x.volume for x in candles[max(0, i - lookback_window + 1): i + 1]]
        if len(recent_volumes) >= lookback_window:
            vol_mean = mean(recent_volumes)
            vol_std = pstdev(recent_volumes)
            volume_zscore = 0.0 if vol_std == 0 else (c.volume - vol_mean) / vol_std
        else:
            volume_zscore = None

        rows.append(FeatureRow(
            timestamp=c.timestamp,
            symbol=c.symbol,
            timeframe=c.timeframe,
            close=c.close,
            simple_return_1=_round(simple_return),
            log_return_1=_round(log_return),
            high_low_range_pct=_round(range_pct),
            close_position_in_range=_round(close_pos),
            rolling_return_mean=_round(rolling_mean),
            rolling_volatility=_round(rolling_vol),
            volume_zscore=_round(volume_zscore),
            lookback_window=lookback_window,
        ))
    return rows

def build_features_if_allowed(candles: list[MarketCandle], report: DataQualityReport, lookback_window: int = 6) -> list[FeatureRow]:
    if report.model_blocked:
        raise ValueError(f"Feature generation blocked by DQL: status={report.status}, dqs={report.dqs}")
    return generate_basic_features(candles, lookback_window=lookback_window)

def feature_matrix_artifact(name: str, report: DataQualityReport, features: list[FeatureRow]) -> dict:
    return {
        "schema": FEATURE_SCHEMA,
        "name": name,
        "source_report": report.to_dict(),
        "feature_count": len(features),
        "columns": [
            "timestamp", "symbol", "timeframe", "close", "simple_return_1", "log_return_1",
            "high_low_range_pct", "close_position_in_range", "rolling_return_mean",
            "rolling_volatility", "volume_zscore", "lookback_window"
        ],
        "features": [f.to_dict() for f in features],
        "scope_guardrails": [
            "offline_only", "no_live_api", "no_orders", "no_capital", "no_trading_signal"
        ],
    }
