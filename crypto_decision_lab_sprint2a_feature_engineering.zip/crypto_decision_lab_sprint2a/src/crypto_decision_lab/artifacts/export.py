import json
from pathlib import Path

def write_json(path: str | Path, payload: dict) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return path

def write_txt_summary(path: str | Path, payload: dict) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    report = payload["source_report"]
    text = (
        f"Schema: {payload['schema']}\n"
        f"Name: {payload['name']}\n"
        f"Source status: {report['status']}\n"
        f"Source DQS: {report['dqs']:.4f}\n"
        f"Feature count: {payload['feature_count']}\n"
        f"Columns: {', '.join(payload['columns'])}\n"
        f"Guardrails: {', '.join(payload['scope_guardrails'])}\n"
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path
