from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Optional

@dataclass(frozen=True)
class MarketCandle:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    symbol: str = "BTCUSDT"
    timeframe: str = "1h"

@dataclass(frozen=True)
class FeatureRow:
    timestamp: datetime
    symbol: str
    timeframe: str
    close: float
    simple_return_1: Optional[float]
    log_return_1: Optional[float]
    high_low_range_pct: Optional[float]
    close_position_in_range: Optional[float]
    rolling_return_mean: Optional[float]
    rolling_volatility: Optional[float]
    volume_zscore: Optional[float]
    lookback_window: int

    def to_dict(self) -> dict:
        d = asdict(self)
        d["timestamp"] = self.timestamp.isoformat()
        return d

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
