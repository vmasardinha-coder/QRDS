# Crypto Decision Lab - Sprint 2A

Feature Engineering offline para candles validados por DQL.

## Escopo

- Sem Binance live
- Sem API key
- Sem WebSocket
- Sem ordens
- Sem capital real
- Sem sinal Long/Short

## Teste

```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_feature_engineering.py
```
