from crypto_decision_lab.ingestion.binance_klines import load_binance_klines_csv
from crypto_decision_lab.dql.report import generate_data_quality_report
from crypto_decision_lab.features.engineering import build_feature_matrix
from crypto_decision_lab.regimes.diagnostics import generate_regime_diagnostics
from crypto_decision_lab.export.artifacts import export_json, export_txt

clean = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-clean-48.csv")
dirty = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-dirty-48.csv")
clean_dql = generate_data_quality_report(clean)
dirty_dql = generate_data_quality_report(dirty)
features = build_feature_matrix(clean, clean_dql)
report = generate_regime_diagnostics(features, feature_quality_status="PASS")

out_dir = "reports/sprint2c"
export_json(report, f"{out_dir}/regime_diagnostics_report.json")
export_txt(report, f"{out_dir}/regime_diagnostics_report.txt")
export_json(features, f"{out_dir}/feature_matrix.json")

print("=== Sprint 2C Regime Diagnostics Offline ===")
print(f"Feature schema: {features.schema}")
print(f"Regime schema: {report.schema}")
print(f"Rows: {report.rows}")
print(f"Regime status: {report.status}")
print(f"Model blocked: {report.model_blocked}")
print(f"Regime score: {report.regime_score:.4f}")
print(f"Volatility counts: {report.volatility_counts}")
print(f"Trend counts: {report.trend_counts}")
print(f"Volume counts: {report.volume_counts}")
if report.last_snapshot:
    print(f"Last volatility regime: {report.last_snapshot.volatility_regime}")
    print(f"Last trend regime: {report.last_snapshot.trend_regime}")
    print(f"Last volume regime: {report.last_snapshot.volume_regime}")
    print(f"Last regime code: {report.last_snapshot.regime_code}")
print(f"Dirty DQL status: {dirty_dql.status}")
try:
    dirty_features = build_feature_matrix(dirty, dirty_dql)
    dirty_report = generate_regime_diagnostics(dirty_features, feature_quality_status="PASS")
    print(f"Dirty regime status: {dirty_report.status}")
except ValueError as exc:
    print(f"Dirty regime gate: {exc}")
print(f"Generated files: {out_dir}/")
