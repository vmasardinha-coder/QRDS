# QRDS Sprint 2C - Regime Diagnostics Offline

Gera diagnosticos de regime de mercado a partir da matriz de features validada.

Ainda nao ha sinal Long/Short, backtest, API key, WebSocket, ordens ou capital real.

## Validacao

```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_regime_diagnostics.py
```
