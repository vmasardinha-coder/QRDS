import math
from statistics import mean, pstdev
from crypto_decision_lab.domain.models import FeatureRow, FeatureMatrix

FEATURE_SCHEMA = "qrds.feature_matrix.v1"

def _zscore(values, idx, window):
    start = max(0, idx - window + 1)
    sample = values[start:idx+1]
    if len(sample) < 2:
        return None
    sd = pstdev(sample)
    if sd == 0:
        return 0.0
    return (values[idx] - mean(sample)) / sd

def build_feature_matrix(candles, dql_report, rolling_window=5, volume_window=10):
    if dql_report.status != "PASS" or dql_report.model_blocked:
        raise ValueError(f"Feature generation blocked by DQL: status={dql_report.status}, dqs={dql_report.dqs}")
    rows=[]
    closes=[c.close for c in candles]
    volumes=[c.volume for c in candles]
    returns=[]
    for i,c in enumerate(candles):
        prev = closes[i-1] if i > 0 else None
        simple = None if prev is None else (c.close / prev) - 1
        logret = None if prev is None else math.log(c.close / prev)
        returns.append(simple)
        valid_returns = [x for x in returns[max(0, i-rolling_window+1):i+1] if x is not None]
        rr_mean = mean(valid_returns) if valid_returns else None
        rr_vol = pstdev(valid_returns) if len(valid_returns) >= 2 else None
        candle_range = c.high - c.low
        range_pct = candle_range / c.close if c.close else 0.0
        close_position = (c.close - c.low) / candle_range if candle_range else 0.5
        candle_efficiency = abs(c.close - c.open) / candle_range if candle_range else 0.0
        vol_z = _zscore(volumes, i, volume_window)
        rows.append(FeatureRow(c.timestamp.isoformat(), c.close, None if simple is None else round(simple, 8), None if logret is None else round(logret, 8), round(range_pct, 8), round(close_position, 8), None if rr_mean is None else round(rr_mean, 8), None if rr_vol is None else round(rr_vol, 8), None if vol_z is None else round(vol_z, 8), round(candle_efficiency, 8)))
    return FeatureMatrix(FEATURE_SCHEMA, dql_report.status, dql_report.dqs, rows)
