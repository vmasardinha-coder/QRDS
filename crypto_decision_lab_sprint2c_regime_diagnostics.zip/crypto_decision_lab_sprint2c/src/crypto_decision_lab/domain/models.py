from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Any

@dataclass(frozen=True)
class MarketCandle:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    symbol: str = "BTCUSDT"
    timeframe: str = "1h"

@dataclass(frozen=True)
class DataQualityReport:
    schema: str
    total_candles: int
    duplicate_timestamps: int
    gap_count: int
    invalid_ohlc_count: int
    invalid_price_count: int
    invalid_volume_count: int
    missing_values_count: int
    dqs: float
    status: str
    model_blocked: bool
    issues: list[str]

@dataclass(frozen=True)
class FeatureRow:
    timestamp: str
    close: float
    simple_return_1: float | None
    log_return_1: float | None
    range_pct: float
    close_position: float
    rolling_return_mean: float | None
    rolling_volatility: float | None
    volume_zscore: float | None
    candle_efficiency: float

@dataclass(frozen=True)
class FeatureMatrix:
    schema: str
    source_status: str
    source_dqs: float
    rows: list[FeatureRow]

@dataclass(frozen=True)
class RegimeSnapshot:
    timestamp: str
    volatility_regime: str
    trend_regime: str
    volume_regime: str
    efficiency_regime: str
    regime_code: str

@dataclass(frozen=True)
class RegimeDiagnosticsReport:
    schema: str
    feature_schema: str
    rows: int
    status: str
    model_blocked: bool
    regime_score: float
    volatility_counts: dict[str, int]
    trend_counts: dict[str, int]
    volume_counts: dict[str, int]
    last_snapshot: RegimeSnapshot | None
    issues: list[str]

def to_dict(obj: Any) -> Any:
    if hasattr(obj, "__dataclass_fields__"):
        return {k: to_dict(v) for k, v in asdict(obj).items()}
    if isinstance(obj, list):
        return [to_dict(v) for v in obj]
    if isinstance(obj, dict):
        return {k: to_dict(v) for k, v in obj.items()}
    return obj
