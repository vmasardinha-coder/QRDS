import csv
from datetime import datetime, timezone
from pathlib import Path
from crypto_decision_lab.domain.models import MarketCandle

def _ts(ms: str) -> datetime:
    return datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc)

def load_binance_klines_csv(path: str | Path) -> list[MarketCandle]:
    candles = []
    with Path(path).open("r", newline="") as f:
        for row in csv.reader(f):
            if not row or row[0].lower() in {"open_time", "timestamp"}:
                continue
            candles.append(MarketCandle(timestamp=_ts(row[0]), open=float(row[1]), high=float(row[2]), low=float(row[3]), close=float(row[4]), volume=float(row[5])))
    return candles
