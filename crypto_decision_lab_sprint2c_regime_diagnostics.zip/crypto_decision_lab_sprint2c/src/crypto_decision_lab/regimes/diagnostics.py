from crypto_decision_lab.domain.models import RegimeDiagnosticsReport, RegimeSnapshot

REGIME_SCHEMA = "qrds.regime_diagnostics.v1"

MIN_ROWS = 30

def _clean(values):
    return [v for v in values if v is not None]

def _quantiles(values):
    vals = sorted(_clean(values))
    if not vals:
        return 0.0, 0.0
    def q(p):
        idx = min(len(vals)-1, max(0, int(round((len(vals)-1)*p))))
        return vals[idx]
    return q(0.33), q(0.66)

def _vol_regime(value, low_q, high_q):
    if value is None:
        return "unknown_volatility"
    if value <= low_q:
        return "low_volatility"
    if value >= high_q:
        return "high_volatility"
    return "normal_volatility"

def _trend_regime(value, eps=0.00005):
    if value is None:
        return "unknown_trend"
    if value > eps:
        return "upward_drift"
    if value < -eps:
        return "downward_drift"
    return "flat_drift"

def _volume_regime(value):
    if value is None:
        return "unknown_volume"
    if value >= 1.0:
        return "elevated_volume"
    if value <= -1.0:
        return "quiet_volume"
    return "normal_volume"

def _efficiency_regime(value):
    if value >= 0.60:
        return "directional_candle"
    if value <= 0.25:
        return "inefficient_candle"
    return "balanced_candle"

def _count(items):
    out={}
    for x in items:
        out[x] = out.get(x, 0) + 1
    return dict(sorted(out.items()))

def generate_regime_diagnostics(feature_matrix, feature_quality_status="PASS"):
    issues=[]
    if feature_matrix.source_status != "PASS":
        issues.append("source_dql_blocked")
    if feature_quality_status != "PASS":
        issues.append("feature_quality_blocked")
    if len(feature_matrix.rows) < MIN_ROWS:
        issues.append("insufficient_rows")
    if issues:
        return RegimeDiagnosticsReport(REGIME_SCHEMA, feature_matrix.schema, len(feature_matrix.rows), "BLOCKED", True, 0.0, {}, {}, {}, None, issues)
    vols = [r.rolling_volatility for r in feature_matrix.rows]
    low_q, high_q = _quantiles(vols)
    snapshots=[]
    for r in feature_matrix.rows:
        vol = _vol_regime(r.rolling_volatility, low_q, high_q)
        trend = _trend_regime(r.rolling_return_mean)
        volume = _volume_regime(r.volume_zscore)
        eff = _efficiency_regime(r.candle_efficiency)
        code = f"{vol}|{trend}|{volume}|{eff}"
        snapshots.append(RegimeSnapshot(r.timestamp, vol, trend, volume, eff, code))
    vol_counts = _count([s.volatility_regime for s in snapshots])
    trend_counts = _count([s.trend_regime for s in snapshots])
    volume_counts = _count([s.volume_regime for s in snapshots])
    known = sum(1 for s in snapshots if not s.regime_code.startswith("unknown"))
    score = round(known / len(snapshots), 4) if snapshots else 0.0
    return RegimeDiagnosticsReport(REGIME_SCHEMA, feature_matrix.schema, len(snapshots), "PASS", False, score, vol_counts, trend_counts, volume_counts, snapshots[-1], [])
