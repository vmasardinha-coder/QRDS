from crypto_decision_lab.domain.models import DataQualityReport

DQS_THRESHOLD = 0.80

def validate_ohlc(c):
    return c.low <= c.open <= c.high and c.low <= c.close <= c.high and c.low <= c.high

def validate_positive_prices(c):
    return c.open > 0 and c.high > 0 and c.low > 0 and c.close > 0

def validate_non_negative_volume(c):
    return c.volume >= 0

def count_duplicate_timestamps(candles):
    seen = set(); dup = 0
    for c in candles:
        if c.timestamp in seen: dup += 1
        seen.add(c.timestamp)
    return dup

def count_gaps(candles, expected_interval_seconds=3600):
    ordered = sorted(candles, key=lambda c: c.timestamp)
    gaps = 0
    for a,b in zip(ordered, ordered[1:]):
        if int((b.timestamp - a.timestamp).total_seconds()) != expected_interval_seconds:
            gaps += 1
    return gaps

def timestamp_order_ok(candles):
    return all(candles[i].timestamp > candles[i-1].timestamp for i in range(1, len(candles)))

def generate_data_quality_report(candles, expected_interval_seconds=3600):
    total = len(candles)
    if total == 0:
        return DataQualityReport("qrds.dql_report.v1", 0,0,0,0,0,0,0,0.0,"BLOCKED",True,["empty_dataset"])
    dup = count_duplicate_timestamps(candles)
    gaps = count_gaps(candles, expected_interval_seconds)
    invalid_ohlc = sum(1 for c in candles if not validate_ohlc(c))
    invalid_price = sum(1 for c in candles if not validate_positive_prices(c))
    invalid_volume = sum(1 for c in candles if not validate_non_negative_volume(c))
    missing = 0
    order_ok = timestamp_order_ok(candles)
    issues=[]
    if dup: issues.append("duplicate_timestamps")
    if gaps: issues.append("timestamp_gaps")
    if invalid_ohlc: issues.append("invalid_ohlc")
    if invalid_price: issues.append("invalid_prices")
    if invalid_volume: issues.append("invalid_volume")
    if missing: issues.append("missing_values")
    if not order_ok: issues.append("timestamp_order")
    completeness = max(0.0, 1.0 - ((dup+gaps)/total))
    consistency = max(0.0, 1.0 - ((invalid_ohlc+invalid_price+invalid_volume+missing)/total))
    freshness = 1.0
    temporality = 1.0 if order_ok and dup == 0 else 0.0
    dqs = round((completeness + consistency + freshness + temporality) / 4, 4)
    status = "PASS" if dqs >= DQS_THRESHOLD and not issues else "BLOCKED"
    return DataQualityReport("qrds.dql_report.v1", total, dup, gaps, invalid_ohlc, invalid_price, invalid_volume, missing, dqs, status, status != "PASS", issues)
