import json
from pathlib import Path
from crypto_decision_lab.domain.models import to_dict

def export_json(obj, path):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(to_dict(obj), indent=2, ensure_ascii=False), encoding="utf-8")
    return path

def export_txt(report, path):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "QRDS Sprint 2C - Regime Diagnostics",
        f"Schema: {report.schema}",
        f"Feature schema: {report.feature_schema}",
        f"Rows: {report.rows}",
        f"Status: {report.status}",
        f"Model blocked: {report.model_blocked}",
        f"Regime score: {report.regime_score:.4f}",
        f"Volatility counts: {report.volatility_counts}",
        f"Trend counts: {report.trend_counts}",
        f"Volume counts: {report.volume_counts}",
        f"Last snapshot: {report.last_snapshot}",
        f"Issues: {report.issues if report.issues else 'none'}",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
