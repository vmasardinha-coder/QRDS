import json
from dataclasses import dataclass, asdict
from pathlib import Path

@dataclass(frozen=True)
class IntegratedResearchDataset:
    schema: str
    rows: list
    row_count: int
    horizons: list
    status: str
    model_blocked: bool
    quality_score: float
    issues: list
    lineage: dict


def build_integrated_research_dataset(feature_matrix, feature_quality_report, regime_diagnostics, target_matrix, target_quality_report, dql_report):
    gates = {
        "dql": dql_report.status,
        "feature_matrix": feature_matrix.status,
        "feature_quality": feature_quality_report.status,
        "regime_diagnostics": regime_diagnostics.status,
        "target_matrix": target_matrix.status,
        "target_quality": target_quality_report.status,
    }
    if any(v != "PASS" for v in gates.values()):
        return IntegratedResearchDataset(
            "qrds.integrated_research_dataset.v1", [], 0, target_matrix.horizons if hasattr(target_matrix, "horizons") else [], "BLOCKED", True, 0.0,
            [f"integrated_dataset_blocked_by_gate:{k}={v}" for k, v in gates.items() if v != "PASS"],
            {"gates": gates},
        )
    features_by_ts = {r["timestamp"]: r for r in feature_matrix.rows}
    regimes_by_ts = {r["timestamp"]: r for r in regime_diagnostics.regime_rows}
    rows = []
    for t in target_matrix.rows:
        ts = t["timestamp"]
        feature = features_by_ts.get(ts, {})
        regime = regimes_by_ts.get(ts, {})
        rows.append({
            "timestamp": ts,
            "symbol": feature.get("symbol"),
            "timeframe": feature.get("timeframe"),
            "horizon": t["horizon"],
            "close": feature.get("close"),
            "simple_return_1": feature.get("simple_return_1"),
            "log_return_1": feature.get("log_return_1"),
            "hl_range_pct": feature.get("hl_range_pct"),
            "close_position": feature.get("close_position"),
            "rolling_return_mean": feature.get("rolling_return_mean"),
            "rolling_volatility": feature.get("rolling_volatility"),
            "volume_zscore": feature.get("volume_zscore"),
            "regime_code": regime.get("regime_code"),
            "volatility_regime": regime.get("volatility_regime"),
            "trend_regime": regime.get("trend_regime"),
            "volume_regime": regime.get("volume_regime"),
            "future_return": t["future_return"],
            "direction_label": t["direction_label"],
            "target_valid": t["target_valid"],
        })
    quality_score = round((dql_report.dqs + feature_quality_report.score + regime_diagnostics.score + target_quality_report.score) / 4.0, 4)
    status = "PASS" if rows and quality_score >= 0.8 else "BLOCKED"
    return IntegratedResearchDataset(
        "qrds.integrated_research_dataset.v1", rows, len(rows), target_matrix.horizons, status, status == "BLOCKED", quality_score, [],
        {
            "gates": gates,
            "source_schemas": {
                "dql": dql_report.schema,
                "feature_matrix": feature_matrix.schema,
                "feature_quality": feature_quality_report.schema,
                "regime_diagnostics": regime_diagnostics.schema,
                "target_matrix": target_matrix.schema,
                "target_quality": target_quality_report.schema,
            },
        },
    )


def export_integrated_research_dataset(dataset, output_dir):
    path = Path(output_dir)
    path.mkdir(parents=True, exist_ok=True)
    json_path = path / "integrated_research_dataset.json"
    txt_path = path / "integrated_research_dataset.txt"
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(asdict(dataset), f, indent=2, ensure_ascii=False)
    with txt_path.open("w", encoding="utf-8") as f:
        f.write("QRDS Integrated Research Dataset\n")
        f.write(f"Schema: {dataset.schema}\n")
        f.write(f"Status: {dataset.status}\n")
        f.write(f"Model blocked: {dataset.model_blocked}\n")
        f.write(f"Rows: {dataset.row_count}\n")
        f.write(f"Quality score: {dataset.quality_score:.4f}\n")
        f.write(f"Horizons: {dataset.horizons}\n")
        f.write(f"Issues: {dataset.issues if dataset.issues else 'none'}\n")
    return {"json": str(json_path), "txt": str(txt_path)}
