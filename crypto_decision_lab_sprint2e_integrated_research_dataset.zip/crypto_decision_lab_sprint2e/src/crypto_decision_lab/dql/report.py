from dataclasses import dataclass

@dataclass(frozen=True)
class DataQualityReport:
    schema: str
    total_candles: int
    dqs: float
    status: str
    model_blocked: bool
    duplicate_timestamps: int
    gap_count: int
    invalid_ohlc_count: int
    invalid_price_count: int
    invalid_volume_count: int
    missing_values_count: int
    issues: list


def count_duplicate_timestamps(candles):
    seen = set()
    dup = 0
    for c in candles:
        if c.timestamp in seen:
            dup += 1
        seen.add(c.timestamp)
    return dup


def count_gaps(candles, expected_interval_seconds=3600):
    ordered = sorted(candles, key=lambda c: c.timestamp)
    gaps = 0
    for a, b in zip(ordered, ordered[1:]):
        if int((b.timestamp - a.timestamp).total_seconds()) != expected_interval_seconds:
            gaps += 1
    return gaps


def generate_data_quality_report(candles, expected_interval_seconds=3600):
    total = len(candles)
    if total == 0:
        return DataQualityReport("qrds.dql_report.v1", 0, 0.0, "BLOCKED", True, 0, 0, 0, 0, 0, 0, ["empty_dataset"])

    dup = count_duplicate_timestamps(candles)
    gaps = count_gaps(candles, expected_interval_seconds)
    invalid_ohlc = sum(1 for c in candles if not (c.low <= c.open <= c.high and c.low <= c.close <= c.high and c.low <= c.high))
    invalid_price = sum(1 for c in candles if any(v is None or v <= 0 for v in (c.open, c.high, c.low, c.close)))
    invalid_volume = sum(1 for c in candles if c.volume is None or c.volume < 0)
    missing = sum(1 for c in candles if any(v is None for v in (c.timestamp, c.open, c.high, c.low, c.close, c.volume)))
    ordered = all(candles[i].timestamp > candles[i - 1].timestamp for i in range(1, total))

    issues = []
    if dup: issues.append("duplicate_timestamps")
    if gaps: issues.append("timestamp_gaps")
    if invalid_ohlc: issues.append("invalid_ohlc")
    if invalid_price: issues.append("invalid_prices")
    if invalid_volume: issues.append("invalid_volume")
    if missing: issues.append("missing_values")
    if not ordered: issues.append("timestamp_order")

    completeness = max(0.0, 1.0 - ((dup + gaps) / total))
    consistency = max(0.0, 1.0 - ((invalid_ohlc + invalid_price + invalid_volume + missing) / total))
    freshness = 1.0
    temporality = 1.0 if ordered and dup == 0 else 0.0
    dqs = round((completeness + consistency + freshness + temporality) / 4.0, 4)
    status = "PASS" if dqs >= 0.8 and not issues else "BLOCKED"
    return DataQualityReport("qrds.dql_report.v1", total, dqs, status, status == "BLOCKED", dup, gaps, invalid_ohlc, invalid_price, invalid_volume, missing, issues)
