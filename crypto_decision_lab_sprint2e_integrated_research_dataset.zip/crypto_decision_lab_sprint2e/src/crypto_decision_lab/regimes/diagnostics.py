from dataclasses import dataclass
from statistics import median

@dataclass(frozen=True)
class RegimeDiagnostics:
    schema: str
    rows: int
    score: float
    status: str
    model_blocked: bool
    regime_rows: list
    issues: list


def _bucket(value, low, high, labels):
    if value is None:
        return labels[0]
    if value < low:
        return labels[1]
    if value > high:
        return labels[3]
    return labels[2]


def generate_regime_diagnostics(feature_matrix, feature_quality_report):
    if feature_matrix.status != "PASS" or feature_quality_report.status != "PASS":
        return RegimeDiagnostics("qrds.regime_diagnostics.v1", 0, 0.0, "BLOCKED", True, [], ["regime_generation_blocked_by_feature_quality"])
    rows = feature_matrix.rows
    vols = [r["rolling_volatility"] for r in rows if r.get("rolling_volatility") is not None]
    volume_z = [abs(r["volume_zscore"]) for r in rows if r.get("volume_zscore") is not None]
    vol_mid = median(vols) if vols else 0.0
    vol_high = vol_mid * 1.25 if vol_mid else 0.0
    z_high = median(volume_z) * 1.25 if volume_z else 1.0
    out = []
    unknown = 0
    for r in rows:
        vol_regime = _bucket(r.get("rolling_volatility"), vol_mid * 0.75, vol_high, ["unknown_volatility", "low_volatility", "normal_volatility", "high_volatility"])
        ret = r.get("rolling_return_mean")
        if ret is None:
            trend = "unknown_trend"
        elif ret > 0:
            trend = "upward_drift"
        elif ret < 0:
            trend = "downward_drift"
        else:
            trend = "flat_drift"
        z = r.get("volume_zscore")
        if z is None:
            volume = "unknown_volume"
        elif abs(z) > z_high:
            volume = "elevated_volume"
        else:
            volume = "normal_volume"
        pos = r.get("close_position")
        candle = "unknown_candle" if pos is None else ("top_close" if pos > 0.67 else "bottom_close" if pos < 0.33 else "balanced_candle")
        code = f"{vol_regime}|{trend}|{volume}|{candle}"
        unknown += 1 if "unknown" in code else 0
        out.append({"timestamp": r["timestamp"], "volatility_regime": vol_regime, "trend_regime": trend, "volume_regime": volume, "candle_regime": candle, "regime_code": code})
    score = round(1.0 - (unknown / max(1, len(rows)) / 4.0), 4)
    status = "PASS" if score >= 0.8 else "BLOCKED"
    return RegimeDiagnostics("qrds.regime_diagnostics.v1", len(rows), score, status, status == "BLOCKED", out, [])
