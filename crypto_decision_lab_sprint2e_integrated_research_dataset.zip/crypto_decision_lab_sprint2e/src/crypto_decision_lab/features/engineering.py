from dataclasses import dataclass
from math import log, sqrt
from statistics import mean, pstdev

@dataclass(frozen=True)
class FeatureMatrix:
    schema: str
    source_status: str
    source_dqs: float
    rows: list
    status: str
    model_blocked: bool
    issues: list


def _pct(a, b):
    return None if b in (None, 0) else (a / b) - 1.0


def _round(x):
    return None if x is None else round(float(x), 8)


def generate_feature_matrix(candles, dql_report, rolling_window=6):
    if dql_report.status != "PASS":
        return FeatureMatrix("qrds.feature_matrix.v1", dql_report.status, dql_report.dqs, [], "BLOCKED", True, [f"Feature generation blocked by DQL: status={dql_report.status}, dqs={dql_report.dqs}"])
    rows = []
    returns = []
    volumes = [c.volume for c in candles]
    for i, c in enumerate(candles):
        prev_close = candles[i - 1].close if i > 0 else None
        simple_return = None if prev_close is None else _pct(c.close, prev_close)
        log_return = None if prev_close is None else log(c.close / prev_close)
        returns.append(simple_return)
        rng = (c.high - c.low) / c.open if c.open else None
        close_pos = (c.close - c.low) / (c.high - c.low) if c.high != c.low else None
        window_returns = [r for r in returns[max(0, i - rolling_window + 1): i + 1] if r is not None]
        rolling_mean = mean(window_returns) if window_returns else None
        rolling_vol = pstdev(window_returns) if len(window_returns) > 1 else None
        window_vols = volumes[max(0, i - rolling_window + 1): i + 1]
        vol_std = pstdev(window_vols) if len(window_vols) > 1 else 0.0
        volume_zscore = None if vol_std == 0 else (c.volume - mean(window_vols)) / vol_std
        rows.append({
            "timestamp": c.timestamp.isoformat(),
            "symbol": c.symbol,
            "timeframe": c.timeframe,
            "close": _round(c.close),
            "simple_return_1": _round(simple_return),
            "log_return_1": _round(log_return),
            "hl_range_pct": _round(rng),
            "close_position": _round(close_pos),
            "rolling_return_mean": _round(rolling_mean),
            "rolling_volatility": _round(rolling_vol),
            "volume_zscore": _round(volume_zscore),
        })
    return FeatureMatrix("qrds.feature_matrix.v1", dql_report.status, dql_report.dqs, rows, "PASS", False, [])
