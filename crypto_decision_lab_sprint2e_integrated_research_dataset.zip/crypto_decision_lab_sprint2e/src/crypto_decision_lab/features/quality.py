from dataclasses import dataclass
from statistics import pstdev

REQUIRED_FEATURES = ["simple_return_1", "log_return_1", "hl_range_pct", "close_position", "rolling_return_mean", "rolling_volatility", "volume_zscore"]

@dataclass(frozen=True)
class FeatureQualityReport:
    schema: str
    rows: int
    score: float
    status: str
    null_ratio: float
    finite_ratio: float
    low_variance_features: list
    issues: list
    model_blocked: bool


def _is_finite(v):
    return isinstance(v, (int, float)) and v == v and v not in (float("inf"), float("-inf"))


def generate_feature_quality_report(feature_matrix, min_rows=30):
    if feature_matrix.status != "PASS":
        return FeatureQualityReport("qrds.feature_quality_report.v1", 0, 0.0, "BLOCKED", 1.0, 0.0, [], feature_matrix.issues, True)
    rows = feature_matrix.rows
    issues = []
    if len(rows) < min_rows:
        issues.append("insufficient_rows")
    missing_required = [f for f in REQUIRED_FEATURES if f not in rows[0]] if rows else REQUIRED_FEATURES
    if missing_required:
        issues.append("missing_required_features")
    values = []
    nulls = 0
    finite = 0
    total = 0
    for r in rows:
        for f in REQUIRED_FEATURES:
            total += 1
            v = r.get(f)
            if v is None:
                nulls += 1
            elif _is_finite(v):
                finite += 1
            values.append((f, v))
    null_ratio = round(nulls / total, 4) if total else 1.0
    finite_ratio = round(finite / max(1, total - nulls), 4)
    low_var = []
    for f in REQUIRED_FEATURES:
        nums = [r.get(f) for r in rows if _is_finite(r.get(f))]
        if len(nums) >= 2 and pstdev(nums) == 0:
            low_var.append(f)
    if low_var:
        issues.append("low_variance_features")
    score = round(max(0.0, 1.0 - null_ratio) * finite_ratio, 4)
    status = "PASS" if score >= 0.8 and not missing_required and len(rows) >= min_rows else "BLOCKED"
    return FeatureQualityReport("qrds.feature_quality_report.v1", len(rows), score, status, null_ratio, finite_ratio, low_var, issues, status == "BLOCKED")
