from crypto_decision_lab.io.loader import load_binance_klines_csv
from crypto_decision_lab.dql.report import generate_data_quality_report
from crypto_decision_lab.features.engineering import generate_feature_matrix
from crypto_decision_lab.features.quality import generate_feature_quality_report
from crypto_decision_lab.regimes.diagnostics import generate_regime_diagnostics
from crypto_decision_lab.targets.labels import generate_target_label_matrix, generate_target_quality_report
from crypto_decision_lab.research.dataset import build_integrated_research_dataset


def run_offline_research_pipeline(csv_path):
    candles = load_binance_klines_csv(csv_path)
    dql = generate_data_quality_report(candles)
    features = generate_feature_matrix(candles, dql)
    feature_quality = generate_feature_quality_report(features)
    regimes = generate_regime_diagnostics(features, feature_quality)
    targets = generate_target_label_matrix(candles, dql, feature_quality, regimes)
    target_quality = generate_target_quality_report(targets)
    dataset = build_integrated_research_dataset(features, feature_quality, regimes, targets, target_quality, dql)
    return {
        "candles": candles,
        "dql": dql,
        "features": features,
        "feature_quality": feature_quality,
        "regimes": regimes,
        "targets": targets,
        "target_quality": target_quality,
        "dataset": dataset,
    }
