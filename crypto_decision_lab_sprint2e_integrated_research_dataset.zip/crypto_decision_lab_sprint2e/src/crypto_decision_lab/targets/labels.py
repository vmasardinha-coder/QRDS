from dataclasses import dataclass
from collections import Counter

@dataclass(frozen=True)
class TargetLabelMatrix:
    schema: str
    rows: list
    horizons: list
    status: str
    model_blocked: bool
    issues: list

@dataclass(frozen=True)
class TargetQualityReport:
    schema: str
    rows: int
    score: float
    status: str
    valid_ratio: float
    label_counts: dict
    issues: list
    model_blocked: bool


def generate_target_label_matrix(candles, dql_report, feature_quality_report, regime_diagnostics, horizons=(1, 3, 6), flat_threshold=0.0005):
    if dql_report.status != "PASS":
        return TargetLabelMatrix("qrds.target_label_matrix.v1", [], list(horizons), "BLOCKED", True, [f"Target generation blocked by DQL: status={dql_report.status}, dqs={dql_report.dqs}"])
    if feature_quality_report.status != "PASS" or regime_diagnostics.status != "PASS":
        return TargetLabelMatrix("qrds.target_label_matrix.v1", [], list(horizons), "BLOCKED", True, ["target_generation_blocked_by_previous_gate"])
    rows = []
    for i, c in enumerate(candles):
        for h in horizons:
            future_i = i + h
            if future_i >= len(candles):
                fut = None
                label = "unknown"
                valid = False
            else:
                fut = round((candles[future_i].close / c.close) - 1.0, 8)
                if fut > flat_threshold:
                    label = "up"
                elif fut < -flat_threshold:
                    label = "down"
                else:
                    label = "flat"
                valid = True
            rows.append({"timestamp": c.timestamp.isoformat(), "horizon": h, "future_return": fut, "direction_label": label, "target_valid": valid})
    return TargetLabelMatrix("qrds.target_label_matrix.v1", rows, list(horizons), "PASS", False, [])


def generate_target_quality_report(target_matrix):
    if target_matrix.status != "PASS":
        return TargetQualityReport("qrds.target_quality_report.v1", 0, 0.0, "BLOCKED", 0.0, {}, target_matrix.issues, True)
    rows = target_matrix.rows
    valid = sum(1 for r in rows if r["target_valid"])
    valid_ratio = round(valid / max(1, len(rows)), 4)
    counts = dict(Counter(r["direction_label"] for r in rows))
    issues = []
    if valid_ratio < 0.8:
        issues.append("low_valid_ratio")
    status = "PASS" if valid_ratio >= 0.8 else "BLOCKED"
    return TargetQualityReport("qrds.target_quality_report.v1", len(rows), valid_ratio, status, valid_ratio, counts, issues, status == "BLOCKED")
