# QRDS/QOS - Sprint 2E - Integrated Research Dataset Offline

This sprint builds an offline, versioned research dataset that joins:

- DQL report
- Feature matrix
- Feature quality report
- Regime diagnostics
- Target labels

No exchange connection, no API key, no WebSocket, no live order, no capital real.

## Validate

```bash
cd /workspaces/QRDS/crypto_decision_lab_sprint2e
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_integrated_research_dataset.py
```
