from collections import Counter
from crypto_decision_lab.pipeline import run_offline_research_pipeline
from crypto_decision_lab.research.dataset import export_integrated_research_dataset

clean = run_offline_research_pipeline("data/fixtures/clean_48.csv")
dirty = run_offline_research_pipeline("data/fixtures/dirty_48.csv")
paths = export_integrated_research_dataset(clean["dataset"], "reports/sprint2e")

labels = Counter(r["direction_label"] for r in clean["dataset"].rows)
regimes = Counter(r["regime_code"] for r in clean["dataset"].rows if r.get("regime_code"))

print("=== Sprint 2E Integrated Research Dataset Offline ===")
print(f"Research schema: {clean['dataset'].schema}")
print(f"DQL status: {clean['dql'].status}")
print(f"Feature quality status: {clean['feature_quality'].status}")
print(f"Regime status: {clean['regimes'].status}")
print(f"Target quality status: {clean['target_quality'].status}")
print(f"Integrated dataset status: {clean['dataset'].status}")
print(f"Model blocked: {clean['dataset'].model_blocked}")
print(f"Quality score: {clean['dataset'].quality_score:.4f}")
print(f"Rows: {clean['dataset'].row_count}")
print(f"Horizons: {clean['dataset'].horizons}")
print(f"Label counts: {dict(labels)}")
print(f"Regime variants: {len(regimes)}")
print(f"First row horizon: {clean['dataset'].rows[0]['horizon']}")
print(f"Last row target label: {clean['dataset'].rows[-1]['direction_label']}")
print(f"Dirty DQL status: {dirty['dql'].status}")
print(f"Dirty integrated status: {dirty['dataset'].status}")
print(f"Dirty integrated gate: {dirty['dataset'].issues[0] if dirty['dataset'].issues else 'none'}")
print(f"Generated files: {paths}")
