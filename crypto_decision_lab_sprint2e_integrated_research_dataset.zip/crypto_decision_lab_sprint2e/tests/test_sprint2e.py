from crypto_decision_lab.pipeline import run_offline_research_pipeline
from crypto_decision_lab.research.dataset import export_integrated_research_dataset
from crypto_decision_lab.targets.labels import generate_target_quality_report

CLEAN = "data/fixtures/clean_48.csv"
DIRTY = "data/fixtures/dirty_48.csv"


def test_clean_dql_pass():
    r = run_offline_research_pipeline(CLEAN)
    assert r["dql"].status == "PASS"
    assert r["dql"].dqs == 1.0


def test_dirty_dql_blocked():
    r = run_offline_research_pipeline(DIRTY)
    assert r["dql"].status == "BLOCKED"
    assert r["dql"].model_blocked is True


def test_feature_matrix_schema_and_rows():
    r = run_offline_research_pipeline(CLEAN)
    assert r["features"].schema == "qrds.feature_matrix.v1"
    assert len(r["features"].rows) == 48


def test_feature_quality_pass():
    r = run_offline_research_pipeline(CLEAN)
    assert r["feature_quality"].status == "PASS"
    assert r["feature_quality"].score > 0.9


def test_regime_schema_and_pass():
    r = run_offline_research_pipeline(CLEAN)
    assert r["regimes"].schema == "qrds.regime_diagnostics.v1"
    assert r["regimes"].status == "PASS"


def test_regime_rows_match_features():
    r = run_offline_research_pipeline(CLEAN)
    assert len(r["regimes"].regime_rows) == len(r["features"].rows)


def test_target_matrix_schema():
    r = run_offline_research_pipeline(CLEAN)
    assert r["targets"].schema == "qrds.target_label_matrix.v1"


def test_target_horizons():
    r = run_offline_research_pipeline(CLEAN)
    assert r["targets"].horizons == [1, 3, 6]


def test_target_rows_equal_48_times_3():
    r = run_offline_research_pipeline(CLEAN)
    assert len(r["targets"].rows) == 144


def test_target_quality_pass():
    r = run_offline_research_pipeline(CLEAN)
    assert r["target_quality"].status == "PASS"
    assert r["target_quality"].valid_ratio == 0.9306


def test_target_unknowns_exist_at_tail():
    r = run_offline_research_pipeline(CLEAN)
    unknown = [x for x in r["targets"].rows if x["direction_label"] == "unknown"]
    assert len(unknown) == 10


def test_integrated_schema():
    r = run_offline_research_pipeline(CLEAN)
    assert r["dataset"].schema == "qrds.integrated_research_dataset.v1"


def test_integrated_pass():
    r = run_offline_research_pipeline(CLEAN)
    assert r["dataset"].status == "PASS"
    assert r["dataset"].model_blocked is False


def test_integrated_rows():
    r = run_offline_research_pipeline(CLEAN)
    assert r["dataset"].row_count == 144


def test_integrated_row_contains_features_regime_and_target():
    r = run_offline_research_pipeline(CLEAN)
    row = r["dataset"].rows[5]
    assert "simple_return_1" in row
    assert "regime_code" in row
    assert "direction_label" in row


def test_integrated_lineage_contains_all_gates():
    r = run_offline_research_pipeline(CLEAN)
    gates = r["dataset"].lineage["gates"]
    assert set(gates) == {"dql", "feature_matrix", "feature_quality", "regime_diagnostics", "target_matrix", "target_quality"}


def test_integrated_quality_score_high():
    r = run_offline_research_pipeline(CLEAN)
    assert r["dataset"].quality_score >= 0.9


def test_dirty_integrated_blocked():
    r = run_offline_research_pipeline(DIRTY)
    assert r["dataset"].status == "BLOCKED"
    assert r["dataset"].model_blocked is True


def test_dirty_integrated_issue_names_gate():
    r = run_offline_research_pipeline(DIRTY)
    assert any("dql=BLOCKED" in issue for issue in r["dataset"].issues)


def test_export_integrated_dataset(tmp_path):
    r = run_offline_research_pipeline(CLEAN)
    paths = export_integrated_research_dataset(r["dataset"], tmp_path)
    assert paths["json"].endswith("integrated_research_dataset.json")
    assert paths["txt"].endswith("integrated_research_dataset.txt")


def test_export_files_exist(tmp_path):
    r = run_offline_research_pipeline(CLEAN)
    paths = export_integrated_research_dataset(r["dataset"], tmp_path)
    import pathlib
    assert pathlib.Path(paths["json"]).exists()
    assert pathlib.Path(paths["txt"]).exists()


def test_no_signal_or_backtest_fields_in_integrated_rows():
    r = run_offline_research_pipeline(CLEAN)
    row = r["dataset"].rows[0]
    assert "signal" not in row
    assert "position" not in row
    assert "pnl" not in row
    assert "order" not in row
