from __future__ import annotations

from dataclasses import dataclass, asdict, replace
from pathlib import Path
from typing import Dict, List, Any
import json

SAFETY_POLICY = "PUBLIC_LIVE_DATA_PIPELINE_NO_AUTH_NO_ORDERS_NO_REAL_CAPITAL"

@dataclass(frozen=True)
class NormalizedCandle:
    exchange: str
    route: str
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    symbol: str = "BTCUSDT"
    timeframe: str = "1m"

@dataclass(frozen=True)
class ExchangeRoute:
    exchange: str
    role: str
    route_status: str
    route_kind: str
    live_enabled: bool
    fixture_replay_used: bool
    network_calls_executed: bool
    api_key_required: bool
    account_connection_required: bool
    orders_generated: bool
    notes: List[str]

@dataclass(frozen=True)
class PublicLiveDataPipelineReport:
    schema: str
    pipeline_status: str
    model_blocked: bool
    safety_policy: str
    simulation_exchange: str
    real_base_target_exchanges: List[str]
    real_base_active_now: List[str]
    real_base_pending: List[str]
    exchange_routes: Dict[str, ExchangeRoute]
    normalized_candles_per_route: Dict[str, int]
    total_normalized_candles: int
    live_pipeline_enabled: bool
    fixture_replay_used: bool
    network_calls_executed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    issues: List[str]
    action: str
    next_required_gate: str
    generated_files: Dict[str, str]


def _fixture_candles(exchange: str, route: str, n: int = 5) -> List[NormalizedCandle]:
    base = 1704067200000
    candles = []
    for i in range(n):
        o = 50000.0 + i * 10
        candles.append(NormalizedCandle(
            exchange=exchange,
            route=route,
            timestamp=base + i * 60000,
            open=o,
            high=o + 100.0,
            low=o - 100.0,
            close=o + 25.0,
            volume=100.0 + i,
        ))
    return candles


def build_exchange_routes() -> Dict[str, ExchangeRoute]:
    return {
        "binance": ExchangeRoute(
            exchange="binance",
            role="SIMULATION_ONLY_PUBLIC_DATA_ALLOWED",
            route_status="PASS",
            route_kind="SIMULATION_FIXTURE_REPLAY",
            live_enabled=False,
            fixture_replay_used=True,
            network_calls_executed=False,
            api_key_required=False,
            account_connection_required=False,
            orders_generated=False,
            notes=["binance_not_real_base", "public_data_and_simulation_only"],
        ),
        "okx": ExchangeRoute(
            exchange="okx",
            role="REAL_BASE_CANDIDATE_PUBLIC_HTTP_OK",
            route_status="PASS",
            route_kind="PUBLIC_HTTP_READY_FIXTURE_DEFAULT",
            live_enabled=False,
            fixture_replay_used=True,
            network_calls_executed=False,
            api_key_required=False,
            account_connection_required=False,
            orders_generated=False,
            notes=["active_real_base_candidate", "public_http_smoke_previously_ok"],
        ),
        "bybit": ExchangeRoute(
            exchange="bybit",
            role="REAL_BASE_CANDIDATE_PENDING_403",
            route_status="PENDING",
            route_kind="PENDING_BLOCKED_BY_403",
            live_enabled=False,
            fixture_replay_used=False,
            network_calls_executed=False,
            api_key_required=False,
            account_connection_required=False,
            orders_generated=False,
            notes=["public_http_blocked_by_403_in_codespaces", "not_blocking_core_progress"],
        ),
    }


def validate_pipeline_safety(routes: Dict[str, ExchangeRoute]) -> List[str]:
    issues: List[str] = []
    if routes["binance"].role != "SIMULATION_ONLY_PUBLIC_DATA_ALLOWED":
        issues.append("binance_role_not_simulation_only")
    if routes["okx"].role != "REAL_BASE_CANDIDATE_PUBLIC_HTTP_OK":
        issues.append("okx_role_not_active_real_base_candidate")
    if routes["bybit"].role != "REAL_BASE_CANDIDATE_PENDING_403":
        issues.append("bybit_role_not_pending_403")
    for name, route in routes.items():
        if route.api_key_required:
            issues.append(f"{name}:api_key_required")
        if route.account_connection_required:
            issues.append(f"{name}:account_connection_required")
        if route.orders_generated:
            issues.append(f"{name}:orders_generated")
        if route.network_calls_executed:
            issues.append(f"{name}:network_calls_unexpected_in_default_pipeline")
    return issues


def build_public_live_data_pipeline_report(output_dir: str | Path = "reports/sprint4l") -> PublicLiveDataPipelineReport:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    routes = build_exchange_routes()
    issues = validate_pipeline_safety(routes)
    candles = {
        "binance_simulation": _fixture_candles("binance", "simulation"),
        "okx_public": _fixture_candles("okx", "public_http_ready"),
    }
    counts = {name: len(value) for name, value in candles.items()}
    total = sum(counts.values())
    status = "PASS_WITH_PENDING_BYBIT" if not issues else "BLOCKED"
    report = PublicLiveDataPipelineReport(
        schema="qrds.public_live_data_pipeline_report.v1",
        pipeline_status=status,
        model_blocked=bool(issues),
        safety_policy=SAFETY_POLICY,
        simulation_exchange="binance",
        real_base_target_exchanges=["okx", "bybit"],
        real_base_active_now=["okx"],
        real_base_pending=["bybit"],
        exchange_routes=routes,
        normalized_candles_per_route=counts,
        total_normalized_candles=total,
        live_pipeline_enabled=False,
        fixture_replay_used=True,
        network_calls_executed=False,
        authenticated_connection_used=False,
        api_key_required=False,
        api_key_present=False,
        account_connection_required=False,
        websocket_used=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        issues=issues + ["bybit_public_http_blocked_by_403_pending_not_blocking"],
        action="ROUTE_OKX_PUBLIC_DATA_AND_BINANCE_SIMULATION_KEEP_BYBIT_PENDING",
        next_required_gate="PUBLIC_LIVE_DATA_PIPELINE_VALIDATION_REQUIRED",
        generated_files={},
    )
    json_path = out / "public_live_data_pipeline_report.json"
    txt_path = out / "public_live_data_pipeline_report.txt"
    json_path.write_text(json.dumps(_to_json_dict(report), indent=2), encoding="utf-8")
    txt_path.write_text(render_report_text(report), encoding="utf-8")
    return replace(report, generated_files={"json": str(json_path), "txt": str(txt_path)})


def build_dirty_pipeline_report() -> PublicLiveDataPipelineReport:
    routes = build_exchange_routes()
    routes["binance"] = ExchangeRoute(
        exchange="binance",
        role="REAL_BASE_INVALID",
        route_status="FAIL",
        route_kind="INVALID_REAL_BASE",
        live_enabled=True,
        fixture_replay_used=False,
        network_calls_executed=True,
        api_key_required=True,
        account_connection_required=True,
        orders_generated=True,
        notes=["invalid_dirty_case"],
    )
    issues = validate_pipeline_safety(routes)
    return PublicLiveDataPipelineReport(
        schema="qrds.public_live_data_pipeline_report.v1",
        pipeline_status="BLOCKED",
        model_blocked=True,
        safety_policy=SAFETY_POLICY,
        simulation_exchange="binance",
        real_base_target_exchanges=["okx", "bybit"],
        real_base_active_now=["okx"],
        real_base_pending=["bybit"],
        exchange_routes=routes,
        normalized_candles_per_route={},
        total_normalized_candles=0,
        live_pipeline_enabled=True,
        fixture_replay_used=False,
        network_calls_executed=True,
        authenticated_connection_used=True,
        api_key_required=True,
        api_key_present=True,
        account_connection_required=True,
        websocket_used=True,
        real_capital_used=True,
        exchange_connected=True,
        orders_generated=True,
        issues=issues,
        action="NO_PUBLIC_LIVE_DATA_PIPELINE_BLOCKED",
        next_required_gate="FIX_EXCHANGE_ROLE_POLICY_REQUIRED",
        generated_files={},
    )


def _to_json_dict(report: PublicLiveDataPipelineReport) -> Dict[str, Any]:
    data = asdict(report)
    data["exchange_routes"] = {k: asdict(v) if hasattr(v, "__dataclass_fields__") else v for k, v in report.exchange_routes.items()}
    return data


def render_report_text(report: PublicLiveDataPipelineReport) -> str:
    return "\n".join([
        "=== Sprint 4L Public Live Data Pipeline OKX + Binance Simulation ===",
        f"Pipeline schema: {report.schema}",
        f"Pipeline status: {report.pipeline_status}",
        f"Model blocked: {report.model_blocked}",
        f"Safety policy: {report.safety_policy}",
        f"Simulation exchange: {report.simulation_exchange}",
        f"Binance route: {report.exchange_routes['binance'].route_kind}",
        f"OKX route: {report.exchange_routes['okx'].route_kind}",
        f"Bybit route: {report.exchange_routes['bybit'].route_kind}",
        f"Real base target exchanges: {report.real_base_target_exchanges}",
        f"Real base active now: {report.real_base_active_now}",
        f"Real base pending: {report.real_base_pending}",
        f"Live pipeline enabled: {report.live_pipeline_enabled}",
        f"Fixture replay used: {report.fixture_replay_used}",
        f"Network calls executed: {report.network_calls_executed}",
        f"Authenticated connection used: {report.authenticated_connection_used}",
        f"API key required: {report.api_key_required}",
        f"API key present: {report.api_key_present}",
        f"Account connection required: {report.account_connection_required}",
        f"WebSocket used: {report.websocket_used}",
        f"Real capital used: {report.real_capital_used}",
        f"Exchange connected: {report.exchange_connected}",
        f"Orders generated: {report.orders_generated}",
        f"Normalized candles per route: {report.normalized_candles_per_route}",
        f"Total normalized candles: {report.total_normalized_candles}",
        f"Issues: {report.issues if report.issues else 'none'}",
        f"Action: {report.action}",
        f"Next required gate: {report.next_required_gate}",
        f"Generated files: {report.generated_files}",
    ])
