import json
from pathlib import Path

from crypto_decision_lab.live_data_pipeline import (
    build_exchange_routes,
    validate_pipeline_safety,
    build_public_live_data_pipeline_report,
    build_dirty_pipeline_report,
    render_report_text,
    _fixture_candles,
)


def test_01_routes_exist():
    routes = build_exchange_routes()
    assert set(routes) == {"binance", "okx", "bybit"}


def test_02_binance_simulation_only():
    assert build_exchange_routes()["binance"].role == "SIMULATION_ONLY_PUBLIC_DATA_ALLOWED"


def test_03_okx_active_real_base_candidate():
    assert build_exchange_routes()["okx"].role == "REAL_BASE_CANDIDATE_PUBLIC_HTTP_OK"


def test_04_bybit_pending_403():
    assert build_exchange_routes()["bybit"].role == "REAL_BASE_CANDIDATE_PENDING_403"


def test_05_no_route_requires_api_key():
    assert not any(r.api_key_required for r in build_exchange_routes().values())


def test_06_no_route_requires_account():
    assert not any(r.account_connection_required for r in build_exchange_routes().values())


def test_07_no_route_generates_orders():
    assert not any(r.orders_generated for r in build_exchange_routes().values())


def test_08_no_route_executes_network_by_default():
    assert not any(r.network_calls_executed for r in build_exchange_routes().values())


def test_09_validate_pipeline_safety_clean():
    assert validate_pipeline_safety(build_exchange_routes()) == []


def test_10_fixture_candles_count():
    assert len(_fixture_candles("okx", "public")) == 5


def test_11_fixture_timestamps_ordered():
    cs = _fixture_candles("okx", "public")
    assert all(cs[i].timestamp > cs[i-1].timestamp for i in range(1, len(cs)))


def test_12_fixture_ohlc_valid():
    for c in _fixture_candles("okx", "public"):
        assert c.low <= c.open <= c.high
        assert c.low <= c.close <= c.high


def test_13_report_schema():
    assert build_public_live_data_pipeline_report().schema == "qrds.public_live_data_pipeline_report.v1"


def test_14_report_status():
    assert build_public_live_data_pipeline_report().pipeline_status == "PASS_WITH_PENDING_BYBIT"


def test_15_report_model_not_blocked():
    assert build_public_live_data_pipeline_report().model_blocked is False


def test_16_report_simulation_exchange():
    assert build_public_live_data_pipeline_report().simulation_exchange == "binance"


def test_17_report_real_base_targets():
    assert build_public_live_data_pipeline_report().real_base_target_exchanges == ["okx", "bybit"]


def test_18_report_real_base_active():
    assert build_public_live_data_pipeline_report().real_base_active_now == ["okx"]


def test_19_report_real_base_pending():
    assert build_public_live_data_pipeline_report().real_base_pending == ["bybit"]


def test_20_report_fixture_default():
    assert build_public_live_data_pipeline_report().fixture_replay_used is True


def test_21_report_no_network_default():
    assert build_public_live_data_pipeline_report().network_calls_executed is False


def test_22_report_no_auth_connection():
    r = build_public_live_data_pipeline_report()
    assert r.authenticated_connection_used is False
    assert r.account_connection_required is False


def test_23_report_no_api_key():
    r = build_public_live_data_pipeline_report()
    assert r.api_key_required is False
    assert r.api_key_present is False


def test_24_report_no_websocket():
    assert build_public_live_data_pipeline_report().websocket_used is False


def test_25_report_no_real_capital():
    assert build_public_live_data_pipeline_report().real_capital_used is False


def test_26_report_no_exchange_connected():
    assert build_public_live_data_pipeline_report().exchange_connected is False


def test_27_report_no_orders():
    assert build_public_live_data_pipeline_report().orders_generated is False


def test_28_report_counts():
    r = build_public_live_data_pipeline_report()
    assert r.normalized_candles_per_route == {"binance_simulation": 5, "okx_public": 5}


def test_29_report_total_count():
    assert build_public_live_data_pipeline_report().total_normalized_candles == 10


def test_30_report_bybit_pending_issue_note():
    assert "bybit_public_http_blocked_by_403_pending_not_blocking" in build_public_live_data_pipeline_report().issues


def test_31_report_action():
    assert build_public_live_data_pipeline_report().action == "ROUTE_OKX_PUBLIC_DATA_AND_BINANCE_SIMULATION_KEEP_BYBIT_PENDING"


def test_32_report_next_gate():
    assert build_public_live_data_pipeline_report().next_required_gate == "PUBLIC_LIVE_DATA_PIPELINE_VALIDATION_REQUIRED"


def test_33_json_export_exists(tmp_path):
    r = build_public_live_data_pipeline_report(tmp_path)
    assert Path(r.generated_files["json"]).exists()


def test_34_txt_export_exists(tmp_path):
    r = build_public_live_data_pipeline_report(tmp_path)
    assert Path(r.generated_files["txt"]).exists()


def test_35_json_export_schema(tmp_path):
    r = build_public_live_data_pipeline_report(tmp_path)
    data = json.loads(Path(r.generated_files["json"]).read_text())
    assert data["schema"] == "qrds.public_live_data_pipeline_report.v1"


def test_36_text_render_contains_status():
    assert "Pipeline status: PASS_WITH_PENDING_BYBIT" in render_report_text(build_public_live_data_pipeline_report())


def test_37_text_render_contains_okx_route():
    assert "OKX route" in render_report_text(build_public_live_data_pipeline_report())


def test_38_text_render_contains_binance_route():
    assert "Binance route" in render_report_text(build_public_live_data_pipeline_report())


def test_39_text_render_contains_bybit_route():
    assert "Bybit route" in render_report_text(build_public_live_data_pipeline_report())


def test_40_dirty_status_blocked():
    assert build_dirty_pipeline_report().pipeline_status == "BLOCKED"


def test_41_dirty_model_blocked():
    assert build_dirty_pipeline_report().model_blocked is True


def test_42_dirty_issues_include_api_key():
    assert "binance:api_key_required" in build_dirty_pipeline_report().issues


def test_43_dirty_issues_include_account():
    assert "binance:account_connection_required" in build_dirty_pipeline_report().issues


def test_44_dirty_issues_include_orders():
    assert "binance:orders_generated" in build_dirty_pipeline_report().issues


def test_45_dirty_issues_include_network():
    assert "binance:network_calls_unexpected_in_default_pipeline" in build_dirty_pipeline_report().issues


def test_46_dirty_binance_role_invalid():
    assert "binance_role_not_simulation_only" in build_dirty_pipeline_report().issues


def test_47_dirty_action():
    assert build_dirty_pipeline_report().action == "NO_PUBLIC_LIVE_DATA_PIPELINE_BLOCKED"


def test_48_safety_policy():
    assert build_public_live_data_pipeline_report().safety_policy == "PUBLIC_LIVE_DATA_PIPELINE_NO_AUTH_NO_ORDERS_NO_REAL_CAPITAL"


def test_49_bybit_route_status_pending():
    assert build_exchange_routes()["bybit"].route_status == "PENDING"


def test_50_okx_route_status_pass():
    assert build_exchange_routes()["okx"].route_status == "PASS"
