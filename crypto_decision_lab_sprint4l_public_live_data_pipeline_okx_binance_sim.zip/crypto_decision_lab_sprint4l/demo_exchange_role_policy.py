from crypto_decision_lab.live_data_pipeline import build_public_live_data_pipeline_report, build_dirty_pipeline_report, render_report_text

report = build_public_live_data_pipeline_report()
print(render_report_text(report))

dirty = build_dirty_pipeline_report()
print(f"Dirty pipeline status: {dirty.pipeline_status}")
print(f"Dirty action: {dirty.action}")
print(f"Dirty issues: {dirty.issues}")
