# Sprint 4L - Public Live Data Pipeline OKX + Binance Simulation

This sprint builds a safe public-data pipeline routing layer:

- Binance = simulation/public data benchmark only
- OKX = active public-data route for future real-base candidate
- Bybit = future real-base candidate, pending HTTP 403 remediation

No API key, no account connection, no WebSocket auth, no real orders, no real capital.
