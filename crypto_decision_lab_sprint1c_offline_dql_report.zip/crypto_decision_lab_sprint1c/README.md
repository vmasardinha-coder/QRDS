# Crypto Decision Lab — Sprint 1C

Sprint 1C: Dataset histórico offline maior + relatório DQL mais realista.

Escopo permitido:
- CSV/ZIP local.
- Dataset offline maior.
- Relatório de qualidade de dados.
- Testes unitários.
- Export de relatório local em JSON e TXT.

Ainda proibido:
- Binance live.
- API key.
- WebSocket.
- Ordens.
- Capital real.

## Comando de validação

```bash
cd /workspaces/QRDS/crypto_decision_lab_sprint1c && \
python -m pip install -e . && \
PYTHONPATH="$(pwd)/src" pytest -q tests/ && \
PYTHONPATH="$(pwd)/src" python demo_data_quality_report_large.py
```

Resultado esperado:
- Testes passando.
- Dataset clean com `Status: PASS`.
- Dataset com problemas com `Status: BLOCKED`.
