from pathlib import Path
import json
import math
import pytest
from crypto_decision_lab.ingestion.binance_klines import load_binance_klines_csv
from crypto_decision_lab.dql.report import generate_simple_dql
from crypto_decision_lab.features.engineering import generate_feature_matrix
from crypto_decision_lab.features.quality import generate_feature_quality_report
from crypto_decision_lab.regimes.diagnostics import generate_regime_diagnostics
from crypto_decision_lab.targets.labels import classify_return, generate_target_label_matrix, generate_target_quality_report
from crypto_decision_lab.export.artifacts import export_json, export_txt

FIXTURE = "data/fixtures/BTCUSDT-1h-48-clean.csv"


def pipeline():
    candles = load_binance_klines_csv(FIXTURE)
    dql = generate_simple_dql(candles)
    features = generate_feature_matrix(candles, dql)
    quality = generate_feature_quality_report(features)
    regime = generate_regime_diagnostics(features, quality)
    labels = generate_target_label_matrix(features, quality, regime, horizons=(1,3,6), threshold=0.0005)
    target_quality = generate_target_quality_report(labels)
    return candles, dql, features, quality, regime, labels, target_quality


def test_01_loads_48_candles():
    assert len(load_binance_klines_csv(FIXTURE)) == 48


def test_02_dql_pass():
    assert generate_simple_dql(load_binance_klines_csv(FIXTURE)).status == "PASS"


def test_03_dql_blocked_when_forced():
    assert generate_simple_dql(load_binance_klines_csv(FIXTURE), force_blocked=True).model_blocked


def test_04_feature_matrix_rows():
    *_, features, quality, regime, labels, tq = pipeline()
    assert len(features.rows) == 48


def test_05_feature_schema():
    *_, features, quality, regime, labels, tq = pipeline()
    assert features.schema == "qrds.feature_matrix.v1"


def test_06_feature_quality_pass():
    *_, quality, regime, labels, tq = pipeline()[3:]
    assert quality.status == "PASS"


def test_07_regime_pass():
    *_, regime, labels, tq = pipeline()[4:]
    assert regime.status == "PASS"


def test_08_classify_up():
    assert classify_return(0.01) == "up"


def test_09_classify_down():
    assert classify_return(-0.01) == "down"


def test_10_classify_flat():
    assert classify_return(0.0) == "flat"


def test_11_classify_unknown():
    assert classify_return(None) == "unknown"


def test_12_label_matrix_schema():
    labels = pipeline()[5]
    assert labels.schema == "qrds.target_label_matrix.v1"


def test_13_label_rows_are_48_times_3_horizons():
    labels = pipeline()[5]
    assert len(labels.rows) == 144


def test_14_last_horizon_has_unknowns():
    labels = pipeline()[5]
    assert any(r.direction_label == "unknown" for r in labels.rows)


def test_15_target_quality_schema():
    tq = pipeline()[6]
    assert tq.schema == "qrds.target_quality_report.v1"


def test_16_target_quality_pass():
    tq = pipeline()[6]
    assert tq.status == "PASS"


def test_17_valid_ratio_high():
    tq = pipeline()[6]
    assert tq.valid_ratio >= 0.80


def test_18_has_multiple_classes():
    tq = pipeline()[6]
    assert len([k for k in tq.label_counts if k != "unknown"]) >= 2


def test_19_dirty_dql_blocks_features():
    candles = load_binance_klines_csv(FIXTURE)
    dql = generate_simple_dql(candles, force_blocked=True)
    with pytest.raises(ValueError):
        generate_feature_matrix(candles, dql)


def test_20_exports_json_and_txt(tmp_path):
    tq = pipeline()[6]
    j = export_json(tq, tmp_path / "target_quality.json")
    t = export_txt(["ok"], tmp_path / "target_quality.txt")
    assert json.loads(j.read_text())["schema"] == "qrds.target_quality_report.v1"
    assert t.read_text().strip() == "ok"
