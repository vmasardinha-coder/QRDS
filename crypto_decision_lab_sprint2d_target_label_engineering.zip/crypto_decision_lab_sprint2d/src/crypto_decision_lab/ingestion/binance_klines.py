import csv
from datetime import datetime, timezone
from pathlib import Path
from crypto_decision_lab.domain.models import MarketCandle


def _ts(ms):
    return datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc)


def load_binance_klines_csv(path):
    candles = []
    with Path(path).open("r", newline="") as f:
        for row in csv.reader(f):
            if not row or row[0].lower() in {"open_time", "timestamp"}:
                continue
            candles.append(MarketCandle(_ts(row[0]), float(row[1]), float(row[2]), float(row[3]), float(row[4]), float(row[5])))
    return candles
