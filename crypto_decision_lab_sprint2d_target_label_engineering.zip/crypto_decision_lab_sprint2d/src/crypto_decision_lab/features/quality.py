import math
from dataclasses import asdict
from crypto_decision_lab.domain.models import FeatureQualityReport

REQUIRED_FEATURES = ["simple_return_1", "log_return_1", "range_pct", "close_position", "rolling_mean_return", "rolling_volatility", "volume_zscore"]


def generate_feature_quality_report(matrix, min_rows=20, max_null_ratio=0.25):
    if matrix.model_blocked:
        return FeatureQualityReport("qrds.feature_quality_report.v1", "BLOCKED", True, 0.0, len(matrix.rows), 1.0, 0.0, [], ["feature_matrix_blocked"])
    rows = [asdict(r) for r in matrix.rows]
    values = []
    nulls = 0
    nonfinite = 0
    for r in rows:
        for key in REQUIRED_FEATURES:
            v = r.get(key)
            values.append(v)
            if v is None:
                nulls += 1
            elif not math.isfinite(float(v)):
                nonfinite += 1
    total = len(values) or 1
    null_ratio = nulls / total
    finite_ratio = 1.0 - (nonfinite / total)
    low_variance = []
    for key in REQUIRED_FEATURES:
        vals = [float(r[key]) for r in rows if r.get(key) is not None and math.isfinite(float(r[key]))]
        if len(set(round(v, 12) for v in vals)) <= 1 and vals:
            low_variance.append(key)
    issues = []
    if len(rows) < min_rows:
        issues.append("insufficient_rows")
    if null_ratio > max_null_ratio:
        issues.append("high_null_ratio")
    if finite_ratio < 1.0:
        issues.append("nonfinite_values")
    score = max(0.0, min(1.0, 1.0 - null_ratio - (1.0 - finite_ratio) - 0.01 * len(low_variance)))
    status = "PASS" if not issues else "BLOCKED"
    return FeatureQualityReport("qrds.feature_quality_report.v1", status, status != "PASS", round(score, 4), len(rows), round(null_ratio, 4), round(finite_ratio, 4), low_variance, issues)
