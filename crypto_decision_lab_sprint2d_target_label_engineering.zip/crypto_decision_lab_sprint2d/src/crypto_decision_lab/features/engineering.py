import math
from crypto_decision_lab.domain.models import FeatureRow, FeatureMatrix


def _mean(values):
    return sum(values) / len(values) if values else None


def _std(values):
    if len(values) < 2:
        return None
    m = _mean(values)
    return math.sqrt(sum((x - m) ** 2 for x in values) / len(values))


def generate_feature_matrix(candles, dql_report, window=5):
    if dql_report.model_blocked or dql_report.status != "PASS":
        raise ValueError(f"Feature generation blocked by DQL: status={dql_report.status}, dqs={dql_report.dqs}")
    rows = []
    returns = []
    volumes = [c.volume for c in candles]
    vol_mean = _mean(volumes) or 0.0
    vol_std = _std(volumes) or 1.0
    for i, c in enumerate(candles):
        prev_close = candles[i-1].close if i > 0 else None
        simple = None if prev_close is None else (c.close / prev_close) - 1.0
        logret = None if prev_close is None else math.log(c.close / prev_close)
        if simple is not None:
            returns.append(simple)
        recent = returns[-window:]
        low_high_range = c.high - c.low
        close_position = 0.5 if low_high_range == 0 else (c.close - c.low) / low_high_range
        row = FeatureRow(
            timestamp=c.timestamp,
            close=c.close,
            simple_return_1=simple,
            log_return_1=logret,
            range_pct=(c.high - c.low) / c.close,
            close_position=close_position,
            rolling_mean_return=_mean(recent) if len(recent) >= window else None,
            rolling_volatility=_std(recent) if len(recent) >= window else None,
            volume_zscore=(c.volume - vol_mean) / vol_std if vol_std else 0.0,
        )
        rows.append(row)
    return FeatureMatrix("qrds.feature_matrix.v1", dql_report.status, dql_report.dqs, False, rows)
