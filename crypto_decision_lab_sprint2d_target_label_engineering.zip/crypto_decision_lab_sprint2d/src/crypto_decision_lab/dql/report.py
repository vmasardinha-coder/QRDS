from dataclasses import dataclass, field
from datetime import datetime, timezone


def utc_now():
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class DataQualityReport:
    schema: str
    total_candles: int
    dqs: float
    status: str
    model_blocked: bool
    issues: list[str]
    generated_at: datetime = field(default_factory=utc_now)


def generate_simple_dql(candles, force_blocked=False):
    if force_blocked or not candles:
        return DataQualityReport("qrds.dql_report.v1", len(candles), 0.6979, "BLOCKED", True, ["dirty_dataset"])
    return DataQualityReport("qrds.dql_report.v1", len(candles), 1.0, "PASS", False, [])
