from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Optional


def utc_now():
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class MarketCandle:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    symbol: str = "BTCUSDT"
    timeframe: str = "1h"


@dataclass(frozen=True)
class FeatureRow:
    timestamp: datetime
    close: float
    simple_return_1: Optional[float]
    log_return_1: Optional[float]
    range_pct: float
    close_position: float
    rolling_mean_return: Optional[float]
    rolling_volatility: Optional[float]
    volume_zscore: Optional[float]


@dataclass(frozen=True)
class FeatureMatrix:
    schema: str
    source_status: str
    source_dqs: float
    model_blocked: bool
    rows: list[FeatureRow]
    generated_at: datetime = field(default_factory=utc_now)


@dataclass(frozen=True)
class FeatureQualityReport:
    schema: str
    status: str
    model_blocked: bool
    score: float
    rows: int
    null_ratio: float
    finite_ratio: float
    low_variance_features: list[str]
    issues: list[str]
    generated_at: datetime = field(default_factory=utc_now)


@dataclass(frozen=True)
class RegimeDiagnostics:
    schema: str
    status: str
    model_blocked: bool
    score: float
    rows: int
    last_regime_code: str
    issues: list[str]
    generated_at: datetime = field(default_factory=utc_now)


@dataclass(frozen=True)
class TargetLabelRow:
    timestamp: datetime
    close: float
    horizon: int
    future_close: Optional[float]
    future_return: Optional[float]
    direction_label: str
    target_valid: bool


@dataclass(frozen=True)
class TargetLabelMatrix:
    schema: str
    feature_schema: str
    source_status: str
    source_dqs: float
    feature_quality_status: str
    regime_status: str
    model_blocked: bool
    rows: list[TargetLabelRow]
    generated_at: datetime = field(default_factory=utc_now)


@dataclass(frozen=True)
class TargetQualityReport:
    schema: str
    status: str
    model_blocked: bool
    score: float
    rows: int
    valid_ratio: float
    horizons: list[int]
    label_counts: dict[str, int]
    issues: list[str]
    generated_at: datetime = field(default_factory=utc_now)
