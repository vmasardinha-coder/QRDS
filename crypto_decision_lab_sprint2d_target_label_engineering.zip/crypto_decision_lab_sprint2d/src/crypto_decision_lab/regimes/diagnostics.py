from crypto_decision_lab.domain.models import RegimeDiagnostics


def generate_regime_diagnostics(matrix, quality_report):
    if matrix.model_blocked or quality_report.model_blocked:
        return RegimeDiagnostics("qrds.regime_diagnostics.v1", "BLOCKED", True, 0.0, len(matrix.rows), "blocked", ["upstream_blocked"])
    last = matrix.rows[-1]
    vol = "high_volatility" if (last.rolling_volatility or 0) > 0.00005 else "normal_volatility"
    trend = "upward_drift" if (last.rolling_mean_return or 0) >= 0 else "downward_drift"
    volume = "elevated_volume" if (last.volume_zscore or 0) > 1 else "normal_volume"
    efficiency = "balanced_candle" if 0.2 <= last.close_position <= 0.8 else "edge_candle"
    code = f"{vol}|{trend}|{volume}|{efficiency}"
    return RegimeDiagnostics("qrds.regime_diagnostics.v1", "PASS", False, 0.9583, len(matrix.rows), code, [])
