from dataclasses import asdict
from crypto_decision_lab.domain.models import TargetLabelRow, TargetLabelMatrix, TargetQualityReport


def classify_return(future_return, threshold=0.0005):
    if future_return is None:
        return "unknown"
    if future_return >= threshold:
        return "up"
    if future_return <= -threshold:
        return "down"
    return "flat"


def generate_target_label_matrix(feature_matrix, feature_quality_report, regime_diagnostics, horizons=(1, 3, 6), threshold=0.0005):
    if feature_matrix.model_blocked or feature_quality_report.model_blocked or regime_diagnostics.model_blocked:
        raise ValueError("Target generation blocked by upstream gate")
    rows = []
    features = feature_matrix.rows
    for i, row in enumerate(features):
        for h in horizons:
            j = i + h
            if j >= len(features):
                future_close = None
                future_return = None
                label = "unknown"
                valid = False
            else:
                future_close = features[j].close
                future_return = (future_close / row.close) - 1.0
                label = classify_return(future_return, threshold)
                valid = True
            rows.append(TargetLabelRow(row.timestamp, row.close, h, future_close, future_return, label, valid))
    return TargetLabelMatrix(
        schema="qrds.target_label_matrix.v1",
        feature_schema=feature_matrix.schema,
        source_status=feature_matrix.source_status,
        source_dqs=feature_matrix.source_dqs,
        feature_quality_status=feature_quality_report.status,
        regime_status=regime_diagnostics.status,
        model_blocked=False,
        rows=rows,
    )


def generate_target_quality_report(label_matrix, min_valid_ratio=0.80):
    rows = label_matrix.rows
    total = len(rows)
    valid = sum(1 for r in rows if r.target_valid)
    valid_ratio = valid / total if total else 0.0
    counts = {}
    horizons = sorted(set(r.horizon for r in rows))
    for r in rows:
        counts[r.direction_label] = counts.get(r.direction_label, 0) + 1
    issues = []
    if total == 0:
        issues.append("empty_label_matrix")
    if valid_ratio < min_valid_ratio:
        issues.append("low_valid_ratio")
    if len([k for k in counts if k != "unknown"]) < 2:
        issues.append("single_class_targets")
    score = round(max(0.0, min(1.0, valid_ratio - 0.05 * len(issues))), 4)
    status = "PASS" if not issues else "BLOCKED"
    return TargetQualityReport(
        schema="qrds.target_quality_report.v1",
        status=status,
        model_blocked=status != "PASS",
        score=score,
        rows=total,
        valid_ratio=round(valid_ratio, 4),
        horizons=horizons,
        label_counts=counts,
        issues=issues,
    )
