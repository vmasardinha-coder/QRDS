import json
from dataclasses import asdict, is_dataclass
from datetime import datetime
from pathlib import Path


def _default(o):
    if isinstance(o, datetime):
        return o.isoformat()
    if is_dataclass(o):
        return asdict(o)
    raise TypeError(f"Object of type {type(o).__name__} is not JSON serializable")


def export_json(obj, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, default=_default, indent=2, sort_keys=True), encoding="utf-8")
    return path


def export_txt(lines, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
