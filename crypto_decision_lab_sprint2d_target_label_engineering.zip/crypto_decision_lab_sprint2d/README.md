# QRDS/QOS - Sprint 2D - Target Label Engineering Offline

Objetivo: criar labels/targets futuros para pesquisa quantitativa offline, sem gerar sinal Long/Short, sem backtest e sem conexão com exchange.

## Escopo
- Entrada: candles offline publicos/locais.
- Gate: DQL PASS + Feature Quality PASS + Regime Diagnostics PASS.
- Saida: matriz de labels futuros por horizonte.
- Exports: JSON/TXT em `reports/sprint2d/`.

## Fora de escopo
- Binance live, API key, WebSocket autenticado, ordens, capital real, alavancagem, sinal Long/Short, backtest.
- Binance pode ser usada apenas como fonte publica/offline sem conexao de conta real.
