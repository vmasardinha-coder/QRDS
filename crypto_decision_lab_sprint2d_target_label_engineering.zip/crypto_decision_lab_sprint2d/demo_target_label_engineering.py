from crypto_decision_lab.ingestion.binance_klines import load_binance_klines_csv
from crypto_decision_lab.dql.report import generate_simple_dql
from crypto_decision_lab.features.engineering import generate_feature_matrix
from crypto_decision_lab.features.quality import generate_feature_quality_report
from crypto_decision_lab.regimes.diagnostics import generate_regime_diagnostics
from crypto_decision_lab.targets.labels import generate_target_label_matrix, generate_target_quality_report
from crypto_decision_lab.export.artifacts import export_json, export_txt

OUT = "reports/sprint2d"

candles = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-48-clean.csv")
dql = generate_simple_dql(candles)
features = generate_feature_matrix(candles, dql)
quality = generate_feature_quality_report(features)
regime = generate_regime_diagnostics(features, quality)
labels = generate_target_label_matrix(features, quality, regime, horizons=(1, 3, 6), threshold=0.0005)
target_quality = generate_target_quality_report(labels)

export_json(labels, f"{OUT}/target_label_matrix.json")
export_json(target_quality, f"{OUT}/target_quality_report.json")
export_txt([
    "QRDS Sprint 2D - Target Label Engineering Offline",
    f"Label schema: {labels.schema}",
    f"Quality schema: {target_quality.schema}",
    f"Rows: {target_quality.rows}",
    f"Target quality score: {target_quality.score:.4f}",
    f"Target quality status: {target_quality.status}",
    f"Valid ratio: {target_quality.valid_ratio:.4f}",
    f"Horizons: {target_quality.horizons}",
    f"Label counts: {target_quality.label_counts}",
    f"Issues: {target_quality.issues if target_quality.issues else 'none'}",
], f"{OUT}/target_quality_report.txt")

print("=== Sprint 2D Target Label Engineering Offline ===")
print(f"Feature schema: {features.schema}")
print(f"Target schema: {labels.schema}")
print(f"Quality schema: {target_quality.schema}")
print(f"Source status: {features.source_status}")
print(f"Feature quality status: {quality.status}")
print(f"Regime status: {regime.status}")
print(f"Label rows: {target_quality.rows}")
print(f"Target quality score: {target_quality.score:.4f}")
print(f"Target quality status: {target_quality.status}")
print(f"Valid ratio: {target_quality.valid_ratio:.4f}")
print(f"Horizons: {target_quality.horizons}")
print(f"Label counts: {target_quality.label_counts}")
print(f"Issues: {target_quality.issues if target_quality.issues else 'none'}")

try:
    dirty_dql = generate_simple_dql(candles, force_blocked=True)
    dirty_features = generate_feature_matrix(candles, dirty_dql)
except ValueError as exc:
    print(f"Dirty DQL status: BLOCKED")
    print(f"Dirty target gate: {exc}")

print(f"Generated files: {OUT}/")
