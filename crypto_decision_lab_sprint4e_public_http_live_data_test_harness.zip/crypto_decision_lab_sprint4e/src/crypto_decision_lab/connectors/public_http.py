from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any

SUPPORTED_EXCHANGES = ["binance", "bybit", "okx"]

@dataclass(frozen=True)
class EndpointSpec:
    exchange: str
    method: str
    base_url: str
    path: str
    auth_required: bool
    api_key_required: bool
    account_connection_required: bool
    websocket: bool
    public_only: bool

@dataclass(frozen=True)
class NormalizedCandle:
    exchange: str
    symbol: str
    timeframe: str
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float


def endpoint_specs() -> dict[str, EndpointSpec]:
    return {
        "binance": EndpointSpec(
            exchange="binance",
            method="GET",
            base_url="https://api.binance.com",
            path="/api/v3/klines",
            auth_required=False,
            api_key_required=False,
            account_connection_required=False,
            websocket=False,
            public_only=True,
        ),
        "bybit": EndpointSpec(
            exchange="bybit",
            method="GET",
            base_url="https://api.bybit.com",
            path="/v5/market/kline",
            auth_required=False,
            api_key_required=False,
            account_connection_required=False,
            websocket=False,
            public_only=True,
        ),
        "okx": EndpointSpec(
            exchange="okx",
            method="GET",
            base_url="https://www.okx.com",
            path="/api/v5/market/candles",
            auth_required=False,
            api_key_required=False,
            account_connection_required=False,
            websocket=False,
            public_only=True,
        ),
    }


def fixture_payload(exchange: str) -> list[list[Any]]:
    base = 1704067200000
    rows = []
    for i in range(5):
        ts = base + i * 3600_000
        open_ = 50000.0 + i * 100
        high = open_ + 150
        low = open_ - 120
        close = open_ + 75
        volume = 100.0 + i
        if exchange == "binance":
            rows.append([ts, str(open_), str(high), str(low), str(close), str(volume), ts + 3599999])
        elif exchange == "bybit":
            rows.append([str(ts), str(open_), str(high), str(low), str(close), str(volume), "0"])
        elif exchange == "okx":
            rows.append([str(ts), str(open_), str(high), str(low), str(close), str(volume), "0", "0", "1"])
        else:
            raise ValueError(f"unsupported exchange: {exchange}")
    return rows


def _dt(ms: Any) -> datetime:
    return datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc)


def normalize_fixture(exchange: str, symbol: str = "BTCUSDT", timeframe: str = "1h") -> list[NormalizedCandle]:
    candles: list[NormalizedCandle] = []
    for row in fixture_payload(exchange):
        candles.append(
            NormalizedCandle(
                exchange=exchange,
                symbol=symbol,
                timeframe=timeframe,
                timestamp=_dt(row[0]),
                open=float(row[1]),
                high=float(row[2]),
                low=float(row[3]),
                close=float(row[4]),
                volume=float(row[5]),
            )
        )
    return candles


def validate_timestamp_order(candles: list[NormalizedCandle]) -> bool:
    return all(candles[i].timestamp > candles[i - 1].timestamp for i in range(1, len(candles)))


def validate_ohlcv_contract(candles: list[NormalizedCandle]) -> bool:
    for c in candles:
        if not (c.low <= c.open <= c.high and c.low <= c.close <= c.high):
            return False
        if min(c.open, c.high, c.low, c.close) <= 0:
            return False
        if c.volume < 0:
            return False
    return True


def validate_endpoint_specs(specs: dict[str, EndpointSpec]) -> list[str]:
    issues: list[str] = []
    for exchange in SUPPORTED_EXCHANGES:
        spec = specs.get(exchange)
        if spec is None:
            issues.append(f"missing_spec:{exchange}")
            continue
        if spec.auth_required:
            issues.append(f"auth_required:{exchange}")
        if spec.api_key_required:
            issues.append(f"api_key_required:{exchange}")
        if spec.account_connection_required:
            issues.append(f"account_connection_required:{exchange}")
        if spec.websocket:
            issues.append(f"websocket_used:{exchange}")
        if spec.method != "GET":
            issues.append(f"invalid_method:{exchange}")
        if not spec.public_only:
            issues.append(f"not_public_only:{exchange}")
    return issues


def normalized_summary() -> dict[str, int]:
    return {exchange: len(normalize_fixture(exchange)) for exchange in SUPPORTED_EXCHANGES}


def candles_to_dict(candles: list[NormalizedCandle]) -> list[dict[str, Any]]:
    return [
        {
            **asdict(c),
            "timestamp": c.timestamp.isoformat(),
        }
        for c in candles
    ]
