from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import json

from crypto_decision_lab.connectors.public_http import (
    SUPPORTED_EXCHANGES,
    endpoint_specs,
    normalize_fixture,
    validate_endpoint_specs,
    validate_ohlcv_contract,
    validate_timestamp_order,
    normalized_summary,
)

SCHEMA = "qrds.public_http_live_data_test_report.v1"

@dataclass(frozen=True)
class PublicHttpLiveDataTestReport:
    schema: str
    connector_status: str
    live_test_status: str
    model_blocked: bool
    public_http_live_data_allowed: bool
    live_http_mode_enabled: bool
    fixture_replay_used: bool
    network_calls_executed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    endpoint_specs_valid: bool
    adapter_contract_valid: bool
    timestamp_order_valid: bool
    ohlcv_contract_valid: bool
    response_shape_valid: bool
    normalization_consistent: bool
    supported_exchanges: list[str]
    normalized_candles_per_exchange: dict[str, int]
    safety_policy: str
    next_required_gate: str
    action: str
    issues: list[str]


def build_report(live_http_mode_enabled: bool = False) -> PublicHttpLiveDataTestReport:
    # Official validation stays deterministic and safe. Live mode must be enabled by a future gate.
    specs = endpoint_specs()
    issues = validate_endpoint_specs(specs)
    by_exchange = {exchange: normalize_fixture(exchange) for exchange in SUPPORTED_EXCHANGES}

    timestamp_order_valid = all(validate_timestamp_order(c) for c in by_exchange.values())
    ohlcv_contract_valid = all(validate_ohlcv_contract(c) for c in by_exchange.values())
    response_shape_valid = all(len(c) == 5 for c in by_exchange.values())
    normalization_consistent = len(set(len(c) for c in by_exchange.values())) == 1

    if not timestamp_order_valid:
        issues.append("timestamp_order_invalid")
    if not ohlcv_contract_valid:
        issues.append("ohlcv_contract_invalid")
    if not response_shape_valid:
        issues.append("response_shape_invalid")
    if not normalization_consistent:
        issues.append("normalization_inconsistent")

    # Even when the harness exists, the official command does not execute network calls.
    network_calls_executed = False
    fixture_replay_used = True
    live_status = "PASS" if not issues else "BLOCKED"
    return PublicHttpLiveDataTestReport(
        schema=SCHEMA,
        connector_status="PASS",
        live_test_status=live_status,
        model_blocked=live_status != "PASS",
        public_http_live_data_allowed=True,
        live_http_mode_enabled=live_http_mode_enabled,
        fixture_replay_used=fixture_replay_used,
        network_calls_executed=network_calls_executed,
        authenticated_connection_used=False,
        api_key_required=False,
        account_connection_required=False,
        websocket_used=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        endpoint_specs_valid=len(validate_endpoint_specs(specs)) == 0,
        adapter_contract_valid=True,
        timestamp_order_valid=timestamp_order_valid,
        ohlcv_contract_valid=ohlcv_contract_valid,
        response_shape_valid=response_shape_valid,
        normalization_consistent=normalization_consistent,
        supported_exchanges=list(SUPPORTED_EXCHANGES),
        normalized_candles_per_exchange=normalized_summary(),
        safety_policy="PUBLIC_ONLY_NO_AUTH_LIVE_TEST_HARNESS_FIXTURE_DEFAULT",
        next_required_gate="OPTIONAL_PUBLIC_HTTP_LIVE_SMOKE_TEST_REQUIRED",
        action="NO_LIVE_NETWORK_CALL_FIXTURE_REPLAY_ONLY",
        issues=issues,
    )


def build_dirty_report() -> PublicHttpLiveDataTestReport:
    return PublicHttpLiveDataTestReport(
        schema=SCHEMA,
        connector_status="BLOCKED",
        live_test_status="BLOCKED",
        model_blocked=True,
        public_http_live_data_allowed=False,
        live_http_mode_enabled=True,
        fixture_replay_used=False,
        network_calls_executed=True,
        authenticated_connection_used=True,
        api_key_required=True,
        account_connection_required=True,
        websocket_used=True,
        real_capital_used=True,
        exchange_connected=True,
        orders_generated=True,
        endpoint_specs_valid=False,
        adapter_contract_valid=False,
        timestamp_order_valid=False,
        ohlcv_contract_valid=False,
        response_shape_valid=False,
        normalization_consistent=False,
        supported_exchanges=list(SUPPORTED_EXCHANGES),
        normalized_candles_per_exchange={"binance": 0, "bybit": 0, "okx": 0},
        safety_policy="INVALID_AUTH_OR_LIVE_EXPOSURE_DETECTED",
        next_required_gate="NO_NEXT_GATE_BLOCKED",
        action="NO_PUBLIC_LIVE_DATA_TEST_BLOCKED",
        issues=[
            "network_calls_executed_without_live_gate",
            "authenticated_connection_used",
            "api_key_required",
            "account_connection_required",
            "websocket_used",
            "real_capital_used",
            "exchange_or_order_exposure",
        ],
    )


def report_to_dict(report: PublicHttpLiveDataTestReport) -> dict[str, Any]:
    return asdict(report)


def export_report(report: PublicHttpLiveDataTestReport, out_dir: str | Path = "reports/sprint4e") -> dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    payload = report_to_dict(report)
    json_path = out / "public_http_live_data_test_report.json"
    txt_path = out / "public_http_live_data_test_report.txt"
    json_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    lines = [
        "Public HTTP Live Data Test Report",
        f"schema={report.schema}",
        f"live_test_status={report.live_test_status}",
        f"model_blocked={report.model_blocked}",
        f"live_http_mode_enabled={report.live_http_mode_enabled}",
        f"fixture_replay_used={report.fixture_replay_used}",
        f"network_calls_executed={report.network_calls_executed}",
        f"supported_exchanges={report.supported_exchanges}",
        f"issues={report.issues if report.issues else 'none'}",
    ]
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
