import json
import pytest

from crypto_decision_lab.connectors.public_http import (
    SUPPORTED_EXCHANGES,
    endpoint_specs,
    fixture_payload,
    normalize_fixture,
    validate_endpoint_specs,
    validate_timestamp_order,
    validate_ohlcv_contract,
    normalized_summary,
)
from crypto_decision_lab.reports.live_data_test import build_report, build_dirty_report, export_report, report_to_dict


def test_supported_exchanges_count():
    assert SUPPORTED_EXCHANGES == ["binance", "bybit", "okx"]

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_endpoint_specs_supported(exchange):
    assert endpoint_specs()[exchange].exchange == exchange

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_endpoint_specs_no_auth(exchange):
    assert endpoint_specs()[exchange].auth_required is False

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_endpoint_specs_no_api_key(exchange):
    assert endpoint_specs()[exchange].api_key_required is False

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_endpoint_specs_no_websocket(exchange):
    assert endpoint_specs()[exchange].websocket is False

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_endpoint_specs_get_method(exchange):
    assert endpoint_specs()[exchange].method == "GET"

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_fixture_rows_available(exchange):
    assert len(fixture_payload(exchange)) == 5

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_normalized_candle_count(exchange):
    assert len(normalize_fixture(exchange)) == 5

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_timestamp_order(exchange):
    assert validate_timestamp_order(normalize_fixture(exchange)) is True

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_ohlcv_contract(exchange):
    assert validate_ohlcv_contract(normalize_fixture(exchange)) is True

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_exchange_label(exchange):
    assert all(c.exchange == exchange for c in normalize_fixture(exchange))

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_volume_non_negative(exchange):
    assert all(c.volume >= 0 for c in normalize_fixture(exchange))

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_close_within_range(exchange):
    assert all(c.low <= c.close <= c.high for c in normalize_fixture(exchange))


def test_build_report_pass():
    assert build_report().live_test_status == "PASS"


def test_report_no_network():
    r = build_report()
    assert r.network_calls_executed is False
    assert r.fixture_replay_used is True


def test_report_no_auth():
    r = build_report()
    assert r.authenticated_connection_used is False
    assert r.api_key_required is False
    assert r.account_connection_required is False


def test_report_next_gate():
    assert build_report().next_required_gate == "OPTIONAL_PUBLIC_HTTP_LIVE_SMOKE_TEST_REQUIRED"


def test_report_supported_exchange_summary():
    assert build_report().normalized_candles_per_exchange == {"binance": 5, "bybit": 5, "okx": 5}


def test_dirty_report_blocked():
    d = build_dirty_report()
    assert d.live_test_status == "BLOCKED"
    assert d.model_blocked is True


def test_dirty_report_action():
    assert build_dirty_report().action == "NO_PUBLIC_LIVE_DATA_TEST_BLOCKED"


def test_exports(tmp_path):
    files = export_report(build_report(), tmp_path)
    assert set(files) == {"json", "txt"}
    assert "PASS" in (tmp_path / "public_http_live_data_test_report.txt").read_text()


def test_report_serializable():
    payload = report_to_dict(build_report())
    assert json.loads(json.dumps(payload))["schema"] == "qrds.public_http_live_data_test_report.v1"
