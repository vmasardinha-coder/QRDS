from crypto_decision_lab.ingestion.binance_klines import load_binance_klines_csv
from crypto_decision_lab.dql.report import generate_data_quality_report
from crypto_decision_lab.features.engineering import generate_feature_matrix
from crypto_decision_lab.features.quality import generate_feature_quality_report
from crypto_decision_lab.exporters.json_txt import export_json, export_txt

OUT = "reports/sprint2b"

clean = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-clean-48.csv")
clean_dql = generate_data_quality_report(clean)
clean_matrix = generate_feature_matrix(clean, clean_dql)
clean_quality = generate_feature_quality_report(clean_matrix)

issues = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-issues-48.csv")
issues_dql = generate_data_quality_report(issues)
try:
    issues_matrix = generate_feature_matrix(issues, issues_dql)
    issues_quality = generate_feature_quality_report(issues_matrix)
    blocked_message = "unexpected"
except ValueError as exc:
    issues_quality = None
    blocked_message = str(exc)

export_json(clean_matrix, f"{OUT}/clean_feature_matrix.json")
export_json(clean_quality, f"{OUT}/clean_feature_quality_report.json")
export_txt(clean_quality, f"{OUT}/clean_feature_quality_report.txt")
export_json({"dirty_dql_status": issues_dql.status, "dirty_dql_score": issues_dql.dqs, "blocked_message": blocked_message}, f"{OUT}/dirty_feature_gate.json")

print("=== Sprint 2B Feature Quality Report Offline ===")
print(f"Feature schema: {clean_matrix.schema}")
print(f"Quality schema: {clean_quality.schema}")
print(f"Rows: {clean_quality.row_count}")
print(f"Feature quality score: {clean_quality.score:.4f}")
print(f"Feature quality status: {clean_quality.status}")
print(f"Null ratio: {clean_quality.null_ratio:.4f}")
print(f"Finite ratio: {clean_quality.finite_ratio:.4f}")
print(f"Low variance features: {clean_quality.low_variance_features if clean_quality.low_variance_features else 'none'}")
print(f"Dirty DQL status: {issues_dql.status}")
print(f"Dirty feature gate: {blocked_message}")
print(f"Generated files: {OUT}/")
