# QRDS Crypto Decision Lab - Sprint 2B

## Sprint 2B - Feature Validation / Feature Quality Report Offline

Objetivo: validar se as features geradas na Sprint 2A sao utilizaveis para pesquisa quantitativa offline, sem ainda produzir sinal Long/Short, backtest, ordem ou integracao live.

### Escopo

- Usa dataset offline limpo de 48 candles.
- Usa dataset offline com problemas intencionais.
- Gera feature matrix offline.
- Bloqueia feature generation quando DQL esta BLOCKED.
- Valida qualidade das features: cobertura, nulos, finitude, variancia, linhas esperadas e colunas obrigatorias.
- Exporta relatorio JSON/TXT local.

### Fora do escopo

- Binance live
- API key
- WebSocket
- ordens
- capital real
- alavancagem
- sinal Long/Short
- backtest

### Validacao

```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_feature_quality_report.py
```
