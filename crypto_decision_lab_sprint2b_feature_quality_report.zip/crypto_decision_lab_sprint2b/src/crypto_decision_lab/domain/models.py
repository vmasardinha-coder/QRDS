from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


def utc_now():
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class MarketCandle:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    symbol: str = "BTCUSDT"
    timeframe: str = "1h"


@dataclass(frozen=True)
class DataQualityReport:
    total_candles: int
    duplicate_timestamps: int
    gap_count: int
    invalid_ohlc_count: int
    invalid_price_count: int
    invalid_volume_count: int
    missing_values_count: int
    dqs: float
    status: str
    issues: list[str]
    completeness: float
    freshness: float
    consistency: float
    temporality: float
    generated_at: datetime = field(default_factory=utc_now)

    @property
    def model_blocked(self) -> bool:
        return self.status != "PASS"


@dataclass(frozen=True)
class FeatureMatrix:
    schema: str
    source_status: str
    source_dqs: float
    rows: list[dict[str, Any]]
    generated_at: datetime = field(default_factory=utc_now)


@dataclass(frozen=True)
class FeatureQualityReport:
    schema: str
    status: str
    score: float
    row_count: int
    feature_count: int
    required_features_present: bool
    null_ratio: float
    finite_ratio: float
    low_variance_features: list[str]
    blocked_reason: str | None
    issues: list[str]
    generated_at: datetime = field(default_factory=utc_now)

    @property
    def model_blocked(self) -> bool:
        return self.status != "PASS"
