import json
from dataclasses import asdict, is_dataclass
from datetime import datetime
from pathlib import Path


def _clean(obj):
    if is_dataclass(obj):
        return _clean(asdict(obj))
    if isinstance(obj, dict):
        return {k: _clean(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_clean(v) for v in obj]
    if isinstance(obj, datetime):
        return obj.isoformat()
    return obj


def export_json(obj, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_clean(obj), indent=2, sort_keys=True), encoding="utf-8")
    return path


def export_txt(report, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "=== Feature Quality Report ===",
        f"Schema: {report.schema}",
        f"Status: {report.status}",
        f"Score: {report.score:.4f}",
        f"Rows: {report.row_count}",
        f"Features: {report.feature_count}",
        f"Required present: {report.required_features_present}",
        f"Null ratio: {report.null_ratio:.4f}",
        f"Finite ratio: {report.finite_ratio:.4f}",
        f"Low variance features: {report.low_variance_features if report.low_variance_features else 'none'}",
        f"Blocked reason: {report.blocked_reason if report.blocked_reason else 'none'}",
        f"Issues: {report.issues if report.issues else 'none'}",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
