from crypto_decision_lab.config import DQS_THRESHOLD
from crypto_decision_lab.domain.models import DataQualityReport


def _valid_ohlc(c):
    return c.low <= c.open <= c.high and c.low <= c.close <= c.high and c.low <= c.high


def _positive_prices(c):
    return c.open > 0 and c.high > 0 and c.low > 0 and c.close > 0


def _non_negative_volume(c):
    return c.volume >= 0


def _strict_order(candles):
    return all(candles[i].timestamp > candles[i-1].timestamp for i in range(1, len(candles)))


def count_duplicate_timestamps(candles):
    seen = set()
    dup = 0
    for c in candles:
        if c.timestamp in seen:
            dup += 1
        seen.add(c.timestamp)
    return dup


def count_gaps(candles, expected_interval_seconds):
    ordered = sorted(candles, key=lambda c: c.timestamp)
    gaps = 0
    for a, b in zip(ordered, ordered[1:]):
        delta = int((b.timestamp - a.timestamp).total_seconds())
        if delta != expected_interval_seconds:
            gaps += 1
    return gaps


def generate_data_quality_report(candles, expected_interval_seconds=3600):
    total = len(candles)
    if total == 0:
        return DataQualityReport(0,0,0,0,0,0,0,0.0,"BLOCKED",["empty_dataset"],0.0,1.0,0.0,0.0)

    dup = count_duplicate_timestamps(candles)
    gaps = count_gaps(candles, expected_interval_seconds)
    invalid_ohlc = sum(1 for c in candles if not _valid_ohlc(c))
    invalid_prices = sum(1 for c in candles if not _positive_prices(c))
    invalid_volume = sum(1 for c in candles if not _non_negative_volume(c))
    missing = 0
    order_ok = _strict_order(candles)

    issues = []
    if dup: issues.append("duplicate_timestamps")
    if gaps: issues.append("timestamp_gaps")
    if invalid_ohlc: issues.append("invalid_ohlc")
    if invalid_prices: issues.append("invalid_prices")
    if invalid_volume: issues.append("invalid_volume")
    if missing: issues.append("missing_values")
    if not order_ok: issues.append("timestamp_order")

    completeness = max(0.0, 1.0 - ((dup + gaps) / total))
    consistency = max(0.0, 1.0 - ((invalid_ohlc + invalid_prices + invalid_volume + missing) / total))
    freshness = 1.0
    temporality = 1.0 if order_ok and dup == 0 else 0.0
    dqs = round((completeness + freshness + consistency + temporality) / 4, 4)
    status = "PASS" if dqs >= DQS_THRESHOLD and not issues else "BLOCKED"

    return DataQualityReport(total, dup, gaps, invalid_ohlc, invalid_prices, invalid_volume, missing, dqs, status, issues, completeness, freshness, consistency, temporality)
