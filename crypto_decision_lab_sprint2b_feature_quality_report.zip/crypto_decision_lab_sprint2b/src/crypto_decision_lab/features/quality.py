import math
from crypto_decision_lab.config import FEATURE_QUALITY_SCHEMA, FEATURE_QUALITY_THRESHOLD
from crypto_decision_lab.domain.models import FeatureQualityReport

REQUIRED_FEATURES = [
    "simple_return_1",
    "log_return_1",
    "candle_range_pct",
    "close_position",
    "rolling_mean_return",
    "rolling_volatility",
    "volume_zscore",
]


def _is_number(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def _is_finite_or_none(x):
    if x is None:
        return True
    return _is_number(x) and math.isfinite(x)


def generate_feature_quality_report(feature_matrix, min_rows=30, max_null_ratio=0.40, min_variance_features=3):
    rows = feature_matrix.rows
    row_count = len(rows)
    issues = []

    if row_count == 0:
        return FeatureQualityReport(FEATURE_QUALITY_SCHEMA, "BLOCKED", 0.0, 0, 0, False, 1.0, 0.0, [], "empty_feature_matrix", ["empty_feature_matrix"])

    present = set(rows[0].keys())
    required_present = all(f in present for f in REQUIRED_FEATURES)
    if not required_present:
        issues.append("missing_required_features")

    cells = []
    finite_cells = []
    numeric_by_feature = {f: [] for f in REQUIRED_FEATURES if f in present}

    for row in rows:
        for f in REQUIRED_FEATURES:
            if f not in row:
                continue
            value = row[f]
            cells.append(value)
            if _is_finite_or_none(value):
                finite_cells.append(value)
            if _is_number(value) and math.isfinite(value):
                numeric_by_feature.setdefault(f, []).append(float(value))

    null_ratio = sum(1 for x in cells if x is None) / len(cells) if cells else 1.0
    finite_ratio = len(finite_cells) / len(cells) if cells else 0.0

    low_variance = []
    for f, values in numeric_by_feature.items():
        if len(values) >= 2 and max(values) == min(values):
            low_variance.append(f)

    non_low_variance_count = len([f for f in numeric_by_feature if f not in low_variance and len(numeric_by_feature[f]) >= 2])

    if row_count < min_rows:
        issues.append("insufficient_rows")
    if null_ratio > max_null_ratio:
        issues.append("excessive_null_ratio")
    if finite_ratio < 1.0:
        issues.append("non_finite_values")
    if non_low_variance_count < min_variance_features:
        issues.append("insufficient_feature_variance")

    row_score = min(1.0, row_count / min_rows)
    null_score = max(0.0, 1.0 - null_ratio)
    finite_score = finite_ratio
    variance_score = min(1.0, non_low_variance_count / min_variance_features)
    presence_score = 1.0 if required_present else 0.0
    score = round((row_score + null_score + finite_score + variance_score + presence_score) / 5, 4)

    status = "PASS" if score >= FEATURE_QUALITY_THRESHOLD and not issues else "BLOCKED"
    blocked_reason = None if status == "PASS" else ", ".join(issues)

    return FeatureQualityReport(
        schema=FEATURE_QUALITY_SCHEMA,
        status=status,
        score=score,
        row_count=row_count,
        feature_count=len(REQUIRED_FEATURES),
        required_features_present=required_present,
        null_ratio=round(null_ratio, 4),
        finite_ratio=round(finite_ratio, 4),
        low_variance_features=low_variance,
        blocked_reason=blocked_reason,
        issues=issues,
    )
