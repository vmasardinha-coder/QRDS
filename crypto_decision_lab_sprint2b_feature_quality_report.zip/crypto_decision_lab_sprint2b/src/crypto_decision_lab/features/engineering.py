import math
from crypto_decision_lab.config import FEATURE_SCHEMA
from crypto_decision_lab.domain.models import FeatureMatrix


def _mean(values):
    return sum(values) / len(values) if values else None


def _std(values):
    if len(values) < 2:
        return None
    m = _mean(values)
    return math.sqrt(sum((x - m) ** 2 for x in values) / (len(values) - 1))


def generate_feature_matrix(candles, dql_report, rolling_window=5):
    if dql_report.model_blocked:
        raise ValueError(f"Feature generation blocked by DQL: status={dql_report.status}, dqs={dql_report.dqs}")

    rows = []
    closes = []
    returns = []
    volumes = []

    for i, c in enumerate(candles):
        prev_close = candles[i-1].close if i > 0 else None
        simple_return = None if prev_close is None else (c.close / prev_close) - 1
        log_return = None if prev_close is None else math.log(c.close / prev_close)
        candle_range_pct = (c.high - c.low) / c.close if c.close else None
        close_position = (c.close - c.low) / (c.high - c.low) if c.high != c.low else None

        returns.append(simple_return)
        volumes.append(c.volume)
        closes.append(c.close)

        valid_returns = [r for r in returns[-rolling_window:] if r is not None]
        rolling_mean_return = _mean(valid_returns) if len(valid_returns) >= rolling_window else None
        rolling_volatility = _std(valid_returns) if len(valid_returns) >= rolling_window else None

        valid_volumes = volumes[-rolling_window:]
        vol_mean = _mean(valid_volumes) if len(valid_volumes) >= rolling_window else None
        vol_std = _std(valid_volumes) if len(valid_volumes) >= rolling_window else None
        volume_zscore = None if not vol_std else (c.volume - vol_mean) / vol_std

        rows.append({
            "timestamp": c.timestamp.isoformat(),
            "close": round(c.close, 8),
            "volume": round(c.volume, 8),
            "simple_return_1": None if simple_return is None else round(simple_return, 8),
            "log_return_1": None if log_return is None else round(log_return, 8),
            "candle_range_pct": None if candle_range_pct is None else round(candle_range_pct, 8),
            "close_position": None if close_position is None else round(close_position, 8),
            "rolling_mean_return": None if rolling_mean_return is None else round(rolling_mean_return, 8),
            "rolling_volatility": None if rolling_volatility is None else round(rolling_volatility, 8),
            "volume_zscore": None if volume_zscore is None else round(volume_zscore, 8),
        })

    return FeatureMatrix(schema=FEATURE_SCHEMA, source_status=dql_report.status, source_dqs=dql_report.dqs, rows=rows)
