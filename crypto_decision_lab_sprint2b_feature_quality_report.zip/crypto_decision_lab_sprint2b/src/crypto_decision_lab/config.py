DQS_THRESHOLD = 0.80
FEATURE_QUALITY_THRESHOLD = 0.80
FEATURE_SCHEMA = "qrds.feature_matrix.v1"
FEATURE_QUALITY_SCHEMA = "qrds.feature_quality_report.v1"
