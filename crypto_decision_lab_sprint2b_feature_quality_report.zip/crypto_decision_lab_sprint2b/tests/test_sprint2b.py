import json
import math
from pathlib import Path
import pytest

from crypto_decision_lab.ingestion.binance_klines import load_binance_klines_csv
from crypto_decision_lab.dql.report import generate_data_quality_report
from crypto_decision_lab.features.engineering import generate_feature_matrix
from crypto_decision_lab.features.quality import generate_feature_quality_report, REQUIRED_FEATURES
from crypto_decision_lab.exporters.json_txt import export_json, export_txt

CLEAN = "data/fixtures/BTCUSDT-1h-clean-48.csv"
DIRTY = "data/fixtures/BTCUSDT-1h-issues-48.csv"


def test_clean_fixture_loads_48_rows():
    candles = load_binance_klines_csv(CLEAN)
    assert len(candles) == 48
    assert candles[0].close > 0


def test_clean_dql_passes():
    candles = load_binance_klines_csv(CLEAN)
    report = generate_data_quality_report(candles)
    assert report.status == "PASS"
    assert report.dqs == 1.0
    assert not report.model_blocked


def test_dirty_dql_blocks():
    candles = load_binance_klines_csv(DIRTY)
    report = generate_data_quality_report(candles)
    assert report.status == "BLOCKED"
    assert report.model_blocked
    assert "duplicate_timestamps" in report.issues
    assert "invalid_ohlc" in report.issues
    assert "invalid_prices" in report.issues
    assert "invalid_volume" in report.issues


def test_feature_generation_from_clean_dql():
    candles = load_binance_klines_csv(CLEAN)
    dql = generate_data_quality_report(candles)
    matrix = generate_feature_matrix(candles, dql)
    assert matrix.schema == "qrds.feature_matrix.v1"
    assert matrix.source_status == "PASS"
    assert len(matrix.rows) == 48
    assert matrix.rows[0]["simple_return_1"] is None
    assert matrix.rows[-1]["rolling_volatility"] is not None


def test_feature_generation_blocks_dirty_dql():
    candles = load_binance_klines_csv(DIRTY)
    dql = generate_data_quality_report(candles)
    with pytest.raises(ValueError, match="Feature generation blocked by DQL"):
        generate_feature_matrix(candles, dql)


def test_required_features_present():
    candles = load_binance_klines_csv(CLEAN)
    matrix = generate_feature_matrix(candles, generate_data_quality_report(candles))
    for feature in REQUIRED_FEATURES:
        assert feature in matrix.rows[0]


def test_feature_quality_passes_clean_matrix():
    candles = load_binance_klines_csv(CLEAN)
    matrix = generate_feature_matrix(candles, generate_data_quality_report(candles))
    report = generate_feature_quality_report(matrix)
    assert report.schema == "qrds.feature_quality_report.v1"
    assert report.status == "PASS"
    assert report.score >= 0.80
    assert not report.model_blocked
    assert report.row_count == 48
    assert report.required_features_present
    assert report.finite_ratio == 1.0


def test_feature_quality_blocks_insufficient_rows():
    candles = load_binance_klines_csv(CLEAN)[:10]
    matrix = generate_feature_matrix(candles, generate_data_quality_report(candles))
    report = generate_feature_quality_report(matrix)
    assert report.status == "BLOCKED"
    assert "insufficient_rows" in report.issues


def test_feature_quality_blocks_missing_required_feature():
    candles = load_binance_klines_csv(CLEAN)
    matrix = generate_feature_matrix(candles, generate_data_quality_report(candles))
    rows = [dict(row) for row in matrix.rows]
    for row in rows:
        row.pop("volume_zscore", None)
    from crypto_decision_lab.domain.models import FeatureMatrix
    broken = FeatureMatrix(matrix.schema, matrix.source_status, matrix.source_dqs, rows)
    report = generate_feature_quality_report(broken)
    assert report.status == "BLOCKED"
    assert "missing_required_features" in report.issues


def test_feature_quality_detects_non_finite_values():
    candles = load_binance_klines_csv(CLEAN)
    matrix = generate_feature_matrix(candles, generate_data_quality_report(candles))
    rows = [dict(row) for row in matrix.rows]
    rows[-1]["simple_return_1"] = float("inf")
    from crypto_decision_lab.domain.models import FeatureMatrix
    broken = FeatureMatrix(matrix.schema, matrix.source_status, matrix.source_dqs, rows)
    report = generate_feature_quality_report(broken)
    assert report.status == "BLOCKED"
    assert "non_finite_values" in report.issues


def test_low_variance_detection_blocks_when_all_constant():
    candles = load_binance_klines_csv(CLEAN)
    matrix = generate_feature_matrix(candles, generate_data_quality_report(candles))
    rows = [dict(row) for row in matrix.rows]
    for row in rows:
        for f in REQUIRED_FEATURES:
            row[f] = 1.0
    from crypto_decision_lab.domain.models import FeatureMatrix
    flat = FeatureMatrix(matrix.schema, matrix.source_status, matrix.source_dqs, rows)
    report = generate_feature_quality_report(flat)
    assert report.status == "BLOCKED"
    assert "insufficient_feature_variance" in report.issues
    assert len(report.low_variance_features) == len(REQUIRED_FEATURES)


def test_json_export(tmp_path):
    candles = load_binance_klines_csv(CLEAN)
    matrix = generate_feature_matrix(candles, generate_data_quality_report(candles))
    report = generate_feature_quality_report(matrix)
    path = export_json(report, tmp_path / "quality.json")
    data = json.loads(path.read_text())
    assert data["status"] == "PASS"
    assert data["schema"] == "qrds.feature_quality_report.v1"


def test_txt_export(tmp_path):
    candles = load_binance_klines_csv(CLEAN)
    matrix = generate_feature_matrix(candles, generate_data_quality_report(candles))
    report = generate_feature_quality_report(matrix)
    path = export_txt(report, tmp_path / "quality.txt")
    text = path.read_text()
    assert "Feature Quality Report" in text
    assert "Status: PASS" in text


def test_feature_values_are_finite_or_none():
    candles = load_binance_klines_csv(CLEAN)
    matrix = generate_feature_matrix(candles, generate_data_quality_report(candles))
    for row in matrix.rows:
        for feature in REQUIRED_FEATURES:
            value = row[feature]
            assert value is None or math.isfinite(value)


def test_source_dqs_is_carried_to_matrix():
    candles = load_binance_klines_csv(CLEAN)
    dql = generate_data_quality_report(candles)
    matrix = generate_feature_matrix(candles, dql)
    assert matrix.source_dqs == dql.dqs
    assert matrix.source_status == dql.status


def test_report_blocked_reason_none_on_pass():
    candles = load_binance_klines_csv(CLEAN)
    matrix = generate_feature_matrix(candles, generate_data_quality_report(candles))
    report = generate_feature_quality_report(matrix)
    assert report.blocked_reason is None
    assert report.issues == []
