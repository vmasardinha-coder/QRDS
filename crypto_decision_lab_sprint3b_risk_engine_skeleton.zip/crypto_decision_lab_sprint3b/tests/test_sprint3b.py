import json
from pathlib import Path
import pytest

from crypto_decision_lab.backtest_fixture import make_clean_backtest_report, make_dirty_backtest_report
from crypto_decision_lab.exporters import export_json, export_txt
from crypto_decision_lab.models import RiskPolicy
from crypto_decision_lab.risk_engine import generate_risk_engine_report, validate_policy


def test_clean_risk_report_passes():
    report = generate_risk_engine_report(make_clean_backtest_report())
    assert report.schema == "qrds.risk_engine_report.v1"
    assert report.risk_status == "PASS"
    assert report.model_blocked is False
    assert report.research_allowed is True
    assert report.operational_decision_allowed is False
    assert report.action == "NO_TRADE_RISK_RESEARCH_ONLY"


def test_clean_report_never_uses_real_capital_or_exchange():
    report = generate_risk_engine_report(make_clean_backtest_report())
    assert report.real_capital_used is False
    assert report.exchange_connected is False
    assert report.orders_generated is False
    assert report.kill_switch_active is False


def test_clean_report_risk_numbers():
    report = generate_risk_engine_report(make_clean_backtest_report())
    assert report.account_equity == 10000.0
    assert report.max_loss_per_trade == 100.0
    assert report.max_position_notional == 500.0
    assert report.observed_max_drawdown_pct == 0.022457
    assert report.drawdown_utilization == 0.22457


def test_clean_report_next_gate():
    report = generate_risk_engine_report(make_clean_backtest_report())
    assert report.next_required_gate == "PAPER_TRADING_REQUIRED"
    assert report.issues == []


def test_dirty_backtest_blocks_risk():
    report = generate_risk_engine_report(make_dirty_backtest_report())
    assert report.risk_status == "BLOCKED"
    assert report.model_blocked is True
    assert report.research_allowed is False
    assert report.action == "NO_RISK_BLOCKED"
    assert "backtest_status:BLOCKED" in report.issues


def test_policy_default_is_valid():
    assert validate_policy(RiskPolicy()) == []


@pytest.mark.parametrize("field,value,issue", [
    ("account_equity", 0.0, "invalid_account_equity"),
    ("account_equity", -1.0, "invalid_account_equity"),
    ("max_risk_per_trade_pct", 0.0, "invalid_max_risk_per_trade_pct"),
    ("max_risk_per_trade_pct", 0.10, "invalid_max_risk_per_trade_pct"),
    ("max_position_notional_pct", 0.0, "invalid_max_position_notional_pct"),
    ("max_position_notional_pct", 1.50, "invalid_max_position_notional_pct"),
    ("max_allowed_drawdown_pct", 0.0, "invalid_max_allowed_drawdown_pct"),
    ("max_allowed_drawdown_pct", 1.50, "invalid_max_allowed_drawdown_pct"),
    ("leverage_allowed", True, "leverage_not_allowed_in_sprint3b"),
    ("real_capital_allowed", True, "real_capital_not_allowed_in_sprint3b"),
    ("exchange_connection_allowed", True, "exchange_connection_not_allowed_in_sprint3b"),
    ("order_generation_allowed", True, "order_generation_not_allowed_in_sprint3b"),
])
def test_policy_validation_flags_invalid_inputs(field, value, issue):
    policy = RiskPolicy(**{field: value})
    assert issue in validate_policy(policy)


@pytest.mark.parametrize("field,value,expected_issue", [
    ("real_capital_used", True, "real_capital_used"),
    ("exchange_connected", True, "exchange_connected"),
    ("orders_generated", True, "orders_generated"),
    ("prediction_coverage", 0.1, "low_prediction_coverage"),
    ("trades", 1, "insufficient_trades_for_research"),
    ("max_drawdown_pct", 0.50, "max_drawdown_exceeded"),
    ("status", "BLOCKED", "backtest_status:BLOCKED"),
    ("model_blocked", True, "backtest_model_blocked"),
    ("research_allowed", False, "research_not_allowed"),
    ("operational_decision_allowed", True, "unexpected_operational_decision_allowed"),
])
def test_backtest_risk_blocking_conditions(field, value, expected_issue):
    base = make_clean_backtest_report().to_dict()
    base[field] = value
    from crypto_decision_lab.models import BacktestReport
    report = generate_risk_engine_report(BacktestReport(**base))
    assert report.risk_status == "BLOCKED"
    assert expected_issue in report.issues


def test_policy_to_dict_contains_schema():
    data = RiskPolicy().to_dict()
    assert data["schema"] == "qrds.risk_policy.v1"


def test_report_to_dict_contains_schema_and_status():
    data = generate_risk_engine_report(make_clean_backtest_report()).to_dict()
    assert data["schema"] == "qrds.risk_engine_report.v1"
    assert data["risk_status"] == "PASS"


def test_export_json(tmp_path):
    report = generate_risk_engine_report(make_clean_backtest_report())
    path = export_json(report.to_dict(), tmp_path / "risk.json")
    loaded = json.loads(Path(path).read_text())
    assert loaded["risk_status"] == "PASS"


def test_export_txt(tmp_path):
    report = generate_risk_engine_report(make_clean_backtest_report())
    path = export_txt(report.to_dict(), tmp_path / "risk.txt")
    text = Path(path).read_text()
    assert "risk_status: PASS" in text
