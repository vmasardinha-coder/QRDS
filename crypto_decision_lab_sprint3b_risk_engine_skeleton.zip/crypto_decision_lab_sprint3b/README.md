# Crypto Decision Lab - Sprint 3B Risk Engine Skeleton Offline

Sprint 3B cria o primeiro Risk Engine offline de pesquisa.

Ainda nao ha execucao real, API key, WebSocket autenticado, ordem, capital real ou alavancagem.

## Validacao

```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_risk_engine_report.py
```

Resultado esperado: `32 passed` e relatorio PASS para o caso limpo.
