from crypto_decision_lab.backtest_fixture import make_clean_backtest_report, make_dirty_backtest_report
from crypto_decision_lab.exporters import export_json, export_txt
from crypto_decision_lab.risk_engine import generate_risk_engine_report


def main() -> None:
    clean_backtest = make_clean_backtest_report()
    clean_report = generate_risk_engine_report(clean_backtest)
    dirty_report = generate_risk_engine_report(make_dirty_backtest_report())

    json_path = export_json(clean_report.to_dict(), "reports/sprint3b/risk_engine_report.json")
    txt_path = export_txt(clean_report.to_dict(), "reports/sprint3b/risk_engine_report.txt")

    print("=== Sprint 3B Risk Engine Skeleton Offline ===")
    print(f"Risk schema: {clean_report.schema}")
    print(f"Backtest status: {clean_report.backtest_status}")
    print(f"Risk status: {clean_report.risk_status}")
    print(f"Model blocked: {clean_report.model_blocked}")
    print(f"Research allowed: {clean_report.research_allowed}")
    print(f"Operational decision allowed: {clean_report.operational_decision_allowed}")
    print(f"Risk stage: {clean_report.risk_stage}")
    print(f"Action: {clean_report.action}")
    print(f"Risk score: {clean_report.risk_score:.4f}")
    print(f"Account equity: {clean_report.account_equity:.2f}")
    print(f"Max risk per trade pct: {clean_report.max_risk_per_trade_pct:.4f}")
    print(f"Max loss per trade: {clean_report.max_loss_per_trade:.2f}")
    print(f"Max position notional: {clean_report.max_position_notional:.2f}")
    print(f"Observed max drawdown pct: {clean_report.observed_max_drawdown_pct:.6f}")
    print(f"Drawdown utilization: {clean_report.drawdown_utilization:.6f}")
    print(f"Kill switch active: {clean_report.kill_switch_active}")
    print(f"Real capital used: {clean_report.real_capital_used}")
    print(f"Exchange connected: {clean_report.exchange_connected}")
    print(f"Orders generated: {clean_report.orders_generated}")
    print(f"Next required gate: {clean_report.next_required_gate}")
    print(f"Issues: {clean_report.issues if clean_report.issues else 'none'}")
    print(f"Dirty risk status: {dirty_report.risk_status}")
    print(f"Dirty action: {dirty_report.action}")
    print(f"Dirty issues: {dirty_report.issues}")
    print(f"Generated files: {{'json': '{json_path}', 'txt': '{txt_path}'}}")


if __name__ == "__main__":
    main()
