from crypto_decision_lab.models import BacktestReport


def make_clean_backtest_report() -> BacktestReport:
    return BacktestReport(
        schema="qrds.backtest_report.v1",
        status="PASS",
        model_blocked=False,
        research_allowed=True,
        operational_decision_allowed=False,
        decision_stage="BACKTEST_RESEARCH_ONLY",
        action="NO_TRADE_BACKTEST_RESEARCH_ONLY",
        edge_status="RESEARCH_BACKTEST_ONLY",
        initial_equity=10000.0,
        final_equity=9775.43,
        total_return_pct=-0.022457,
        max_drawdown_pct=0.022457,
        trades=47,
        win_rate=0.0638,
        prediction_coverage=1.0,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        next_required_gate="RISK_ENGINE_REQUIRED",
        issues=[],
    )


def make_dirty_backtest_report() -> BacktestReport:
    return BacktestReport(
        schema="qrds.backtest_report.v1",
        status="BLOCKED",
        model_blocked=True,
        research_allowed=False,
        operational_decision_allowed=False,
        decision_stage="BLOCKED_BY_GATE",
        action="NO_BACKTEST_BLOCKED",
        edge_status="BLOCKED_BY_GATE",
        initial_equity=10000.0,
        final_equity=10000.0,
        total_return_pct=0.0,
        max_drawdown_pct=0.0,
        trades=0,
        win_rate=0.0,
        prediction_coverage=0.0,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        next_required_gate="FIX_UPSTREAM_GATES",
        issues=["gate_blocked:dql=BLOCKED"],
    )
