from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import List, Dict, Any


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True)
class BacktestReport:
    schema: str
    status: str
    model_blocked: bool
    research_allowed: bool
    operational_decision_allowed: bool
    decision_stage: str
    action: str
    edge_status: str
    initial_equity: float
    final_equity: float
    total_return_pct: float
    max_drawdown_pct: float
    trades: int
    win_rate: float
    prediction_coverage: float
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    next_required_gate: str
    issues: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RiskPolicy:
    schema: str = "qrds.risk_policy.v1"
    account_equity: float = 10000.0
    max_risk_per_trade_pct: float = 0.01
    max_position_notional_pct: float = 0.05
    max_allowed_drawdown_pct: float = 0.10
    min_prediction_coverage: float = 0.80
    min_trades_for_research: int = 10
    leverage_allowed: bool = False
    real_capital_allowed: bool = False
    exchange_connection_allowed: bool = False
    order_generation_allowed: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RiskEngineReport:
    schema: str
    generated_at: str
    backtest_status: str
    risk_status: str
    model_blocked: bool
    research_allowed: bool
    operational_decision_allowed: bool
    risk_stage: str
    action: str
    risk_score: float
    account_equity: float
    max_risk_per_trade_pct: float
    max_loss_per_trade: float
    max_position_notional_pct: float
    max_position_notional: float
    max_allowed_drawdown_pct: float
    observed_max_drawdown_pct: float
    drawdown_utilization: float
    kill_switch_active: bool
    leverage_allowed: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    next_required_gate: str
    issues: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
