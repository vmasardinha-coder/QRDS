from crypto_decision_lab.models import BacktestReport, RiskPolicy, RiskEngineReport, utc_now_iso


def _bounded(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(value)))


def validate_policy(policy: RiskPolicy) -> list[str]:
    issues: list[str] = []
    if policy.account_equity <= 0:
        issues.append("invalid_account_equity")
    if not (0 < policy.max_risk_per_trade_pct <= 0.05):
        issues.append("invalid_max_risk_per_trade_pct")
    if not (0 < policy.max_position_notional_pct <= 1.0):
        issues.append("invalid_max_position_notional_pct")
    if not (0 < policy.max_allowed_drawdown_pct <= 1.0):
        issues.append("invalid_max_allowed_drawdown_pct")
    if policy.leverage_allowed:
        issues.append("leverage_not_allowed_in_sprint3b")
    if policy.real_capital_allowed:
        issues.append("real_capital_not_allowed_in_sprint3b")
    if policy.exchange_connection_allowed:
        issues.append("exchange_connection_not_allowed_in_sprint3b")
    if policy.order_generation_allowed:
        issues.append("order_generation_not_allowed_in_sprint3b")
    return issues


def generate_risk_engine_report(backtest: BacktestReport, policy: RiskPolicy | None = None) -> RiskEngineReport:
    policy = policy or RiskPolicy()
    issues = validate_policy(policy)

    if backtest.status != "PASS":
        issues.append(f"backtest_status:{backtest.status}")
    if backtest.model_blocked:
        issues.append("backtest_model_blocked")
    if not backtest.research_allowed:
        issues.append("research_not_allowed")
    if backtest.operational_decision_allowed:
        issues.append("unexpected_operational_decision_allowed")
    if backtest.real_capital_used:
        issues.append("real_capital_used")
    if backtest.exchange_connected:
        issues.append("exchange_connected")
    if backtest.orders_generated:
        issues.append("orders_generated")
    if backtest.prediction_coverage < policy.min_prediction_coverage:
        issues.append("low_prediction_coverage")
    if backtest.trades < policy.min_trades_for_research:
        issues.append("insufficient_trades_for_research")
    if backtest.max_drawdown_pct > policy.max_allowed_drawdown_pct:
        issues.append("max_drawdown_exceeded")

    max_loss_per_trade = round(policy.account_equity * policy.max_risk_per_trade_pct, 2)
    max_position_notional = round(policy.account_equity * policy.max_position_notional_pct, 2)
    drawdown_utilization = _bounded(backtest.max_drawdown_pct / policy.max_allowed_drawdown_pct) if policy.max_allowed_drawdown_pct else 1.0
    kill_switch_active = any(issue in issues for issue in [
        "real_capital_used",
        "exchange_connected",
        "orders_generated",
        "max_drawdown_exceeded",
        "leverage_not_allowed_in_sprint3b",
    ])

    blocked = bool(issues) or kill_switch_active
    if blocked:
        risk_status = "BLOCKED"
        action = "NO_RISK_BLOCKED"
        risk_stage = "RISK_BLOCKED"
        next_required_gate = "FIX_RISK_OR_UPSTREAM_GATES"
        research_allowed = False
    else:
        risk_status = "PASS"
        action = "NO_TRADE_RISK_RESEARCH_ONLY"
        risk_stage = "RISK_RESEARCH_ONLY"
        next_required_gate = "PAPER_TRADING_REQUIRED"
        research_allowed = True

    drawdown_component = 1.0 - drawdown_utilization
    coverage_component = _bounded(backtest.prediction_coverage)
    safety_component = 0.0 if kill_switch_active else 1.0
    risk_score = round((drawdown_component + coverage_component + safety_component) / 3.0, 4)
    if blocked:
        risk_score = min(risk_score, 0.5)

    return RiskEngineReport(
        schema="qrds.risk_engine_report.v1",
        generated_at=utc_now_iso(),
        backtest_status=backtest.status,
        risk_status=risk_status,
        model_blocked=blocked,
        research_allowed=research_allowed,
        operational_decision_allowed=False,
        risk_stage=risk_stage,
        action=action,
        risk_score=risk_score,
        account_equity=policy.account_equity,
        max_risk_per_trade_pct=policy.max_risk_per_trade_pct,
        max_loss_per_trade=max_loss_per_trade,
        max_position_notional_pct=policy.max_position_notional_pct,
        max_position_notional=max_position_notional,
        max_allowed_drawdown_pct=policy.max_allowed_drawdown_pct,
        observed_max_drawdown_pct=backtest.max_drawdown_pct,
        drawdown_utilization=round(drawdown_utilization, 6),
        kill_switch_active=kill_switch_active,
        leverage_allowed=policy.leverage_allowed,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        next_required_gate=next_required_gate,
        issues=issues,
    )
