from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import os
import time
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Tuple

APPROVAL_PHRASE = "APROVO TESTE PUBLICO HTTP LIVE SEM API KEY, SEM CONTA REAL, SEM ORDEM E SEM CAPITAL REAL."
API_KEY_ENV_VARS = (
    "BINANCE_API_KEY",
    "BINANCE_SECRET_KEY",
    "BINANCE_API_SECRET",
    "BYBIT_API_KEY",
    "BYBIT_SECRET_KEY",
    "BYBIT_API_SECRET",
    "OKX_API_KEY",
    "OKX_SECRET_KEY",
    "OKX_API_SECRET",
    "OKX_PASSPHRASE",
)
SUPPORTED_EXCHANGES = ("binance", "bybit", "okx")


@dataclass(frozen=True)
class NormalizedCandle:
    exchange: str
    symbol: str
    timestamp_ms: int
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass(frozen=True)
class EndpointSpec:
    exchange: str
    url: str
    params: Dict[str, str]
    timeout_seconds: float = 5.0

    def full_url(self) -> str:
        return f"{self.url}?{urllib.parse.urlencode(self.params)}"


@dataclass
class PublicLiveSmokeReport:
    schema: str
    generated_at_utc: str
    live_smoke_status: str
    model_blocked: bool
    public_http_live_data_allowed: bool
    live_http_opt_in_enabled: bool
    manual_approval_required: bool
    manual_approval_granted: bool
    explicit_approval_phrase_valid: bool
    live_smoke_authorized: bool
    live_smoke_executed: bool
    fixture_replay_used: bool
    network_calls_executed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    supported_exchanges: List[str]
    requested_exchanges: List[str]
    successful_exchanges: List[str]
    failed_exchanges: Dict[str, str]
    normalized_candles_per_exchange: Dict[str, int]
    endpoint_specs_valid: bool
    adapter_contract_valid: bool
    timestamp_order_valid: bool
    ohlcv_contract_valid: bool
    response_shape_valid: bool
    normalization_consistent: bool
    public_endpoints_reached: int
    safety_policy: str
    next_required_gate: str
    issues: List[str]
    action: str


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def api_key_present() -> bool:
    return any(bool(os.environ.get(name)) for name in API_KEY_ENV_VARS)


def live_opt_in_enabled() -> bool:
    return os.environ.get("QRDS_PUBLIC_HTTP_LIVE_SMOKE_ENABLED", "").strip() == "1"


def explicit_approval_valid() -> bool:
    return os.environ.get("QRDS_PUBLIC_HTTP_LIVE_SMOKE_APPROVAL", "").strip() == APPROVAL_PHRASE


def default_endpoint_specs() -> Dict[str, EndpointSpec]:
    return {
        "binance": EndpointSpec(
            exchange="binance",
            url="https://data-api.binance.vision/api/v3/klines",
            params={"symbol": "BTCUSDT", "interval": "1m", "limit": "5"},
        ),
        "bybit": EndpointSpec(
            exchange="bybit",
            url="https://api.bybit.com/v5/market/kline",
            params={"category": "spot", "symbol": "BTCUSDT", "interval": "1", "limit": "5"},
        ),
        "okx": EndpointSpec(
            exchange="okx",
            url="https://www.okx.com/api/v5/market/candles",
            params={"instId": "BTC-USDT", "bar": "1m", "limit": "5"},
        ),
    }


def fixture_payloads() -> Dict[str, Any]:
    base = 1_704_067_200_000
    return {
        "binance": [
            [base + i * 60_000, "50000", "50100", "49900", "50050", "10"] for i in range(5)
        ],
        "bybit": {
            "retCode": 0,
            "result": {
                "list": [
                    [str(base + i * 60_000), "50000", "50100", "49900", "50050", "10"] for i in reversed(range(5))
                ]
            },
        },
        "okx": {
            "code": "0",
            "data": [
                [str(base + i * 60_000), "50000", "50100", "49900", "50050", "10"] for i in reversed(range(5))
            ],
        },
    }


def http_get_json(spec: EndpointSpec) -> Any:
    req = urllib.request.Request(
        spec.full_url(),
        headers={
            "User-Agent": "QRDS-QOS-public-http-live-smoke/0.4.9",
            "Accept": "application/json",
        },
        method="GET",
    )
    started = time.time()
    with urllib.request.urlopen(req, timeout=spec.timeout_seconds) as response:  # noqa: S310 - public no-auth smoke test only
        raw = response.read(2_000_000)
        if response.status < 200 or response.status >= 300:
            raise RuntimeError(f"HTTP {response.status}")
    elapsed = time.time() - started
    if elapsed > spec.timeout_seconds + 2:
        raise RuntimeError(f"timeout_budget_exceeded:{elapsed:.2f}s")
    return json.loads(raw.decode("utf-8"))


def normalize(exchange: str, payload: Any) -> List[NormalizedCandle]:
    rows: List[Any]
    symbol = "BTCUSDT"
    if exchange == "binance":
        if not isinstance(payload, list):
            raise ValueError("binance_response_not_list")
        rows = payload
    elif exchange == "bybit":
        if not isinstance(payload, dict) or payload.get("retCode") != 0:
            raise ValueError("bybit_response_invalid")
        rows = payload.get("result", {}).get("list", [])
    elif exchange == "okx":
        if not isinstance(payload, dict) or payload.get("code") != "0":
            raise ValueError("okx_response_invalid")
        rows = payload.get("data", [])
        symbol = "BTC-USDT"
    else:
        raise ValueError(f"unsupported_exchange:{exchange}")

    candles: List[NormalizedCandle] = []
    for row in rows:
        if not isinstance(row, (list, tuple)) or len(row) < 6:
            raise ValueError(f"{exchange}_row_shape_invalid")
        candles.append(
            NormalizedCandle(
                exchange=exchange,
                symbol=symbol,
                timestamp_ms=int(row[0]),
                open=float(row[1]),
                high=float(row[2]),
                low=float(row[3]),
                close=float(row[4]),
                volume=float(row[5]),
            )
        )
    candles.sort(key=lambda c: c.timestamp_ms)
    return candles


def validate_candles(candles: List[NormalizedCandle]) -> Tuple[bool, bool]:
    if not candles:
        return False, False
    timestamp_ok = all(candles[i].timestamp_ms > candles[i - 1].timestamp_ms for i in range(1, len(candles)))
    ohlcv_ok = all(
        c.low <= c.open <= c.high
        and c.low <= c.close <= c.high
        and c.low <= c.high
        and c.open > 0
        and c.high > 0
        and c.low > 0
        and c.close > 0
        and c.volume >= 0
        for c in candles
    )
    return timestamp_ok, ohlcv_ok


def build_report(use_live: bool | None = None, requested_exchanges: List[str] | None = None) -> PublicLiveSmokeReport:
    requested = requested_exchanges or list(SUPPORTED_EXCHANGES)
    key_present = api_key_present()
    opt_in = live_opt_in_enabled() if use_live is None else use_live
    approval_ok = explicit_approval_valid()
    authorized = bool(opt_in and approval_ok and not key_present)

    endpoint_specs = default_endpoint_specs()
    payloads = fixture_payloads()
    fixture_mode = not authorized

    issues: List[str] = []
    failed: Dict[str, str] = {}
    normalized_counts: Dict[str, int] = {}
    successful: List[str] = []
    all_timestamp_ok = True
    all_ohlcv_ok = True
    response_shape_valid = True

    if key_present:
        issues.append("exchange_api_key_env_present")
    if opt_in and not approval_ok:
        issues.append("explicit_approval_phrase_missing_or_invalid")

    for exchange in requested:
        if exchange not in SUPPORTED_EXCHANGES:
            failed[exchange] = "unsupported_exchange"
            continue
        try:
            payload = http_get_json(endpoint_specs[exchange]) if authorized else payloads[exchange]
            candles = normalize(exchange, payload)
            timestamp_ok, ohlcv_ok = validate_candles(candles)
            normalized_counts[exchange] = len(candles)
            all_timestamp_ok = all_timestamp_ok and timestamp_ok
            all_ohlcv_ok = all_ohlcv_ok and ohlcv_ok
            if timestamp_ok and ohlcv_ok and len(candles) >= 1:
                successful.append(exchange)
            else:
                failed[exchange] = "normalized_candle_validation_failed"
        except Exception as exc:  # public smoke report must capture failures rather than crashing
            failed[exchange] = f"{type(exc).__name__}:{exc}"
            response_shape_valid = False

    endpoints_valid = set(requested).issubset(set(SUPPORTED_EXCHANGES)) and bool(requested)
    adapter_contract_valid = len(successful) > 0 and all(v >= 1 for v in normalized_counts.values())
    normalization_consistent = all(v >= 1 for v in normalized_counts.values()) and all_timestamp_ok and all_ohlcv_ok

    if authorized:
        network_calls_executed = True
        live_executed = True
        public_endpoints_reached = len(successful)
        if len(successful) == len(requested) and not failed and all_timestamp_ok and all_ohlcv_ok:
            status = "PASS"
        elif len(successful) >= 1:
            status = "PARTIAL"
            issues.append("one_or_more_public_endpoints_failed")
        else:
            status = "BLOCKED"
            issues.append("all_public_endpoints_failed")
    else:
        network_calls_executed = False
        live_executed = False
        public_endpoints_reached = 0
        # The safety gate can pass in fixture mode only if it blocks live execution correctly.
        status = "PASS" if not key_present else "BLOCKED"

    if not all_timestamp_ok:
        issues.append("timestamp_order_invalid")
    if not all_ohlcv_ok:
        issues.append("ohlcv_contract_invalid")
    if failed and authorized:
        for exchange, reason in failed.items():
            issues.append(f"{exchange}_public_endpoint_failed:{reason}")

    model_blocked = status == "BLOCKED"
    if status == "PASS" and authorized:
        action = "PUBLIC_LIVE_SMOKE_COMPLETED_REVIEW_REQUIRED"
        next_gate = "PUBLIC_HTTP_LIVE_SMOKE_RESULT_REVIEW_REQUIRED"
        safety_policy = "PUBLIC_ONLY_NO_AUTH_EXPLICIT_APPROVAL_LIVE_SMOKE_EXECUTED"
    elif status == "PARTIAL":
        action = "PUBLIC_LIVE_SMOKE_PARTIAL_REVIEW_REQUIRED"
        next_gate = "PUBLIC_HTTP_LIVE_SMOKE_RESULT_REVIEW_REQUIRED"
        safety_policy = "PUBLIC_ONLY_NO_AUTH_EXPLICIT_APPROVAL_LIVE_SMOKE_PARTIAL"
    elif not authorized:
        action = "NO_PUBLIC_LIVE_SMOKE_AWAITING_EXPLICIT_APPROVAL"
        next_gate = "PUBLIC_HTTP_LIVE_SMOKE_EXPLICIT_APPROVAL_REQUIRED"
        safety_policy = "PUBLIC_ONLY_NO_AUTH_EXPLICIT_APPROVAL_GATE_FIXTURE_DEFAULT"
    else:
        action = "NO_PUBLIC_LIVE_SMOKE_BLOCKED"
        next_gate = "PUBLIC_HTTP_LIVE_SMOKE_REMEDIATION_REQUIRED"
        safety_policy = "PUBLIC_ONLY_NO_AUTH_EXPLICIT_APPROVAL_LIVE_SMOKE_BLOCKED"

    return PublicLiveSmokeReport(
        schema="qrds.public_http_live_smoke_execute_report.v1",
        generated_at_utc=utc_now_iso(),
        live_smoke_status=status,
        model_blocked=model_blocked,
        public_http_live_data_allowed=True,
        live_http_opt_in_enabled=bool(opt_in),
        manual_approval_required=True,
        manual_approval_granted=approval_ok,
        explicit_approval_phrase_valid=approval_ok,
        live_smoke_authorized=authorized,
        live_smoke_executed=live_executed,
        fixture_replay_used=fixture_mode,
        network_calls_executed=network_calls_executed,
        authenticated_connection_used=False,
        api_key_required=False,
        api_key_present=key_present,
        account_connection_required=False,
        websocket_used=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        supported_exchanges=list(SUPPORTED_EXCHANGES),
        requested_exchanges=requested,
        successful_exchanges=successful,
        failed_exchanges=failed,
        normalized_candles_per_exchange=normalized_counts,
        endpoint_specs_valid=endpoints_valid,
        adapter_contract_valid=adapter_contract_valid,
        timestamp_order_valid=all_timestamp_ok,
        ohlcv_contract_valid=all_ohlcv_ok,
        response_shape_valid=response_shape_valid,
        normalization_consistent=normalization_consistent,
        public_endpoints_reached=public_endpoints_reached,
        safety_policy=safety_policy,
        next_required_gate=next_gate,
        issues=issues,
        action=action,
    )


def report_to_dict(report: PublicLiveSmokeReport) -> Dict[str, Any]:
    return asdict(report)
