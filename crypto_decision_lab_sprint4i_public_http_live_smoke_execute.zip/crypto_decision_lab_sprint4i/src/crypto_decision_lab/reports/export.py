from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Tuple


def export_report(report: Dict[str, Any], out_dir: str | Path = "reports/sprint4i") -> Dict[str, str]:
    path = Path(out_dir)
    path.mkdir(parents=True, exist_ok=True)
    json_path = path / "public_http_live_smoke_execute_report.json"
    txt_path = path / "public_http_live_smoke_execute_report.txt"
    json_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    lines = [
        "QRDS Sprint 4I Public HTTP Live Smoke Execute Report",
        f"schema: {report.get('schema')}",
        f"live_smoke_status: {report.get('live_smoke_status')}",
        f"live_smoke_authorized: {report.get('live_smoke_authorized')}",
        f"live_smoke_executed: {report.get('live_smoke_executed')}",
        f"network_calls_executed: {report.get('network_calls_executed')}",
        f"api_key_required: {report.get('api_key_required')}",
        f"api_key_present: {report.get('api_key_present')}",
        f"account_connection_required: {report.get('account_connection_required')}",
        f"websocket_used: {report.get('websocket_used')}",
        f"real_capital_used: {report.get('real_capital_used')}",
        f"exchange_connected: {report.get('exchange_connected')}",
        f"orders_generated: {report.get('orders_generated')}",
        f"successful_exchanges: {report.get('successful_exchanges')}",
        f"failed_exchanges: {report.get('failed_exchanges')}",
        f"normalized_candles_per_exchange: {report.get('normalized_candles_per_exchange')}",
        f"next_required_gate: {report.get('next_required_gate')}",
        f"issues: {report.get('issues')}",
        f"action: {report.get('action')}",
    ]
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
