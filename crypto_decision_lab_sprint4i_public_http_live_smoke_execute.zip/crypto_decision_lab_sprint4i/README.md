# QRDS Sprint 4I — Public HTTP Live Smoke Test

Safety gate para executar somente chamadas HTTP públicas de mercado, sem API key, sem conta real, sem WebSocket, sem ordens e sem capital real.

## Aprovação explícita exigida

O modo live só roda se as variáveis abaixo forem definidas:

```bash
export QRDS_PUBLIC_HTTP_LIVE_SMOKE_ENABLED=1
export QRDS_PUBLIC_HTTP_LIVE_SMOKE_APPROVAL="APROVO TESTE PUBLICO HTTP LIVE SEM API KEY, SEM CONTA REAL, SEM ORDEM E SEM CAPITAL REAL."
```

Sem isso, o sistema permanece em fixture/replay.
