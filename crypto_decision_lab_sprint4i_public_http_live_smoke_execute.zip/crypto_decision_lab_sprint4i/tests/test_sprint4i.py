import os
import pytest

from crypto_decision_lab.connectors.public_http_live_smoke import (
    API_KEY_ENV_VARS,
    APPROVAL_PHRASE,
    SUPPORTED_EXCHANGES,
    build_report,
    default_endpoint_specs,
    explicit_approval_valid,
    fixture_payloads,
    live_opt_in_enabled,
    normalize,
    report_to_dict,
    validate_candles,
)
from crypto_decision_lab.reports.export import export_report


CASES = list(range(54))


def clear_env(monkeypatch):
    monkeypatch.delenv("QRDS_PUBLIC_HTTP_LIVE_SMOKE_ENABLED", raising=False)
    monkeypatch.delenv("QRDS_PUBLIC_HTTP_LIVE_SMOKE_APPROVAL", raising=False)
    for key in API_KEY_ENV_VARS:
        monkeypatch.delenv(key, raising=False)


@pytest.mark.parametrize("case", CASES)
def test_sprint4i_contracts(case, monkeypatch, tmp_path):
    clear_env(monkeypatch)
    fixtures = fixture_payloads()

    if case < 3:
        exchange = SUPPORTED_EXCHANGES[case]
        candles = normalize(exchange, fixtures[exchange])
        assert len(candles) == 5
        assert all(c.exchange == exchange for c in candles)
        return

    if case < 6:
        exchange = SUPPORTED_EXCHANGES[case - 3]
        candles = normalize(exchange, fixtures[exchange])
        timestamp_ok, ohlcv_ok = validate_candles(candles)
        assert timestamp_ok is True
        assert ohlcv_ok is True
        return

    if case < 9:
        exchange = SUPPORTED_EXCHANGES[case - 6]
        spec = default_endpoint_specs()[exchange]
        url = spec.full_url()
        assert url.startswith("https://")
        assert "api_key" not in url.lower()
        assert "secret" not in url.lower()
        return

    if case == 9:
        assert live_opt_in_enabled() is False
        return

    if case == 10:
        monkeypatch.setenv("QRDS_PUBLIC_HTTP_LIVE_SMOKE_ENABLED", "1")
        assert live_opt_in_enabled() is True
        return

    if case == 11:
        assert explicit_approval_valid() is False
        return

    if case == 12:
        monkeypatch.setenv("QRDS_PUBLIC_HTTP_LIVE_SMOKE_APPROVAL", APPROVAL_PHRASE)
        assert explicit_approval_valid() is True
        return

    if case == 13:
        report = build_report(use_live=False)
        assert report.live_smoke_status == "PASS"
        assert report.live_smoke_executed is False
        assert report.network_calls_executed is False
        return

    if case == 14:
        report = build_report(use_live=False)
        assert report.fixture_replay_used is True
        assert report.api_key_required is False
        assert report.account_connection_required is False
        return

    if case == 15:
        monkeypatch.setenv("BINANCE_API_KEY", "forbidden")
        report = build_report(use_live=False)
        assert report.live_smoke_status == "BLOCKED"
        assert report.api_key_present is True
        return

    if case == 16:
        report = build_report(use_live=False, requested_exchanges=["binance"])
        assert report.requested_exchanges == ["binance"]
        assert report.normalized_candles_per_exchange["binance"] == 5
        return

    if case == 17:
        report = build_report(use_live=False, requested_exchanges=["bybit"])
        assert report.requested_exchanges == ["bybit"]
        assert report.normalized_candles_per_exchange["bybit"] == 5
        return

    if case == 18:
        report = build_report(use_live=False, requested_exchanges=["okx"])
        assert report.requested_exchanges == ["okx"]
        assert report.normalized_candles_per_exchange["okx"] == 5
        return

    if case == 19:
        report = build_report(use_live=False, requested_exchanges=["invalid"])
        assert report.failed_exchanges["invalid"] == "unsupported_exchange"
        return

    if case == 20:
        report = build_report(use_live=False)
        d = report_to_dict(report)
        assert d["schema"] == "qrds.public_http_live_smoke_execute_report.v1"
        return

    if case == 21:
        report = build_report(use_live=False)
        paths = export_report(report_to_dict(report), tmp_path)
        assert paths["json"].endswith(".json")
        assert paths["txt"].endswith(".txt")
        return

    if case == 22:
        report = build_report(use_live=False)
        assert report.orders_generated is False
        assert report.real_capital_used is False
        assert report.exchange_connected is False
        return

    if case == 23:
        report = build_report(use_live=False)
        assert report.websocket_used is False
        assert report.authenticated_connection_used is False
        return

    if case == 24:
        report = build_report(use_live=False)
        assert report.supported_exchanges == ["binance", "bybit", "okx"]
        return

    if case == 25:
        report = build_report(use_live=False)
        assert report.endpoint_specs_valid is True
        assert report.adapter_contract_valid is True
        return

    if case == 26:
        report = build_report(use_live=False)
        assert report.timestamp_order_valid is True
        assert report.ohlcv_contract_valid is True
        return

    if case == 27:
        report = build_report(use_live=False)
        assert report.response_shape_valid is True
        assert report.normalization_consistent is True
        return

    if case == 28:
        report = build_report(use_live=False)
        assert report.public_endpoints_reached == 0
        return

    if case == 29:
        report = build_report(use_live=False)
        assert report.next_required_gate == "PUBLIC_HTTP_LIVE_SMOKE_EXPLICIT_APPROVAL_REQUIRED"
        return

    if case == 30:
        report = build_report(use_live=False)
        assert report.action == "NO_PUBLIC_LIVE_SMOKE_AWAITING_EXPLICIT_APPROVAL"
        return

    if case == 31:
        report = build_report(use_live=False)
        assert report.issues == []
        return

    if case == 32:
        candles = normalize("binance", fixtures["binance"])
        assert candles[0].timestamp_ms < candles[-1].timestamp_ms
        return

    if case == 33:
        candles = normalize("bybit", fixtures["bybit"])
        assert candles[0].timestamp_ms < candles[-1].timestamp_ms
        return

    if case == 34:
        candles = normalize("okx", fixtures["okx"])
        assert candles[0].timestamp_ms < candles[-1].timestamp_ms
        return

    if case == 35:
        spec = default_endpoint_specs()["binance"]
        assert "symbol=BTCUSDT" in spec.full_url()
        return

    if case == 36:
        spec = default_endpoint_specs()["bybit"]
        assert "category=spot" in spec.full_url()
        return

    if case == 37:
        spec = default_endpoint_specs()["okx"]
        assert "instId=BTC-USDT" in spec.full_url()
        return

    if case == 38:
        report = build_report(use_live=False)
        assert report.safety_policy == "PUBLIC_ONLY_NO_AUTH_EXPLICIT_APPROVAL_GATE_FIXTURE_DEFAULT"
        return

    if case == 39:
        monkeypatch.setenv("QRDS_PUBLIC_HTTP_LIVE_SMOKE_ENABLED", "1")
        report = build_report()
        assert report.live_http_opt_in_enabled is True
        assert report.live_smoke_authorized is False
        return

    if case == 40:
        monkeypatch.setenv("QRDS_PUBLIC_HTTP_LIVE_SMOKE_APPROVAL", APPROVAL_PHRASE)
        report = build_report()
        assert report.manual_approval_granted is True
        assert report.live_smoke_authorized is False
        return

    if case == 41:
        monkeypatch.setenv("QRDS_PUBLIC_HTTP_LIVE_SMOKE_ENABLED", "1")
        monkeypatch.setenv("QRDS_PUBLIC_HTTP_LIVE_SMOKE_APPROVAL", "wrong")
        report = build_report()
        assert "explicit_approval_phrase_missing_or_invalid" in report.issues
        return

    if case == 42:
        monkeypatch.setenv("QRDS_PUBLIC_HTTP_LIVE_SMOKE_ENABLED", "1")
        monkeypatch.setenv("QRDS_PUBLIC_HTTP_LIVE_SMOKE_APPROVAL", APPROVAL_PHRASE)
        monkeypatch.setenv("OKX_API_KEY", "forbidden")
        report = build_report()
        assert report.live_smoke_authorized is False
        assert report.api_key_present is True
        return

    if case == 43:
        report = build_report(use_live=False)
        assert set(report.successful_exchanges) == set(SUPPORTED_EXCHANGES)
        return

    if case == 44:
        report = build_report(use_live=False)
        assert report.failed_exchanges == {}
        return

    if case == 45:
        report = build_report(use_live=False)
        assert report.live_smoke_status in {"PASS", "PARTIAL", "BLOCKED"}
        return

    if case == 46:
        report = build_report(use_live=False)
        assert report.model_blocked is False
        return

    if case == 47:
        report = build_report(use_live=False)
        assert report.public_http_live_data_allowed is True
        return

    if case == 48:
        report = build_report(use_live=False)
        assert report.manual_approval_required is True
        return

    if case == 49:
        report = build_report(use_live=False)
        assert report.api_key_required is False
        return

    if case == 50:
        report = build_report(use_live=False)
        assert report.account_connection_required is False
        return

    if case == 51:
        report = build_report(use_live=False)
        assert report.live_smoke_executed is False
        return

    if case == 52:
        report = build_report(use_live=False)
        assert report.network_calls_executed is False
        return

    if case == 53:
        report = build_report(use_live=False)
        assert report.normalized_candles_per_exchange == {"binance": 5, "bybit": 5, "okx": 5}
        return
