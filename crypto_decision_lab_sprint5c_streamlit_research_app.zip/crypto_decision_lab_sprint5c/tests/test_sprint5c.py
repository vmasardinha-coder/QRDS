import json
from pathlib import Path
import pytest

from crypto_decision_lab.dashboard.payload import build_dashboard_payload, render_dashboard_html
from crypto_decision_lab.export.artifacts import write_json_txt

INVARIANTS = [('schema', 'qrds.streamlit_research_app.v1'), ('app_status', 'PASS'), ('validation_status', 'PASS'), ('model_blocked', False), ('research_allowed', True), ('operational_decision_allowed', False), ('app_mode', 'INTERACTIVE_RESEARCH_ONLY'), ('quality_score', 1.0), ('dashboard_contract_valid', True), ('html_artifact_valid', True), ('streamlit_app_optional', True), ('streamlit_required_for_tests', False), ('local_run_required', False), ('live_pipeline_enabled', False), ('network_calls_executed', False), ('authenticated_connection_used', False), ('api_key_required', False), ('api_key_present', False), ('account_connection_required', False), ('websocket_used', False), ('real_capital_used', False), ('exchange_connected', False), ('orders_generated', False), ('simulation_exchange', 'binance'), ('action', 'PROMOTE_STREAMLIT_RESEARCH_APP_OPTIONAL_NO_OPERATIONAL_DECISION'), ('next_required_gate', 'INTERACTIVE_RESEARCH_APP_LOCAL_RUN_VALIDATION_OPTIONAL'), ('routes.binance', 'SIMULATION_FIXTURE_REPLAY'), ('routes.okx', 'PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH'), ('routes.bybit', 'PENDING_BLOCKED_BY_403'), ('kpis.total_normalized_candles', 10), ('kpis.feature_rows', 10), ('kpis.regime_variants', 3), ('kpis.last_regime_code', 'high_volatility|upper_close'), ('kpis.dql_status', 'PASS'), ('kpis.feature_quality_status', 'PASS'), ('kpis.regime_status', 'PASS'), ('panels.kpi_panel_valid', True), ('panels.route_panel_valid', True), ('panels.safety_panel_valid', True), ('panels.research_panel_valid', True), ('issues.0', 'bybit_public_http_blocked_by_403_pending_not_blocking'), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False), ('operational_decision_allowed', False)]


def get_path(payload, dotted):
    cur = payload
    for part in dotted.split('.'):
        if isinstance(cur, list):
            cur = cur[int(part)]
        else:
            cur = cur[part]
    return cur


@pytest.mark.parametrize("path, expected", INVARIANTS)
def test_payload_invariants(path, expected):
    payload = build_dashboard_payload()
    assert get_path(payload, path) == expected


def test_html_render_contains_core_sections(tmp_path):
    payload = build_dashboard_payload()
    html_path = render_dashboard_html(payload, tmp_path / "index.html")
    text = Path(html_path).read_text(encoding="utf-8")
    assert "QRDS Interactive Research Dashboard" in text
    assert "Routes" in text
    assert "Safety" in text
    assert "INTERACTIVE_RESEARCH_ONLY" in text


def test_json_txt_export(tmp_path):
    payload = build_dashboard_payload()
    artifacts = write_json_txt(payload, tmp_path, "report")
    assert Path(artifacts["json"]).exists()
    assert Path(artifacts["txt"]).exists()
    data = json.loads(Path(artifacts["json"]).read_text(encoding="utf-8"))
    assert data["schema"] == "qrds.streamlit_research_app.v1"


def test_app_streamlit_file_exists():
    assert Path("app_streamlit.py").exists()


def test_no_real_risk_flags():
    p = build_dashboard_payload()
    assert not p["api_key_required"]
    assert not p["api_key_present"]
    assert not p["account_connection_required"]
    assert not p["orders_generated"]
    assert not p["real_capital_used"]


def test_routes_policy():
    p = build_dashboard_payload()
    assert p["routes"]["binance"] == "SIMULATION_FIXTURE_REPLAY"
    assert "OKX" not in p["routes"]["binance"]
    assert p["routes"]["okx"].endswith("NO_AUTH")
    assert p["routes"]["bybit"] == "PENDING_BLOCKED_BY_403"


def test_operational_decision_blocked():
    p = build_dashboard_payload()
    assert p["research_allowed"] is True
    assert p["operational_decision_allowed"] is False


def test_streamlit_is_optional():
    p = build_dashboard_payload()
    assert p["streamlit_app_optional"] is True
    assert p["streamlit_required_for_tests"] is False


def test_kpi_values_are_positive():
    p = build_dashboard_payload()
    assert p["kpis"]["total_normalized_candles"] > 0
    assert p["kpis"]["feature_rows"] > 0
    assert p["kpis"]["regime_variants"] > 0


def test_next_gate_is_optional_local_validation():
    p = build_dashboard_payload()
    assert p["next_required_gate"] == "INTERACTIVE_RESEARCH_APP_LOCAL_RUN_VALIDATION_OPTIONAL"


def test_schema_prefix():
    p = build_dashboard_payload()
    assert p["schema"].startswith("qrds.")
