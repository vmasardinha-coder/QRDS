from pathlib import Path
from crypto_decision_lab.dashboard.payload import build_dashboard_payload, render_dashboard_html
from crypto_decision_lab.export.artifacts import write_json_txt

payload = build_dashboard_payload()
html = render_dashboard_html(payload)
artifacts = write_json_txt(payload)
artifacts["html"] = html

print("=== Sprint 5C Interactive Research App Streamlit Optional ===")
print(f"App schema: {payload['schema']}")
print(f"App status: {payload['app_status']}")
print(f"Validation status: {payload['validation_status']}")
print(f"Research allowed: {payload['research_allowed']}")
print(f"Operational decision allowed: {payload['operational_decision_allowed']}")
print(f"App mode: {payload['app_mode']}")
print(f"Streamlit optional: {payload['streamlit_app_optional']}")
print(f"Streamlit required for tests: {payload['streamlit_required_for_tests']}")
print(f"API key required: {payload['api_key_required']}")
print(f"Account connection required: {payload['account_connection_required']}")
print(f"Orders generated: {payload['orders_generated']}")
print(f"Binance route: {payload['routes']['binance']}")
print(f"OKX route: {payload['routes']['okx']}")
print(f"Bybit route: {payload['routes']['bybit']}")
print(f"Generated files: {artifacts}")
print("Optional run: streamlit run app_streamlit.py")
