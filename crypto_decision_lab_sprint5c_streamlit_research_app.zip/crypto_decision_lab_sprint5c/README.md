# Sprint 5C - Interactive Research App Streamlit Optional

Objetivo: validar um app Streamlit opcional em modo INTERACTIVE_RESEARCH_ONLY.

Sem API key, sem conta real, sem ordem, sem capital real e sem execucao operacional.

## Teste

```bash
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_streamlit_research_app.py
```

## App opcional

```bash
python -m pip install -e ".[dashboard]"
streamlit run app_streamlit.py
```
