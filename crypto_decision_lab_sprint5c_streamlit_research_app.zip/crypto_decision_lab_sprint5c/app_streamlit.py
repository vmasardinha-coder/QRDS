from crypto_decision_lab.dashboard.payload import build_dashboard_payload

payload = build_dashboard_payload()

try:
    import streamlit as st
except Exception:
    print("Streamlit is optional. Install with: python -m pip install -e '.[dashboard]'")
    print(payload)
else:
    st.set_page_config(page_title="QRDS Research Dashboard", layout="wide")
    st.title("QRDS Interactive Research Dashboard")
    st.caption("Research-only. No API key, no real account, no orders, no real capital.")
    c1, c2, c3 = st.columns(3)
    c1.metric("App status", payload["app_status"])
    c2.metric("Quality", payload["quality_score"])
    c3.metric("Operational", str(payload["operational_decision_allowed"]))
    st.subheader("Routes")
    st.json(payload["routes"])
    st.subheader("KPIs")
    st.json(payload["kpis"])
    st.subheader("Safety")
    st.json({k: payload[k] for k in ["api_key_required", "api_key_present", "account_connection_required", "orders_generated", "real_capital_used"]})
