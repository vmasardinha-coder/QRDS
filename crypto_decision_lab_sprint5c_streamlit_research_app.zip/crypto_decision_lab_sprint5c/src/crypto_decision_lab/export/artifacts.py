import json
from pathlib import Path


def _flatten(value, prefix=""):
    lines = []
    if isinstance(value, dict):
        for k, v in value.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            lines.extend(_flatten(v, key))
    else:
        lines.append(f"{prefix}: {value}")
    return lines


def write_json_txt(payload, output_dir="reports/sprint5c", stem="streamlit_research_app_report"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    json_path = out / f"{stem}.json"
    txt_path = out / f"{stem}.txt"
    json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    txt_path.write_text("\n".join(_flatten(payload)) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
