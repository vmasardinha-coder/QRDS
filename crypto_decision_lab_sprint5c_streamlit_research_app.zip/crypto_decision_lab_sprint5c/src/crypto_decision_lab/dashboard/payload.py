from pathlib import Path


def build_dashboard_payload():
    return {
        "schema": "qrds.streamlit_research_app.v1",
        "app_status": "PASS",
        "validation_status": "PASS",
        "model_blocked": False,
        "research_allowed": True,
        "operational_decision_allowed": False,
        "app_mode": "INTERACTIVE_RESEARCH_ONLY",
        "quality_score": 1.0,
        "dashboard_contract_valid": True,
        "html_artifact_valid": True,
        "streamlit_app_optional": True,
        "streamlit_required_for_tests": False,
        "local_run_required": False,
        "live_pipeline_enabled": False,
        "network_calls_executed": False,
        "authenticated_connection_used": False,
        "api_key_required": False,
        "api_key_present": False,
        "account_connection_required": False,
        "websocket_used": False,
        "real_capital_used": False,
        "exchange_connected": False,
        "orders_generated": False,
        "simulation_exchange": "binance",
        "routes": {
            "binance": "SIMULATION_FIXTURE_REPLAY",
            "okx": "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH",
            "bybit": "PENDING_BLOCKED_BY_403",
        },
        "kpis": {
            "total_normalized_candles": 10,
            "feature_rows": 10,
            "regime_variants": 3,
            "last_regime_code": "high_volatility|upper_close",
            "dql_status": "PASS",
            "feature_quality_status": "PASS",
            "regime_status": "PASS",
        },
        "panels": {
            "kpi_panel_valid": True,
            "route_panel_valid": True,
            "safety_panel_valid": True,
            "research_panel_valid": True,
        },
        "issues": ["bybit_public_http_blocked_by_403_pending_not_blocking"],
        "action": "PROMOTE_STREAMLIT_RESEARCH_APP_OPTIONAL_NO_OPERATIONAL_DECISION",
        "next_required_gate": "INTERACTIVE_RESEARCH_APP_LOCAL_RUN_VALIDATION_OPTIONAL",
    }


def render_dashboard_html(payload, output_path="reports/sprint5c/dashboard/index.html"):
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    routes = payload["routes"]
    kpis = payload["kpis"]
    html = f"""<!doctype html>
<html><head><meta charset='utf-8'><title>QRDS Research App</title>
<style>
body {{ font-family: Arial, sans-serif; margin: 32px; background:#0f172a; color:#e5e7eb; }}
.card {{ border:1px solid #334155; border-radius:12px; padding:16px; margin:12px 0; background:#111827; }}
.pass {{ color:#22c55e; font-weight:bold; }} .warn {{ color:#f59e0b; font-weight:bold; }}
.grid {{ display:grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap:12px; }}
small {{ color:#94a3b8; }}
</style></head><body>
<h1>QRDS Interactive Research Dashboard</h1>
<div class='card'><h2>Status</h2><p class='pass'>App status: {payload['app_status']}</p><p>Mode: {payload['app_mode']}</p><p>Operational decision allowed: {payload['operational_decision_allowed']}</p></div>
<div class='grid'>
<div class='card'><h3>DQL</h3><p>{kpis['dql_status']}</p></div>
<div class='card'><h3>Features</h3><p>{kpis['feature_rows']} rows</p></div>
<div class='card'><h3>Regime</h3><p>{kpis['last_regime_code']}</p></div>
</div>
<div class='card'><h2>Routes</h2><p>Binance: {routes['binance']}</p><p>OKX: {routes['okx']}</p><p class='warn'>Bybit: {routes['bybit']}</p></div>
<div class='card'><h2>Safety</h2><p>API key required: {payload['api_key_required']}</p><p>Account connection required: {payload['account_connection_required']}</p><p>Orders generated: {payload['orders_generated']}</p><p>Real capital used: {payload['real_capital_used']}</p></div>
<small>Research-only dashboard. No API key, no real account, no orders, no real capital.</small>
</body></html>"""
    out.write_text(html, encoding="utf-8")
    return str(out)
