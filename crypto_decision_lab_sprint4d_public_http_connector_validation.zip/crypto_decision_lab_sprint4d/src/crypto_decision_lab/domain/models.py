from dataclasses import dataclass, asdict
from typing import Dict, List

@dataclass(frozen=True)
class MarketCandle:
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    symbol: str
    timeframe: str
    exchange: str

@dataclass(frozen=True)
class PublicHttpConnectorValidationReport:
    schema: str
    connector_schema: str
    validation_status: str
    connector_status: str
    model_blocked: bool
    public_http_market_data_allowed: bool
    fixture_replay_used: bool
    network_calls_executed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    endpoint_specs_valid: bool
    adapter_contract_valid: bool
    timestamp_order_valid: bool
    ohlcv_contract_valid: bool
    response_shape_valid: bool
    normalization_consistent: bool
    supported_exchanges: List[str]
    normalized_candles_per_exchange: Dict[str, int]
    safety_policy: str
    next_required_gate: str
    issues: List[str]

    def to_dict(self):
        return asdict(self)
