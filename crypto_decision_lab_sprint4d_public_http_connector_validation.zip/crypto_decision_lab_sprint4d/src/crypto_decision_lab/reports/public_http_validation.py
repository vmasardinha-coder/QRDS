import json
from pathlib import Path
from crypto_decision_lab.domain.models import PublicHttpConnectorValidationReport
from crypto_decision_lab.connectors.public_http import (
    SUPPORTED_EXCHANGES,
    SAFETY_POLICY,
    load_normalized_fixture,
    validate_endpoint_specs,
    validate_timestamp_order,
    validate_ohlcv,
    validate_response_shape,
    validate_normalization_consistency,
)

def build_public_http_connector_validation_report(dirty: bool = False):
    if dirty:
        return PublicHttpConnectorValidationReport(
            schema="qrds.public_http_market_data_connector_validation_report.v1",
            connector_schema="qrds.public_http_market_data_connector_report.v1",
            validation_status="BLOCKED",
            connector_status="BLOCKED",
            model_blocked=True,
            public_http_market_data_allowed=False,
            fixture_replay_used=False,
            network_calls_executed=True,
            authenticated_connection_used=True,
            api_key_required=True,
            account_connection_required=True,
            websocket_used=True,
            real_capital_used=True,
            exchange_connected=True,
            orders_generated=True,
            endpoint_specs_valid=False,
            adapter_contract_valid=False,
            timestamp_order_valid=False,
            ohlcv_contract_valid=False,
            response_shape_valid=False,
            normalization_consistent=False,
            supported_exchanges=[],
            normalized_candles_per_exchange={},
            safety_policy="INVALID",
            next_required_gate="NO_PUBLIC_HTTP_VALIDATION_BLOCKED",
            issues=[
                "connector_status:BLOCKED",
                "authenticated_connection_used",
                "api_key_required",
                "account_connection_required",
                "network_calls_executed",
                "exchange_or_order_exposure",
                "endpoint_specs_invalid",
                "adapter_contract_invalid",
            ],
        )
    counts = {exchange: len(load_normalized_fixture(exchange)) for exchange in SUPPORTED_EXCHANGES}
    response_shape_valid = all(validate_response_shape(exchange) for exchange in SUPPORTED_EXCHANGES)
    timestamp_order_valid = all(validate_timestamp_order(load_normalized_fixture(exchange)) for exchange in SUPPORTED_EXCHANGES)
    ohlcv_contract_valid = all(validate_ohlcv(load_normalized_fixture(exchange)) for exchange in SUPPORTED_EXCHANGES)
    endpoint_specs_valid = validate_endpoint_specs()
    normalization_consistent = validate_normalization_consistency()
    adapter_contract_valid = response_shape_valid and timestamp_order_valid and ohlcv_contract_valid and endpoint_specs_valid
    issues = []
    if not endpoint_specs_valid: issues.append("endpoint_specs_invalid")
    if not response_shape_valid: issues.append("response_shape_invalid")
    if not timestamp_order_valid: issues.append("timestamp_order_invalid")
    if not ohlcv_contract_valid: issues.append("ohlcv_contract_invalid")
    if not normalization_consistent: issues.append("normalization_inconsistent")
    status = "PASS" if not issues and adapter_contract_valid else "BLOCKED"
    return PublicHttpConnectorValidationReport(
        schema="qrds.public_http_market_data_connector_validation_report.v1",
        connector_schema="qrds.public_http_market_data_connector_report.v1",
        validation_status=status,
        connector_status="PASS",
        model_blocked=status != "PASS",
        public_http_market_data_allowed=status == "PASS",
        fixture_replay_used=True,
        network_calls_executed=False,
        authenticated_connection_used=False,
        api_key_required=False,
        account_connection_required=False,
        websocket_used=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        endpoint_specs_valid=endpoint_specs_valid,
        adapter_contract_valid=adapter_contract_valid,
        timestamp_order_valid=timestamp_order_valid,
        ohlcv_contract_valid=ohlcv_contract_valid,
        response_shape_valid=response_shape_valid,
        normalization_consistent=normalization_consistent,
        supported_exchanges=list(SUPPORTED_EXCHANGES),
        normalized_candles_per_exchange=counts,
        safety_policy=SAFETY_POLICY,
        next_required_gate="PUBLIC_HTTP_LIVE_PUBLIC_DATA_TEST_REQUIRED",
        issues=issues,
    )

def export_report(report, out_dir="reports/sprint4d"):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = report.to_dict()
    json_path = out / "public_http_market_data_connector_validation_report.json"
    txt_path = out / "public_http_market_data_connector_validation_report.txt"
    json_path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    txt_lines = [
        "Public HTTP Market Data Connector Validation Report",
        f"schema: {report.schema}",
        f"validation_status: {report.validation_status}",
        f"connector_status: {report.connector_status}",
        f"public_http_market_data_allowed: {report.public_http_market_data_allowed}",
        f"fixture_replay_used: {report.fixture_replay_used}",
        f"network_calls_executed: {report.network_calls_executed}",
        f"supported_exchanges: {report.supported_exchanges}",
        f"issues: {report.issues if report.issues else 'none'}",
    ]
    txt_path.write_text("\n".join(txt_lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
