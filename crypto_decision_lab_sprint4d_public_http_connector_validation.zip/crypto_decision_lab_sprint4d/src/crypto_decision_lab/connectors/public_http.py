from crypto_decision_lab.domain.models import MarketCandle

SUPPORTED_EXCHANGES = ["binance", "bybit", "okx"]
SAFETY_POLICY = "PUBLIC_ONLY_NO_AUTH_FIXTURE_REPLAY_VALIDATED"

ENDPOINT_SPECS = {
    "binance": {
        "method": "GET",
        "path": "/api/v3/klines",
        "requires_api_key": False,
        "requires_account": False,
        "public_only": True,
    },
    "bybit": {
        "method": "GET",
        "path": "/v5/market/kline",
        "requires_api_key": False,
        "requires_account": False,
        "public_only": True,
    },
    "okx": {
        "method": "GET",
        "path": "/api/v5/market/candles",
        "requires_api_key": False,
        "requires_account": False,
        "public_only": True,
    },
}

FIXTURES = {
    "binance": [
        [1704067200000, "50000", "50100", "49900", "50050", "100"],
        [1704070800000, "50050", "50200", "50000", "50150", "101"],
        [1704074400000, "50150", "50300", "50100", "50250", "102"],
        [1704078000000, "50250", "50400", "50200", "50350", "103"],
        [1704081600000, "50350", "50500", "50300", "50450", "104"],
    ],
    "bybit": [
        ["1704067200000", "50000", "50100", "49900", "50050", "100"],
        ["1704070800000", "50050", "50200", "50000", "50150", "101"],
        ["1704074400000", "50150", "50300", "50100", "50250", "102"],
        ["1704078000000", "50250", "50400", "50200", "50350", "103"],
        ["1704081600000", "50350", "50500", "50300", "50450", "104"],
    ],
    "okx": [
        ["1704067200000", "50050", "50100", "49900", "50000", "100"],
        ["1704070800000", "50150", "50200", "50000", "50050", "101"],
        ["1704074400000", "50250", "50300", "50100", "50150", "102"],
        ["1704078000000", "50350", "50400", "50200", "50250", "103"],
        ["1704081600000", "50450", "50500", "50300", "50350", "104"],
    ],
}

def get_endpoint_spec(exchange: str) -> dict:
    exchange = exchange.lower()
    if exchange not in ENDPOINT_SPECS:
        raise ValueError(f"Unsupported exchange: {exchange}")
    return dict(ENDPOINT_SPECS[exchange])

def fetch_fixture_response(exchange: str):
    exchange = exchange.lower()
    if exchange not in FIXTURES:
        raise ValueError(f"Unsupported exchange: {exchange}")
    return list(FIXTURES[exchange])

def _to_float(value):
    return float(value)

def normalize_kline(exchange: str, row, symbol="BTCUSDT", timeframe="1h") -> MarketCandle:
    exchange = exchange.lower()
    if exchange in ("binance", "bybit"):
        ts, op, high, low, close, vol = row[:6]
    elif exchange == "okx":
        ts, close, high, low, op, vol = row[:6]
    else:
        raise ValueError(f"Unsupported exchange: {exchange}")
    return MarketCandle(
        timestamp=int(ts),
        open=_to_float(op),
        high=_to_float(high),
        low=_to_float(low),
        close=_to_float(close),
        volume=_to_float(vol),
        symbol=symbol,
        timeframe=timeframe,
        exchange=exchange,
    )

def load_normalized_fixture(exchange: str):
    return [normalize_kline(exchange, row) for row in fetch_fixture_response(exchange)]

def validate_endpoint_specs() -> bool:
    for exchange in SUPPORTED_EXCHANGES:
        spec = get_endpoint_spec(exchange)
        if spec.get("method") != "GET":
            return False
        if spec.get("requires_api_key") is not False:
            return False
        if spec.get("requires_account") is not False:
            return False
        if spec.get("public_only") is not True:
            return False
        if not spec.get("path", "").startswith("/"):
            return False
    return True

def validate_timestamp_order(candles) -> bool:
    return all(candles[i].timestamp > candles[i - 1].timestamp for i in range(1, len(candles)))

def validate_ohlcv(candles) -> bool:
    for c in candles:
        if not (c.low <= c.open <= c.high and c.low <= c.close <= c.high):
            return False
        if c.open <= 0 or c.high <= 0 or c.low <= 0 or c.close <= 0:
            return False
        if c.volume < 0:
            return False
    return True

def validate_response_shape(exchange: str) -> bool:
    rows = fetch_fixture_response(exchange)
    return bool(rows) and all(len(row) >= 6 for row in rows)

def validate_normalization_consistency() -> bool:
    counts = {exchange: len(load_normalized_fixture(exchange)) for exchange in SUPPORTED_EXCHANGES}
    return len(set(counts.values())) == 1 and list(counts.values())[0] == 5
