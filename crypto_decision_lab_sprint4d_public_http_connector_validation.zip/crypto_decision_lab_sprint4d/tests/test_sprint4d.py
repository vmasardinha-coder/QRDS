import json
import pytest
from crypto_decision_lab.connectors.public_http import (
    SUPPORTED_EXCHANGES, SAFETY_POLICY, get_endpoint_spec, fetch_fixture_response,
    normalize_kline, load_normalized_fixture, validate_endpoint_specs,
    validate_timestamp_order, validate_ohlcv, validate_response_shape,
    validate_normalization_consistency,
)
from crypto_decision_lab.reports.public_http_validation import build_public_http_connector_validation_report, export_report

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_endpoint_spec_is_public_get(exchange):
    spec = get_endpoint_spec(exchange)
    assert spec["method"] == "GET"
    assert spec["public_only"] is True
    assert spec["requires_api_key"] is False
    assert spec["requires_account"] is False

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_fixture_response_shape(exchange):
    rows = fetch_fixture_response(exchange)
    assert len(rows) == 5
    assert validate_response_shape(exchange)
    assert all(len(row) >= 6 for row in rows)

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_normalized_candle_contract(exchange):
    candles = load_normalized_fixture(exchange)
    assert len(candles) == 5
    for c in candles:
        assert c.exchange == exchange
        assert c.symbol == "BTCUSDT"
        assert c.timeframe == "1h"
        assert c.open > 0
        assert c.high >= c.open
        assert c.low <= c.close
        assert c.volume >= 0

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_timestamp_order_per_exchange(exchange):
    assert validate_timestamp_order(load_normalized_fixture(exchange)) is True

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_ohlcv_contract_per_exchange(exchange):
    assert validate_ohlcv(load_normalized_fixture(exchange)) is True

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_normalize_single_row(exchange):
    row = fetch_fixture_response(exchange)[0]
    candle = normalize_kline(exchange, row)
    assert candle.timestamp == 1704067200000
    assert candle.high == 50100.0
    assert candle.low == 49900.0

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_no_auth_in_endpoint_specs(exchange):
    spec = get_endpoint_spec(exchange)
    assert "api" in spec["path"] or "market" in spec["path"]
    assert spec["requires_api_key"] is False

@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_fixture_replay_counts(exchange):
    assert len(load_normalized_fixture(exchange)) == 5

# 8*3 = 24 tests above

def test_supported_exchanges():
    assert SUPPORTED_EXCHANGES == ["binance", "bybit", "okx"]

def test_safety_policy():
    assert SAFETY_POLICY == "PUBLIC_ONLY_NO_AUTH_FIXTURE_REPLAY_VALIDATED"

def test_endpoint_specs_all_valid():
    assert validate_endpoint_specs() is True

def test_normalization_consistency():
    assert validate_normalization_consistency() is True

def test_unsupported_exchange_spec_raises():
    with pytest.raises(ValueError):
        get_endpoint_spec("coinbase")

def test_unsupported_exchange_fixture_raises():
    with pytest.raises(ValueError):
        fetch_fixture_response("coinbase")

def test_unsupported_exchange_normalize_raises():
    with pytest.raises(ValueError):
        normalize_kline("coinbase", [1,2,3,4,5,6])

def test_report_pass():
    r = build_public_http_connector_validation_report()
    assert r.validation_status == "PASS"
    assert r.connector_status == "PASS"
    assert r.model_blocked is False
    assert r.issues == []

def test_report_public_allowed():
    r = build_public_http_connector_validation_report()
    assert r.public_http_market_data_allowed is True
    assert r.fixture_replay_used is True
    assert r.network_calls_executed is False

def test_report_no_auth_no_account():
    r = build_public_http_connector_validation_report()
    assert r.authenticated_connection_used is False
    assert r.api_key_required is False
    assert r.account_connection_required is False
    assert r.websocket_used is False

def test_report_no_capital_no_orders():
    r = build_public_http_connector_validation_report()
    assert r.real_capital_used is False
    assert r.exchange_connected is False
    assert r.orders_generated is False

def test_report_contract_flags():
    r = build_public_http_connector_validation_report()
    assert r.endpoint_specs_valid is True
    assert r.adapter_contract_valid is True
    assert r.timestamp_order_valid is True
    assert r.ohlcv_contract_valid is True

def test_report_response_and_normalization():
    r = build_public_http_connector_validation_report()
    assert r.response_shape_valid is True
    assert r.normalization_consistent is True

def test_report_counts():
    r = build_public_http_connector_validation_report()
    assert r.normalized_candles_per_exchange == {"binance": 5, "bybit": 5, "okx": 5}

def test_report_next_gate():
    r = build_public_http_connector_validation_report()
    assert r.next_required_gate == "PUBLIC_HTTP_LIVE_PUBLIC_DATA_TEST_REQUIRED"

def test_dirty_report_blocked():
    r = build_public_http_connector_validation_report(dirty=True)
    assert r.validation_status == "BLOCKED"
    assert r.model_blocked is True
    assert r.public_http_market_data_allowed is False

def test_dirty_report_exposure_flags():
    r = build_public_http_connector_validation_report(dirty=True)
    assert r.authenticated_connection_used is True
    assert r.api_key_required is True
    assert r.account_connection_required is True
    assert r.network_calls_executed is True

def test_dirty_report_issues():
    r = build_public_http_connector_validation_report(dirty=True)
    assert "authenticated_connection_used" in r.issues
    assert "exchange_or_order_exposure" in r.issues

def test_export_report(tmp_path):
    r = build_public_http_connector_validation_report()
    paths = export_report(r, tmp_path)
    assert paths["json"].endswith(".json")
    assert paths["txt"].endswith(".txt")

# 20 tests after the parametrized block = 44 total

def test_export_report_content(tmp_path):
    r = build_public_http_connector_validation_report()
    paths = export_report(r, tmp_path)
    data = json.loads(open(paths["json"], encoding="utf-8").read())
    assert data["schema"] == "qrds.public_http_market_data_connector_validation_report.v1"
    assert data["validation_status"] == "PASS"
