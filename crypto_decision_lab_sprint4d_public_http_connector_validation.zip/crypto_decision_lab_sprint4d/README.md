# Crypto Decision Lab - Sprint 4D

Public HTTP Market Data Connector Validation.

This sprint validates public HTTP connector contracts in fixture/replay mode for Binance, Bybit and OKX.

Safety policy:
- no API key
- no account connection
- no authenticated request
- no real network calls by default
- no websocket
- no orders
- no real capital
