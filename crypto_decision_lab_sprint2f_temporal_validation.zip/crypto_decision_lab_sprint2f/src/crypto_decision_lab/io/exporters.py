from __future__ import annotations

import json
from pathlib import Path


def export_json(payload: dict, path: str | Path) -> str:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return str(path)


def export_txt(report: dict, path: str | Path) -> str:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "QRDS Sprint 2F - Temporal Validation Report",
        f"Schema: {report.get('schema')}",
        f"Integrated status: {report.get('integrated_dataset_status')}",
        f"Temporal status: {report.get('temporal_validation_status')}",
        f"Model blocked: {report.get('model_blocked')}",
        f"Quality score: {report.get('quality_score')}",
        f"Split count: {report.get('split_count')}",
        f"Embargo candles: {report.get('embargo_candles')}",
        f"Issues: {report.get('issues') if report.get('issues') else 'none'}",
    ]
    for split in report.get("splits", []):
        lines.append(
            f"Split {split['split_id']}: train={split['train_start']}-{split['train_end']} "
            f"embargo={split['embargo_start']}-{split['embargo_end']} "
            f"validation={split['validation_start']}-{split['validation_end']} "
            f"train_rows={split['train_rows']} validation_rows={split['validation_rows']}"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(path)
