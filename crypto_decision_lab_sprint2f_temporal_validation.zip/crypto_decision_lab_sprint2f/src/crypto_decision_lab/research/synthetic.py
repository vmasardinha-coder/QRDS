from __future__ import annotations

from datetime import datetime, timedelta, timezone
from math import sin

HORIZONS = [1, 3, 6]


def _label_from_return(value: float, threshold: float = 0.00015) -> str:
    if value > threshold:
        return "up"
    if value < -threshold:
        return "down"
    return "flat"


def generate_integrated_research_dataset(n_candles: int = 48, horizons=None) -> dict:
    """Create a deterministic offline integrated research dataset.

    This is not market data and not a trading signal. It is a fixture used to
    validate the research pipeline contracts before real datasets are plugged in.
    """
    horizons = list(horizons or HORIZONS)
    start = datetime(2024, 1, 1, tzinfo=timezone.utc)
    rows = []
    label_counts = {"up": 0, "down": 0, "flat": 0, "unknown": 0}

    for i in range(n_candles):
        timestamp = start + timedelta(hours=i)
        simple_return_1 = None if i == 0 else round(0.0002 + 0.00012 * sin(i / 4), 8)
        rolling_volatility = None if i < 3 else round(0.0001 + 0.00002 * (i % 5), 8)
        volume_zscore = None if i == 0 else round((i % 9 - 4) / 2.5, 8)

        if i < 2:
            volatility_regime = "unknown_volatility"
        elif i % 3 == 0:
            volatility_regime = "high_volatility"
        elif i % 3 == 1:
            volatility_regime = "normal_volatility"
        else:
            volatility_regime = "low_volatility"

        trend_regime = "unknown_trend" if i == 0 else "upward_drift"
        volume_regime = "unknown_volume" if i == 0 else ("elevated_volume" if i % 4 != 0 else "normal_volume")
        candle_regime = "balanced_candle" if i % 5 else "wide_range_candle"
        regime_code = f"{volatility_regime}|{trend_regime}|{volume_regime}|{candle_regime}"

        for horizon in horizons:
            future_index = i + horizon
            if future_index >= n_candles:
                future_return = None
                target_label = "unknown"
                target_valid = False
            else:
                future_return = round(0.00025 * horizon + 0.0001 * sin((i + horizon) / 5), 8)
                target_label = _label_from_return(future_return)
                target_valid = True
            label_counts[target_label] += 1
            rows.append({
                "schema": "qrds.integrated_research_row.v1",
                "symbol": "BTCUSDT",
                "timeframe": "1h",
                "timestamp": timestamp.isoformat(),
                "candle_index": i,
                "horizon": horizon,
                "future_index": future_index,
                "simple_return_1": simple_return_1,
                "rolling_volatility": rolling_volatility,
                "volume_zscore": volume_zscore,
                "regime_code": regime_code,
                "volatility_regime": volatility_regime,
                "trend_regime": trend_regime,
                "volume_regime": volume_regime,
                "target_label": target_label,
                "future_return": future_return,
                "target_valid": target_valid,
            })

    return {
        "schema": "qrds.integrated_research_dataset.v1",
        "dql_status": "PASS",
        "feature_quality_status": "PASS",
        "regime_status": "PASS",
        "target_quality_status": "PASS",
        "integrated_dataset_status": "PASS",
        "model_blocked": False,
        "quality_score": 0.9756,
        "rows": rows,
        "row_count": len(rows),
        "candle_count": n_candles,
        "horizons": horizons,
        "label_counts": label_counts,
    }


def generate_dirty_integrated_dataset() -> dict:
    return {
        "schema": "qrds.integrated_research_dataset.v1",
        "dql_status": "BLOCKED",
        "feature_quality_status": "UNKNOWN",
        "regime_status": "UNKNOWN",
        "target_quality_status": "UNKNOWN",
        "integrated_dataset_status": "BLOCKED",
        "model_blocked": True,
        "quality_score": 0.0,
        "rows": [],
        "row_count": 0,
        "candle_count": 0,
        "horizons": [],
        "label_counts": {},
    }
