# QRDS Sprint 2F - Temporal Validation Offline

Objetivo: validar a integridade temporal do dataset integrado de pesquisa sem backtest, sem sinal Long/Short e sem execucao real.

Inclui:
- splits walk-forward offline
- embargo por horizonte maximo
- validacao contra leakage simples
- relatorio JSON/TXT versionado
- bloqueio se qualquer gate anterior estiver BLOCKED

Proibido nesta sprint:
- Binance real conectada
- API key real
- WebSocket autenticado
- ordens
- capital real
- alavancagem
- sinal Long/Short
- backtest

Comando local:

```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_temporal_validation.py
```
