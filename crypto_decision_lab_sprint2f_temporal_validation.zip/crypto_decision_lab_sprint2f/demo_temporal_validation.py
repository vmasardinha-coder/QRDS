from crypto_decision_lab.io.exporters import export_json, export_txt
from crypto_decision_lab.research.synthetic import generate_dirty_integrated_dataset, generate_integrated_research_dataset
from crypto_decision_lab.temporal.report import generate_temporal_validation_report

payload = generate_integrated_research_dataset()
report = generate_temporal_validation_report(payload)

dirty_payload = generate_dirty_integrated_dataset()
dirty_report = generate_temporal_validation_report(dirty_payload)

json_path = export_json(report, "reports/sprint2f/temporal_validation_report.json")
txt_path = export_txt(report, "reports/sprint2f/temporal_validation_report.txt")

print("=== Sprint 2F Temporal Validation Offline ===")
print(f"Integrated schema: {payload['schema']}")
print(f"Temporal schema: {report['schema']}")
print(f"Integrated status: {payload['integrated_dataset_status']}")
print(f"Temporal status: {report['temporal_validation_status']}")
print(f"Model blocked: {report['model_blocked']}")
print(f"Temporal quality score: {report['quality_score']:.4f}")
print(f"Splits: {report['split_count']}")
print(f"Embargo candles: {report['embargo_candles']}")
first = report['splits'][0]
print(f"First split train rows: {first['train_rows']}")
print(f"First split validation rows: {first['validation_rows']}")
print(f"Leakage issues: {report['issues'] if report['issues'] else 'none'}")
print(f"Dirty integrated status: {dirty_payload['integrated_dataset_status']}")
print(f"Dirty temporal status: {dirty_report['temporal_validation_status']}")
print(f"Generated files: {{'json': '{json_path}', 'txt': '{txt_path}'}}")
