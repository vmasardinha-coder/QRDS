from pathlib import Path
import json

from crypto_decision_lab.io.exporters import export_json, export_txt
from crypto_decision_lab.research.synthetic import generate_dirty_integrated_dataset, generate_integrated_research_dataset
from crypto_decision_lab.temporal.report import gates_are_passed, generate_temporal_validation_report
from crypto_decision_lab.temporal.splits import (
    make_walk_forward_splits,
    max_horizon,
    unique_candle_indices,
    validate_horizon_embargo,
    validate_split_has_rows,
    validate_split_no_overlap,
)


def test_01_payload_schema():
    payload = generate_integrated_research_dataset()
    assert payload["schema"] == "qrds.integrated_research_dataset.v1"


def test_02_payload_rows():
    payload = generate_integrated_research_dataset()
    assert payload["row_count"] == 144


def test_03_payload_candles():
    payload = generate_integrated_research_dataset()
    assert payload["candle_count"] == 48


def test_04_payload_horizons():
    payload = generate_integrated_research_dataset()
    assert payload["horizons"] == [1, 3, 6]


def test_05_payload_gate_pass():
    assert gates_are_passed(generate_integrated_research_dataset())


def test_06_dirty_gate_blocked():
    assert not gates_are_passed(generate_dirty_integrated_dataset())


def test_07_unique_candle_indices():
    rows = generate_integrated_research_dataset()["rows"]
    assert unique_candle_indices(rows)[0] == 0
    assert unique_candle_indices(rows)[-1] == 47


def test_08_max_horizon():
    rows = generate_integrated_research_dataset()["rows"]
    assert max_horizon(rows) == 6


def test_09_make_splits_count():
    rows = generate_integrated_research_dataset()["rows"]
    assert len(make_walk_forward_splits(rows)) == 3


def test_10_first_split_bounds():
    rows = generate_integrated_research_dataset()["rows"]
    split = make_walk_forward_splits(rows)[0]
    assert split["train_start"] == 0
    assert split["train_end"] == 23
    assert split["validation_start"] == 30
    assert split["validation_end"] == 35


def test_11_second_split_bounds():
    rows = generate_integrated_research_dataset()["rows"]
    split = make_walk_forward_splits(rows)[1]
    assert split["train_end"] == 29
    assert split["validation_start"] == 36


def test_12_third_split_bounds():
    rows = generate_integrated_research_dataset()["rows"]
    split = make_walk_forward_splits(rows)[2]
    assert split["train_end"] == 35
    assert split["validation_start"] == 42
    assert split["validation_end"] == 47


def test_13_split_no_overlap():
    rows = generate_integrated_research_dataset()["rows"]
    assert all(validate_split_no_overlap(s) for s in make_walk_forward_splits(rows))


def test_14_split_has_rows():
    rows = generate_integrated_research_dataset()["rows"]
    assert all(validate_split_has_rows(s) for s in make_walk_forward_splits(rows))


def test_15_horizon_embargo():
    rows = generate_integrated_research_dataset()["rows"]
    assert all(validate_horizon_embargo(rows, s) for s in make_walk_forward_splits(rows))


def test_16_train_rows_first_split():
    rows = generate_integrated_research_dataset()["rows"]
    assert make_walk_forward_splits(rows)[0]["train_rows"] == 72


def test_17_validation_rows_first_split():
    rows = generate_integrated_research_dataset()["rows"]
    assert make_walk_forward_splits(rows)[0]["validation_rows"] == 18


def test_18_report_schema():
    report = generate_temporal_validation_report(generate_integrated_research_dataset())
    assert report["schema"] == "qrds.temporal_validation_report.v1"


def test_19_report_pass():
    report = generate_temporal_validation_report(generate_integrated_research_dataset())
    assert report["temporal_validation_status"] == "PASS"
    assert report["model_blocked"] is False


def test_20_report_quality_score():
    report = generate_temporal_validation_report(generate_integrated_research_dataset())
    assert report["quality_score"] == 1.0


def test_21_report_issues_none():
    report = generate_temporal_validation_report(generate_integrated_research_dataset())
    assert report["issues"] == []


def test_22_dirty_report_blocked():
    report = generate_temporal_validation_report(generate_dirty_integrated_dataset())
    assert report["temporal_validation_status"] == "BLOCKED"
    assert report["model_blocked"] is True


def test_23_export_json(tmp_path):
    report = generate_temporal_validation_report(generate_integrated_research_dataset())
    path = export_json(report, tmp_path / "report.json")
    assert json.loads(Path(path).read_text())["schema"] == "qrds.temporal_validation_report.v1"


def test_24_export_txt(tmp_path):
    report = generate_temporal_validation_report(generate_integrated_research_dataset())
    path = export_txt(report, tmp_path / "report.txt")
    text = Path(path).read_text()
    assert "Temporal Validation Report" in text
    assert "Temporal status: PASS" in text
