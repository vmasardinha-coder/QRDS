import pathlib,requests,json
root=pathlib.Path(r"C:\GATE_BTC_PROJECT\SOURCE_PROBES\PIT150_THREE_20261016")
body=[{"jsonrpc":"2.0","id":i,"method":"eth_call","params":[{"to":"0xa3931d71877c0e7a3148cb7eb4463524fec27fbd","data":"0x07a2d13a"+format(10**18,"064x")},hex(25000000+i)]} for i in range(2)]
r=requests.post("https://eth.drpc.org",json=body,timeout=25)
(root/"OHM_SUSDS_BATCH_PROBE.json").write_bytes(r.content)
print(r.status_code,r.text[:800])
p=pathlib.Path(r"C:\Users\jsard\AppData\Local\Temp\capture_ohm_usdc_candidate.py")
s=p.read_text().replace(r'\OHM_USDC_NATIVE',r'\OHM_PRIMARY_NATIVE').replace('0x893f503fac2ee1e5b78665db23f9c94017aae97d','0x0858e2b0f9d75f7300b38d64482ac2c8df06a755')
# Address replacement occurs inside the source being loaded by the wrapper.
s=s.replace('s=s.replace("0xb96cee75211700bc148b95b1c907d726791f4457","0x893f503fac2ee1e5b78665db23f9c94017aae97d")','s=s.replace("0xb96cee75211700bc148b95b1c907d726791f4457","0x0858e2b0f9d75f7300b38d64482ac2c8df06a755")')
exec(compile(s,"ohm_primary_capture","exec"))
