import requests,pathlib,json,datetime,concurrent.futures,hashlib,time,threading
root=pathlib.Path(r"C:\GATE_BTC_PROJECT\SOURCE_PROBES\PIT150_THREE_20261016\USDAI_NATIVE")
root.mkdir(parents=True,exist_ok=True)
URL="https://arb1.arbitrum.io/rpc";POOL="0xba9ed8ae94c70ef9aa2cd1045ed473aaa405c6c7";TOPIC="0xdc004dbca4ef9c966218431ee5d9133d337ad018dd5b5c5493722803f75c64f7"
manifest=[];lock=threading.Lock()
def fetch(name,body):
 path=root/name
 if path.exists():raw=path.read_bytes()
 else:
  for retry in range(3):
   try:
    r=requests.post(URL,json=body,timeout=30)
    if r.status_code==200:break
    if r.status_code not in [429,500,502,503,504]:r.raise_for_status()
   except requests.RequestException:
    if retry==2:raise
   time.sleep(3*(retry+1))
  r.raise_for_status();raw=r.content;path.write_bytes(raw)
 with lock:manifest.append({"file":name,"body":body,"sha256":hashlib.sha256(raw).hexdigest()})
 return json.loads(raw)
def rpc(name,method,params):
 p=fetch(name,{"jsonrpc":"2.0","id":1,"method":method,"params":params})
 if p.get("error") or p.get("result") is None or p.get("id")!=1:raise ValueError(p)
 return p["result"]
assert rpc("chain.json","eth_chainId",[])=="0xa4b1"
head=rpc("head.json","eth_getBlockByNumber",["latest",False]);headnum=int(head["number"],16)
def lower_bound(day,label):
 target=int(datetime.datetime.fromisoformat(day).replace(tzinfo=datetime.timezone.utc).timestamp());a=max(0,headnum-100_000_000);b=headnum
 low=rpc(label+"_low.json","eth_getBlockByNumber",[hex(a),False])
 assert int(low["timestamp"],16)<target<int(head["timestamp"],16)
 for i in range(32):
  if b-a<=1:break
  mid=(a+b)//2;h=rpc(f"{label}_boundary_{i:02}.json","eth_getBlockByNumber",[hex(mid),False])
  assert int(h["number"],16)==mid
  if int(h["timestamp"],16)<target:a=mid
  else:b=mid
 assert b-a==1
 return b
lo=lower_bound("2026-03-30","first");hi=lower_bound("2026-10-16","end")
print(json.dumps({"first_block":lo,"end_exclusive":hi,"range":hi-lo}),flush=True)
ranges=[(a,min(a+1_000_000,hi)) for a in range(lo,hi,1_000_000)]
def logs(item):
 i,(a,b)=item
 p=rpc(f"logs_{i:03}.json","eth_getLogs",[{"address":POOL,"topics":[TOPIC],"fromBlock":hex(a),"toBlock":hex(b-1)}])
 assert isinstance(p,list) and len(p)<10000
 for x in p:
  assert a<=int(x["blockNumber"],16)<b and x["removed"] is False and x["address"].lower()==POOL and x["topics"]==[TOPIC]
 if i%10==0:print(json.dumps({"range":i,"rows":len(p)}),flush=True)
 return p
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:events=[x for page in ex.map(logs,enumerate(ranges)) for x in page]
keys=[(int(x["blockNumber"],16),int(x["logIndex"],16)) for x in events];assert len(keys)==len(set(keys))
blocks=sorted({int(x["blockNumber"],16) for x in events})
chunks=[blocks[i:i+50] for i in range(0,len(blocks),50)]
print(json.dumps({"events":len(events),"unique_blocks":len(blocks),"header_batches":len(chunks)}),flush=True)
def headers(item):
 i,nums=item
 body=[{"jsonrpc":"2.0","id":j,"method":"eth_getBlockByNumber","params":[hex(n),False]} for j,n in enumerate(nums)]
 p=fetch(f"headers_{i:04}.json",body)
 assert isinstance(p,list) and len(p)==len(nums) and {x["id"] for x in p}==set(range(len(nums)))
 byid={x["id"]:x for x in p};out={}
 for j,n in enumerate(nums):
  h=byid[j].get("result");assert h is not None and not byid[j].get("error") and int(h["number"],16)==n
  out[n]=h
 if i%25==0:print(json.dumps({"header_batch":i}),flush=True)
 return out
blocks_map={}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 for h in ex.map(headers,enumerate(chunks)):blocks_map.update(h)
converted=[]
for x in events:
 n=int(x["blockNumber"],16);h=blocks_map[n]
 assert h["hash"]==x["blockHash"] and x["transactionHash"] in h["transactions"]
 converted.append({"block_number":n,"index":int(x["logIndex"],16),"address":{"hash":POOL},"topics":[TOPIC,None,None,None],"data":x["data"],"block_hash":x["blockHash"],"transaction_hash":x["transactionHash"],"block_timestamp":datetime.datetime.fromtimestamp(int(h["timestamp"],16),datetime.timezone.utc).isoformat()})
days={x["block_timestamp"][:10] for x in converted}
wanted={(datetime.date(2026,10,15)-datetime.timedelta(days=i)).isoformat() for i in range(200)}
(root/"EVENTS.json").write_bytes((json.dumps(converted)+"\n").encode())
result={"status":"COMPLETE_RPC_ARCHIVE","first_block":lo,"end_exclusive":hi,"events":len(events),"unique_blocks":len(blocks),"days_200":len(wanted&days),"missing":sorted(wanted-days),"manifest":sorted(manifest,key=lambda x:x["file"]),"orders":0,"admission_changed":False}
(root/"RESULT.json").write_bytes((json.dumps(result,indent=2)+"\n").encode())
print(json.dumps({k:v for k,v in result.items() if k!="manifest"}),flush=True)
