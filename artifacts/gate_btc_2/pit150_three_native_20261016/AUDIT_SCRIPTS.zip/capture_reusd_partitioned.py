import pathlib,requests,json,hashlib,time,concurrent.futures,datetime
root=pathlib.Path(r"C:\GATE_BTC_PROJECT\SOURCE_PROBES\PIT150_THREE_20261016\REUSD_NATIVE")
files=sorted(root.glob("page_*.json"));last=json.loads(files[-1].read_bytes());cursor=last["next_page_params"]
upper=cursor["block_number"];lower=24650000
bounds=list(range(lower,upper,200000))+[upper]
topic="0xdc004dbca4ef9c966218431ee5d9133d337ad018dd5b5c5493722803f75c64f7"
url="https://eth.blockscout.com/api/v2/addresses/0xb96cee75211700bc148b95b1c907d726791f4457/logs"
def part(pair):
 lo,hi=pair;out=root/f"range_{lo}_{hi}";out.mkdir(exist_ok=True)
 params={**cursor,"topic":topic} if hi==upper else {"block_number":hi,"index":1000000000,"items_count":50,"topic":topic}
 manifest=[];events=[];previous=None;complete=False
 for n in range(300):
  path=out/f"page_{n:04}.json"
  if path.exists():raw=path.read_bytes()
  else:
   for retry in range(3):
    try:
     r=requests.get(url,params=params,timeout=25)
     if r.status_code==200:break
     if r.status_code not in [429,500,502,503,504]:r.raise_for_status()
    except requests.RequestException:
     if retry==2:raise
    time.sleep(3*(retry+1))
   r.raise_for_status();raw=r.content;path.write_bytes(raw)
  p=json.loads(raw);items=p["items"]
  manifest.append({"file":str(path.relative_to(root)),"params":params,"sha256":hashlib.sha256(raw).hexdigest()})
  for x in items:
   k=x["block_number"],x["index"]
   if previous is not None and k>=previous:raise ValueError("NON_DESCENDING_PAGE")
   previous=k
   if lo<=k[0]<=hi:events.append(x)
  if n%20==0:print(json.dumps({"range":lo,"page":n,"oldest":items[-1]["block_timestamp"] if items else None}),flush=True)
  if not items or items[-1]["block_number"]<lo or not p.get("next_page_params"):complete=True;break
  params={**p["next_page_params"],"topic":topic}
 if not complete:raise ValueError("BOUNDED_PARTITION_NOT_COMPLETE")
 result={"low_inclusive":lo,"high":hi,"complete":complete,"manifest":manifest,"events":len(events)}
 (out/"RESULT.json").write_bytes((json.dumps(result,indent=2)+"\n").encode())
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:parts=list(ex.map(part,zip(bounds[:-1],bounds[1:])))
events={}
for f in root.rglob("page_*.json"):
 for x in json.loads(f.read_bytes())["items"]:
  k=x["block_number"],x["index"]
  if k in events and events[k]!=x:raise ValueError("CONFLICTING_OVERLAP")
  events[k]=x
wanted={(datetime.date(2026,10,15)-datetime.timedelta(days=i)).isoformat() for i in range(200)}
days={x["block_timestamp"][:10] for x in events.values()}
result={"status":"ARCHIVE_PHYSICALLY_CAPTURED","pages":len(list(root.rglob("page_*.json"))),"events":len(events),"days_200":len(wanted&days),"missing":sorted(wanted-days),"partitions":[{k:v for k,v in p.items() if k!="manifest"} for p in parts],"original_last_cursor":cursor,"admission_changed":False,"orders":0}
(root/"RESULT.json").write_bytes((json.dumps(result,indent=2)+"\n").encode())
print(json.dumps(result),flush=True)
