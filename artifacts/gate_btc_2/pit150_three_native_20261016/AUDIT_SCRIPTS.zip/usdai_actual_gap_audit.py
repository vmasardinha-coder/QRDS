import pathlib,json,requests,datetime,time
root=pathlib.Path(r"C:\GATE_BTC_PROJECT\SOURCE_PROBES\PIT150_THREE_20261016\USDAI_NATIVE")
events=[x for p in sorted(root.glob("logs_*.json")) for x in json.loads(p.read_bytes())["result"]]
nums=sorted({int(x["blockNumber"],16) for x in events})
pairs=sorted(zip(nums,nums[1:]),key=lambda p:p[1]-p[0],reverse=True)[:5]
print(json.dumps({"largest_gaps_blocks":[[a,b,b-a] for a,b in pairs]}),flush=True)
out=[]
for i,(a,b) in enumerate(pairs):
 body=[{"jsonrpc":"2.0","id":j,"method":"eth_getBlockByNumber","params":[hex(n),False]} for j,n in enumerate([a,b])]
 r=requests.post("https://arb1.arbitrum.io/rpc",json=body,timeout=25)
 (root/f"gap_{i:02}_headers.json").write_bytes(r.content)
 if r.status_code!=200:print("HTTP",r.status_code,flush=True);break
 p={x["id"]:x["result"] for x in r.json()}
 at=datetime.datetime.fromtimestamp(int(p[0]["timestamp"],16),datetime.timezone.utc)
 bt=datetime.datetime.fromtimestamp(int(p[1]["timestamp"],16),datetime.timezone.utc)
 dates=[];d=at.date()+datetime.timedelta(days=1)
 while d<bt.date():dates.append(d.isoformat());d+=datetime.timedelta(days=1)
 out.append({"from_block":a,"to_block":b,"from_utc":at.isoformat(),"to_utc":bt.isoformat(),"whole_utc_days_without_observed_swap":dates})
 print(json.dumps(out[-1]),flush=True);time.sleep(2)
(root/"GAP_AUDIT.json").write_bytes((json.dumps({"source":"official Arbitrum RPC exact pool","events":len(events),"audited":out,"qualification_pass":False,"historical_admission_changed":False},indent=2)+"\n").encode())
