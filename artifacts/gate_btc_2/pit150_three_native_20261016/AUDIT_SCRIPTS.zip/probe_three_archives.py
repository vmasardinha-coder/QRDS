import pathlib,json,requests,concurrent.futures,hashlib,datetime,zipfile
root=pathlib.Path(r"C:\GATE_BTC_PROJECT\SOURCE_PROBES\PIT150_THREE_20261016");root.mkdir(parents=True,exist_ok=True)
pools={"REUSD":("eth","0xb96cee75211700bc148b95b1c907d726791f4457","https://eth.blockscout.com"),"USDAI":("arbitrum","0xba9ed8ae94c70ef9aa2cd1045ed473aaa405c6c7","https://arbitrum.blockscout.com"),"OHM":("eth","0x0858e2b0f9d75f7300b38d64482ac2c8df06a755","https://eth.blockscout.com")}
jobs=[]
end=int(datetime.datetime(2026,10,16,tzinfo=datetime.timezone.utc).timestamp())-1
old=int(datetime.datetime(2026,3,31,tzinfo=datetime.timezone.utc).timestamp())
for s,(net,pool,bs) in pools.items():
 gt=f"https://api.geckoterminal.com/api/v2/networks/{net}/pools/{pool}"
 jobs += [(s,"identity",gt+"?include=base_token,quote_token"),(s,"daily",gt+f"/ohlcv/day?aggregate=1&before_timestamp={end}&limit=1000&currency=usd&include_empty_intervals=false"),(s,"old",gt+f"/ohlcv/day?aggregate=1&before_timestamp={old}&limit=1000&currency=usd&include_empty_intervals=false"),(s,"logs",bs+f"/api/v2/addresses/{pool}/logs"),(s,"contract",bs+f"/api/v2/smart-contracts/{pool}")]
def run(job):
 s,n,url=job
 try:
  r=requests.get(url,timeout=25,headers={"Accept":"application/json","User-Agent":"QRDS/1","Accept-Version":"20230302"})
  raw=r.content;(root/f"{s}_{n}.json").write_bytes(raw)
  obj={"symbol":s,"kind":n,"url":url,"http":r.status_code,"sha256":hashlib.sha256(raw).hexdigest(),"bytes":len(raw)}
  if r.status_code==200:
   p=r.json()
   if n in ("daily","old"):
    rows=p.get("data",{}).get("attributes",{}).get("ohlcv_list",[])
    stamps=[x[0] for x in rows]
    ds=sorted({datetime.datetime.fromtimestamp(t,datetime.timezone.utc).date().isoformat() for t in stamps if t<=end})
    wanted={(datetime.date(2026,10,15)-datetime.timedelta(days=i)).isoformat() for i in range(200)}
    obj.update(rows=len(rows),unique=len(ds),first=ds[0] if ds else None,last=ds[-1] if ds else None,missing_200=sorted(wanted-set(ds)))
   if n=="logs":obj.update(items=len(p.get("items",[])),sample=p.get("items",[])[:1],next=p.get("next_page_params"))
   if n=="contract":obj.update(name=p.get("name"),implementations=p.get("implementations"),events=[x for x in (p.get("abi") or []) if x.get("type")=="event"])
  return obj
 except Exception as e:return {"symbol":s,"kind":n,"url":url,"error":str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:result=list(ex.map(run,jobs))
(root/"PROBE.json").write_bytes((json.dumps({"observed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"results":result,"admission_changed":False,"orders":0},indent=2)+"\n").encode())
for x in result:
 if "missing_200" in x:x["missing_count"]=len(x.pop("missing_200"))
 print(json.dumps(x))
