import pathlib
p=pathlib.Path(r"C:\Users\jsard\AppData\Local\Temp\capture_reusd_partitioned.py")
s=p.read_text()
s=s.replace(r'\REUSD_NATIVE")',r'\OHM_USDC_NATIVE")')
a=s.index('files=sorted(');b=s.index('topic=',a)
s=s[:a]+'root.mkdir(parents=True,exist_ok=True)\nupper=26210000;lower=24700000\nbounds=list(range(lower,upper,200000))+[upper]\ncursor={"block_number":upper,"index":0,"items_count":50}\n'+s[b:]
s=s.replace("0xdc004dbca4ef9c966218431ee5d9133d337ad018dd5b5c5493722803f75c64f7","0xc42079f94a6350d7e6235f29174924f928cc2ac818eb64fed8004e115fbcca67")
s=s.replace("0xb96cee75211700bc148b95b1c907d726791f4457","0x893f503fac2ee1e5b78665db23f9c94017aae97d")
exec(compile(s,"ohm_capture","exec"))
