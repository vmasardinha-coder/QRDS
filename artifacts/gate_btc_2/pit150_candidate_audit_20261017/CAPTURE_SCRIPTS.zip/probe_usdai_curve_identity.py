from pathlib import Path
import requests,json,time
root=Path(r"C:\GATE_BTC_PROJECT\SOURCE_PROBES\PIT150_GRX_20261017\USDAI_ALTERNATIVE_NATIVE")
pool="0x52a5b1a832a16c9275571e4bcdbe9b886853a90e";url="https://arb1.arbitrum.io/rpc"
for i in (0,1):
 body={"jsonrpc":"2.0","id":1,"method":"eth_call","params":[{"to":pool,"data":"0xc6610657"+format(i,"064x")},"latest"]}
 r=requests.post(url,json=body,timeout=25);(root/("coin_"+str(i)+".json")).write_bytes(r.content);print("COIN",i,r.status_code,r.text[:300],flush=True);time.sleep(.5)
u="https://arbitrum.blockscout.com/api/v2/smart-contracts/"+pool
r=requests.get(u,timeout=25);(root/"contract.json").write_bytes(r.content)
print("CONTRACT",r.status_code,flush=True)
if r.status_code==200:
 d=r.json();print("NAME",d.get("name"),"IMPL",d.get("implementations"),"EVENTS",[e for e in (d.get("abi") or []) if e.get("type")=="event" and "TokenExchange" in e.get("name","")],flush=True)
