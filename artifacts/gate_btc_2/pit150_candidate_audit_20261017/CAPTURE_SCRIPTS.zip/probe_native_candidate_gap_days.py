from pathlib import Path
import requests,json,time,hashlib,concurrent.futures
from datetime import datetime,timezone,timedelta
root=Path(r"C:\GATE_BTC_PROJECT\SOURCE_PROBES\PIT150_GRX_20261017")
configs=[("USDAI_CURVE","https://arb1.arbitrum.io/rpc","0xa4b1","0x52a5b1a832a16c9275571e4bcdbe9b886853a90e",["2026-07-01","2026-07-26"],100_000_000),("OHM_WETH","https://eth.drpc.org","0x1","0x88051b0eea095007d3bef21ab287be961f3d8598",["2026-06-10","2026-06-12","2026-06-13"],4_000_000)]
def run(cfg):
 name,url,chain,pool,dates,back=cfg;out=root/(name+"_CANONICAL_GAPS");out.mkdir(exist_ok=True)
 session=requests.Session();cache={};manifest=[]
 def rpc(label,m,p):
  body={"jsonrpc":"2.0","id":1,"method":m,"params":p};path=out/(label+".json")
  for i in range(4):
   r=session.post(url,json=body,timeout=30)
   if r.status_code not in (429,500,502,503,504):break
   time.sleep(2+i)
  path.write_bytes(r.content);r.raise_for_status();d=r.json()
  manifest.append({"file":path.name,"method":m,"params":p,"sha256":hashlib.sha256(r.content).hexdigest()})
  if d.get("error") or d.get("result") is None:raise ValueError(d)
  time.sleep(.18);return d["result"]
 assert rpc("chain","eth_chainId",[])==chain
 head=rpc("head","eth_getBlockByNumber",["latest",False]);n=int(head["number"],16)
 def header(num):
  if num not in cache:
   h=rpc("block_"+str(num),"eth_getBlockByNumber",[hex(num),False])
   assert int(h["number"],16)==num;cache[num]=h
  return cache[num]
 def bound(stamp):
  a=max(0,n-back);b=n
  assert int(header(a)["timestamp"],16)<stamp<int(head["timestamp"],16)
  while b-a>1:
   mid=(a+b)//2
   if int(header(mid)["timestamp"],16)<stamp:a=mid
   else:b=mid
  assert int(header(a)["timestamp"],16)<stamp<=int(header(b)["timestamp"],16)
  return b
 results=[]
 for day in dates:
  a=datetime.fromisoformat(day).replace(tzinfo=timezone.utc);lo=bound(int(a.timestamp()));hi=bound(int((a+timedelta(days=1)).timestamp()))
  logs=rpc("all_pool_logs_"+day,"eth_getLogs",[{"address":pool,"fromBlock":hex(lo),"toBlock":hex(hi-1)}])
  assert isinstance(logs,list) and len(logs)<10000
  for x in logs:
   assert x["address"].lower()==pool and lo<=int(x["blockNumber"],16)<hi and x["removed"] is False
  row={"day":day,"first_block":lo,"end_block_exclusive":hi,"all_native_pool_logs":len(logs),"topic_counts":{t:sum(x["topics"][0]==t for x in logs) for t in sorted({x["topics"][0] for x in logs if x["topics"]})}}
  results.append(row);print(name,json.dumps(row),flush=True)
 result={"pool":pool,"chain_id":chain,"rpc":url,"days":results,"manifest":manifest,"candidate_only_not_admission":True,"orders":0}
 (out/"RESULT.json").write_bytes((json.dumps(result,indent=2)+"\n").encode())
 return {"case":name,"days":results}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 for result in ex.map(run,configs):print("COMPLETE",json.dumps(result),flush=True)
