from pathlib import Path
import requests,json,time,hashlib
from datetime import datetime,timezone,timedelta
root=Path(r"C:\GATE_BTC_PROJECT\SOURCE_PROBES\PIT150_GRX_20261017");out=root/"ALTERNATIVE_POOLS";out.mkdir(exist_ok=True)
session=requests.Session();session.headers.update({"Accept":"application/json","Accept-Version":"20230302"})
cut=datetime(2026,10,17,tzinfo=timezone.utc);wanted={(cut.date()-timedelta(days=i+1)).isoformat() for i in range(200)}
def get(name,url):
 for i in range(3):
  r=session.get(url,timeout=25)
  (out/(name+".json")).write_bytes(r.content)
  if r.status_code!=429:break
  time.sleep(5)
 time.sleep(2.1)
 if r.status_code!=200:print("HTTP",name,r.status_code,flush=True);return None
 return r.json()
for symbol,net,token in (("OHM","eth","0x64aa3364f17a4d01c6f1751fd97c2bd3d7e7f1d5"),("USDAI","arbitrum","0x0a1a1a107e45b7ced86833863f482bc5f4ed82ef")):
 d=get(symbol+"_pools",f"https://api.geckoterminal.com/api/v2/networks/{net}/tokens/{token}/pools?include=base_token,quote_token&page=1")
 if not d:continue
 print("POOL_LIST",symbol,[(p["attributes"]["address"],p["attributes"]["name"]) for p in d.get("data",[])][:15],flush=True)
 candidates=d.get("data",[])[:7]
 for i,p in enumerate(candidates):
  a=p["attributes"];addr=a["address"]
  tokenids={p["relationships"][k]["data"]["id"] for k in ("base_token","quote_token")}
  if net+"_"+token not in tokenids:continue
  v=get(symbol+"_daily_"+str(i),f"https://api.geckoterminal.com/api/v2/networks/{net}/pools/{addr}/ohlcv/day?aggregate=1&before_timestamp={int(cut.timestamp())-1}&limit=1000&currency=usd&include_empty_intervals=false")
  if not v:continue
  bars=v.get("data",{}).get("attributes",{}).get("ohlcv_list",[])
  days={datetime.fromtimestamp(b[0],timezone.utc).date().isoformat() for b in bars if b[0]<int(cut.timestamp()) and b[5]>0}
  result={"symbol":symbol,"pool":addr,"name":a["name"],"rows":len(bars),"observed_days_200":len(days&wanted),"missing":sorted(wanted-days),"identity":p,"candidate_only_not_admission":True}
  (out/(symbol+"_RESULT_"+str(i)+".json")).write_bytes((json.dumps(result,indent=2)+"\n").encode())
  print("CANDIDATE",json.dumps({k:v for k,v in result.items() if k!="identity"}),flush=True)
