from pathlib import Path
import sys,json,gzip,time,hashlib
from datetime import datetime,timezone,timedelta
from decimal import Decimal
root=Path(r"C:\GATE_BTC_PROJECT\SOURCE_PROBES\PIT150_GRX_20261017")
out=root/"HOUR_ARCHIVE";out.mkdir(exist_ok=True)
sys.path.insert(0,str(root/"wsdeps"));import websocket
start=int(datetime(2026,3,30,tzinfo=timezone.utc).timestamp());end=int(datetime(2026,10,17,tzinfo=timezone.utc).timestamp())
ws=websocket.create_connection("wss://ws.grovex.io/kline-api/ws",timeout=25,origin="https://www.grovex.io")
oldest=None;allbars={};manifest=[]
for page in range(45):
 params={"channel":"market_grxusdt_kline_60min","cb_id":"qrdshistory"+str(page),"pageSize":300}
 if oldest is not None:params["endIdx"]=oldest-1
 request={"event":"req","params":params};ws.send(json.dumps(request))
 for _ in range(10):
  b=ws.recv()
  if isinstance(b,bytes):
   try:b=gzip.decompress(b).decode()
   except Exception:b=b.decode()
  d=json.loads(b)
  if "ping" in d:ws.send(json.dumps({"pong":d["ping"]}));continue
  if d.get("channel")!=params["channel"] or not isinstance(d.get("data"),list):continue
  assert d["data"],"EMPTY_PAGE"
  raw=(json.dumps({"request":request,"response":d},indent=2)+"\n").encode()
  (out/("PAGE_"+str(page).zfill(3)+".json")).write_bytes(raw)
  bars=d["data"];ids=[r["id"] for r in bars]
  assert len(ids)==len(set(ids)) and ids==sorted(ids)
  assert oldest is None or max(ids)<oldest
  for r in bars:
   assert r["id"] not in allbars
   allbars[r["id"]]=r
  oldest=min(ids);manifest.append({"page":page,"rows":len(bars),"first":oldest,"last":max(ids),"sha256":hashlib.sha256(raw).hexdigest()})
  if page%5==0:print("PAGE",page,"ROWS",len(allbars),"FIRST",datetime.fromtimestamp(oldest,timezone.utc).isoformat(),flush=True)
  break
 else:raise RuntimeError("NO_EXPECTED_PAGE")
 if oldest<=start:break
 time.sleep(.4)
ws.close()
assert oldest<=start
ordered=[allbars[k] for k in sorted(allbars)]
(out/"ALL_HOURS.json").write_bytes((json.dumps(ordered,indent=2)+"\n").encode())
(out/"MANIFEST.json").write_bytes((json.dumps({"cutoff":"2026-10-16","pages":manifest,"rows":len(ordered),"first":oldest,"fetched_at_utc":datetime.now(timezone.utc).isoformat(),"orders":0},indent=2)+"\n").encode())
selected=[r for r in ordered if start+86400<=r["id"]<end]
assert len(selected)==4800,len(selected)
assert [r["id"] for r in selected]==list(range(start+86400,end,3600))
days={}
for r in selected:days.setdefault(datetime.fromtimestamp(r["id"],timezone.utc).date().isoformat(),[]).append(r)
print("UTC_DAYS",len(days),"COMPLETE_24H",sum(len(v)==24 for v in days.values()),"POSITIVE",sum(any(r["vol"]>0 for r in v) for v in days.values()),flush=True)
# Compare native local-day candles against the physical hourly archive where fully covered.
native=json.loads((root/"ws_day_0.json").read_bytes())["data"]
diffs=[];compared=0
for d in native:
 h=[allbars.get(d["id"]+i*3600) for i in range(24)]
 if not all(h):continue
 compared+=1
 checks={"close":h[-1]["close"],"vol":sum(Decimal(str(r["vol"])) for r in h),"amount":sum(Decimal(str(r["amount"])) for r in h),"high":max(r["high"] for r in h),"low":min(r["low"] for r in h)}
 for k,v in checks.items():
  if abs(Decimal(str(v))-Decimal(str(d[k])))>max(Decimal("0.000001"),abs(Decimal(str(d[k])))*Decimal("0.00000001")):
   diffs.append({"id":d["id"],"field":k,"day":d[k],"hours":str(v)})
print("NATIVE_DAY_RECONCILIATION",compared,"DIFFERENCES",len(diffs),"SAMPLE",diffs[:6],flush=True)
(out/"NATIVE_DAY_RECONCILIATION.json").write_bytes((json.dumps({"compared":compared,"differences":diffs,"orders":0},indent=2)+"\n").encode())
