from pathlib import Path
src=Path(r"C:\Users\jsard\AppData\Local\Temp\capture_grx_hour_archive.py").read_text(encoding="utf-8")
src=src.replace('out=root/"HOUR_ARCHIVE"','out=root/"HALFHOUR_ARCHIVE"')
src=src.replace('range(45)','range(80)').replace('market_grxusdt_kline_60min','market_grxusdt_kline_30min')
src=src.replace('ALL_HOURS.json','ALL_HALFHOURS.json')
src=src[:src.index('assert len(selected)==4800')]+'\nprint("HALFHOUR_CAPTURED",len(selected),flush=True)\n'
exec(compile(src,"grx_30min_archive", "exec"))
