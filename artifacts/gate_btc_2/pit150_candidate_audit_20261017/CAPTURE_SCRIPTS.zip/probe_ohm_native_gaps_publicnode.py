from pathlib import Path
p=Path(r"C:\Users\jsard\AppData\Local\Temp\probe_ohm_native_gaps_partitioned.py")
s=p.read_text(encoding="utf-8")
# Keep the documented range limit conservative and use the public canonical Ethereum node.
s=s.replace('s=Path(r"C:\\Users\\jsard\\AppData\\Local\\Temp\\probe_native_candidate_gap_days.py").read_text(encoding="utf-8")','s=Path(r"C:\\Users\\jsard\\AppData\\Local\\Temp\\probe_native_candidate_gap_days.py").read_text(encoding="utf-8")\ns=s.replace("https://eth.drpc.org","https://ethereum-rpc.publicnode.com").replace("OHM_WETH","OHM_WETH_PUBLICNODE")')
s=s.replace("9999","5000")
exec(compile(s,"ohm_publicnode_native_gap_probe","exec"))
