from pathlib import Path
s=Path(r"C:\Users\jsard\AppData\Local\Temp\probe_native_candidate_gap_days.py").read_text(encoding="utf-8")
s=s.replace('with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:','configs=[configs[1]]\nwith concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:')
old='  logs=rpc("all_pool_logs_"+day,"eth_getLogs",[{"address":pool,"fromBlock":hex(lo),"toBlock":hex(hi-1)}])'
new='''  logs=[];partitions=[]
  for part,a0 in enumerate(range(lo,hi,9999)):
   b0=min(a0+9999,hi)
   batch=rpc("all_pool_logs_"+day+"_part_"+str(part),"eth_getLogs",[{"address":pool,"fromBlock":hex(a0),"toBlock":hex(b0-1)}])
   assert isinstance(batch,list) and len(batch)<10000
   partitions.append({"first_inclusive":a0,"end_exclusive":b0,"rows":len(batch)})
   logs.extend(batch)
  (out/("all_pool_logs_"+day+".json")).write_bytes((json.dumps({"partitions":partitions,"logs":logs},indent=2)+"\\n").encode())'''
assert old in s;s=s.replace(old,new)
s=s.replace(' assert rpc("chain","eth_chainId",[])==chain',''' assert rpc("chain","eth_chainId",[])==chain
 t0=rpc("token0","eth_call",[{"to":pool,"data":"0x0dfe1681"},"latest"])
 t1=rpc("token1","eth_call",[{"to":pool,"data":"0xd21220a7"},"latest"])
 assert t0[-40:]=="64aa3364f17a4d01c6f1751fd97c2bd3d7e7f1d5" and t1[-40:]=="c02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
''')
exec(compile(s,"ohm_partitioned_native_gap_probe","exec"))
