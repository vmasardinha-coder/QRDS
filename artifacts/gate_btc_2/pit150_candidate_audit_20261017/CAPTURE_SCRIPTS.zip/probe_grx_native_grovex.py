from pathlib import Path
import requests,json,hashlib,time
from datetime import datetime,timezone
out=Path(r"C:\GATE_BTC_PROJECT\SOURCE_PROBES\PIT150_GRX_20261017");out.mkdir(parents=True,exist_ok=True)
s=requests.Session();records=[]
jobs=[("identity","https://www.grovex.io/grx-chain",None),("api_docs","https://www.grovex.io/api",None),("symbols","https://openapi.grovex.io/open/api/common/symbols",None),("daily","https://openapi.grovex.io/open/api/get_records",{"symbol":"grxusdt","period":1440}),("ticker","https://openapi.grovex.io/open/api/get_ticker",{"symbol":"grxusdt"}),("trades","https://openapi.grovex.io/open/api/get_trades",{"symbol":"grxusdt"})]
for name,url,params in jobs:
 try:
  r=s.get(url,params=params,timeout=25);p=out/(name+".raw");p.write_bytes(r.content)
  item={"name":name,"url":r.url,"status":r.status_code,"sha256":hashlib.sha256(r.content).hexdigest(),"bytes":len(r.content)}
  try:
   d=r.json();item["shape"]=list(d)[:10] if isinstance(d,dict) else "list"
   if name=="symbols":
    item["sample"]=str(d)[:250]
    item["grx_entries"]=[x for x in (d.get("data",[]) if isinstance(d,dict) else d) if "grx" in str(x).lower()][:10]
   elif name in ("daily","trades","ticker"):
    item["sample"]=str(d)[:1300];v=d.get("data") if isinstance(d,dict) else d
    item["data_type"]=type(v).__name__;item["data_rows"]=len(v) if isinstance(v,(list,dict)) else None
    if isinstance(v,list) and v:item["last"]=str(v[-1])[:400]
  except Exception as e:item["parse_note"]=str(e)[:180]
  records.append(item);print(json.dumps(item),flush=True)
 except Exception as e:records.append({"name":name,"error":str(e)});print(name,str(e),flush=True)
 time.sleep(.5)
(out/"MANIFEST.json").write_bytes((json.dumps({"fetched_at_utc":datetime.now(timezone.utc).isoformat(),"requests":records,"orders":0},indent=2)+"\n").encode())
