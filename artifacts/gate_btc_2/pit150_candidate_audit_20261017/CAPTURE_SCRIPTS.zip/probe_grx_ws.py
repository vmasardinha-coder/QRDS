from pathlib import Path
import importlib.util,json,time,gzip,zlib
root=Path(r"C:\GATE_BTC_PROJECT\SOURCE_PROBES\PIT150_GRX_20261017")
print("WEBSOCKET_AVAILABLE",bool(importlib.util.find_spec("websocket")),flush=True)
import websocket
results=[]
for key,channel in (("day","market_grxusdt_kline_1day"),("minute","market_grxusdt_kline_1min")):
 try:
  ws=websocket.create_connection("wss://ws.grovex.io/kline-api/ws",timeout=20,origin="https://www.grovex.io")
  req={"event":"req","params":{"channel":channel,"cb_id":"qrdspublic","pageSize":300}}
  ws.send(json.dumps(req));print("SENT",json.dumps(req),flush=True)
  for i in range(8):
   msg=ws.recv()
   if isinstance(msg,bytes):
    try:msg=gzip.decompress(msg).decode()
    except Exception:
     try:msg=zlib.decompress(msg).decode()
     except Exception:msg=msg.decode()
   d=json.loads(msg)
   if "ping" in d:ws.send(json.dumps({"pong":d["ping"]}));continue
   (root/("ws_"+key+"_"+str(i)+".json")).write_bytes((json.dumps(d,indent=2)+"\n").encode())
   print("RESPONSE",key,str(d)[:1400],flush=True)
   if d.get("data"):
    data=d["data"];print("ROWS",len(data),"FIRST",str(data[0])[:400],"LAST",str(data[-1])[:400],flush=True);results.append({"channel":channel,"rows":len(data)});break
  ws.close()
 except Exception as e:print("ERROR",key,str(e),flush=True);results.append({"channel":channel,"error":str(e)})
(root/"WS_PROBE_RESULT.json").write_bytes((json.dumps(results,indent=2)+"\n").encode())
