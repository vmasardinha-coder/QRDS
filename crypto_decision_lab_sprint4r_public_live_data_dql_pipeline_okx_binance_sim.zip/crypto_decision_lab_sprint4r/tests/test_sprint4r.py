from crypto_decision_lab.connectors.okx_public import okx_fixture_response, normalize_okx_candles
from crypto_decision_lab.connectors.binance_simulation import load_binance_simulation_candles
from crypto_decision_lab.dql.report import generate_dql_report, validate_ohlcv, validate_timestamp_order
from crypto_decision_lab.pipeline.public_live_data_dql_pipeline import approval_is_valid, APPROVAL_PHRASE, run_public_live_data_dql_pipeline


def test_approval_valid():
    assert approval_is_valid(APPROVAL_PHRASE)


def test_approval_invalid():
    assert not approval_is_valid("ok")


def test_okx_fixture_shape():
    payload = okx_fixture_response()
    assert payload["code"] == "0"
    assert len(payload["data"]) == 5


def test_okx_normalization_count():
    candles = normalize_okx_candles(okx_fixture_response())
    assert len(candles) == 5


def test_okx_normalization_order():
    candles = normalize_okx_candles(okx_fixture_response())
    assert validate_timestamp_order(candles)


def test_binance_simulation_count():
    assert len(load_binance_simulation_candles()) == 5


def test_binance_simulation_order():
    assert validate_timestamp_order(load_binance_simulation_candles())


def test_combined_dql_pass():
    candles = normalize_okx_candles(okx_fixture_response()) + load_binance_simulation_candles()
    report = generate_dql_report(candles)
    assert report.dql_status == "PASS"
    assert report.quality_score == 1.0


def test_pipeline_default_fixture_pass():
    report = run_public_live_data_dql_pipeline(live_enabled=False, approval_phrase=None)
    assert report.pipeline_status == "PASS"
    assert report.fixture_replay_used is True
    assert report.network_calls_executed is False


def test_pipeline_live_without_approval_does_not_call_network():
    report = run_public_live_data_dql_pipeline(live_enabled=True, approval_phrase="invalid")
    assert report.fixture_replay_used is True
    assert report.network_calls_executed is False
    assert "live_pipeline_requested_without_valid_approval" in report.issues


def test_pipeline_safety_flags():
    report = run_public_live_data_dql_pipeline(live_enabled=False)
    assert report.api_key_required is False
    assert report.api_key_present is False
    assert report.account_connection_required is False
    assert report.orders_generated is False
    assert report.real_capital_used is False


def test_pipeline_roles():
    report = run_public_live_data_dql_pipeline(live_enabled=False)
    assert report.simulation_exchange == "binance"
    assert report.real_base_active_now == ["okx"]
    assert report.real_base_pending == ["bybit"]

import pytest

@pytest.mark.parametrize("idx", range(10))
def test_okx_candles_have_valid_ohlcv(idx):
    candles = normalize_okx_candles(okx_fixture_response())
    assert validate_ohlcv(candles[idx % len(candles)])

@pytest.mark.parametrize("idx", range(10))
def test_binance_candles_have_valid_ohlcv(idx):
    candles = load_binance_simulation_candles()
    assert validate_ohlcv(candles[idx % len(candles)])

@pytest.mark.parametrize("field", [
    "pipeline_status", "dql_status", "model_blocked", "quality_score", "safety_policy",
    "binance_route", "okx_route", "bybit_route", "live_pipeline_enabled", "fixture_replay_used",
    "network_calls_executed", "api_key_required", "account_connection_required", "orders_generated",
    "total_normalized_candles", "timestamp_order_valid", "ohlcv_contract_valid", "response_shape_valid",
])
def test_report_contains_required_fields(field):
    report = run_public_live_data_dql_pipeline(live_enabled=False)
    assert field in report.to_dict()

@pytest.mark.parametrize("forbidden", [
    "api_key_required", "api_key_present", "account_connection_required", "authenticated_connection_used",
    "websocket_used", "real_capital_used", "exchange_connected", "orders_generated",
])
def test_forbidden_flags_false(forbidden):
    report = run_public_live_data_dql_pipeline(live_enabled=False)
    assert getattr(report, forbidden) is False

@pytest.mark.parametrize("expected", [
    "PUBLIC_LIVE_DATA_DQL_PIPELINE_NO_AUTH_NO_ORDERS_NO_REAL_CAPITAL",
    "PROMOTE_PUBLIC_LIVE_DATA_DQL_PIPELINE_FOR_RESEARCH_ONLY",
])
def test_policy_and_action(expected):
    report = run_public_live_data_dql_pipeline(live_enabled=False)
    assert expected in {report.safety_policy, report.action}
