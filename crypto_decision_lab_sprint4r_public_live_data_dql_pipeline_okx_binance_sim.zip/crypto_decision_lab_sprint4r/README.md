# QRDS Sprint 4R - Public Live Data DQL Pipeline OKX + Binance Simulation

Purpose: validate an OKX public HTTP live data route combined with Binance simulation data through a DQL gate.

Safety policy:
- no API key
- no real account
- no authenticated WebSocket
- no real orders
- no real capital
- Binance remains simulation/benchmark only
- OKX is the active real-base public data candidate
- Bybit remains pending due to HTTP 403 observed in Codespaces

Default unit tests do not call live network. The demo executes OKX public HTTP live only when explicit environment approval is provided.
