from __future__ import annotations
from dataclasses import dataclass
from crypto_decision_lab.domain.models import MarketCandle

@dataclass(frozen=True)
class DqlResult:
    dql_status: str
    quality_score: float
    model_blocked: bool
    timestamp_order_valid: bool
    ohlcv_contract_valid: bool
    response_shape_valid: bool
    duplicate_timestamps: int
    gap_count: int
    total_candles: int
    issues: list[str]

    def to_dict(self) -> dict:
        return {
            "dql_status": self.dql_status,
            "quality_score": self.quality_score,
            "model_blocked": self.model_blocked,
            "timestamp_order_valid": self.timestamp_order_valid,
            "ohlcv_contract_valid": self.ohlcv_contract_valid,
            "response_shape_valid": self.response_shape_valid,
            "duplicate_timestamps": self.duplicate_timestamps,
            "gap_count": self.gap_count,
            "total_candles": self.total_candles,
            "issues": self.issues,
        }


def validate_timestamp_order(candles: list[MarketCandle]) -> bool:
    return all(candles[i].timestamp > candles[i - 1].timestamp for i in range(1, len(candles)))


def validate_ohlcv(c: MarketCandle) -> bool:
    return (
        c.open > 0
        and c.high > 0
        and c.low > 0
        and c.close > 0
        and c.volume >= 0
        and c.low <= c.open <= c.high
        and c.low <= c.close <= c.high
    )


def count_duplicate_timestamps(candles: list[MarketCandle]) -> int:
    seen = set()
    duplicates = 0
    for c in candles:
        key = (c.exchange, c.route, c.timestamp)
        if key in seen:
            duplicates += 1
        seen.add(key)
    return duplicates


def count_gaps(candles: list[MarketCandle], expected_interval_seconds: int = 3600) -> int:
    by_route: dict[tuple[str, str], list[MarketCandle]] = {}
    for c in candles:
        by_route.setdefault((c.exchange, c.route), []).append(c)
    gaps = 0
    for route_candles in by_route.values():
        ordered = sorted(route_candles, key=lambda x: x.timestamp)
        for a, b in zip(ordered, ordered[1:]):
            if int((b.timestamp - a.timestamp).total_seconds()) != expected_interval_seconds:
                gaps += 1
    return gaps


def generate_dql_report(candles: list[MarketCandle], min_candles_per_active_route: int = 5) -> DqlResult:
    issues: list[str] = []
    if not candles:
        return DqlResult("BLOCKED", 0.0, True, False, False, False, 0, 0, 0, ["empty_candle_set"])

    route_counts: dict[tuple[str, str], int] = {}
    for c in candles:
        route_counts[(c.exchange, c.route)] = route_counts.get((c.exchange, c.route), 0) + 1

    for route, count in route_counts.items():
        if count < min_candles_per_active_route:
            issues.append(f"insufficient_candles:{route[0]}:{count}")

    timestamp_order_valid = all(validate_timestamp_order(sorted([c for c in candles if (c.exchange, c.route) == route], key=lambda x: x.timestamp)) for route in route_counts)
    ohlcv_contract_valid = all(validate_ohlcv(c) for c in candles)
    response_shape_valid = all(c.timestamp is not None and c.symbol and c.timeframe and c.exchange and c.route for c in candles)
    duplicates = count_duplicate_timestamps(candles)
    gaps = count_gaps(candles)

    if not timestamp_order_valid:
        issues.append("timestamp_order_invalid")
    if not ohlcv_contract_valid:
        issues.append("ohlcv_contract_invalid")
    if not response_shape_valid:
        issues.append("response_shape_invalid")
    if duplicates:
        issues.append("duplicate_timestamps")
    if gaps:
        issues.append("timestamp_gaps")

    components = [
        1.0 if timestamp_order_valid else 0.0,
        1.0 if ohlcv_contract_valid else 0.0,
        1.0 if response_shape_valid else 0.0,
        max(0.0, 1.0 - duplicates / max(1, len(candles))),
        max(0.0, 1.0 - gaps / max(1, len(candles))),
        1.0 if not [i for i in issues if i.startswith("insufficient_candles")] else 0.0,
    ]
    score = round(sum(components) / len(components), 4)
    status = "PASS" if score >= 0.95 and not issues else "BLOCKED"
    return DqlResult(status, score, status != "PASS", timestamp_order_valid, ohlcv_contract_valid, response_shape_valid, duplicates, gaps, len(candles), issues)
