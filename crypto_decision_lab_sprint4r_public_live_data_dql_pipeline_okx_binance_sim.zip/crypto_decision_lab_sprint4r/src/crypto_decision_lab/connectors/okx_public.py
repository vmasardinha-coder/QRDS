from __future__ import annotations
import json
import urllib.parse
import urllib.request
from typing import Any

from crypto_decision_lab.domain.models import MarketCandle, ms_to_utc

OKX_PUBLIC_CANDLES_ENDPOINT = "https://www.okx.com/api/v5/market/candles"


def okx_fixture_response() -> dict[str, Any]:
    return {
        "code": "0",
        "msg": "",
        "data": [
            ["1704081600000", "50350.0", "50500.0", "50300.0", "50450.0", "104.0", "0", "0", "1"],
            ["1704078000000", "50250.0", "50400.0", "50200.0", "50350.0", "103.0", "0", "0", "1"],
            ["1704074400000", "50150.0", "50300.0", "50100.0", "50250.0", "102.0", "0", "0", "1"],
            ["1704070800000", "50050.0", "50200.0", "50000.0", "50150.0", "101.0", "0", "0", "1"],
            ["1704067200000", "50000.0", "50100.0", "49900.0", "50050.0", "100.0", "0", "0", "1"],
        ],
    }


def fetch_okx_public_candles_live(inst_id: str = "BTC-USDT", bar: str = "1H", limit: int = 5, timeout: int = 8) -> dict[str, Any]:
    params = urllib.parse.urlencode({"instId": inst_id, "bar": bar, "limit": str(limit)})
    url = f"{OKX_PUBLIC_CANDLES_ENDPOINT}?{params}"
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "QRDS-QOS-PublicDataSmoke/1.0",
            "Accept": "application/json",
        },
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def normalize_okx_candles(payload: dict[str, Any], symbol: str = "BTC-USDT", timeframe: str = "1H", route: str = "PUBLIC_HTTP_LIVE_APPROVED_NO_AUTH") -> list[MarketCandle]:
    if payload.get("code") != "0":
        raise ValueError(f"OKX payload code not success: {payload.get('code')}")
    rows = payload.get("data") or []
    candles: list[MarketCandle] = []
    for row in rows:
        candles.append(
            MarketCandle(
                timestamp=ms_to_utc(row[0]),
                open=float(row[1]),
                high=float(row[2]),
                low=float(row[3]),
                close=float(row[4]),
                volume=float(row[5]),
                symbol=symbol,
                timeframe=timeframe,
                exchange="okx",
                route=route,
            )
        )
    return sorted(candles, key=lambda c: c.timestamp)
