from __future__ import annotations
from crypto_decision_lab.domain.models import MarketCandle, ms_to_utc


def load_binance_simulation_candles() -> list[MarketCandle]:
    rows = [
        [1704067200000, 50000.0, 50100.0, 49900.0, 50050.0, 100.0],
        [1704070800000, 50050.0, 50200.0, 50000.0, 50150.0, 101.0],
        [1704074400000, 50150.0, 50300.0, 50100.0, 50250.0, 102.0],
        [1704078000000, 50250.0, 50400.0, 50200.0, 50350.0, 103.0],
        [1704081600000, 50350.0, 50500.0, 50300.0, 50450.0, 104.0],
    ]
    return [
        MarketCandle(
            timestamp=ms_to_utc(r[0]),
            open=r[1],
            high=r[2],
            low=r[3],
            close=r[4],
            volume=r[5],
            symbol="BTCUSDT",
            timeframe="1H",
            exchange="binance",
            route="SIMULATION_FIXTURE_REPLAY",
        )
        for r in rows
    ]
