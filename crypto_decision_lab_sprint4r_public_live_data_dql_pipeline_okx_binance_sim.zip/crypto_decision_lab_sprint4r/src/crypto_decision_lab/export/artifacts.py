from __future__ import annotations
import json
from pathlib import Path
from typing import Any


def write_json_txt(report: Any, out_dir: str | Path, stem: str) -> dict[str, str]:
    path = Path(out_dir)
    path.mkdir(parents=True, exist_ok=True)
    data = report.to_dict() if hasattr(report, "to_dict") else dict(report)
    json_path = path / f"{stem}.json"
    txt_path = path / f"{stem}.txt"
    json_path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    txt_lines = [f"{k}: {v}" for k, v in data.items() if k != "dql_report"]
    txt_path.write_text("
".join(txt_lines) + "
", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
