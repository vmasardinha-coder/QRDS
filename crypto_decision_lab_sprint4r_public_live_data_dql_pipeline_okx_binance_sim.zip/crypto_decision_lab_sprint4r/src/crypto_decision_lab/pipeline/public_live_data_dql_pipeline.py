from __future__ import annotations
from dataclasses import dataclass
import os
from typing import Any

from crypto_decision_lab.connectors.okx_public import fetch_okx_public_candles_live, normalize_okx_candles, okx_fixture_response
from crypto_decision_lab.connectors.binance_simulation import load_binance_simulation_candles
from crypto_decision_lab.dql.report import generate_dql_report, DqlResult

APPROVAL_PHRASE = "APROVO OKX PUBLIC HTTP LIVE PIPELINE SEM API KEY, SEM CONTA REAL, SEM ORDEM E SEM CAPITAL REAL."

@dataclass(frozen=True)
class PublicLiveDataDqlPipelineReport:
    schema: str
    pipeline_status: str
    dql_status: str
    model_blocked: bool
    quality_score: float
    safety_policy: str
    simulation_exchange: str
    binance_route: str
    okx_route: str
    bybit_route: str
    real_base_target_exchanges: list[str]
    real_base_active_now: list[str]
    real_base_pending: list[str]
    live_pipeline_enabled: bool
    fixture_replay_used: bool
    network_calls_executed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    endpoint: str
    instrument: str
    okx_candles_normalized: int
    binance_simulation_candles_normalized: int
    total_normalized_candles: int
    timestamp_order_valid: bool
    ohlcv_contract_valid: bool
    response_shape_valid: bool
    bybit_pending_accepted: bool
    issues: list[str]
    action: str
    next_required_gate: str
    dql_report: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()


def approval_is_valid(text: str | None) -> bool:
    return (text or "").strip() == APPROVAL_PHRASE


def run_public_live_data_dql_pipeline(live_enabled: bool | None = None, approval_phrase: str | None = None) -> PublicLiveDataDqlPipelineReport:
    if live_enabled is None:
        live_enabled = os.getenv("QRDS_OKX_PUBLIC_LIVE_DQL_PIPELINE_ENABLED") == "1"
    if approval_phrase is None:
        approval_phrase = os.getenv("QRDS_OKX_PUBLIC_LIVE_DQL_PIPELINE_APPROVAL")

    approved = approval_is_valid(approval_phrase)
    use_live = bool(live_enabled and approved)
    issues: list[str] = []

    if live_enabled and not approved:
        issues.append("live_pipeline_requested_without_valid_approval")

    okx_payload = None
    okx_error = None
    if use_live:
        try:
            okx_payload = fetch_okx_public_candles_live()
        except Exception as exc:  # pragma: no cover - depends on network
            okx_error = f"{type(exc).__name__}:{exc}"
            issues.append(f"okx_public_live_fetch_failed:{okx_error}")
            okx_payload = None
    if okx_payload is None:
        okx_payload = okx_fixture_response()

    okx_route = "PUBLIC_HTTP_LIVE_DQL_EXECUTED_NO_AUTH" if use_live and okx_error is None else "PUBLIC_HTTP_LIVE_APPROVED_FIXTURE_FALLBACK"
    okx_candles = normalize_okx_candles(okx_payload, route=okx_route)
    binance_candles = load_binance_simulation_candles()
    all_candles = okx_candles + binance_candles
    dql: DqlResult = generate_dql_report(all_candles)

    if okx_error is not None:
        pipeline_status = "BLOCKED"
    else:
        pipeline_status = "PASS" if dql.dql_status == "PASS" else "BLOCKED"

    action = "PROMOTE_PUBLIC_LIVE_DATA_DQL_PIPELINE_FOR_RESEARCH_ONLY" if pipeline_status == "PASS" else "NO_PUBLIC_LIVE_DATA_DQL_PIPELINE_BLOCKED"
    next_gate = "PUBLIC_LIVE_DATA_RESEARCH_PIPELINE_INTEGRATION_REQUIRED" if pipeline_status == "PASS" else "PUBLIC_LIVE_DATA_DQL_PIPELINE_REVIEW_REQUIRED"
    merged_issues = issues + dql.issues + ["bybit_public_http_blocked_by_403_pending_not_blocking"]

    return PublicLiveDataDqlPipelineReport(
        schema="qrds.public_live_data_dql_pipeline_report.v1",
        pipeline_status=pipeline_status,
        dql_status=dql.dql_status,
        model_blocked=pipeline_status != "PASS",
        quality_score=dql.quality_score,
        safety_policy="PUBLIC_LIVE_DATA_DQL_PIPELINE_NO_AUTH_NO_ORDERS_NO_REAL_CAPITAL",
        simulation_exchange="binance",
        binance_route="SIMULATION_FIXTURE_REPLAY",
        okx_route=okx_route,
        bybit_route="PENDING_BLOCKED_BY_403",
        real_base_target_exchanges=["okx", "bybit"],
        real_base_active_now=["okx"],
        real_base_pending=["bybit"],
        live_pipeline_enabled=use_live,
        fixture_replay_used=not use_live or okx_error is not None,
        network_calls_executed=use_live,
        authenticated_connection_used=False,
        api_key_required=False,
        api_key_present=False,
        account_connection_required=False,
        websocket_used=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        endpoint="https://www.okx.com/api/v5/market/candles",
        instrument="BTC-USDT",
        okx_candles_normalized=len(okx_candles),
        binance_simulation_candles_normalized=len(binance_candles),
        total_normalized_candles=len(all_candles),
        timestamp_order_valid=dql.timestamp_order_valid,
        ohlcv_contract_valid=dql.ohlcv_contract_valid,
        response_shape_valid=dql.response_shape_valid,
        bybit_pending_accepted=True,
        issues=merged_issues,
        action=action,
        next_required_gate=next_gate,
        dql_report=dql.to_dict(),
    )
