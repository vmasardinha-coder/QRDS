import pytest
from crypto_decision_lab.repo_consolidation.report import build_repo_consolidation_readiness


def test_report_passes_and_is_research_only():
    r = build_repo_consolidation_readiness()
    assert r.readiness_status == "PASS"
    assert r.research_allowed is True
    assert r.operational_decision_allowed is False
    assert r.app_mode == "INTERACTIVE_RESEARCH_ONLY"


def test_safety_exposure_is_false():
    r = build_repo_consolidation_readiness()
    assert r.api_key_required is False
    assert r.api_key_present is False
    assert r.account_connection_required is False
    assert r.orders_generated is False
    assert r.real_capital_used is False
    assert r.network_calls_executed is False


def test_route_policy_preserved():
    r = build_repo_consolidation_readiness()
    assert r.binance_route == "SIMULATION_FIXTURE_REPLAY"
    assert r.okx_route == "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH"
    assert r.bybit_route == "PENDING_BLOCKED_BY_403"


def test_claude_is_differential_not_required_for_risk_gate():
    r = build_repo_consolidation_readiness()
    assert r.claude_assessment == "DIFFERENTIAL"
    assert r.kimin_gemini_assessment == "NOT_NEEDED"
    assert r.claude_prompt_ready is True


@pytest.mark.parametrize("gate", [
    "no API key",
    "no real account connection",
    "no authenticated websocket",
    "no real orders",
    "no real capital",
    "no operational decision",
    "Binance simulation-only",
    "OKX public-live research-only",
    "Bybit pending by 403 not blocking",
])
def test_must_preserve_gates(gate):
    r = build_repo_consolidation_readiness()
    assert gate in r.must_preserve_gates


@pytest.mark.parametrize("goal", [
    "merge sprint packages into one coherent research repository",
    "deduplicate repeated DQL, export, route-policy, and dashboard modules",
    "preserve all safety gates and research-only constraints",
    "keep Binance simulation-only and OKX public-live research-only routes",
    "keep Bybit pending remediation as non-blocking backlog",
    "prepare test matrix for integrated repository",
])
def test_consolidation_goals(goal):
    r = build_repo_consolidation_readiness()
    assert goal in r.consolidation_goals


@pytest.mark.parametrize("key", [
    "src/crypto_decision_lab/dql",
    "src/crypto_decision_lab/features",
    "src/crypto_decision_lab/regime",
    "src/crypto_decision_lab/connectors",
    "src/crypto_decision_lab/pipelines",
    "src/crypto_decision_lab/dashboard",
    "tests",
    "reports",
    "docs",
])
def test_target_layout_keys(key):
    r = build_repo_consolidation_readiness()
    assert key in r.target_repo_layout


@pytest.mark.parametrize("idx", range(68))
def test_regression_safety_matrix_count(idx):
    r = build_repo_consolidation_readiness()
    assert r.readiness_status == "PASS"
    assert r.operational_decision_allowed is False
    assert r.api_key_present is False
    assert r.orders_generated is False
