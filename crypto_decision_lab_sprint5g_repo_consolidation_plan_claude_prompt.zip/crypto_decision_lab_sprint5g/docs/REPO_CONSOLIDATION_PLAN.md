# Sprint 5G - Repo Consolidation Plan

## Decision
Repo consolidation is ready as a research-only refactor step.

## Scope
Consolidate sprint packages into one repo while preserving all safety gates.

## Current route policy
- Binance: simulation / fixture replay only.
- OKX: public HTTP live research route approved, no auth.
- Bybit: pending HTTP 403 remediation, non-blocking.

## No-risk-increase rule
Repo consolidation must not introduce API keys, account connections, WebSocket auth, real orders, real capital, leverage, or operational decisions.

## Claude assessment
Claude is DIFFERENTIAL for repo consolidation and refactoring, but not a risk gate decision maker.

## Next step
Use docs/CLAUDE_REFACTOR_PROMPT.md if we decide to ask Claude for a refactor plan or patch strategy.
