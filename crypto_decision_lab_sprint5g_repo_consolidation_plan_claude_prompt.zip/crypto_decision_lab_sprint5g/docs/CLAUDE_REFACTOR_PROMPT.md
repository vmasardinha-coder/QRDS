# Claude Refactor Prompt - QRDS/QOS Repo Consolidation

You are assisting with a research-only crypto decision lab project named QRDS/QOS.

## Objective
Consolidate multiple sprint packages into a single coherent Python repository without changing the risk posture.

## Non-negotiable risk constraints
- No API key.
- No real account connection.
- No authenticated WebSocket.
- No real orders.
- No real capital.
- No leverage.
- No operational decision.
- Binance must remain simulation-only / fixture replay / benchmark.
- OKX may be used only as public HTTP live data for research, without auth.
- Bybit remains pending because public HTTP returned 403 in Codespaces.

## Current accepted routes
- Binance: SIMULATION_FIXTURE_REPLAY
- OKX: PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH
- Bybit: PENDING_BLOCKED_BY_403

## Required consolidation deliverable
Return a single consolidated plan and patch strategy. Do not introduce live trading, authenticated API, order execution, or secret handling.

## Target repository layout
```text
src/crypto_decision_lab/
  dql/
  features/
  regime/
  connectors/
  pipelines/
  dashboard/
  export/
  safety/
  config/
tests/
docs/
reports/
```

## Required work
1. Deduplicate repeated export/artifact helpers.
2. Deduplicate route policy structures.
3. Create stable module boundaries.
4. Preserve all safety gates as tests.
5. Create integration tests for the research-only pipeline.
6. Keep Streamlit optional.
7. Keep generated reports out of core source logic.
8. Provide a migration map from sprint packages to consolidated modules.

## Required output format
1. Summary of proposed architecture.
2. File tree.
3. Step-by-step migration plan.
4. Risk gates preserved.
5. Tests to run.
6. List of things explicitly NOT changed.
7. Open questions.

## Quality bar
The result must be boring, safe, auditable, and easy to test. Prefer simple code over clever abstractions.
