# Sprint 5G - Repo Consolidation Plan + Claude Refactor Prompt

This sprint validates readiness for consolidating the QRDS/QOS sprint packages into a single research-only repository.

## Safety
No API key. No real account. No authenticated WebSocket. No orders. No real capital. No operational decisions.

## Run

```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_repo_consolidation_plan.py
```

## Claude prompt
See `docs/CLAUDE_REFACTOR_PROMPT.md`.
