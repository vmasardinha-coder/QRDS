import json
from pathlib import Path
from dataclasses import asdict, is_dataclass


def _plain(value):
    if is_dataclass(value):
        return _plain(asdict(value))
    if isinstance(value, dict):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    return value


def _lines(value, prefix=""):
    out = []
    if isinstance(value, dict):
        for key, val in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            out.extend(_lines(val, path))
    else:
        out.append(f"{prefix}: {value}")
    return out


def write_json_txt(payload, output_dir="reports/sprint5g", stem="repo_consolidation_plan"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    plain = _plain(payload)
    json_path = out / f"{stem}.json"
    txt_path = out / f"{stem}.txt"
    json_path.write_text(json.dumps(plain, indent=2, ensure_ascii=False), encoding="utf-8")
    txt_path.write_text("\n".join(_lines(plain)) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
