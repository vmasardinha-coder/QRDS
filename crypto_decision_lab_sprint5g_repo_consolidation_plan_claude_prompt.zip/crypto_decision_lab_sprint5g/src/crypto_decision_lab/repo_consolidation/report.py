from dataclasses import dataclass, asdict
from typing import List, Dict


@dataclass(frozen=True)
class RepoConsolidationReadiness:
    schema: str
    readiness_status: str
    research_allowed: bool
    operational_decision_allowed: bool
    app_mode: str
    repo_consolidation_ready: bool
    claude_assessment: str
    kimin_gemini_assessment: str
    safety_policy: str
    binance_route: str
    okx_route: str
    bybit_route: str
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    orders_generated: bool
    real_capital_used: bool
    network_calls_executed: bool
    consolidation_goals: List[str]
    target_repo_layout: Dict[str, str]
    must_preserve_gates: List[str]
    claude_prompt_ready: bool
    issues: List[str]
    action: str
    next_required_gate: str

    def to_dict(self):
        return asdict(self)


def build_repo_consolidation_readiness():
    return RepoConsolidationReadiness(
        schema="qrds.repo_consolidation_plan.v1",
        readiness_status="PASS",
        research_allowed=True,
        operational_decision_allowed=False,
        app_mode="INTERACTIVE_RESEARCH_ONLY",
        repo_consolidation_ready=True,
        claude_assessment="DIFFERENTIAL",
        kimin_gemini_assessment="NOT_NEEDED",
        safety_policy="REPO_CONSOLIDATION_NO_AUTH_NO_ORDERS_NO_REAL_CAPITAL",
        binance_route="SIMULATION_FIXTURE_REPLAY",
        okx_route="PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH",
        bybit_route="PENDING_BLOCKED_BY_403",
        api_key_required=False,
        api_key_present=False,
        account_connection_required=False,
        orders_generated=False,
        real_capital_used=False,
        network_calls_executed=False,
        consolidation_goals=[
            "merge sprint packages into one coherent research repository",
            "deduplicate repeated DQL, export, route-policy, and dashboard modules",
            "preserve all safety gates and research-only constraints",
            "keep Binance simulation-only and OKX public-live research-only routes",
            "keep Bybit pending remediation as non-blocking backlog",
            "prepare test matrix for integrated repository",
        ],
        target_repo_layout={
            "src/crypto_decision_lab/dql": "data quality and safety gates",
            "src/crypto_decision_lab/features": "feature engineering and quality",
            "src/crypto_decision_lab/regime": "regime diagnostics",
            "src/crypto_decision_lab/connectors": "public-data adapters only",
            "src/crypto_decision_lab/pipelines": "research-only pipelines",
            "src/crypto_decision_lab/dashboard": "HTML/Streamlit research dashboard",
            "tests": "unit and integration tests preserving safety gates",
            "reports": "generated research artifacts only",
            "docs": "QRDS gates and Claude prompt",
        },
        must_preserve_gates=[
            "no API key",
            "no real account connection",
            "no authenticated websocket",
            "no real orders",
            "no real capital",
            "no operational decision",
            "Binance simulation-only",
            "OKX public-live research-only",
            "Bybit pending by 403 not blocking",
        ],
        claude_prompt_ready=True,
        issues=["bybit_public_http_blocked_by_403_pending_not_blocking", "many_sprint_packages_require_repo_consolidation"],
        action="PREPARE_CLAUDE_REFACTOR_PROMPT_FOR_RESEARCH_ONLY_REPO_CONSOLIDATION",
        next_required_gate="CLAUDE_REFACTOR_REVIEW_OR_REPO_CONSOLIDATION_EXECUTION_REQUIRED",
    )
