# Sprint 0B — Review Notes

## Resultado

Sprint 0B concluída como pacote local mínimo.

## Testes

- `pytest tests/`: 16 testes aprovados.
- `python demo.py`: executado com dados fake.

## Alterações feitas sobre a Sprint 0A

1. Mantido escopo sem Binance, API, WebSocket, banco ou trading real.
2. Adicionado `pyproject.toml` para suportar `src layout` com instalação editável.
3. Timestamps internos de criação (`DecisionRecord`, `DataQualityEvent`) ajustados para UTC timezone-aware.
4. Dados fake do `demo.py` ajustados para UTC explícito.
5. Removidos imports desnecessários de `pytest` nos testes.
6. Adicionado validator `validate_non_negative_volume`.
7. Adicionados testes para timestamp repetido e volume negativo.
8. README corrigido para instalação local e execução.

## Limitações intencionais

- Ainda usa `float`.
- Ainda não usa banco de dados.
- Ainda não possui ingestão real.
- Ainda não possui Expected Utility real.
- Ainda não possui DQL robusto.
- Ainda não possui dashboard.
- Ainda não possui execução de ordens.

## Próxima fase sugerida

Sprint 1 somente depois de decisão formal:

- Persistência local simples ou schema SQL inicial.
- Histórico fake/CSV antes de API real.
- Expansão do DQL com relatórios por janela.
