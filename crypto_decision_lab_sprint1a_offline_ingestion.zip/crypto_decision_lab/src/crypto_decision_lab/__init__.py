"""Crypto Decision Lab — Sprint 0B."""

__version__ = "0.0.1"
