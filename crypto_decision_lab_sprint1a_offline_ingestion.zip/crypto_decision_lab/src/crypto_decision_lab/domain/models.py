"""Modelos de domínio da Sprint 0B.

Mantidos simples por design. Não representam ainda schema final de banco.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone


def utc_now() -> datetime:
    """Retorna timestamp UTC timezone-aware."""
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class MarketCandle:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass(frozen=True)
class FuturesMetric:
    funding_rate: float
    open_interest: float
    long_short_ratio: float


@dataclass(frozen=True)
class QuantFeature:
    feature_name: str
    value: float
    weight: float


@dataclass(frozen=True)
class ScenarioResult:
    scenario_id: str
    expected_utility_long: float
    expected_utility_short: float


@dataclass(frozen=True)
class DecisionRecord:
    decision: str  # "Long", "Short", "No Trade"
    reason: str
    dqs: float
    timestamp: datetime = field(default_factory=utc_now)


@dataclass(frozen=True)
class DataQualityEvent:
    event_type: str
    severity: str  # "low", "medium", "high", "critical"
    message: str
    timestamp: datetime = field(default_factory=utc_now)
