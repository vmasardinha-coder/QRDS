"""Decision layer."""
