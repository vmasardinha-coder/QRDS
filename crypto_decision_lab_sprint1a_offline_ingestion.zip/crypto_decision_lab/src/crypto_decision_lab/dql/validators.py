"""Validadores puros do Data Quality Layer.

Sprint 0B: valida apenas regras básicas com dados fake/local.
"""

from collections.abc import Sequence

from crypto_decision_lab.domain.models import MarketCandle


def validate_ohlc(candle: MarketCandle) -> bool:
    """Valida consistência lógica OHLC."""
    return (
        candle.low <= candle.open <= candle.high
        and candle.low <= candle.close <= candle.high
        and candle.low <= candle.high
    )


def validate_timestamp_order(candles: Sequence[MarketCandle]) -> bool:
    """Valida timestamps estritamente crescentes."""
    return all(
        candles[i].timestamp > candles[i - 1].timestamp
        for i in range(1, len(candles))
    )


def validate_missing_values(candles: Sequence[MarketCandle]) -> bool:
    """Valida ausência de campos nulos nos candles."""
    for candle in candles:
        values = (
            candle.timestamp,
            candle.open,
            candle.high,
            candle.low,
            candle.close,
            candle.volume,
        )
        if any(value is None for value in values):
            return False
    return True


def validate_positive_prices(candle: MarketCandle) -> bool:
    """Valida preços estritamente positivos."""
    return all(
        value > 0
        for value in (candle.open, candle.high, candle.low, candle.close)
    )


def validate_non_negative_volume(candle: MarketCandle) -> bool:
    """Valida volume maior ou igual a zero."""
    return candle.volume >= 0
