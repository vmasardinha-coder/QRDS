"""Cálculo simples do Data Quality Score da Sprint 0B."""

from crypto_decision_lab.config import DQS_THRESHOLD


def calculate_dqs(
    completeness: float,
    freshness: float,
    consistency: float,
    temporality: float,
) -> float:
    """Calcula DQS simples com pesos iguais.

    Sprint 0B: pesos iguais por simplicidade. Versões futuras podem ponderar.
    """
    dqs = (completeness + freshness + consistency + temporality) / 4.0
    return round(dqs, 4)


def is_model_blocked(dqs: float) -> bool:
    """Bloqueia modelo quando DQS está abaixo do threshold."""
    return dqs < DQS_THRESHOLD
