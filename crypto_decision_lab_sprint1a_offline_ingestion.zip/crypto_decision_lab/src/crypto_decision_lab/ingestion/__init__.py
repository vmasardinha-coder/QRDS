"""Offline ingestion utilities for Sprint 1A."""
