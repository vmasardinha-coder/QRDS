"""Offline Binance kline loader.

Sprint 1A scope:
- local CSV/ZIP files only;
- no Binance API;
- no WebSocket;
- no downloads;
- no database.
"""

from __future__ import annotations

import csv
import zipfile
from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path
from typing import TextIO

from crypto_decision_lab.domain.models import MarketCandle

# Binance kline columns:
# open_time, open, high, low, close, volume, close_time,
# quote_asset_volume, number_of_trades, taker_buy_base_asset_volume,
# taker_buy_quote_asset_volume, ignore
MIN_KLINE_COLUMNS = 6


class OfflineKlineFormatError(ValueError):
    """Raised when a local kline file cannot be parsed safely."""


def _epoch_to_utc_datetime(raw_timestamp: str | int | float) -> datetime:
    """Convert Binance epoch timestamp to timezone-aware UTC datetime.

    Binance public kline files usually use milliseconds. This function also
    tolerates microseconds for future compatibility with public data variants.
    """
    value = int(float(raw_timestamp))

    if value > 10**14:  # likely microseconds
        seconds = value / 1_000_000
    elif value > 10**11:  # likely milliseconds
        seconds = value / 1_000
    else:  # already seconds
        seconds = value

    return datetime.fromtimestamp(seconds, tz=timezone.utc)


def _is_header(row: list[str]) -> bool:
    """Return True when the first CSV row looks like a header."""
    if not row:
        return False
    try:
        int(float(row[0]))
        return False
    except ValueError:
        return True


def _row_to_market_candle(row: list[str]) -> MarketCandle:
    """Convert one Binance kline CSV row to MarketCandle."""
    if len(row) < MIN_KLINE_COLUMNS:
        raise OfflineKlineFormatError(
            f"Expected at least {MIN_KLINE_COLUMNS} columns, got {len(row)}"
        )

    try:
        return MarketCandle(
            timestamp=_epoch_to_utc_datetime(row[0]),
            open=float(row[1]),
            high=float(row[2]),
            low=float(row[3]),
            close=float(row[4]),
            volume=float(row[5]),
        )
    except (TypeError, ValueError) as exc:
        raise OfflineKlineFormatError(f"Invalid kline row: {row}") from exc


def _read_csv_rows(file_obj: TextIO, limit: int | None = None) -> list[MarketCandle]:
    """Read CSV rows from an opened text file."""
    candles: list[MarketCandle] = []
    reader = csv.reader(file_obj)

    for row in reader:
        if not row:
            continue
        if _is_header(row):
            continue
        candles.append(_row_to_market_candle(row))
        if limit is not None and len(candles) >= limit:
            break

    return candles


def _load_csv(path: Path, limit: int | None = None) -> list[MarketCandle]:
    with path.open("r", encoding="utf-8", newline="") as file_obj:
        return _read_csv_rows(file_obj, limit=limit)


def _load_zip(path: Path, limit: int | None = None) -> list[MarketCandle]:
    with zipfile.ZipFile(path) as archive:
        csv_names = [name for name in archive.namelist() if name.lower().endswith(".csv")]
        if not csv_names:
            raise OfflineKlineFormatError("ZIP file does not contain a CSV file")

        csv_name = sorted(csv_names)[0]
        with archive.open(csv_name, "r") as binary_file:
            text = (line.decode("utf-8") for line in binary_file)
            return _read_csv_rows(text, limit=limit)


def load_binance_klines(path: str | Path, limit: int | None = None) -> list[MarketCandle]:
    """Load Binance kline candles from a local CSV or ZIP file.

    Parameters
    ----------
    path:
        Local path to a Binance kline CSV or ZIP file.
    limit:
        Optional maximum number of candles to load.

    Returns
    -------
    list[MarketCandle]
        Parsed candles using open_time as timestamp.
    """
    local_path = Path(path)
    if not local_path.exists():
        raise FileNotFoundError(f"File not found: {local_path}")

    suffix = local_path.suffix.lower()
    if suffix == ".csv":
        candles = _load_csv(local_path, limit=limit)
    elif suffix == ".zip":
        candles = _load_zip(local_path, limit=limit)
    else:
        raise OfflineKlineFormatError("Only .csv and .zip files are supported")

    if not candles:
        raise OfflineKlineFormatError("No candles were loaded")

    return candles
