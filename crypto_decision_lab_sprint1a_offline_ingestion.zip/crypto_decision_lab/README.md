# Crypto Decision Lab — Sprint 0B

Laboratório quantitativo local para BTCUSDT Perpetual.

Esta Sprint 0B é apenas uma fundação técnica mínima com dados fake.

## O que existe nesta versão

- Estrutura local de projeto Python em `src/`.
- Dataclasses de domínio.
- Validadores básicos do Data Quality Layer.
- Cálculo simples de Data Quality Score.
- Decisão dummy: Long, Short ou No Trade.
- Testes unitários com `pytest`.
- Demo local com dados fake.

## O que NÃO existe nesta versão

- Sem Binance.
- Sem WebSocket.
- Sem REST externo.
- Sem API key.
- Sem banco de dados.
- Sem SQLAlchemy.
- Sem execução de ordens.
- Sem alavancagem.
- Sem estratégia real.
- Sem Expected Utility real.

## Estrutura

```text
crypto_decision_lab/
├── README.md
├── requirements.txt
├── demo.py
├── pyproject.toml
├── src/
│   └── crypto_decision_lab/
│       ├── __init__.py
│       ├── config.py
│       ├── domain/
│       │   ├── __init__.py
│       │   └── models.py
│       ├── dql/
│       │   ├── __init__.py
│       │   ├── validators.py
│       │   └── score.py
│       └── decision/
│           ├── __init__.py
│           └── dummy_decision.py
└── tests/
    ├── test_validators.py
    ├── test_dqs.py
    └── test_dummy_decision.py
```

## Instalação local

```bash
cd crypto_decision_lab
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate   # Windows
pip install -r requirements.txt
pip install -e .
```

## Rodar demo

```bash
python demo.py
```

## Rodar testes

```bash
pytest tests/
```

## Critério de aprovação Sprint 0B

A Sprint 0B é considerada aprovada se:

- `pytest tests/` passar.
- `python demo.py` rodar com dados fake.
- O projeto continuar sem conexão externa.
- O DQL bloquear decisão quando `DQS < 0.80`.

---

## Sprint 1A — Ingestão Histórica Offline

Objetivo: carregar um arquivo local CSV/ZIP de klines no formato Binance, sem API, sem WebSocket e sem trading real.

### Rodar demo offline

```bash
python demo_ingest_offline.py
```

### Rodar testes

```bash
pytest tests/
```

### Escopo proibido nesta sprint

- Binance live
- API key
- WebSocket
- download automático
- banco de dados real
- ordens
- capital real
