"""Sprint 1A demo: offline Binance kline CSV ingestion.

No API, no WebSocket, no downloads, no trading.
"""

from pathlib import Path

from crypto_decision_lab.dql.score import calculate_dqs
from crypto_decision_lab.dql.validators import (
    validate_missing_values,
    validate_non_negative_volume,
    validate_ohlc,
    validate_positive_prices,
    validate_timestamp_order,
)
from crypto_decision_lab.ingestion.offline_klines import load_binance_klines


FIXTURE = Path(__file__).parent / "tests" / "fixtures" / "BTCUSDT-1h-sample.csv"


def main() -> None:
    candles = load_binance_klines(FIXTURE)

    checks = {
        "timestamp_order": validate_timestamp_order(candles),
        "missing_values": validate_missing_values(candles),
        "ohlc": all(validate_ohlc(candle) for candle in candles),
        "positive_prices": all(validate_positive_prices(candle) for candle in candles),
        "non_negative_volume": all(validate_non_negative_volume(candle) for candle in candles),
    }

    consistency = 1.0 if all(checks.values()) else 0.0
    dqs = calculate_dqs(
        completeness=1.0,
        freshness=1.0,
        consistency=consistency,
        temporality=1.0,
    )

    print("=== Sprint 1A: Offline Kline Ingestion ===")
    print(f"Arquivo: {FIXTURE.name}")
    print(f"Candles carregados: {len(candles)}")
    print(f"Primeiro candle: {candles[0]}")
    print(f"Último candle: {candles[-1]}")
    print("\n=== DQL Checks ===")
    for name, passed in checks.items():
        print(f"{name}: {passed}")
    print(f"\nDQS: {dqs}")


if __name__ == "__main__":
    main()
