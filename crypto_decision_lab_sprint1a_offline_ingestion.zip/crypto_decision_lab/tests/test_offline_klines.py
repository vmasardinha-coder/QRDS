from datetime import timezone
from pathlib import Path
from zipfile import ZipFile

import pytest

from crypto_decision_lab.dql.validators import (
    validate_missing_values,
    validate_non_negative_volume,
    validate_ohlc,
    validate_positive_prices,
    validate_timestamp_order,
)
from crypto_decision_lab.ingestion.offline_klines import (
    OfflineKlineFormatError,
    load_binance_klines,
)

FIXTURE = Path(__file__).parent / "fixtures" / "BTCUSDT-1h-sample.csv"


def test_load_binance_klines_from_csv():
    candles = load_binance_klines(FIXTURE)

    assert len(candles) == 5
    assert candles[0].timestamp.tzinfo == timezone.utc
    assert candles[0].open == 42314.00
    assert candles[-1].close == 42850.00


def test_loaded_candles_pass_basic_dql():
    candles = load_binance_klines(FIXTURE)

    assert validate_timestamp_order(candles) is True
    assert validate_missing_values(candles) is True
    assert all(validate_ohlc(candle) for candle in candles)
    assert all(validate_positive_prices(candle) for candle in candles)
    assert all(validate_non_negative_volume(candle) for candle in candles)


def test_load_binance_klines_limit():
    candles = load_binance_klines(FIXTURE, limit=2)

    assert len(candles) == 2


def test_load_binance_klines_from_zip(tmp_path):
    zip_path = tmp_path / "sample.zip"
    with ZipFile(zip_path, "w") as archive:
        archive.write(FIXTURE, arcname="BTCUSDT-1h-sample.csv")

    candles = load_binance_klines(zip_path)

    assert len(candles) == 5
    assert candles[0].close == 42450.00


def test_unsupported_file_extension(tmp_path):
    unsupported = tmp_path / "sample.txt"
    unsupported.write_text("not a csv", encoding="utf-8")

    with pytest.raises(OfflineKlineFormatError):
        load_binance_klines(unsupported)


def test_invalid_kline_row(tmp_path):
    invalid_csv = tmp_path / "invalid.csv"
    invalid_csv.write_text("1704067200000,not-a-price\n", encoding="utf-8")

    with pytest.raises(OfflineKlineFormatError):
        load_binance_klines(invalid_csv)
