from crypto_decision_lab.dql.score import calculate_dqs, is_model_blocked


def test_dqs_abaixo_de_threshold():
    dqs = calculate_dqs(0.5, 0.5, 0.5, 0.5)
    assert dqs == 0.5
    assert is_model_blocked(dqs) is True


def test_dqs_acima_de_threshold():
    dqs = calculate_dqs(1.0, 1.0, 1.0, 1.0)
    assert dqs == 1.0
    assert is_model_blocked(dqs) is False


def test_dqs_no_threshold():
    dqs = calculate_dqs(0.8, 0.8, 0.8, 0.8)
    assert dqs == 0.8
    assert is_model_blocked(dqs) is False
