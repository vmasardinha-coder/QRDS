# Sprint 1A — Notas de Implementação

Status: concluída em ambiente local de teste.

## O que entrou

- Loader offline de klines Binance em CSV.
- Suporte a ZIP local com CSV dentro.
- Fixture pequena de BTCUSDT 1h.
- Testes unitários do loader.
- Demo offline `demo_ingest_offline.py`.

## O que não entrou

- Binance live.
- API key.
- WebSocket.
- Download automático.
- Banco de dados.
- Estratégia real.
- Ordens.

## Decisão

A Sprint 1A só prova que o sistema consegue ler dados históricos locais e passar pelo DQL básico.
Ainda não existe ingestão online nem conclusão estatística.
