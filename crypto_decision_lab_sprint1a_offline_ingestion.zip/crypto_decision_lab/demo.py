"""Demo local da Sprint 0B com dados fake."""

from datetime import datetime, timedelta, timezone

from crypto_decision_lab.domain.models import MarketCandle
from crypto_decision_lab.dql.validators import (
    validate_ohlc,
    validate_timestamp_order,
    validate_missing_values,
    validate_positive_prices,
    validate_non_negative_volume,
)
from crypto_decision_lab.dql.score import calculate_dqs, is_model_blocked
from crypto_decision_lab.decision.dummy_decision import make_dummy_decision


def build_fake_candles() -> list[MarketCandle]:
    base = datetime(2024, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    return [
        MarketCandle(
            timestamp=base + timedelta(hours=i),
            open=50000.0 + i * 10,
            high=50100.0 + i * 10,
            low=49900.0 + i * 10,
            close=50050.0 + i * 10,
            volume=100.0 + i,
        )
        for i in range(5)
    ]


def main() -> None:
    candles = build_fake_candles()

    print("=== Candles Fake ===")
    for candle in candles:
        print(candle)

    print("\n=== Validação ===")
    print(f"OHLC válido: {all(validate_ohlc(c) for c in candles)}")
    print(f"Ordem timestamps: {validate_timestamp_order(candles)}")
    print(f"Sem valores nulos: {validate_missing_values(candles)}")
    print(f"Preços positivos: {all(validate_positive_prices(c) for c in candles)}")
    print(f"Volume não negativo: {all(validate_non_negative_volume(c) for c in candles)}")

    dqs = calculate_dqs(
        completeness=1.0,
        freshness=1.0,
        consistency=1.0,
        temporality=1.0,
    )

    print("\n=== DQS ===")
    print(f"DQS: {dqs}")
    print(f"Modelo bloqueado: {is_model_blocked(dqs)}")

    decision = make_dummy_decision(
        dqs=dqs,
        expected_utility_long=0.05,
        expected_utility_short=0.02,
    )

    print("\n=== Decisão ===")
    print(decision)


if __name__ == "__main__":
    main()
