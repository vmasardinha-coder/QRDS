# Crypto Decision Lab - Sprint 1E

Sprint 1E cria um dashboard estatico offline em HTML a partir de artefatos DQL.

## Validacao

```bash
cd /workspaces/QRDS && mkdir -p _backup_local_zips && find . -maxdepth 1 -type f -name "*sprint1e*.zip" -exec mv -f {} _backup_local_zips/ \; ; git pull && ls -lh crypto_decision_lab_sprint1e_static_dashboard.zip && file crypto_decision_lab_sprint1e_static_dashboard.zip && unzip -t crypto_decision_lab_sprint1e_static_dashboard.zip && rm -rf crypto_decision_lab_sprint1e && unzip -o crypto_decision_lab_sprint1e_static_dashboard.zip && cd crypto_decision_lab_sprint1e && python -m pip install -e . && PYTHONPATH="$(pwd)/src" pytest -q tests/ && PYTHONPATH="$(pwd)/src" python demo_static_dashboard.py
```

Esperado: 12 passed e arquivos em `reports/sprint1e/dashboard/`.

Restricoes: sem Binance live, API key, WebSocket, ordens, capital real ou alavancagem.
