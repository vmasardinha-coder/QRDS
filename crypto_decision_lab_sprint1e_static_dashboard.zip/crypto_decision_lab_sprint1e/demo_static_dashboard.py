from crypto_decision_lab.dql.report import clean_candles, dirty_candles, generate_report
from crypto_decision_lab.artifacts.export import dql_artifact, dashboard_payload, write_json
from crypto_decision_lab.dashboard.static import write_dashboard

OUT = "reports/sprint1e/dashboard"

clean_report = generate_report("clean-48", clean_candles())
issues_report = generate_report("issues-48", dirty_candles())
artifacts = [dql_artifact(clean_report), dql_artifact(issues_report)]
payload = dashboard_payload(artifacts)

write_json(f"{OUT}/clean_dql_artifact.json", artifacts[0])
write_json(f"{OUT}/issues_dql_artifact.json", artifacts[1])
write_json(f"{OUT}/dashboard_payload.json", payload)
write_dashboard(f"{OUT}/index.html", payload)

print("=== Sprint 1E Static Dashboard ===")
print(f"Schema: {payload['schema']}")
print(f"Total reports: {payload['summary']['total_reports']}")
print(f"PASS: {payload['summary']['pass_count']}")
print(f"BLOCKED: {payload['summary']['blocked_count']}")
print(f"Worst DQS: {payload['summary']['worst_dqs']:.4f}")
print(f"Best DQS: {payload['summary']['best_dqs']:.4f}")
print(f"Generated dashboard: {OUT}/index.html")
