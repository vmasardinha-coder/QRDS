import json
from pathlib import Path
from crypto_decision_lab.dql.report import clean_candles, dirty_candles, generate_report
from crypto_decision_lab.artifacts.export import dql_artifact, dashboard_payload, write_json
from crypto_decision_lab.dashboard.static import render_dashboard_html, write_dashboard


def test_clean_report_pass():
    r = generate_report("clean-48", clean_candles())
    assert r.status == "PASS"
    assert r.dqs == 1.0
    assert r.model_blocked is False


def test_dirty_report_blocked():
    r = generate_report("issues-48", dirty_candles())
    assert r.status == "BLOCKED"
    assert r.dqs == 0.6979
    assert r.model_blocked is True


def test_dirty_report_has_expected_issues():
    r = generate_report("issues-48", dirty_candles())
    for issue in ["duplicate_timestamps", "timestamp_gaps", "invalid_ohlc", "invalid_prices", "invalid_volume", "timestamp_order"]:
        assert issue in r.issues


def test_dql_artifact_schema():
    a = dql_artifact(generate_report("clean-48", clean_candles()))
    assert a["schema"] == "qrds.dql_report.v1"
    assert a["report"]["status"] == "PASS"


def test_dashboard_payload_schema():
    artifacts = [dql_artifact(generate_report("clean-48", clean_candles())), dql_artifact(generate_report("issues-48", dirty_candles()))]
    p = dashboard_payload(artifacts)
    assert p["schema"] == "qrds.dashboard_static.v1"


def test_dashboard_payload_counts():
    artifacts = [dql_artifact(generate_report("clean-48", clean_candles())), dql_artifact(generate_report("issues-48", dirty_candles()))]
    s = dashboard_payload(artifacts)["summary"]
    assert s["total_reports"] == 2
    assert s["pass_count"] == 1
    assert s["blocked_count"] == 1


def test_dashboard_payload_dqs_bounds():
    artifacts = [dql_artifact(generate_report("clean-48", clean_candles())), dql_artifact(generate_report("issues-48", dirty_candles()))]
    s = dashboard_payload(artifacts)["summary"]
    assert s["best_dqs"] == 1.0
    assert s["worst_dqs"] == 0.6979
    assert s["average_dqs"] == 0.8489


def test_dashboard_payload_issues_are_collected():
    artifacts = [dql_artifact(generate_report("clean-48", clean_candles())), dql_artifact(generate_report("issues-48", dirty_candles()))]
    issues = dashboard_payload(artifacts)["summary"]["all_issues"]
    assert "invalid_volume" in issues
    assert "timestamp_gaps" in issues


def test_html_contains_main_fields():
    artifacts = [dql_artifact(generate_report("clean-48", clean_candles())), dql_artifact(generate_report("issues-48", dirty_candles()))]
    html = render_dashboard_html(dashboard_payload(artifacts))
    assert "QRDS DQL Dashboard Offline" in html
    assert "PASS" in html
    assert "BLOCKED" in html
    assert "0.6979" in html


def test_html_has_no_external_dependencies():
    artifacts = [dql_artifact(generate_report("clean-48", clean_candles())), dql_artifact(generate_report("issues-48", dirty_candles()))]
    html = render_dashboard_html(dashboard_payload(artifacts))
    assert "https://" not in html
    assert "http://" not in html
    assert "cdn" not in html.lower()


def test_write_json(tmp_path):
    path = write_json(tmp_path / "payload.json", {"a": 1})
    assert json.loads(path.read_text())["a"] == 1


def test_write_dashboard(tmp_path):
    artifacts = [dql_artifact(generate_report("clean-48", clean_candles())), dql_artifact(generate_report("issues-48", dirty_candles()))]
    path = write_dashboard(tmp_path / "index.html", dashboard_payload(artifacts))
    assert path.exists()
    assert "<html" in path.read_text()
