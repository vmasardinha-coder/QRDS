from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from crypto_decision_lab.domain.models import MarketCandle

DQS_THRESHOLD = 0.80

@dataclass(frozen=True)
class DataQualityReport:
    name: str
    total_candles: int
    dqs: float
    status: str
    completeness: float
    freshness: float
    consistency: float
    temporality: float
    duplicate_timestamps: int
    gap_count: int
    invalid_ohlc_count: int
    invalid_price_count: int
    invalid_volume_count: int
    missing_values_count: int
    issues: list[str]

    @property
    def model_blocked(self) -> bool:
        return self.status == "BLOCKED" or self.dqs < DQS_THRESHOLD

    def to_dict(self) -> dict:
        d = asdict(self)
        d["model_blocked"] = self.model_blocked
        return d

def clean_candles(n: int = 48) -> list[MarketCandle]:
    start = datetime(2024, 1, 1, tzinfo=timezone.utc)
    candles = []
    for i in range(n):
        base = 50000 + i * 10
        candles.append(MarketCandle(start + timedelta(hours=i), base, base + 100, base - 100, base + 50, 100 + i))
    return candles

def dirty_candles(n: int = 48) -> list[MarketCandle]:
    candles = clean_candles(n)
    candles = list(candles)
    # duplicate timestamp
    candles[10] = candles[9]
    # timestamp gap
    candles[20] = MarketCandle(candles[20].timestamp + timedelta(hours=2), candles[20].open, candles[20].high, candles[20].low, candles[20].close, candles[20].volume)
    # invalid OHLC
    candles[30] = MarketCandle(candles[30].timestamp, 100, 90, 95, 98, candles[30].volume)
    # invalid price
    candles[35] = MarketCandle(candles[35].timestamp, 0, 100, 90, 95, candles[35].volume)
    # invalid volume
    candles[40] = MarketCandle(candles[40].timestamp, candles[40].open, candles[40].high, candles[40].low, candles[40].close, -1)
    return candles

def generate_report(name: str, candles: list[MarketCandle], expected_interval_seconds: int = 3600) -> DataQualityReport:
    total = len(candles)
    if total == 0:
        return DataQualityReport(name, 0, 0.0, "BLOCKED", 0.0, 1.0, 0.0, 0.0, 0, 0, 0, 0, 0, 0, ["empty_dataset"])
    timestamps = [c.timestamp for c in candles]
    duplicate_timestamps = len(timestamps) - len(set(timestamps))
    ordered = sorted(candles, key=lambda c: c.timestamp)
    gap_count = sum(1 for a, b in zip(ordered, ordered[1:]) if int((b.timestamp - a.timestamp).total_seconds()) != expected_interval_seconds)
    invalid_ohlc_count = sum(1 for c in candles if not (c.low <= c.open <= c.high and c.low <= c.close <= c.high and c.low <= c.high))
    invalid_price_count = sum(1 for c in candles if not all(v > 0 for v in (c.open, c.high, c.low, c.close)))
    invalid_volume_count = sum(1 for c in candles if c.volume < 0)
    missing_values_count = 0
    order_ok = all(candles[i].timestamp > candles[i-1].timestamp for i in range(1, len(candles)))
    issues = []
    if duplicate_timestamps: issues.append("duplicate_timestamps")
    if gap_count: issues.append("timestamp_gaps")
    if invalid_ohlc_count: issues.append("invalid_ohlc")
    if invalid_price_count: issues.append("invalid_prices")
    if invalid_volume_count: issues.append("invalid_volume")
    if missing_values_count: issues.append("missing_values")
    if not order_ok: issues.append("timestamp_order")
    completeness = round(max(0.0, 1.0 - ((duplicate_timestamps + gap_count) / total)), 4)
    freshness = 1.0
    consistency = round(max(0.0, 1.0 - ((invalid_ohlc_count + invalid_price_count + invalid_volume_count + missing_values_count) / total)), 4)
    temporality = 1.0 if order_ok and duplicate_timestamps == 0 else 0.0
    dqs = round((completeness + freshness + consistency + temporality) / 4.0, 4)
    status = "PASS" if dqs >= DQS_THRESHOLD and not issues else "BLOCKED"
    return DataQualityReport(name, total, dqs, status, completeness, freshness, consistency, temporality, duplicate_timestamps, gap_count, invalid_ohlc_count, invalid_price_count, invalid_volume_count, missing_values_count, issues)
