from html import escape
from pathlib import Path

STYLE = """
body{font-family:Arial,sans-serif;background:#0f172a;color:#e5e7eb;margin:0;padding:32px;}
.container{max-width:1100px;margin:0 auto;}
.header{margin-bottom:24px;}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin-bottom:24px;}
.card{background:#111827;border:1px solid #334155;border-radius:14px;padding:18px;box-shadow:0 10px 25px rgba(0,0,0,.18);}
.kpi{font-size:34px;font-weight:700;margin:6px 0;}
.badge{display:inline-block;border-radius:999px;padding:4px 10px;font-size:12px;font-weight:700;}
.pass{background:#064e3b;color:#d1fae5;}.blocked{background:#7f1d1d;color:#fee2e2;}
.bar{height:10px;background:#334155;border-radius:999px;overflow:hidden;margin-top:8px}.fill{height:100%;background:#38bdf8;}
table{width:100%;border-collapse:collapse;background:#111827;border-radius:14px;overflow:hidden;}th,td{padding:12px;border-bottom:1px solid #334155;text-align:left;font-size:14px;}th{background:#1f2937;}
.small{color:#9ca3af;font-size:13px}.issues{color:#fbbf24;}
"""

def _pct(value: float) -> str:
    return f"{max(0,min(100, value*100)):.1f}%"

def render_dashboard_html(payload: dict) -> str:
    s = payload["summary"]
    rows = []
    for r in payload["reports"]:
        cls = "pass" if r["status"] == "PASS" else "blocked"
        issues = ", ".join(r.get("issues") or ["none"])
        rows.append(f"""
        <tr>
          <td>{escape(r['name'])}</td>
          <td><span class='badge {cls}'>{escape(r['status'])}</span></td>
          <td>{r['dqs']:.4f}<div class='bar'><div class='fill' style='width:{_pct(r['dqs'])}'></div></div></td>
          <td>{'true' if r['model_blocked'] else 'false'}</td>
          <td class='issues'>{escape(issues)}</td>
        </tr>""")
    return f"""<!doctype html>
<html lang='pt-BR'>
<head><meta charset='utf-8'><title>QRDS DQL Dashboard Offline</title><style>{STYLE}</style></head>
<body><div class='container'>
  <div class='header'>
    <h1>QRDS DQL Dashboard Offline</h1>
    <p class='small'>Schema: {escape(payload['schema'])} | Projeto: {escape(payload['project'])}</p>
  </div>
  <div class='grid'>
    <div class='card'><div class='small'>Total reports</div><div class='kpi'>{s['total_reports']}</div></div>
    <div class='card'><div class='small'>PASS</div><div class='kpi'>{s['pass_count']}</div></div>
    <div class='card'><div class='small'>BLOCKED</div><div class='kpi'>{s['blocked_count']}</div></div>
    <div class='card'><div class='small'>Worst DQS</div><div class='kpi'>{s['worst_dqs']:.4f}</div></div>
  </div>
  <div class='card'>
    <h2>Reports</h2>
    <table><thead><tr><th>Name</th><th>Status</th><th>DQS</th><th>Model blocked</th><th>Issues</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
  </div>
</div></body></html>"""

def write_dashboard(path: str | Path, payload: dict) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_dashboard_html(payload), encoding="utf-8")
    return path
