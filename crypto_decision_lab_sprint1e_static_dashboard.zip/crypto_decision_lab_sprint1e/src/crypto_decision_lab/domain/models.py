from dataclasses import dataclass
from datetime import datetime, timezone

@dataclass(frozen=True)
class MarketCandle:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    symbol: str = "BTCUSDT"
    timeframe: str = "1h"

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
