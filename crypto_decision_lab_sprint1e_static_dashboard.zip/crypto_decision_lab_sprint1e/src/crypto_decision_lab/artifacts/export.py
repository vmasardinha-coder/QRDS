import json
from pathlib import Path
from crypto_decision_lab.domain.models import utc_now_iso

DQL_SCHEMA = "qrds.dql_report.v1"
DASHBOARD_SCHEMA = "qrds.dashboard_static.v1"

def dql_artifact(report) -> dict:
    return {
        "schema": DQL_SCHEMA,
        "generated_at": utc_now_iso(),
        "project": "QOS / QRDS - Crypto Decision Lab",
        "report": report.to_dict(),
    }

def dashboard_payload(artifacts: list[dict]) -> dict:
    reports = [a["report"] for a in artifacts]
    total = len(reports)
    pass_count = sum(1 for r in reports if r["status"] == "PASS")
    blocked_count = sum(1 for r in reports if r["status"] == "BLOCKED")
    dqs_values = [r["dqs"] for r in reports]
    all_issues = sorted({issue for r in reports for issue in r.get("issues", [])})
    return {
        "schema": DASHBOARD_SCHEMA,
        "generated_at": utc_now_iso(),
        "project": "QOS / QRDS - Crypto Decision Lab",
        "summary": {
            "total_reports": total,
            "pass_count": pass_count,
            "blocked_count": blocked_count,
            "best_dqs": max(dqs_values) if dqs_values else None,
            "worst_dqs": min(dqs_values) if dqs_values else None,
            "average_dqs": round(sum(dqs_values) / total, 4) if total else None,
            "all_issues": all_issues,
        },
        "reports": reports,
    }

def write_json(path: str | Path, data: dict) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    return path
