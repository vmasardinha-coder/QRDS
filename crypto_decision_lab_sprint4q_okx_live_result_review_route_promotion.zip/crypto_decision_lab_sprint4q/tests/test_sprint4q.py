
import json
from pathlib import Path
import pytest
from crypto_decision_lab.okx_live_review import (
    build_okx_execute_report,
    review_okx_live_result,
    export_report,
    APPROVED_OKX_ROUTE,
    BINANCE_ROUTE,
    BYBIT_ROUTE,
)

@pytest.fixture()
def review():
    return review_okx_live_result(build_okx_execute_report())

@pytest.mark.parametrize("field,expected", [
    ("schema", "qrds.okx_live_result_review_report.v1"),
    ("review_status", "PASS"),
    ("model_blocked", False),
    ("route_promotion_allowed", True),
    ("okx_public_live_route_approved", True),
    ("simulation_exchange", "binance"),
    ("binance_route", BINANCE_ROUTE),
    ("okx_route", APPROVED_OKX_ROUTE),
    ("bybit_route", BYBIT_ROUTE),
    ("network_calls_confirmed_from_4p", True),
    ("api_key_required", False),
    ("api_key_present", False),
    ("account_connection_required", False),
    ("authenticated_connection_used", False),
    ("websocket_used", False),
    ("real_capital_used", False),
    ("exchange_connected", False),
    ("orders_generated", False),
    ("endpoint", "https://www.okx.com/api/v5/market/candles"),
    ("instrument", "BTC-USDT"),
    ("candles_normalized", 5),
    ("timestamp_order_valid", True),
    ("ohlcv_contract_valid", True),
    ("response_shape_valid", True),
    ("safety_policy", "OKX_PUBLIC_LIVE_REVIEW_NO_AUTH_NO_ORDERS_NO_REAL_CAPITAL"),
    ("quality_score", 1.0),
    ("issues", []),
    ("action", "PROMOTE_OKX_PUBLIC_LIVE_ROUTE_KEEP_BINANCE_SIM_AND_BYBIT_PENDING"),
    ("next_required_gate", "PUBLIC_LIVE_DATA_DQL_PIPELINE_OKX_BINANCE_SIM_REQUIRED"),
])
def test_review_fields(review, field, expected):
    assert getattr(review, field) == expected


def test_real_base_targets(review):
    assert review.real_base_target_exchanges == ["okx", "bybit"]


def test_real_base_active_now(review):
    assert review.real_base_active_now == ["okx"]


def test_real_base_pending(review):
    assert review.real_base_pending == ["bybit"]

@pytest.mark.parametrize("dirty_field", [
    "api_key_exposure_detected",
    "account_or_authenticated_connection_detected",
    "capital_or_order_exposure_detected",
    "insufficient_okx_candles",
    "timestamp_order_invalid",
    "ohlcv_contract_invalid",
    "response_shape_invalid",
])
def test_dirty_review_blocks_and_contains_expected_issues(dirty_field):
    dirty = review_okx_live_result(build_okx_execute_report(dirty=True))
    assert dirty.review_status == "BLOCKED"
    assert dirty.model_blocked is True
    assert dirty.route_promotion_allowed is False
    assert dirty.okx_public_live_route_approved is False
    assert dirty.action == "NO_OKX_ROUTE_PROMOTION_BLOCKED"
    assert dirty_field in dirty.issues

@pytest.mark.parametrize("attr", [
    "api_key_required",
    "api_key_present",
    "account_connection_required",
    "authenticated_connection_used",
    "websocket_used",
    "real_capital_used",
    "exchange_connected",
    "orders_generated",
])
def test_no_security_exposure(review, attr):
    assert getattr(review, attr) is False

@pytest.mark.parametrize("attr", [
    "timestamp_order_valid",
    "ohlcv_contract_valid",
    "response_shape_valid",
    "network_calls_confirmed_from_4p",
])
def test_quality_contracts_true(review, attr):
    assert getattr(review, attr) is True


def test_export_report(tmp_path, review):
    paths = export_report(review, tmp_path)
    assert Path(paths["json"]).exists()
    assert Path(paths["txt"]).exists()
    data = json.loads(Path(paths["json"]).read_text())
    assert data["review_status"] == "PASS"
    assert data["okx_route"] == APPROVED_OKX_ROUTE


def test_execute_report_clean_defaults():
    r = build_okx_execute_report()
    assert r.pipeline_status == "PASS"
    assert r.public_endpoint_reached is True
    assert r.candles_normalized == 5


def test_execute_report_dirty_defaults():
    r = build_okx_execute_report(dirty=True)
    assert r.pipeline_status == "BLOCKED"
    assert r.api_key_present is True
    assert r.orders_generated is True


def test_review_keeps_binance_simulation_only(review):
    assert review.binance_route == "SIMULATION_FIXTURE_REPLAY"
    assert review.simulation_exchange == "binance"


def test_review_keeps_bybit_pending(review):
    assert review.bybit_route == "PENDING_BLOCKED_BY_403"
    assert "bybit" in review.real_base_pending


def test_review_promotes_okx_only(review):
    assert review.okx_route == "PUBLIC_HTTP_LIVE_APPROVED_NO_AUTH"
    assert review.real_base_active_now == ["okx"]

