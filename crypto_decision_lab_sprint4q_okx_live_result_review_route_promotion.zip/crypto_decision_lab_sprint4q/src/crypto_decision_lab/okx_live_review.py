
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json

APPROVED_OKX_ROUTE = "PUBLIC_HTTP_LIVE_APPROVED_NO_AUTH"
BINANCE_ROUTE = "SIMULATION_FIXTURE_REPLAY"
BYBIT_ROUTE = "PENDING_BLOCKED_BY_403"

@dataclass(frozen=True)
class OkxPublicLiveExecuteReport:
    schema: str = "qrds.okx_public_live_pipeline_execute_report.v1"
    pipeline_status: str = "PASS"
    manual_approval_granted: bool = True
    explicit_approval_phrase_valid: bool = True
    okx_public_live_pipeline_authorized: bool = True
    live_pipeline_enabled: bool = True
    fixture_replay_used: bool = False
    network_calls_executed: bool = True
    authenticated_connection_used: bool = False
    api_key_required: bool = False
    api_key_present: bool = False
    account_connection_required: bool = False
    websocket_used: bool = False
    real_capital_used: bool = False
    exchange_connected: bool = False
    orders_generated: bool = False
    simulation_exchange: str = "binance"
    binance_route: str = BINANCE_ROUTE
    okx_route: str = "PUBLIC_HTTP_LIVE_EXECUTED_NO_AUTH"
    bybit_route: str = BYBIT_ROUTE
    endpoint: str = "https://www.okx.com/api/v5/market/candles"
    instrument: str = "BTC-USDT"
    bar: str = "1H"
    public_endpoint_reached: bool = True
    candles_normalized: int = 5
    timestamp_order_valid: bool = True
    ohlcv_contract_valid: bool = True
    response_shape_valid: bool = True
    issues: tuple[str, ...] = ()

@dataclass(frozen=True)
class OkxLiveResultReviewReport:
    schema: str
    review_status: str
    model_blocked: bool
    route_promotion_allowed: bool
    okx_public_live_route_approved: bool
    simulation_exchange: str
    binance_route: str
    okx_route: str
    bybit_route: str
    real_base_target_exchanges: list[str]
    real_base_active_now: list[str]
    real_base_pending: list[str]
    network_calls_confirmed_from_4p: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    authenticated_connection_used: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    endpoint: str
    instrument: str
    candles_normalized: int
    timestamp_order_valid: bool
    ohlcv_contract_valid: bool
    response_shape_valid: bool
    safety_policy: str
    quality_score: float
    issues: list[str]
    action: str
    next_required_gate: str


def build_okx_execute_report(dirty: bool = False) -> OkxPublicLiveExecuteReport:
    if not dirty:
        return OkxPublicLiveExecuteReport()
    return OkxPublicLiveExecuteReport(
        pipeline_status="BLOCKED",
        api_key_present=True,
        account_connection_required=True,
        orders_generated=True,
        real_capital_used=True,
        exchange_connected=True,
        candles_normalized=0,
        timestamp_order_valid=False,
        ohlcv_contract_valid=False,
        response_shape_valid=False,
        issues=("security_exposure_detected",),
    )


def review_okx_live_result(report: OkxPublicLiveExecuteReport) -> OkxLiveResultReviewReport:
    issues: list[str] = []
    if report.pipeline_status != "PASS":
        issues.append(f"pipeline_status:{report.pipeline_status}")
    if not report.manual_approval_granted or not report.explicit_approval_phrase_valid:
        issues.append("approval_not_valid")
    if not report.okx_public_live_pipeline_authorized or not report.live_pipeline_enabled:
        issues.append("okx_live_not_authorized")
    if report.fixture_replay_used:
        issues.append("fixture_replay_unexpected_for_4p_review")
    if not report.network_calls_executed or not report.public_endpoint_reached:
        issues.append("public_endpoint_not_reached")
    if report.api_key_required or report.api_key_present:
        issues.append("api_key_exposure_detected")
    if report.account_connection_required or report.authenticated_connection_used:
        issues.append("account_or_authenticated_connection_detected")
    if report.websocket_used:
        issues.append("websocket_unexpected")
    if report.real_capital_used or report.exchange_connected or report.orders_generated:
        issues.append("capital_or_order_exposure_detected")
    if report.binance_route != BINANCE_ROUTE:
        issues.append("binance_route_policy_invalid")
    if report.bybit_route != BYBIT_ROUTE:
        issues.append("bybit_pending_policy_invalid")
    if report.candles_normalized < 5:
        issues.append("insufficient_okx_candles")
    if not report.timestamp_order_valid:
        issues.append("timestamp_order_invalid")
    if not report.ohlcv_contract_valid:
        issues.append("ohlcv_contract_invalid")
    if not report.response_shape_valid:
        issues.append("response_shape_invalid")

    ok = not issues
    score = 1.0 if ok else max(0.0, round(1 - len(issues) * 0.1, 4))
    return OkxLiveResultReviewReport(
        schema="qrds.okx_live_result_review_report.v1",
        review_status="PASS" if ok else "BLOCKED",
        model_blocked=not ok,
        route_promotion_allowed=ok,
        okx_public_live_route_approved=ok,
        simulation_exchange="binance",
        binance_route=BINANCE_ROUTE,
        okx_route=APPROVED_OKX_ROUTE if ok else "OKX_PUBLIC_LIVE_ROUTE_BLOCKED",
        bybit_route=BYBIT_ROUTE,
        real_base_target_exchanges=["okx", "bybit"],
        real_base_active_now=["okx"] if ok else [],
        real_base_pending=["bybit"],
        network_calls_confirmed_from_4p=report.network_calls_executed,
        api_key_required=report.api_key_required,
        api_key_present=report.api_key_present,
        account_connection_required=report.account_connection_required,
        authenticated_connection_used=report.authenticated_connection_used,
        websocket_used=report.websocket_used,
        real_capital_used=report.real_capital_used,
        exchange_connected=report.exchange_connected,
        orders_generated=report.orders_generated,
        endpoint=report.endpoint,
        instrument=report.instrument,
        candles_normalized=report.candles_normalized,
        timestamp_order_valid=report.timestamp_order_valid,
        ohlcv_contract_valid=report.ohlcv_contract_valid,
        response_shape_valid=report.response_shape_valid,
        safety_policy="OKX_PUBLIC_LIVE_REVIEW_NO_AUTH_NO_ORDERS_NO_REAL_CAPITAL",
        quality_score=score,
        issues=issues,
        action="PROMOTE_OKX_PUBLIC_LIVE_ROUTE_KEEP_BINANCE_SIM_AND_BYBIT_PENDING" if ok else "NO_OKX_ROUTE_PROMOTION_BLOCKED",
        next_required_gate="PUBLIC_LIVE_DATA_DQL_PIPELINE_OKX_BINANCE_SIM_REQUIRED" if ok else "OKX_PUBLIC_LIVE_RESULT_REVIEW_REMEDIATION_REQUIRED",
    )


def to_dict(obj):
    if hasattr(obj, '__dataclass_fields__'):
        return asdict(obj)
    return obj


def export_report(report: OkxLiveResultReviewReport, out_dir: str | Path = "reports/sprint4q") -> dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = to_dict(report)
    json_path = out / "okx_live_result_review_report.json"
    txt_path = out / "okx_live_result_review_report.txt"
    json_path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    lines = [
        "OKX Live Result Review Report",
        f"schema: {report.schema}",
        f"review_status: {report.review_status}",
        f"route_promotion_allowed: {report.route_promotion_allowed}",
        f"okx_route: {report.okx_route}",
        f"binance_route: {report.binance_route}",
        f"bybit_route: {report.bybit_route}",
        f"quality_score: {report.quality_score:.4f}",
        f"issues: {report.issues if report.issues else 'none'}",
        f"action: {report.action}",
        f"next_required_gate: {report.next_required_gate}",
    ]
    txt_path.write_text("\n".join(lines), encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
