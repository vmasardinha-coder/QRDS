
# Sprint 5A - Interactive Research Dashboard

Aplicacao interativa de pesquisa para o QRDS/QOS.

Escopo:
- Dashboard HTML estatico gerado por demo.
- App Streamlit opcional.
- OKX public live route como rota de pesquisa aprovada.
- Binance como simulacao/fixture.
- Bybit pendente por 403.
- Sem API key, sem conta real, sem ordem e sem capital real.

Rodar validacao:

```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_interactive_research_dashboard.py
```

App opcional:

```bash
streamlit run app_streamlit.py
```
