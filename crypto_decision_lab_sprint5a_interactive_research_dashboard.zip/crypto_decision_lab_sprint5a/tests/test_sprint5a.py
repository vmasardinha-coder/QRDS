
import pytest
from crypto_decision_lab.pipeline.research_dashboard import build_dashboard_report, report_to_dict, validate_dashboard_report
from crypto_decision_lab.export.artifacts import write_json_txt, write_static_html


def test_report_validates():
    assert validate_dashboard_report(build_dashboard_report())


def test_report_to_dict_schema():
    d = report_to_dict(build_dashboard_report())
    assert d["schema"] == "qrds.interactive_research_dashboard.v1"


@pytest.mark.parametrize("field,expected", [
    ("dashboard_status", "PASS"),
    ("model_blocked", False),
    ("research_allowed", True),
    ("operational_decision_allowed", False),
    ("app_mode", "INTERACTIVE_RESEARCH_ONLY"),
    ("quality_score", 1.0),
    ("simulation_exchange", "binance"),
    ("binance_route", "SIMULATION_FIXTURE_REPLAY"),
    ("okx_route", "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH"),
    ("bybit_route", "PENDING_BLOCKED_BY_403"),
    ("live_pipeline_enabled", False),
    ("network_calls_executed", False),
    ("api_key_required", False),
    ("api_key_present", False),
    ("account_connection_required", False),
    ("websocket_used", False),
    ("real_capital_used", False),
    ("exchange_connected", False),
    ("orders_generated", False),
    ("total_normalized_candles", 10),
    ("feature_rows", 10),
    ("regime_variants", 3),
    ("last_regime_code", "high_volatility|upper_close"),
    ("action", "OPEN_INTERACTIVE_RESEARCH_DASHBOARD_NO_OPERATIONAL_DECISION"),
    ("next_required_gate", "INTERACTIVE_RESEARCH_DASHBOARD_VALIDATION_REQUIRED"),
])
def test_expected_fields(field, expected):
    assert getattr(build_dashboard_report(), field) == expected


@pytest.mark.parametrize("flag", [
    "api_key_required", "api_key_present", "account_connection_required", "websocket_used",
    "real_capital_used", "exchange_connected", "orders_generated", "operational_decision_allowed",
])
def test_safety_flags_false(flag):
    assert getattr(build_dashboard_report(), flag) is False


@pytest.mark.parametrize("route_key", ["okx", "binance", "bybit"])
def test_route_widgets_exist(route_key):
    assert route_key in build_dashboard_report().widgets["routes"]


@pytest.mark.parametrize("safety_key", ["api_key_present", "account_connection_required", "orders_generated", "real_capital_used"])
def test_safety_widgets_false(safety_key):
    assert build_dashboard_report().widgets["safety"][safety_key] is False


@pytest.mark.parametrize("kpi_key", ["quality_score", "dql_status", "feature_quality_status", "regime_status", "research_allowed", "operational_decision_allowed"])
def test_kpi_widgets_exist(kpi_key):
    assert kpi_key in build_dashboard_report().widgets["kpis"]


@pytest.mark.parametrize("issue", ["bybit_public_http_blocked_by_403_pending_not_blocking"])
def test_expected_issue(issue):
    assert issue in build_dashboard_report().issues


@pytest.mark.parametrize("bad_field,bad_value", [
    ("dashboard_status", "BLOCKED"),
    ("model_blocked", True),
    ("research_allowed", False),
    ("operational_decision_allowed", True),
    ("api_key_required", True),
    ("api_key_present", True),
    ("account_connection_required", True),
    ("websocket_used", True),
    ("real_capital_used", True),
    ("exchange_connected", True),
    ("orders_generated", True),
    ("simulation_exchange", "okx"),
    ("okx_route", "INVALID"),
    ("bybit_route", "ACTIVE"),
])
def test_invalid_mutations_block(bad_field, bad_value):
    r = build_dashboard_report()
    data = r.__dict__.copy()
    data[bad_field] = bad_value
    mutated = type(r)(**data)
    assert validate_dashboard_report(mutated) is False


def test_artifact_writers(tmp_path):
    r = build_dashboard_report()
    out = write_json_txt(r, output_dir=tmp_path, stem="x")
    html = write_static_html(r, output_dir=tmp_path / "dashboard")
    assert out["json"].endswith("x.json")
    assert out["txt"].endswith("x.txt")
    assert html.endswith("index.html")


def test_artifact_contents(tmp_path):
    r = build_dashboard_report()
    out = write_json_txt(r, output_dir=tmp_path, stem="x")
    html = write_static_html(r, output_dir=tmp_path / "dashboard")
    assert "interactive_research_dashboard" in open(out["json"], encoding="utf-8").read()
    assert "Dashboard" in open(html, encoding="utf-8").read()
