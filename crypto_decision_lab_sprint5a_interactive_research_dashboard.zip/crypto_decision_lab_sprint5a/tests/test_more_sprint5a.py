
import pytest
from crypto_decision_lab.pipeline.research_dashboard import build_dashboard_report, report_to_dict

@pytest.mark.parametrize("field", [
    "schema", "dashboard_status", "app_mode", "quality_score", "binance_route", "okx_route", "bybit_route"
])
def test_payload_has_core_fields(field):
    assert field in report_to_dict(build_dashboard_report())
