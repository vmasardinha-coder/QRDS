
from crypto_decision_lab.pipeline.research_dashboard import build_dashboard_report, report_to_dict

try:
    import streamlit as st
except Exception as exc:
    raise SystemExit("Streamlit nao instalado. Rode: python -m pip install '.[dashboard]'") from exc

report = build_dashboard_report()
payload = report_to_dict(report)

st.set_page_config(page_title="QRDS Research Dashboard", layout="wide")
st.title("QRDS/QOS - Interactive Research Dashboard")
st.caption("Research-only. Sem API key, sem conta real, sem ordem e sem capital real.")

c1, c2, c3, c4 = st.columns(4)
c1.metric("Dashboard", report.dashboard_status)
c2.metric("Quality", f"{report.quality_score:.4f}")
c3.metric("Research allowed", str(report.research_allowed))
c4.metric("Operational", str(report.operational_decision_allowed))

st.subheader("Rotas")
st.json(payload["widgets"]["routes"])
st.subheader("Seguranca")
st.json(payload["widgets"]["safety"])
st.subheader("Payload completo")
st.json(payload)
