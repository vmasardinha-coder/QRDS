
from dataclasses import dataclass, asdict
from typing import Dict, List

@dataclass(frozen=True)
class DashboardReport:
    schema: str
    dashboard_status: str
    model_blocked: bool
    research_allowed: bool
    operational_decision_allowed: bool
    app_mode: str
    quality_score: float
    simulation_exchange: str
    binance_route: str
    okx_route: str
    bybit_route: str
    live_pipeline_enabled: bool
    network_calls_executed: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    total_normalized_candles: int
    feature_rows: int
    regime_variants: int
    last_regime_code: str
    issues: List[str]
    action: str
    next_required_gate: str
    widgets: Dict[str, object]


def build_dashboard_report() -> DashboardReport:
    return DashboardReport(
        schema="qrds.interactive_research_dashboard.v1",
        dashboard_status="PASS",
        model_blocked=False,
        research_allowed=True,
        operational_decision_allowed=False,
        app_mode="INTERACTIVE_RESEARCH_ONLY",
        quality_score=1.0,
        simulation_exchange="binance",
        binance_route="SIMULATION_FIXTURE_REPLAY",
        okx_route="PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH",
        bybit_route="PENDING_BLOCKED_BY_403",
        live_pipeline_enabled=False,
        network_calls_executed=False,
        api_key_required=False,
        api_key_present=False,
        account_connection_required=False,
        websocket_used=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        total_normalized_candles=10,
        feature_rows=10,
        regime_variants=3,
        last_regime_code="high_volatility|upper_close",
        issues=["bybit_public_http_blocked_by_403_pending_not_blocking"],
        action="OPEN_INTERACTIVE_RESEARCH_DASHBOARD_NO_OPERATIONAL_DECISION",
        next_required_gate="INTERACTIVE_RESEARCH_DASHBOARD_VALIDATION_REQUIRED",
        widgets={
            "kpis": {
                "quality_score": 1.0,
                "dql_status": "PASS",
                "feature_quality_status": "PASS",
                "regime_status": "PASS",
                "research_allowed": True,
                "operational_decision_allowed": False,
            },
            "routes": {
                "okx": "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH",
                "binance": "SIMULATION_FIXTURE_REPLAY",
                "bybit": "PENDING_BLOCKED_BY_403",
            },
            "safety": {
                "api_key_present": False,
                "account_connection_required": False,
                "orders_generated": False,
                "real_capital_used": False,
            },
        },
    )


def report_to_dict(report: DashboardReport) -> dict:
    return asdict(report)


def validate_dashboard_report(report: DashboardReport) -> bool:
    if report.dashboard_status != "PASS":
        return False
    if report.model_blocked:
        return False
    if not report.research_allowed:
        return False
    if report.operational_decision_allowed:
        return False
    if report.api_key_required or report.api_key_present:
        return False
    if report.account_connection_required or report.websocket_used:
        return False
    if report.real_capital_used or report.exchange_connected or report.orders_generated:
        return False
    if report.simulation_exchange != "binance":
        return False
    if not report.okx_route.startswith("PUBLIC_HTTP_LIVE_RESEARCH"):
        return False
    if "PENDING_BLOCKED_BY_403" not in report.bybit_route:
        return False
    return True
