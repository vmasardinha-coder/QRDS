import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
from html import escape


def _to_plain(value):
    if is_dataclass(value):
        return _to_plain(asdict(value))
    if isinstance(value, dict):
        return {str(k): _to_plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_plain(v) for v in value]
    return value


def write_json_txt(payload, output_dir="reports/sprint5a", stem="interactive_research_dashboard"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    plain = _to_plain(payload)
    json_path = out / f"{stem}.json"
    txt_path = out / f"{stem}.txt"
    json_path.write_text(json.dumps(plain, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    lines = []
    for k, v in plain.items():
        lines.append(f"{k}: {v}")
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}


def write_static_html(payload, output_dir="reports/sprint5a/dashboard"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    p = _to_plain(payload)
    cards = [
        ("Dashboard", p["dashboard_status"]),
        ("Quality", f'{p["quality_score"]:.4f}'),
        ("Research", str(p["research_allowed"])),
        ("Operational", str(p["operational_decision_allowed"])),
        ("OKX", p["okx_route"]),
        ("Binance", p["binance_route"]),
        ("Bybit", p["bybit_route"]),
        ("Safety", "NO_AUTH_NO_ORDERS_NO_CAPITAL"),
    ]
    card_html = "".join(f"<div class='card'><b>{escape(k)}</b><span>{escape(v)}</span></div>" for k, v in cards)
    html = f"""<!doctype html>
<html lang='pt-BR'>
<head>
<meta charset='utf-8'>
<title>QRDS Interactive Research Dashboard</title>
<style>
body {{ font-family: Arial, sans-serif; background:#0f172a; color:#e5e7eb; margin:0; padding:24px; }}
h1 {{ margin-top:0; }}
.grid {{ display:grid; grid-template-columns: repeat(auto-fit,minmax(220px,1fr)); gap:12px; }}
.card {{ background:#111827; border:1px solid #334155; border-radius:12px; padding:16px; }}
.card b {{ display:block; color:#93c5fd; margin-bottom:8px; }}
.card span {{ font-size:14px; word-break:break-word; }}
pre {{ background:#020617; border:1px solid #334155; padding:16px; border-radius:12px; overflow:auto; }}
.ok {{ color:#86efac; }} .warn {{ color:#facc15; }}
</style>
</head>
<body>
<h1>QRDS/QOS - Interactive Research Dashboard</h1>
<p class='ok'>Research-only dashboard. No API key, no real account, no orders, no real capital.</p>
<div class='grid'>{card_html}</div>
<h2>Payload</h2>
<pre>{escape(json.dumps(p, indent=2, ensure_ascii=False))}</pre>
</body></html>"""
    html_path = out / "index.html"
    html_path.write_text(html, encoding="utf-8")
    return str(html_path)
