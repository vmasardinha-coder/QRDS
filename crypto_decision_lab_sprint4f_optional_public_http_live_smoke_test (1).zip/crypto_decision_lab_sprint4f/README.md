# Sprint 4F - Optional Public HTTP Live Smoke Test Safety Gate

Default execution is fixture/replay. No real network call is executed unless explicitly enabled.

Safety policy: PUBLIC_ONLY_NO_AUTH_OPT_IN_SMOKE_TEST_FIXTURE_DEFAULT.

No API key, no account connection, no websocket, no orders, no real capital.
