import os
from crypto_decision_lab.sprint4f import (
    SUPPORTED_EXCHANGES,
    FIXTURE_CANDLES,
    normalize_fixture,
    validate_timestamp_order,
    validate_ohlcv,
    env_requests_live_http,
    detect_forbidden_auth_env,
    build_live_smoke_report,
    build_dirty_live_smoke_report,
    export_report,
)


def test_supported_exchanges():
    assert SUPPORTED_EXCHANGES == ["binance", "bybit", "okx"]


def test_fixture_has_all_exchanges():
    assert set(FIXTURE_CANDLES) == set(SUPPORTED_EXCHANGES)


def test_fixture_lengths_are_equal():
    assert {k: len(v) for k, v in FIXTURE_CANDLES.items()} == {"binance": 5, "bybit": 5, "okx": 5}


def test_normalize_fixture_returns_candles():
    candles = normalize_fixture("binance", FIXTURE_CANDLES["binance"])
    assert len(candles) == 5
    assert candles[0].exchange == "binance"


def test_timestamp_order_valid():
    candles = normalize_fixture("bybit", FIXTURE_CANDLES["bybit"])
    assert validate_timestamp_order(candles)


def test_ohlcv_valid():
    candles = normalize_fixture("okx", FIXTURE_CANDLES["okx"])
    assert validate_ohlcv(candles)


def test_env_opt_in_false_by_default():
    assert env_requests_live_http({}) is False


def test_env_opt_in_true():
    assert env_requests_live_http({"QRDS_ALLOW_PUBLIC_HTTP_LIVE": "1"}) is True


def test_forbidden_auth_env_detection():
    assert detect_forbidden_auth_env({"BINANCE_API_KEY": "x"}) == ["BINANCE_API_KEY"]


def test_report_schema():
    assert build_live_smoke_report().schema == "qrds.public_http_live_smoke_test_report.v1"


def test_report_status_pass():
    r = build_live_smoke_report()
    assert r.live_smoke_status == "PASS"
    assert r.connector_status == "PASS"


def test_report_model_not_blocked():
    assert build_live_smoke_report().model_blocked is False


def test_report_public_allowed():
    assert build_live_smoke_report().public_http_live_data_allowed is True


def test_report_default_no_opt_in():
    assert build_live_smoke_report().live_http_opt_in_enabled is False


def test_report_default_no_live_execution():
    assert build_live_smoke_report().live_smoke_executed is False


def test_report_fixture_used():
    assert build_live_smoke_report().fixture_replay_used is True


def test_report_no_network():
    assert build_live_smoke_report().network_calls_executed is False


def test_report_no_auth():
    r = build_live_smoke_report()
    assert r.authenticated_connection_used is False
    assert r.api_key_required is False
    assert r.account_connection_required is False


def test_report_no_websocket():
    assert build_live_smoke_report().websocket_used is False


def test_report_no_capital():
    assert build_live_smoke_report().real_capital_used is False


def test_report_no_exchange_connected():
    assert build_live_smoke_report().exchange_connected is False


def test_report_no_orders():
    assert build_live_smoke_report().orders_generated is False


def test_report_contracts_valid():
    r = build_live_smoke_report()
    assert r.endpoint_specs_valid
    assert r.adapter_contract_valid
    assert r.timestamp_order_valid
    assert r.ohlcv_contract_valid
    assert r.response_shape_valid
    assert r.normalization_consistent


def test_report_supported_exchanges():
    assert build_live_smoke_report().supported_exchanges == ["binance", "bybit", "okx"]


def test_report_normalized_counts():
    assert build_live_smoke_report().normalized_candles_per_exchange == {"binance": 5, "bybit": 5, "okx": 5}


def test_report_safety_policy():
    assert build_live_smoke_report().safety_policy == "PUBLIC_ONLY_NO_AUTH_OPT_IN_SMOKE_TEST_FIXTURE_DEFAULT"


def test_report_next_gate():
    assert build_live_smoke_report().next_required_gate == "PUBLIC_HTTP_LIVE_SMOKE_MANUAL_APPROVAL_REQUIRED"


def test_report_issues_none():
    assert build_live_smoke_report().issues == []


def test_report_action():
    assert build_live_smoke_report().action == "NO_LIVE_HTTP_SMOKE_FIXTURE_DEFAULT"


def test_opt_in_report_requires_manual_approval():
    r = build_live_smoke_report({"QRDS_ALLOW_PUBLIC_HTTP_LIVE": "1"})
    assert r.live_http_opt_in_enabled is True
    assert r.live_smoke_executed is False
    assert r.action == "NO_LIVE_HTTP_SMOKE_MANUAL_APPROVAL_REQUIRED"


def test_opt_in_report_records_issue():
    r = build_live_smoke_report({"QRDS_ALLOW_PUBLIC_HTTP_LIVE": "1"})
    assert "live_http_opt_in_detected_but_not_executed_in_default_gate" in r.issues


def test_forbidden_auth_blocks():
    r = build_live_smoke_report({"OKX_SECRET": "x"})
    assert r.live_smoke_status == "BLOCKED"
    assert r.model_blocked is True


def test_dirty_status_blocked():
    assert build_dirty_live_smoke_report().live_smoke_status == "BLOCKED"


def test_dirty_model_blocked():
    assert build_dirty_live_smoke_report().model_blocked is True


def test_dirty_network_executed():
    assert build_dirty_live_smoke_report().network_calls_executed is True


def test_dirty_auth_used():
    d = build_dirty_live_smoke_report()
    assert d.authenticated_connection_used is True
    assert d.api_key_required is True
    assert d.account_connection_required is True


def test_dirty_websocket_used():
    assert build_dirty_live_smoke_report().websocket_used is True


def test_dirty_capital_used():
    assert build_dirty_live_smoke_report().real_capital_used is True


def test_dirty_exchange_connected():
    assert build_dirty_live_smoke_report().exchange_connected is True


def test_dirty_orders_generated():
    assert build_dirty_live_smoke_report().orders_generated is True


def test_dirty_contract_invalid():
    d = build_dirty_live_smoke_report()
    assert d.adapter_contract_valid is False
    assert d.timestamp_order_valid is False
    assert d.ohlcv_contract_valid is False


def test_dirty_action():
    assert build_dirty_live_smoke_report().action == "NO_PUBLIC_LIVE_SMOKE_BLOCKED"


def test_export_report(tmp_path):
    paths = export_report(build_live_smoke_report(), tmp_path)
    assert set(paths) == {"json", "txt"}


def test_export_json_exists(tmp_path):
    paths = export_report(build_live_smoke_report(), tmp_path)
    assert (tmp_path / "public_http_live_smoke_test_report.json").exists()
    assert paths["json"].endswith(".json")


def test_export_txt_exists(tmp_path):
    paths = export_report(build_live_smoke_report(), tmp_path)
    assert (tmp_path / "public_http_live_smoke_test_report.txt").exists()
    assert paths["txt"].endswith(".txt")


def test_export_json_content(tmp_path):
    export_report(build_live_smoke_report(), tmp_path)
    text = (tmp_path / "public_http_live_smoke_test_report.json").read_text()
    assert "qrds.public_http_live_smoke_test_report.v1" in text


def test_export_txt_content(tmp_path):
    export_report(build_live_smoke_report(), tmp_path)
    text = (tmp_path / "public_http_live_smoke_test_report.txt").read_text()
    assert "live_smoke_status: PASS" in text


def test_bad_timestamp_order_detection():
    candles = normalize_fixture("binance", list(reversed(FIXTURE_CANDLES["binance"])))
    assert validate_timestamp_order(candles) is False
