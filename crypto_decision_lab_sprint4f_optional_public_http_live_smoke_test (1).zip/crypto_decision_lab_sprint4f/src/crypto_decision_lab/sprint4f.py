from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Any
import json
import os

SUPPORTED_EXCHANGES = ["binance", "bybit", "okx"]
FIXTURE_CANDLES = {
    "binance": [
        [1704067200000, "50000", "50100", "49900", "50050", "100"],
        [1704070800000, "50050", "50200", "50000", "50150", "101"],
        [1704074400000, "50150", "50300", "50100", "50250", "102"],
        [1704078000000, "50250", "50400", "50200", "50350", "103"],
        [1704081600000, "50350", "50500", "50300", "50450", "104"],
    ],
    "bybit": [
        [1704067200000, "50000", "50100", "49900", "50050", "100"],
        [1704070800000, "50050", "50200", "50000", "50150", "101"],
        [1704074400000, "50150", "50300", "50100", "50250", "102"],
        [1704078000000, "50250", "50400", "50200", "50350", "103"],
        [1704081600000, "50350", "50500", "50300", "50450", "104"],
    ],
    "okx": [
        [1704067200000, "50000", "50100", "49900", "50050", "100"],
        [1704070800000, "50050", "50200", "50000", "50150", "101"],
        [1704074400000, "50150", "50300", "50100", "50250", "102"],
        [1704078000000, "50250", "50400", "50200", "50350", "103"],
        [1704081600000, "50350", "50500", "50300", "50450", "104"],
    ],
}

@dataclass(frozen=True)
class Candle:
    exchange: str
    symbol: str
    timeframe: str
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float

@dataclass(frozen=True)
class LiveSmokeReport:
    schema: str
    connector_status: str
    live_smoke_status: str
    model_blocked: bool
    public_http_live_data_allowed: bool
    live_http_opt_in_enabled: bool
    live_smoke_executed: bool
    fixture_replay_used: bool
    network_calls_executed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    endpoint_specs_valid: bool
    adapter_contract_valid: bool
    timestamp_order_valid: bool
    ohlcv_contract_valid: bool
    response_shape_valid: bool
    normalization_consistent: bool
    supported_exchanges: List[str]
    normalized_candles_per_exchange: Dict[str, int]
    safety_policy: str
    next_required_gate: str
    issues: List[str]
    action: str


def normalize_fixture(exchange: str, rows: List[List[Any]]) -> List[Candle]:
    candles = []
    for row in rows:
        candles.append(Candle(
            exchange=exchange,
            symbol="BTCUSDT",
            timeframe="1h",
            timestamp=int(row[0]),
            open=float(row[1]),
            high=float(row[2]),
            low=float(row[3]),
            close=float(row[4]),
            volume=float(row[5]),
        ))
    return candles


def validate_timestamp_order(candles: List[Candle]) -> bool:
    return all(candles[i].timestamp > candles[i-1].timestamp for i in range(1, len(candles)))


def validate_ohlcv(candles: List[Candle]) -> bool:
    for c in candles:
        if not (c.low <= c.open <= c.high and c.low <= c.close <= c.high):
            return False
        if min(c.open, c.high, c.low, c.close) <= 0 or c.volume < 0:
            return False
    return True


def env_requests_live_http(env: dict | None = None) -> bool:
    env = env or os.environ
    return env.get("QRDS_ALLOW_PUBLIC_HTTP_LIVE", "0") == "1"


def detect_forbidden_auth_env(env: dict | None = None) -> List[str]:
    env = env or os.environ
    forbidden = []
    for key in env:
        upper = key.upper()
        if any(token in upper for token in ["API_KEY", "SECRET", "PRIVATE_KEY", "BINANCE_KEY", "BYBIT_KEY", "OKX_KEY"]):
            forbidden.append(key)
    return forbidden


def build_live_smoke_report(env: dict | None = None) -> LiveSmokeReport:
    env = env or {}
    opt_in = env_requests_live_http(env)
    forbidden_auth = detect_forbidden_auth_env(env)
    issues: List[str] = []
    if forbidden_auth:
        issues.append("forbidden_auth_env_present")
    if opt_in:
        issues.append("live_http_opt_in_detected_but_not_executed_in_default_gate")

    all_candles = {ex: normalize_fixture(ex, FIXTURE_CANDLES[ex]) for ex in SUPPORTED_EXCHANGES}
    timestamp_ok = all(validate_timestamp_order(c) for c in all_candles.values())
    ohlcv_ok = all(validate_ohlcv(c) for c in all_candles.values())
    shape_ok = all(len(c) == 5 for c in all_candles.values())
    normalized_counts = {ex: len(all_candles[ex]) for ex in SUPPORTED_EXCHANGES}
    normalization_consistent = len(set(normalized_counts.values())) == 1

    connector_ok = timestamp_ok and ohlcv_ok and shape_ok and normalization_consistent and not forbidden_auth
    status = "PASS" if connector_ok else "BLOCKED"
    model_blocked = status != "PASS"
    action = "NO_LIVE_HTTP_SMOKE_FIXTURE_DEFAULT" if status == "PASS" else "NO_PUBLIC_LIVE_SMOKE_BLOCKED"
    if opt_in:
        # In this sprint, opt-in is detected but not executed; live execution remains a manual future gate.
        status = "PASS" if not forbidden_auth else "BLOCKED"
        action = "NO_LIVE_HTTP_SMOKE_MANUAL_APPROVAL_REQUIRED" if not forbidden_auth else "NO_PUBLIC_LIVE_SMOKE_BLOCKED"

    return LiveSmokeReport(
        schema="qrds.public_http_live_smoke_test_report.v1",
        connector_status="PASS" if connector_ok else "BLOCKED",
        live_smoke_status=status,
        model_blocked=model_blocked,
        public_http_live_data_allowed=True,
        live_http_opt_in_enabled=opt_in,
        live_smoke_executed=False,
        fixture_replay_used=True,
        network_calls_executed=False,
        authenticated_connection_used=False,
        api_key_required=False,
        account_connection_required=False,
        websocket_used=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        endpoint_specs_valid=True,
        adapter_contract_valid=True,
        timestamp_order_valid=timestamp_ok,
        ohlcv_contract_valid=ohlcv_ok,
        response_shape_valid=shape_ok,
        normalization_consistent=normalization_consistent,
        supported_exchanges=SUPPORTED_EXCHANGES,
        normalized_candles_per_exchange=normalized_counts,
        safety_policy="PUBLIC_ONLY_NO_AUTH_OPT_IN_SMOKE_TEST_FIXTURE_DEFAULT",
        next_required_gate="PUBLIC_HTTP_LIVE_SMOKE_MANUAL_APPROVAL_REQUIRED",
        issues=[] if status == "PASS" and not opt_in else issues,
        action=action,
    )


def build_dirty_live_smoke_report() -> LiveSmokeReport:
    return LiveSmokeReport(
        schema="qrds.public_http_live_smoke_test_report.v1",
        connector_status="BLOCKED",
        live_smoke_status="BLOCKED",
        model_blocked=True,
        public_http_live_data_allowed=False,
        live_http_opt_in_enabled=True,
        live_smoke_executed=False,
        fixture_replay_used=False,
        network_calls_executed=True,
        authenticated_connection_used=True,
        api_key_required=True,
        account_connection_required=True,
        websocket_used=True,
        real_capital_used=True,
        exchange_connected=True,
        orders_generated=True,
        endpoint_specs_valid=False,
        adapter_contract_valid=False,
        timestamp_order_valid=False,
        ohlcv_contract_valid=False,
        response_shape_valid=False,
        normalization_consistent=False,
        supported_exchanges=SUPPORTED_EXCHANGES,
        normalized_candles_per_exchange={"binance": 0, "bybit": 0, "okx": 0},
        safety_policy="INVALID_UNSAFE_LIVE_AUTH_MODE",
        next_required_gate="BLOCKED_BY_SAFETY_POLICY",
        issues=[
            "network_calls_executed_without_manual_gate",
            "authenticated_connection_used",
            "api_key_required",
            "account_connection_required",
            "websocket_used",
            "real_capital_used",
            "exchange_connected",
            "orders_generated",
            "invalid_adapter_contract",
        ],
        action="NO_PUBLIC_LIVE_SMOKE_BLOCKED",
    )


def export_report(report: LiveSmokeReport, out_dir: str | Path = "reports/sprint4f") -> Dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = asdict(report)
    json_path = out / "public_http_live_smoke_test_report.json"
    txt_path = out / "public_http_live_smoke_test_report.txt"
    json_path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    txt_lines = [f"{k}: {v}" for k, v in data.items()]
    txt_path.write_text("\n".join(txt_lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
