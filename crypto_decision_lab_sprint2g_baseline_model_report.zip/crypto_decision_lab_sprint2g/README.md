# QRDS Sprint 2G - Baseline Model Report Offline

Objetivo: criar um baseline estatistico simples sobre o dataset integrado e os splits temporais.

Isto **nao** e estrategia de trading, nao e sinal Long/Short, nao e backtest e nao e prova de edge. E apenas uma referencia minima para validar o encadeamento de pesquisa:

integrated dataset -> temporal validation -> baseline evaluation -> report.

Inclui:
- majority baseline por split
- heuristic baseline simples
- accuracy por split
- confusion matrix
- edge vs majority baseline
- `decision_allowed = False`
- export JSON/TXT

Proibido nesta sprint:
- Binance real conectada
- API key real
- WebSocket autenticado
- ordens
- capital real
- alavancagem
- sinal Long/Short
- backtest

Comando local:

```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_baseline_model_report.py
```
