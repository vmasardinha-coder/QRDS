from __future__ import annotations

from crypto_decision_lab.temporal.splits import make_walk_forward_splits, validate_horizon_embargo, validate_split_no_overlap

REQUIRED_GATE_KEYS = ["dql_status", "feature_quality_status", "regime_status", "target_quality_status", "integrated_dataset_status"]


def gates_are_passed(payload: dict) -> bool:
    return all(payload.get(key) == "PASS" for key in REQUIRED_GATE_KEYS) and payload.get("model_blocked") is False


def generate_temporal_validation_report(payload: dict) -> dict:
    if not gates_are_passed(payload):
        failed = [f"{key}={payload.get(key)}" for key in REQUIRED_GATE_KEYS if payload.get(key) != "PASS"]
        return {
            "schema": "qrds.temporal_validation_report.v1",
            "integrated_dataset_status": payload.get("integrated_dataset_status"),
            "temporal_validation_status": "BLOCKED",
            "model_blocked": True,
            "quality_score": 0.0,
            "split_count": 0,
            "embargo_candles": None,
            "splits": [],
            "issues": ["temporal_validation_blocked_by_gate:" + ",".join(failed)],
        }
    rows = payload.get("rows", [])
    splits = make_walk_forward_splits(rows)
    issues = []
    for split in splits:
        if not validate_split_no_overlap(split):
            issues.append(f"split_{split['split_id']}_overlap")
        if not validate_horizon_embargo(rows, split):
            issues.append(f"split_{split['split_id']}_horizon_leakage")
    if len(splits) < 3:
        issues.append("insufficient_walk_forward_splits")
    score = 1.0 if not issues else round(max(0.0, 1.0 - len(issues) / 4), 4)
    status = "PASS" if score >= 0.95 and not issues else "BLOCKED"
    return {
        "schema": "qrds.temporal_validation_report.v1",
        "integrated_dataset_status": payload.get("integrated_dataset_status"),
        "temporal_validation_status": status,
        "model_blocked": status != "PASS",
        "quality_score": score,
        "split_count": len(splits),
        "embargo_candles": splits[0]["embargo_candles"] if splits else None,
        "splits": splits,
        "issues": issues,
    }
