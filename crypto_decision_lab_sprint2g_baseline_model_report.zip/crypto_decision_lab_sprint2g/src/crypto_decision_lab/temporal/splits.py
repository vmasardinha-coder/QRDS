from __future__ import annotations


def unique_candle_indices(rows: list[dict]) -> list[int]:
    return sorted({int(row["candle_index"]) for row in rows})


def max_horizon(rows: list[dict]) -> int:
    if not rows:
        return 0
    return max(int(row["horizon"]) for row in rows)


def make_walk_forward_splits(rows: list[dict], n_splits: int = 3, initial_train_candles: int = 24, validation_candles: int = 6, step_candles: int = 6, embargo_candles: int | None = None) -> list[dict]:
    indices = unique_candle_indices(rows)
    if not indices:
        return []
    max_idx = max(indices)
    embargo = max_horizon(rows) if embargo_candles is None else embargo_candles
    splits = []
    for split_id in range(n_splits):
        train_start = min(indices)
        train_end = initial_train_candles - 1 + split_id * step_candles
        embargo_start = train_end + 1
        embargo_end = train_end + embargo
        validation_start = embargo_end + 1
        validation_end = validation_start + validation_candles - 1
        if validation_end > max_idx:
            break
        splits.append({
            "split_id": split_id,
            "train_start": train_start,
            "train_end": train_end,
            "embargo_start": embargo_start,
            "embargo_end": embargo_end,
            "validation_start": validation_start,
            "validation_end": validation_end,
            "embargo_candles": embargo,
            "train_rows": len([r for r in rows if train_start <= int(r["candle_index"]) <= train_end]),
            "validation_rows": len([r for r in rows if validation_start <= int(r["candle_index"]) <= validation_end]),
        })
    return splits


def validate_split_no_overlap(split: dict) -> bool:
    return split["train_end"] < split["embargo_start"] <= split["embargo_end"] < split["validation_start"] <= split["validation_end"]


def validate_horizon_embargo(rows: list[dict], split: dict) -> bool:
    train_rows = [row for row in rows if split["train_start"] <= int(row["candle_index"]) <= split["train_end"]]
    if not train_rows:
        return False
    max_future_index = max(int(row["future_index"]) for row in train_rows)
    return max_future_index < int(split["validation_start"])
