from __future__ import annotations

from collections import Counter, defaultdict

VALID_LABELS = ["up", "down", "flat"]


def baseline_gates_are_passed(integrated_payload: dict, temporal_report: dict) -> bool:
    return (
        integrated_payload.get("integrated_dataset_status") == "PASS"
        and integrated_payload.get("model_blocked") is False
        and temporal_report.get("temporal_validation_status") == "PASS"
        and temporal_report.get("model_blocked") is False
    )


def rows_for_range(rows: list[dict], start: int, end: int, only_valid_targets: bool = True) -> list[dict]:
    selected = [row for row in rows if start <= int(row["candle_index"]) <= end]
    if only_valid_targets:
        selected = [row for row in selected if row.get("target_valid") is True and row.get("target_label") in VALID_LABELS]
    return selected


def majority_label(rows: list[dict]) -> str:
    valid = [row.get("target_label") for row in rows if row.get("target_label") in VALID_LABELS]
    if not valid:
        return "flat"
    return Counter(valid).most_common(1)[0][0]


def heuristic_predict(row: dict) -> str:
    simple = row.get("simple_return_1") or 0.0
    rolling = row.get("rolling_return_mean_3") or 0.0
    score = 0.70 * float(simple) + 0.30 * float(rolling)
    if score > 0.00008:
        return "up"
    if score < -0.00008:
        return "down"
    return "flat"


def confusion_matrix(actuals: list[str], predictions: list[str]) -> dict:
    matrix = {a: {p: 0 for p in VALID_LABELS} for a in VALID_LABELS}
    for actual, pred in zip(actuals, predictions):
        if actual in VALID_LABELS and pred in VALID_LABELS:
            matrix[actual][pred] += 1
    return matrix


def accuracy(actuals: list[str], predictions: list[str]) -> float:
    if not actuals:
        return 0.0
    return round(sum(a == p for a, p in zip(actuals, predictions)) / len(actuals), 4)


def label_distribution(rows: list[dict]) -> dict:
    counter = Counter(row.get("target_label") for row in rows)
    return {key: int(counter.get(key, 0)) for key in ["up", "down", "flat", "unknown"]}


def evaluate_split(rows: list[dict], split: dict) -> dict:
    train_rows = rows_for_range(rows, split["train_start"], split["train_end"])
    validation_rows = rows_for_range(rows, split["validation_start"], split["validation_end"])
    majority = majority_label(train_rows)
    actuals = [row["target_label"] for row in validation_rows]
    model_predictions = [heuristic_predict(row) for row in validation_rows]
    majority_predictions = [majority for _ in validation_rows]
    return {
        "split_id": split["split_id"],
        "train_rows": len(train_rows),
        "validation_rows": len(validation_rows),
        "majority_label": majority,
        "validation_distribution": label_distribution(validation_rows),
        "model_accuracy": accuracy(actuals, model_predictions),
        "majority_accuracy": accuracy(actuals, majority_predictions),
        "confusion_matrix": confusion_matrix(actuals, model_predictions),
    }


def generate_baseline_model_report(integrated_payload: dict, temporal_report: dict) -> dict:
    if not baseline_gates_are_passed(integrated_payload, temporal_report):
        return {
            "schema": "qrds.baseline_model_report.v1",
            "integrated_status": integrated_payload.get("integrated_dataset_status"),
            "temporal_status": temporal_report.get("temporal_validation_status"),
            "model_status": "BLOCKED",
            "model_blocked": True,
            "decision_allowed": False,
            "issues": ["baseline_model_blocked_by_gate"],
            "split_count": 0,
            "horizons": integrated_payload.get("horizons", []),
            "validation_rows": 0,
            "prediction_coverage": 0.0,
            "model_accuracy": 0.0,
            "majority_accuracy": 0.0,
            "edge_vs_majority": 0.0,
            "edge_status": "NOT_EVALUATED",
            "splits": [],
        }

    rows = integrated_payload.get("rows", [])
    split_reports = [evaluate_split(rows, split) for split in temporal_report.get("splits", [])]
    validation_rows = sum(item["validation_rows"] for item in split_reports)
    weighted_model = sum(item["model_accuracy"] * item["validation_rows"] for item in split_reports)
    weighted_majority = sum(item["majority_accuracy"] * item["validation_rows"] for item in split_reports)
    model_acc = round(weighted_model / validation_rows, 4) if validation_rows else 0.0
    maj_acc = round(weighted_majority / validation_rows, 4) if validation_rows else 0.0
    edge = round(model_acc - maj_acc, 4)
    issues = []
    if validation_rows < 30:
        issues.append("low_validation_rows")
    status = "PASS" if validation_rows >= 30 and len(split_reports) >= 3 else "BLOCKED"
    edge_status = "RESEARCH_BASELINE_ONLY"
    return {
        "schema": "qrds.baseline_model_report.v1",
        "integrated_status": integrated_payload.get("integrated_dataset_status"),
        "temporal_status": temporal_report.get("temporal_validation_status"),
        "model_status": status,
        "model_blocked": status != "PASS",
        "decision_allowed": False,
        "issues": issues,
        "split_count": len(split_reports),
        "horizons": integrated_payload.get("horizons", []),
        "validation_rows": validation_rows,
        "prediction_coverage": 1.0 if validation_rows else 0.0,
        "model_accuracy": model_acc,
        "majority_accuracy": maj_acc,
        "edge_vs_majority": edge,
        "edge_status": edge_status,
        "splits": split_reports,
    }
