from __future__ import annotations

import json
from pathlib import Path


def export_json(payload: dict, path: str | Path) -> str:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return str(path)


def export_txt(report: dict, path: str | Path) -> str:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "QRDS Sprint 2G - Baseline Model Report",
        f"Schema: {report.get('schema')}",
        f"Integrated status: {report.get('integrated_status')}",
        f"Temporal status: {report.get('temporal_status')}",
        f"Model status: {report.get('model_status')}",
        f"Model blocked: {report.get('model_blocked')}",
        f"Decision allowed: {report.get('decision_allowed')}",
        f"Split count: {report.get('split_count')}",
        f"Validation rows: {report.get('validation_rows')}",
        f"Prediction coverage: {report.get('prediction_coverage')}",
        f"Model accuracy: {report.get('model_accuracy')}",
        f"Majority accuracy: {report.get('majority_accuracy')}",
        f"Edge vs majority: {report.get('edge_vs_majority')}",
        f"Edge status: {report.get('edge_status')}",
        f"Issues: {report.get('issues') if report.get('issues') else 'none'}",
    ]
    for split in report.get("splits", []):
        lines.append(
            f"Split {split['split_id']}: train_rows={split['train_rows']} validation_rows={split['validation_rows']} "
            f"model_accuracy={split['model_accuracy']} majority_accuracy={split['majority_accuracy']} majority_label={split['majority_label']}"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(path)
