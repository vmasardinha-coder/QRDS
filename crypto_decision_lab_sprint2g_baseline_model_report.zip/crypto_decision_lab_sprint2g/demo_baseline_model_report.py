from crypto_decision_lab.baseline.model import generate_baseline_model_report
from crypto_decision_lab.io.exporters import export_json, export_txt
from crypto_decision_lab.research.synthetic import generate_dirty_integrated_dataset, generate_integrated_research_dataset
from crypto_decision_lab.temporal.report import generate_temporal_validation_report

payload = generate_integrated_research_dataset()
temporal_report = generate_temporal_validation_report(payload)
baseline_report = generate_baseline_model_report(payload, temporal_report)

dirty_payload = generate_dirty_integrated_dataset()
dirty_temporal = generate_temporal_validation_report(dirty_payload)
dirty_baseline = generate_baseline_model_report(dirty_payload, dirty_temporal)

json_path = export_json(baseline_report, "reports/sprint2g/baseline_model_report.json")
txt_path = export_txt(baseline_report, "reports/sprint2g/baseline_model_report.txt")

print("=== Sprint 2G Baseline Model Report Offline ===")
print(f"Integrated status: {payload['integrated_dataset_status']}")
print(f"Temporal status: {temporal_report['temporal_validation_status']}")
print(f"Baseline schema: {baseline_report['schema']}")
print(f"Model status: {baseline_report['model_status']}")
print(f"Model blocked: {baseline_report['model_blocked']}")
print(f"Decision allowed: {baseline_report['decision_allowed']}")
print(f"Splits: {baseline_report['split_count']}")
print(f"Horizons: {baseline_report['horizons']}")
print(f"Validation rows: {baseline_report['validation_rows']}")
print(f"Prediction coverage: {baseline_report['prediction_coverage']:.4f}")
print(f"Model accuracy: {baseline_report['model_accuracy']:.4f}")
print(f"Majority baseline accuracy: {baseline_report['majority_accuracy']:.4f}")
print(f"Edge vs majority: {baseline_report['edge_vs_majority']:.4f}")
print(f"Edge status: {baseline_report['edge_status']}")
print(f"Issues: {baseline_report['issues'] if baseline_report['issues'] else 'none'}")
print(f"Dirty integrated status: {dirty_payload['integrated_dataset_status']}")
print(f"Dirty baseline status: {dirty_baseline['model_status']}")
print(f"Generated files: {{'json': '{json_path}', 'txt': '{txt_path}'}}")
