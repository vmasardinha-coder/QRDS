from pathlib import Path
import json

from crypto_decision_lab.baseline.model import (
    accuracy,
    baseline_gates_are_passed,
    confusion_matrix,
    evaluate_split,
    generate_baseline_model_report,
    heuristic_predict,
    label_distribution,
    majority_label,
    rows_for_range,
)
from crypto_decision_lab.io.exporters import export_json, export_txt
from crypto_decision_lab.research.synthetic import generate_dirty_integrated_dataset, generate_integrated_research_dataset
from crypto_decision_lab.temporal.report import generate_temporal_validation_report
from crypto_decision_lab.temporal.splits import make_walk_forward_splits


def test_01_payload_schema():
    assert generate_integrated_research_dataset()["schema"] == "qrds.integrated_research_dataset.v1"


def test_02_payload_rows():
    assert generate_integrated_research_dataset()["row_count"] == 144


def test_03_label_counts_include_all_classes():
    counts = generate_integrated_research_dataset()["label_counts"]
    assert counts["up"] > 0 and counts["down"] > 0 and counts["flat"] > 0 and counts["unknown"] > 0


def test_04_temporal_report_pass():
    payload = generate_integrated_research_dataset()
    report = generate_temporal_validation_report(payload)
    assert report["temporal_validation_status"] == "PASS"


def test_05_baseline_gates_pass():
    payload = generate_integrated_research_dataset()
    temporal = generate_temporal_validation_report(payload)
    assert baseline_gates_are_passed(payload, temporal)


def test_06_baseline_gates_block_dirty():
    payload = generate_dirty_integrated_dataset()
    temporal = generate_temporal_validation_report(payload)
    assert not baseline_gates_are_passed(payload, temporal)


def test_07_splits_count():
    rows = generate_integrated_research_dataset()["rows"]
    assert len(make_walk_forward_splits(rows)) == 3


def test_08_rows_for_range_filters_unknowns():
    rows = generate_integrated_research_dataset()["rows"]
    selected = rows_for_range(rows, 42, 47)
    assert all(row["target_label"] != "unknown" for row in selected)


def test_09_majority_label_returns_valid_label():
    rows = generate_integrated_research_dataset()["rows"]
    assert majority_label(rows_for_range(rows, 0, 23)) in {"up", "down", "flat"}


def test_10_heuristic_predict_valid_label():
    row = generate_integrated_research_dataset()["rows"][12]
    assert heuristic_predict(row) in {"up", "down", "flat"}


def test_11_accuracy_perfect():
    assert accuracy(["up", "down"], ["up", "down"]) == 1.0


def test_12_accuracy_partial():
    assert accuracy(["up", "down"], ["up", "up"]) == 0.5


def test_13_confusion_matrix_counts():
    matrix = confusion_matrix(["up", "down", "flat"], ["up", "up", "flat"])
    assert matrix["up"]["up"] == 1
    assert matrix["down"]["up"] == 1
    assert matrix["flat"]["flat"] == 1


def test_14_label_distribution_keys():
    dist = label_distribution(generate_integrated_research_dataset()["rows"])
    assert set(dist) == {"up", "down", "flat", "unknown"}


def test_15_evaluate_split_shape():
    rows = generate_integrated_research_dataset()["rows"]
    split = make_walk_forward_splits(rows)[0]
    result = evaluate_split(rows, split)
    assert result["split_id"] == 0
    assert result["validation_rows"] > 0


def test_16_evaluate_split_metrics_range():
    rows = generate_integrated_research_dataset()["rows"]
    split = make_walk_forward_splits(rows)[0]
    result = evaluate_split(rows, split)
    assert 0.0 <= result["model_accuracy"] <= 1.0
    assert 0.0 <= result["majority_accuracy"] <= 1.0


def test_17_report_schema():
    payload = generate_integrated_research_dataset()
    temporal = generate_temporal_validation_report(payload)
    report = generate_baseline_model_report(payload, temporal)
    assert report["schema"] == "qrds.baseline_model_report.v1"


def test_18_report_pass():
    payload = generate_integrated_research_dataset()
    temporal = generate_temporal_validation_report(payload)
    report = generate_baseline_model_report(payload, temporal)
    assert report["model_status"] == "PASS"


def test_19_decision_not_allowed():
    payload = generate_integrated_research_dataset()
    temporal = generate_temporal_validation_report(payload)
    report = generate_baseline_model_report(payload, temporal)
    assert report["decision_allowed"] is False


def test_20_report_validation_rows():
    payload = generate_integrated_research_dataset()
    temporal = generate_temporal_validation_report(payload)
    report = generate_baseline_model_report(payload, temporal)
    assert report["validation_rows"] >= 30


def test_21_report_prediction_coverage():
    payload = generate_integrated_research_dataset()
    temporal = generate_temporal_validation_report(payload)
    report = generate_baseline_model_report(payload, temporal)
    assert report["prediction_coverage"] == 1.0


def test_22_report_accuracy_range():
    payload = generate_integrated_research_dataset()
    temporal = generate_temporal_validation_report(payload)
    report = generate_baseline_model_report(payload, temporal)
    assert 0.0 <= report["model_accuracy"] <= 1.0


def test_23_dirty_report_blocked():
    payload = generate_dirty_integrated_dataset()
    temporal = generate_temporal_validation_report(payload)
    report = generate_baseline_model_report(payload, temporal)
    assert report["model_status"] == "BLOCKED"
    assert report["model_blocked"] is True


def test_24_edge_status_baseline_only():
    payload = generate_integrated_research_dataset()
    temporal = generate_temporal_validation_report(payload)
    report = generate_baseline_model_report(payload, temporal)
    assert report["edge_status"] == "RESEARCH_BASELINE_ONLY"


def test_25_export_json(tmp_path):
    payload = generate_integrated_research_dataset()
    temporal = generate_temporal_validation_report(payload)
    report = generate_baseline_model_report(payload, temporal)
    path = export_json(report, tmp_path / "baseline.json")
    assert json.loads(Path(path).read_text())["schema"] == "qrds.baseline_model_report.v1"


def test_26_export_txt(tmp_path):
    payload = generate_integrated_research_dataset()
    temporal = generate_temporal_validation_report(payload)
    report = generate_baseline_model_report(payload, temporal)
    path = export_txt(report, tmp_path / "baseline.txt")
    text = Path(path).read_text()
    assert "Baseline Model Report" in text
    assert "Decision allowed: False" in text
