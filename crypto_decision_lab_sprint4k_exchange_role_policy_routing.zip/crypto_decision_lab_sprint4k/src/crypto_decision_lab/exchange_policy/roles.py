from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import json
from typing import Dict, List

SCHEMA = "qrds.exchange_role_policy_report.v1"
SAFETY_POLICY = "EXCHANGE_ROLE_POLICY_NO_AUTH_NO_ORDERS_NO_REAL_CAPITAL"

@dataclass(frozen=True)
class ExchangeRole:
    exchange: str
    role: str
    public_http_status: str
    real_base_candidate: bool
    real_base_active_now: bool
    simulation_allowed: bool
    api_key_allowed: bool
    account_connection_allowed: bool
    authenticated_websocket_allowed: bool
    orders_allowed: bool
    real_capital_allowed: bool
    notes: str

@dataclass(frozen=True)
class ExchangeRolePolicyReport:
    schema: str
    policy_status: str
    model_blocked: bool
    safety_policy: str
    real_base_target_exchanges: List[str]
    real_base_active_now: List[str]
    real_base_pending: List[str]
    simulation_exchange: str
    api_key_required: bool
    account_connection_required: bool
    authenticated_connection_used: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    roles: Dict[str, ExchangeRole]
    issues: List[str]
    action: str
    next_required_gate: str


def build_exchange_role_policy(
    *,
    binance_public_http_status: str = "PASS",
    okx_public_http_status: str = "PASS",
    bybit_public_http_status: str = "BLOCKED_BY_403",
) -> ExchangeRolePolicyReport:
    roles = {
        "binance": ExchangeRole(
            exchange="binance",
            role="SIMULATION_ONLY_PUBLIC_DATA_ALLOWED",
            public_http_status=binance_public_http_status,
            real_base_candidate=False,
            real_base_active_now=False,
            simulation_allowed=True,
            api_key_allowed=False,
            account_connection_allowed=False,
            authenticated_websocket_allowed=False,
            orders_allowed=False,
            real_capital_allowed=False,
            notes="Binance can be used for public/offline/simulation data only; real account/API remains out of scope.",
        ),
        "okx": ExchangeRole(
            exchange="okx",
            role="REAL_BASE_CANDIDATE_PUBLIC_HTTP_OK",
            public_http_status=okx_public_http_status,
            real_base_candidate=True,
            real_base_active_now=(okx_public_http_status == "PASS"),
            simulation_allowed=True,
            api_key_allowed=False,
            account_connection_allowed=False,
            authenticated_websocket_allowed=False,
            orders_allowed=False,
            real_capital_allowed=False,
            notes="OKX is active real-base candidate for future public-data pipeline, still without auth/trading.",
        ),
        "bybit": ExchangeRole(
            exchange="bybit",
            role="REAL_BASE_CANDIDATE_PENDING_403",
            public_http_status=bybit_public_http_status,
            real_base_candidate=True,
            real_base_active_now=(bybit_public_http_status == "PASS"),
            simulation_allowed=True,
            api_key_allowed=False,
            account_connection_allowed=False,
            authenticated_websocket_allowed=False,
            orders_allowed=False,
            real_capital_allowed=False,
            notes="Bybit remains strategic real-base candidate, but public HTTP is pending after 403 in Codespaces.",
        ),
    }
    issues: List[str] = []
    if bybit_public_http_status != "PASS":
        issues.append("bybit_public_http_blocked_by_403_pending")
    if okx_public_http_status != "PASS":
        issues.append("okx_public_http_not_available")
    if binance_public_http_status != "PASS":
        issues.append("binance_public_http_not_available_for_simulation")

    active = [ex for ex, r in roles.items() if r.real_base_active_now]
    pending = [ex for ex, r in roles.items() if r.real_base_candidate and not r.real_base_active_now]
    status = "PASS_WITH_PENDING_BYBIT" if active and "bybit" in pending else ("PASS" if active else "BLOCKED")
    blocked = not bool(active)
    action = "ROUTE_OKX_PUBLIC_DATA_AND_BINANCE_SIMULATION_KEEP_BYBIT_PENDING" if not blocked else "NO_EXCHANGE_ROUTING_BLOCKED"
    return ExchangeRolePolicyReport(
        schema=SCHEMA,
        policy_status=status,
        model_blocked=blocked,
        safety_policy=SAFETY_POLICY,
        real_base_target_exchanges=["okx", "bybit"],
        real_base_active_now=active,
        real_base_pending=pending,
        simulation_exchange="binance",
        api_key_required=False,
        account_connection_required=False,
        authenticated_connection_used=False,
        websocket_used=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        roles=roles,
        issues=issues,
        action=action,
        next_required_gate="PUBLIC_LIVE_DATA_PIPELINE_OKX_BINANCE_SIM_REQUIRED",
    )


def report_to_dict(report: ExchangeRolePolicyReport) -> dict:
    d = asdict(report)
    return d


def export_report(report: ExchangeRolePolicyReport, out_dir: str | Path = "reports/sprint4k") -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = report_to_dict(report)
    json_path = out / "exchange_role_policy_report.json"
    txt_path = out / "exchange_role_policy_report.txt"
    json_path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    lines = [
        "QRDS Sprint 4K Exchange Role Policy Report",
        f"schema: {report.schema}",
        f"policy_status: {report.policy_status}",
        f"model_blocked: {report.model_blocked}",
        f"simulation_exchange: {report.simulation_exchange}",
        f"real_base_target_exchanges: {report.real_base_target_exchanges}",
        f"real_base_active_now: {report.real_base_active_now}",
        f"real_base_pending: {report.real_base_pending}",
        f"action: {report.action}",
        f"next_required_gate: {report.next_required_gate}",
        f"issues: {report.issues}",
    ]
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
