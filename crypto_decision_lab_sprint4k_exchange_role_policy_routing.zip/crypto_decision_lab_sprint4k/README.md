# Crypto Decision Lab - Sprint 4K

Exchange Role Policy and Public Data Routing.

This sprint consolidates exchange roles after Bybit public HTTP returned 403 in Codespaces:

- Binance: simulation/public data only. Real account connection remains out of scope.
- OKX: active real-base candidate for future public-data pipeline.
- Bybit: real-base candidate, but pending public HTTP remediation because all tested endpoints returned 403.

No API keys, no real account, no authenticated WebSocket, no real orders and no real capital.
