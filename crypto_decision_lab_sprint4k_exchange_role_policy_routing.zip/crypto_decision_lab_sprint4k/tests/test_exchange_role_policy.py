import pytest
from crypto_decision_lab.exchange_policy.roles import build_exchange_role_policy, export_report, report_to_dict

@pytest.fixture()
def report():
    return build_exchange_role_policy()

def test_policy_status(report):
    assert report.policy_status == "PASS_WITH_PENDING_BYBIT"
    assert report.model_blocked is False
    assert report.action == "ROUTE_OKX_PUBLIC_DATA_AND_BINANCE_SIMULATION_KEEP_BYBIT_PENDING"

@pytest.mark.parametrize("exchange,role", [
    ("binance", "SIMULATION_ONLY_PUBLIC_DATA_ALLOWED"),
    ("okx", "REAL_BASE_CANDIDATE_PUBLIC_HTTP_OK"),
    ("bybit", "REAL_BASE_CANDIDATE_PENDING_403"),
])
def test_exchange_roles(report, exchange, role):
    assert report.roles[exchange].role == role

@pytest.mark.parametrize("flag", [
    "api_key_required",
    "account_connection_required",
    "authenticated_connection_used",
    "websocket_used",
    "real_capital_used",
    "exchange_connected",
    "orders_generated",
])
def test_global_safety_flags_false(report, flag):
    assert getattr(report, flag) is False

@pytest.mark.parametrize("exchange", ["binance", "okx", "bybit"])
def test_role_forbids_auth_and_orders(report, exchange):
    role = report.roles[exchange]
    assert role.api_key_allowed is False
    assert role.account_connection_allowed is False
    assert role.authenticated_websocket_allowed is False
    assert role.orders_allowed is False
    assert role.real_capital_allowed is False

@pytest.mark.parametrize("exchange,expected", [
    ("okx", True),
    ("bybit", False),
    ("binance", False),
])
def test_active_real_base(report, exchange, expected):
    assert report.roles[exchange].real_base_active_now is expected

@pytest.mark.parametrize("exchange,expected", [
    ("okx", True),
    ("bybit", True),
    ("binance", False),
])
def test_real_base_candidates(report, exchange, expected):
    assert report.roles[exchange].real_base_candidate is expected

@pytest.mark.parametrize("exchange", ["binance", "okx", "bybit"])
def test_simulation_allowed_is_safe(report, exchange):
    assert report.roles[exchange].simulation_allowed is True

@pytest.mark.parametrize("status,blocked,active,pending", [
    ("PASS", False, ["okx", "bybit"], []),
    ("BLOCKED_BY_403", False, ["okx"], ["bybit"]),
])
def test_bybit_status_routes(status, blocked, active, pending):
    r = build_exchange_role_policy(bybit_public_http_status=status)
    assert r.model_blocked is blocked
    assert r.real_base_active_now == active
    assert r.real_base_pending == pending

@pytest.mark.parametrize("status", ["BLOCKED", "TIMEOUT", "HTTP_403", "BLOCKED_BY_403"])
def test_bybit_non_pass_creates_issue(status):
    r = build_exchange_role_policy(bybit_public_http_status=status)
    assert "bybit_public_http_blocked_by_403_pending" in r.issues

@pytest.mark.parametrize("okx_status", ["BLOCKED", "TIMEOUT", "HTTP_500"])
def test_no_active_real_base_blocks_if_okx_down_and_bybit_pending(okx_status):
    r = build_exchange_role_policy(okx_public_http_status=okx_status, bybit_public_http_status="BLOCKED_BY_403")
    assert r.model_blocked is True
    assert r.policy_status == "BLOCKED"
    assert r.action == "NO_EXCHANGE_ROUTING_BLOCKED"

@pytest.mark.parametrize("field", [
    "schema", "policy_status", "model_blocked", "safety_policy", "real_base_target_exchanges", "real_base_active_now", "real_base_pending", "simulation_exchange", "roles", "issues", "action", "next_required_gate"
])
def test_report_dict_contains_required_fields(report, field):
    assert field in report_to_dict(report)

@pytest.mark.parametrize("field", ["json", "txt"])
def test_export_contains_files(tmp_path, report, field):
    files = export_report(report, tmp_path)
    assert field in files
    assert (tmp_path / files[field].split('/')[-1]).exists()

def test_default_targets_are_okx_and_bybit(report):
    assert report.real_base_target_exchanges == ["okx", "bybit"]
    assert report.simulation_exchange == "binance"

def test_next_gate(report):
    assert report.next_required_gate == "PUBLIC_LIVE_DATA_PIPELINE_OKX_BINANCE_SIM_REQUIRED"
