APP_MODE = "INTERACTIVE_RESEARCH_ONLY"
operational_decision_allowed = False


def main():
    try:
        import streamlit as st
    except Exception:
        print("Streamlit is optional. Install with: python -m pip install -e '.[dashboard]'")
        return

    st.set_page_config(page_title="QRDS Research Dashboard", layout="wide")
    st.title("QRDS Interactive Research Dashboard")
    st.caption("Research-only. No API key. No real account. No orders. No real capital.")
    st.metric("App mode", APP_MODE)
    st.metric("Operational decision allowed", str(operational_decision_allowed))
    st.subheader("Routes")
    st.write({
        "binance": "SIMULATION_FIXTURE_REPLAY",
        "okx": "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH",
        "bybit": "PENDING_BLOCKED_BY_403",
    })
    st.subheader("Safety")
    st.write({
        "api_key_required": False,
        "account_connection_required": False,
        "orders_generated": False,
        "real_capital_used": False,
    })


if __name__ == "__main__":
    main()
