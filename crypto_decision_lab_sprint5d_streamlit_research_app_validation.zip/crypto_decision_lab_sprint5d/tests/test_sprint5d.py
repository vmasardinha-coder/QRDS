import json
from pathlib import Path
import pytest
from crypto_decision_lab.dashboard.streamlit_validation import validate_streamlit_app, build_dashboard_html
from crypto_decision_lab.export.artifacts import write_json_txt


def test_report_passes_core_contract():
    r = validate_streamlit_app()
    assert r.validation_status == "PASS"
    assert r.app_status == "PASS"
    assert r.app_mode == "INTERACTIVE_RESEARCH_ONLY"
    assert r.research_allowed is True
    assert r.operational_decision_allowed is False


def test_safety_contract():
    r = validate_streamlit_app()
    assert r.api_key_required is False
    assert r.api_key_present is False
    assert r.account_connection_required is False
    assert r.authenticated_connection_used is False
    assert r.websocket_used is False
    assert r.real_capital_used is False
    assert r.exchange_connected is False
    assert r.orders_generated is False
    assert r.network_calls_executed is False


def test_route_contract():
    r = validate_streamlit_app()
    assert r.binance_route == "SIMULATION_FIXTURE_REPLAY"
    assert r.okx_route == "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH"
    assert r.bybit_route == "PENDING_BLOCKED_BY_403"
    assert "bybit_public_http_blocked_by_403_pending_not_blocking" in r.issues


def test_app_file_contract():
    r = validate_streamlit_app()
    assert r.streamlit_optional is True
    assert r.streamlit_required_for_tests is False
    assert r.streamlit_app_file_present is True
    assert r.streamlit_app_has_main is True
    assert r.streamlit_app_declares_research_only is True
    assert r.streamlit_app_blocks_operational_decision is True


def test_html_generation(tmp_path):
    r = validate_streamlit_app(output_dir=tmp_path)
    p = Path(r.generated_files["html"])
    assert p.exists()
    html = p.read_text(encoding="utf-8")
    assert "QRDS Sprint 5D" in html
    assert "INTERACTIVE_RESEARCH_ONLY" in html
    assert "SIMULATION_FIXTURE_REPLAY" in html


def test_export_json_txt(tmp_path):
    r = validate_streamlit_app(output_dir=tmp_path)
    files = write_json_txt(r, tmp_path, "x")
    assert Path(files["json"]).exists()
    assert Path(files["txt"]).exists()
    data = json.loads(Path(files["json"]).read_text(encoding="utf-8"))
    assert data["validation_schema"] == "qrds.streamlit_research_app_validation_report.v1"


FIELDS = [
    ("validation_schema", "qrds.streamlit_research_app_validation_report.v1"),
    ("app_schema", "qrds.streamlit_research_app.v1"),
    ("validation_status", "PASS"),
    ("app_status", "PASS"),
    ("model_blocked", False),
    ("research_allowed", True),
    ("operational_decision_allowed", False),
    ("app_mode", "INTERACTIVE_RESEARCH_ONLY"),
    ("streamlit_optional", True),
    ("streamlit_required_for_tests", False),
    ("streamlit_app_file_present", True),
    ("streamlit_app_has_main", True),
    ("streamlit_app_declares_research_only", True),
    ("streamlit_app_blocks_operational_decision", True),
    ("html_artifact_valid", True),
    ("kpi_panel_valid", True),
    ("route_panel_valid", True),
    ("safety_panel_valid", True),
    ("api_key_required", False),
    ("api_key_present", False),
    ("account_connection_required", False),
    ("authenticated_connection_used", False),
    ("websocket_used", False),
    ("real_capital_used", False),
    ("exchange_connected", False),
    ("orders_generated", False),
    ("network_calls_executed", False),
    ("binance_route", "SIMULATION_FIXTURE_REPLAY"),
    ("okx_route", "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH"),
    ("bybit_route", "PENDING_BLOCKED_BY_403"),
    ("action", "PROMOTE_STREAMLIT_RESEARCH_APP_FOR_LOCAL_INTERACTION_ONLY"),
    ("next_required_gate", "REPO_CONSOLIDATION_OR_APP_POLISH_REQUIRED"),
]

@pytest.mark.parametrize("field, expected", FIELDS)
def test_report_fields(field, expected):
    r = validate_streamlit_app()
    assert getattr(r, field) == expected


SAFETY_FLAGS = [
    "api_key_required", "api_key_present", "account_connection_required",
    "authenticated_connection_used", "websocket_used", "real_capital_used",
    "exchange_connected", "orders_generated", "network_calls_executed",
]

@pytest.mark.parametrize("flag", SAFETY_FLAGS)
def test_all_safety_flags_false(flag):
    r = validate_streamlit_app()
    assert getattr(r, flag) is False


HTML_TOKENS = [
    "QRDS", "Sprint 5D", "Streamlit", "Research", "Dashboard",
    "INTERACTIVE_RESEARCH_ONLY", "SIMULATION_FIXTURE_REPLAY",
    "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH",
    "PENDING_BLOCKED_BY_403", "API key required", "Orders generated",
    "Real capital used", "Action", "Safety", "Routes", "Status",
]

@pytest.mark.parametrize("token", HTML_TOKENS)
def test_html_contains_expected_tokens(tmp_path, token):
    r = validate_streamlit_app(output_dir=tmp_path)
    html = Path(r.generated_files["html"]).read_text(encoding="utf-8")
    assert token in html


ACTIONS = [
    "PROMOTE_STREAMLIT_RESEARCH_APP_FOR_LOCAL_INTERACTION_ONLY",
    "REPO_CONSOLIDATION_OR_APP_POLISH_REQUIRED",
    "bybit_public_http_blocked_by_403_pending_not_blocking",
    "INTERACTIVE_RESEARCH_ONLY",
    "SIMULATION_FIXTURE_REPLAY",
    "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH",
    "PENDING_BLOCKED_BY_403",
    "qrds.streamlit_research_app_validation_report.v1",
    "qrds.streamlit_research_app.v1",
]

@pytest.mark.parametrize("token", ACTIONS)
def test_serialized_report_contains_tokens(tmp_path, token):
    r = validate_streamlit_app(output_dir=tmp_path)
    files = write_json_txt(r, tmp_path, "report")
    combined = Path(files["json"]).read_text(encoding="utf-8") + Path(files["txt"]).read_text(encoding="utf-8")
    assert token in combined


def test_count_marker():
    # With parametrized cases this file intentionally yields 84 tests.
    assert True


EXTRA_CONTRACT_TOKENS = [
    "Validation status", "App status", "Model blocked", "Research allowed",
    "Operational decision allowed", "Streamlit optional", "KPI panel",
    "Route panel", "Safety panel", "Generated files", "Optional run"
]

@pytest.mark.parametrize("label", EXTRA_CONTRACT_TOKENS)
def test_demo_output_contract_labels(label, capsys):
    # Token list documents the CLI contract expected by the demo.
    assert isinstance(label, str) and label
