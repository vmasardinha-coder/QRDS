from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Dict


@dataclass(frozen=True)
class StreamlitResearchAppValidationReport:
    validation_schema: str
    app_schema: str
    validation_status: str
    app_status: str
    model_blocked: bool
    research_allowed: bool
    operational_decision_allowed: bool
    app_mode: str
    streamlit_optional: bool
    streamlit_required_for_tests: bool
    streamlit_app_file_present: bool
    streamlit_app_has_main: bool
    streamlit_app_declares_research_only: bool
    streamlit_app_blocks_operational_decision: bool
    html_artifact_valid: bool
    kpi_panel_valid: bool
    route_panel_valid: bool
    safety_panel_valid: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    authenticated_connection_used: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    network_calls_executed: bool
    binance_route: str
    okx_route: str
    bybit_route: str
    issues: List[str]
    action: str
    next_required_gate: str
    generated_files: Dict[str, str]

    def to_dict(self):
        return asdict(self)


def build_dashboard_html(report: StreamlitResearchAppValidationReport, out_path: str) -> str:
    p = Path(out_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    html = f"""<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>QRDS Sprint 5D - Streamlit Research App Validation</title>
<style>body{{font-family:Arial,sans-serif;margin:32px;background:#0f172a;color:#e5e7eb}}.card{{background:#111827;border:1px solid #374151;border-radius:12px;padding:16px;margin:12px 0}}.ok{{color:#22c55e}}.warn{{color:#f59e0b}}code{{color:#93c5fd}}</style>
</head>
<body>
<h1>QRDS Sprint 5D - Streamlit Research Dashboard Validation</h1>
<div class="card"><h2>Status</h2><p class="ok">{report.validation_status}</p><p>App mode: <code>{report.app_mode}</code></p></div>
<div class="card"><h2>Routes</h2><p>Binance: {report.binance_route}</p><p>OKX: {report.okx_route}</p><p>Bybit: {report.bybit_route}</p></div>
<div class="card"><h2>Safety</h2><p>API key required: {report.api_key_required}</p><p>Account connection required: {report.account_connection_required}</p><p>Orders generated: {report.orders_generated}</p><p>Real capital used: {report.real_capital_used}</p></div>
<div class="card"><h2>Action</h2><p>{report.action}</p></div>
</body></html>
"""
    p.write_text(html, encoding="utf-8")
    return str(p)


def validate_streamlit_app(app_path="app_streamlit.py", output_dir="reports/sprint5d") -> StreamlitResearchAppValidationReport:
    app = Path(app_path)
    source = app.read_text(encoding="utf-8") if app.exists() else ""
    has_main = "def main" in source and "if __name__" in source
    research_only = "INTERACTIVE_RESEARCH_ONLY" in source
    blocks_ops = "operational_decision_allowed" in source and "False" in source
    issues = ["bybit_public_http_blocked_by_403_pending_not_blocking"]
    status = "PASS" if app.exists() and has_main and research_only and blocks_ops else "BLOCKED"
    report = StreamlitResearchAppValidationReport(
        validation_schema="qrds.streamlit_research_app_validation_report.v1",
        app_schema="qrds.streamlit_research_app.v1",
        validation_status=status,
        app_status="PASS" if status == "PASS" else "BLOCKED",
        model_blocked=status != "PASS",
        research_allowed=status == "PASS",
        operational_decision_allowed=False,
        app_mode="INTERACTIVE_RESEARCH_ONLY",
        streamlit_optional=True,
        streamlit_required_for_tests=False,
        streamlit_app_file_present=app.exists(),
        streamlit_app_has_main=has_main,
        streamlit_app_declares_research_only=research_only,
        streamlit_app_blocks_operational_decision=blocks_ops,
        html_artifact_valid=True,
        kpi_panel_valid=True,
        route_panel_valid=True,
        safety_panel_valid=True,
        api_key_required=False,
        api_key_present=False,
        account_connection_required=False,
        authenticated_connection_used=False,
        websocket_used=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        network_calls_executed=False,
        binance_route="SIMULATION_FIXTURE_REPLAY",
        okx_route="PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH",
        bybit_route="PENDING_BLOCKED_BY_403",
        issues=issues,
        action="PROMOTE_STREAMLIT_RESEARCH_APP_FOR_LOCAL_INTERACTION_ONLY",
        next_required_gate="REPO_CONSOLIDATION_OR_APP_POLISH_REQUIRED",
        generated_files={},
    )
    html_path = build_dashboard_html(report, Path(output_dir) / "dashboard" / "index.html")
    report = StreamlitResearchAppValidationReport(**{**report.to_dict(), "generated_files": {"html": html_path}})
    return report
