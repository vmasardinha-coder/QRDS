import json
from dataclasses import asdict, is_dataclass
from pathlib import Path


def _plain(value):
    if is_dataclass(value):
        return _plain(asdict(value))
    if isinstance(value, dict):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    return value


def _lines(value, prefix=""):
    out = []
    if isinstance(value, dict):
        for k, v in value.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            out.extend(_lines(v, key))
    else:
        out.append(f"{prefix}: {value}")
    return out


def write_json_txt(payload, output_dir, stem):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    plain = _plain(payload)
    jp = out / f"{stem}.json"
    tp = out / f"{stem}.txt"
    jp.write_text(json.dumps(plain, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    tp.write_text("\n".join(_lines(plain)) + "\n", encoding="utf-8")
    return {"json": str(jp), "txt": str(tp)}
