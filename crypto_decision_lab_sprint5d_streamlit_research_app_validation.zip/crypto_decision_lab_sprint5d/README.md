# Sprint 5D - Streamlit Research App Validation

Valida o app Streamlit opcional como camada local de interacao de pesquisa.

Escopo:
- Sem API key.
- Sem conta real.
- Sem ordem.
- Sem capital real.
- Sem chamada live nova.
- Binance segue como simulacao.
- OKX segue como public live research route aprovada.
- Bybit segue pendente por 403.

Rodar:
```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_streamlit_research_app_validation.py
```

Streamlit opcional:
```bash
python -m pip install -e ".[dashboard]"
streamlit run app_streamlit.py
```
