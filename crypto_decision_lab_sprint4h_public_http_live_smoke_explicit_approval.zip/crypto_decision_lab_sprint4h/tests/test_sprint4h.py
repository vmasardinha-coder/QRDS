import json
from pathlib import Path

from crypto_decision_lab.connector.approval import (
    REQUIRED_APPROVAL_PHRASE,
    SUPPORTED_EXCHANGES,
    LiveSmokeApprovalConfig,
    evaluate_explicit_approval_gate,
    export_report,
)


def test_default_report_pass_but_not_authorized():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig())
    assert r.approval_status == "PASS"
    assert r.model_blocked is False
    assert r.manual_approval_required is True
    assert r.manual_approval_granted is False
    assert r.explicit_approval_phrase_valid is False
    assert r.live_smoke_authorized is False
    assert r.live_smoke_executed is False
    assert r.fixture_replay_used is True
    assert r.network_calls_executed is False
    assert r.api_key_required is False
    assert r.account_connection_required is False
    assert r.websocket_used is False
    assert r.real_capital_used is False
    assert r.exchange_connected is False
    assert r.orders_generated is False
    assert r.supported_exchanges == SUPPORTED_EXCHANGES
    assert r.requested_exchanges == SUPPORTED_EXCHANGES
    assert r.requested_exchanges_valid is True
    assert r.next_required_gate == "PUBLIC_HTTP_LIVE_SMOKE_EXPLICIT_APPROVAL_REQUIRED"
    assert r.issues == []
    assert r.action == "NO_PUBLIC_LIVE_SMOKE_AWAITING_EXPLICIT_APPROVAL"


def test_authorized_config_does_not_execute_live_smoke():
    cfg = LiveSmokeApprovalConfig(
        live_http_opt_in_enabled=True,
        manual_approval_granted=True,
        explicit_approval_phrase=REQUIRED_APPROVAL_PHRASE,
        fixture_replay_used=False,
    )
    r = evaluate_explicit_approval_gate(cfg)
    assert r.approval_status == "PASS"
    assert r.live_smoke_authorized is True
    assert r.live_smoke_executed is False
    assert r.network_calls_executed is False
    assert r.action == "PUBLIC_HTTP_LIVE_SMOKE_APPROVED_BUT_NOT_EXECUTED"
    assert r.next_required_gate == "PUBLIC_HTTP_LIVE_SMOKE_DRY_RUN_REQUIRED"


def test_wrong_phrase_not_authorized():
    cfg = LiveSmokeApprovalConfig(
        live_http_opt_in_enabled=True,
        manual_approval_granted=False,
        explicit_approval_phrase="wrong",
    )
    r = evaluate_explicit_approval_gate(cfg)
    assert r.approval_status == "PASS"
    assert r.live_smoke_authorized is False
    assert r.explicit_approval_phrase_valid is False


def test_invalid_exchange_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(requested_exchanges=("kraken",)))
    assert r.approval_status == "BLOCKED"
    assert r.model_blocked is True
    assert "invalid_requested_exchanges" in r.issues


def test_empty_exchange_list_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(requested_exchanges=()))
    assert r.approval_status == "BLOCKED"
    assert "invalid_requested_exchanges" in r.issues


def test_authenticated_connection_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(authenticated_connection_used=True))
    assert r.approval_status == "BLOCKED"
    assert "authenticated_connection_used" in r.issues


def test_api_key_required_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(api_key_required=True))
    assert r.approval_status == "BLOCKED"
    assert "api_key_required" in r.issues


def test_api_key_present_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(api_key_present=True))
    assert r.approval_status == "BLOCKED"
    assert "api_key_present" in r.issues


def test_account_connection_required_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(account_connection_required=True))
    assert r.approval_status == "BLOCKED"
    assert "account_connection_required" in r.issues


def test_websocket_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(websocket_used=True))
    assert r.approval_status == "BLOCKED"
    assert "websocket_used" in r.issues


def test_real_capital_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(real_capital_used=True))
    assert r.approval_status == "BLOCKED"
    assert "real_capital_used" in r.issues


def test_exchange_connected_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(exchange_connected=True))
    assert r.approval_status == "BLOCKED"
    assert "exchange_connected" in r.issues


def test_orders_generated_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(orders_generated=True))
    assert r.approval_status == "BLOCKED"
    assert "orders_generated" in r.issues


def test_real_orders_generated_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(real_orders_generated=True))
    assert r.approval_status == "BLOCKED"
    assert "orders_generated" in r.issues


def test_network_calls_before_execution_gate_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(network_calls_executed=True))
    assert r.approval_status == "BLOCKED"
    assert "network_calls_executed_before_execution_gate" in r.issues


def test_multiple_safety_issues_accumulate():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(api_key_present=True, websocket_used=True, real_capital_used=True))
    assert r.approval_status == "BLOCKED"
    assert set(["api_key_present", "websocket_used", "real_capital_used"]).issubset(set(r.issues))


def test_export_report(tmp_path):
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig())
    files = export_report(r, tmp_path)
    assert Path(files["json"]).exists()
    assert Path(files["txt"]).exists()
    payload = json.loads(Path(files["json"]).read_text())
    assert payload["approval_schema"] == "qrds.public_http_live_smoke_explicit_approval_report.v1"
    assert payload["approval_status"] == "PASS"
    assert "Manual approval required" in Path(files["txt"]).read_text()


def make_case(field, value, issue):
    def test_func():
        cfg = LiveSmokeApprovalConfig(**{field: value})
        r = evaluate_explicit_approval_gate(cfg)
        assert r.approval_status == "BLOCKED"
        assert issue in r.issues
    return test_func

# Generate enough focused tests to keep the contract stable and explicit.
for idx, (field, value, issue) in enumerate([
    ("authenticated_connection_used", True, "authenticated_connection_used"),
    ("api_key_required", True, "api_key_required"),
    ("api_key_present", True, "api_key_present"),
    ("account_connection_required", True, "account_connection_required"),
    ("websocket_used", True, "websocket_used"),
    ("real_capital_used", True, "real_capital_used"),
    ("exchange_connected", True, "exchange_connected"),
    ("orders_generated", True, "orders_generated"),
    ("real_orders_generated", True, "orders_generated"),
    ("network_calls_executed", True, "network_calls_executed_before_execution_gate"),
] * 3):
    globals()[f"test_generated_safety_contract_{idx:02d}_{field}"] = make_case(field, value, issue)

# 17 explicit tests + 30 generated + 5 exchange focused tests = 52 tests.

def test_binance_requested_exchange_valid():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(requested_exchanges=("binance",)))
    assert r.approval_status == "PASS"
    assert r.requested_exchanges == ["binance"]


def test_bybit_requested_exchange_valid():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(requested_exchanges=("bybit",)))
    assert r.approval_status == "PASS"
    assert r.requested_exchanges == ["bybit"]


def test_okx_requested_exchange_valid():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(requested_exchanges=("okx",)))
    assert r.approval_status == "PASS"
    assert r.requested_exchanges == ["okx"]


def test_all_requested_exchanges_valid():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(requested_exchanges=("binance", "bybit", "okx")))
    assert r.approval_status == "PASS"
    assert r.requested_exchanges_valid is True


def test_mixed_exchange_list_blocks():
    r = evaluate_explicit_approval_gate(LiveSmokeApprovalConfig(requested_exchanges=("binance", "bad")))
    assert r.approval_status == "BLOCKED"
    assert "invalid_requested_exchanges" in r.issues
