# Crypto Decision Lab - Sprint 4H

Public HTTP Live Smoke Explicit Approval Gate.

This sprint does not connect to an exchange by default. It validates the explicit approval gate required before any public HTTP live smoke test.

Default safety posture:
- no API key
- no real account
- no authenticated WebSocket
- no orders
- no real capital
- no live network call by default
- fixture/replay remains the default execution path

Expected validation:
- pytest: 52 passed
- demo: explicit approval not granted, live smoke not authorized, network calls not executed
