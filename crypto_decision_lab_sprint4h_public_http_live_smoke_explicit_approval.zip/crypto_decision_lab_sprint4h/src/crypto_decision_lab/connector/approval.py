from dataclasses import asdict, dataclass
from pathlib import Path
import json
import os
from typing import Iterable

SUPPORTED_EXCHANGES = ["binance", "bybit", "okx"]
REQUIRED_APPROVAL_PHRASE = "I_APPROVE_PUBLIC_HTTP_LIVE_SMOKE_NO_AUTH_NO_ACCOUNT_NO_TRADING"
SCHEMA = "qrds.public_http_live_smoke_explicit_approval_report.v1"
SAFETY_POLICY = "PUBLIC_ONLY_NO_AUTH_EXPLICIT_APPROVAL_GATE_FIXTURE_DEFAULT"

@dataclass(frozen=True)
class LiveSmokeApprovalConfig:
    live_http_opt_in_enabled: bool = False
    manual_approval_required: bool = True
    manual_approval_granted: bool = False
    explicit_approval_phrase: str = ""
    requested_exchanges: tuple[str, ...] = tuple(SUPPORTED_EXCHANGES)
    fixture_replay_used: bool = True
    network_calls_executed: bool = False
    authenticated_connection_used: bool = False
    api_key_required: bool = False
    api_key_present: bool = False
    account_connection_required: bool = False
    websocket_used: bool = False
    real_capital_used: bool = False
    exchange_connected: bool = False
    orders_generated: bool = False
    real_orders_generated: bool = False

@dataclass(frozen=True)
class LiveSmokeExplicitApprovalReport:
    approval_schema: str
    approval_status: str
    model_blocked: bool
    manual_approval_required: bool
    manual_approval_granted: bool
    explicit_approval_phrase_valid: bool
    live_http_opt_in_enabled: bool
    live_smoke_authorized: bool
    live_smoke_executed: bool
    fixture_replay_used: bool
    network_calls_executed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    real_orders_generated: bool
    supported_exchanges: list[str]
    requested_exchanges: list[str]
    requested_exchanges_valid: bool
    safety_policy: str
    next_required_gate: str
    issues: list[str]
    action: str


def _parse_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def _parse_exchanges(value: str | None) -> tuple[str, ...]:
    if not value:
        return tuple(SUPPORTED_EXCHANGES)
    return tuple(x.strip().lower() for x in value.split(",") if x.strip())


def build_default_config() -> LiveSmokeApprovalConfig:
    """Build config from environment, still safe by default."""
    phrase = os.getenv("QRDS_PUBLIC_HTTP_LIVE_SMOKE_APPROVAL", "")
    opt_in = _parse_bool(os.getenv("QRDS_ENABLE_PUBLIC_HTTP_LIVE_SMOKE"), False)
    requested = _parse_exchanges(os.getenv("QRDS_PUBLIC_HTTP_LIVE_SMOKE_EXCHANGES"))
    return LiveSmokeApprovalConfig(
        live_http_opt_in_enabled=opt_in,
        manual_approval_required=True,
        manual_approval_granted=phrase == REQUIRED_APPROVAL_PHRASE,
        explicit_approval_phrase=phrase,
        requested_exchanges=requested,
        fixture_replay_used=not opt_in,
        network_calls_executed=False,
        authenticated_connection_used=False,
        api_key_required=False,
        api_key_present=bool(os.getenv("BINANCE_API_KEY") or os.getenv("BYBIT_API_KEY") or os.getenv("OKX_API_KEY")),
        account_connection_required=False,
        websocket_used=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        real_orders_generated=False,
    )


def _requested_exchanges_valid(exchanges: Iterable[str]) -> bool:
    requested = list(exchanges)
    if not requested:
        return False
    return all(x in SUPPORTED_EXCHANGES for x in requested)


def evaluate_explicit_approval_gate(config: LiveSmokeApprovalConfig | None = None) -> LiveSmokeExplicitApprovalReport:
    cfg = config or build_default_config()
    issues: list[str] = []
    explicit_phrase_valid = cfg.explicit_approval_phrase == REQUIRED_APPROVAL_PHRASE
    requested_valid = _requested_exchanges_valid(cfg.requested_exchanges)

    if not requested_valid:
        issues.append("invalid_requested_exchanges")
    if cfg.authenticated_connection_used:
        issues.append("authenticated_connection_used")
    if cfg.api_key_required:
        issues.append("api_key_required")
    if cfg.api_key_present:
        issues.append("api_key_present")
    if cfg.account_connection_required:
        issues.append("account_connection_required")
    if cfg.websocket_used:
        issues.append("websocket_used")
    if cfg.real_capital_used:
        issues.append("real_capital_used")
    if cfg.exchange_connected:
        issues.append("exchange_connected")
    if cfg.orders_generated or cfg.real_orders_generated:
        issues.append("orders_generated")

    live_smoke_authorized = (
        cfg.live_http_opt_in_enabled
        and cfg.manual_approval_required
        and cfg.manual_approval_granted
        and explicit_phrase_valid
        and requested_valid
        and not issues
    )

    # Sprint 4H authorizes only the gate state; it still does not execute live network.
    live_smoke_executed = False
    if cfg.network_calls_executed:
        issues.append("network_calls_executed_before_execution_gate")

    approval_status = "PASS" if requested_valid and not issues else "BLOCKED"
    model_blocked = approval_status != "PASS"

    if model_blocked:
        action = "NO_PUBLIC_LIVE_SMOKE_EXPLICIT_APPROVAL_BLOCKED"
    elif live_smoke_authorized:
        action = "PUBLIC_HTTP_LIVE_SMOKE_APPROVED_BUT_NOT_EXECUTED"
    else:
        action = "NO_PUBLIC_LIVE_SMOKE_AWAITING_EXPLICIT_APPROVAL"

    next_gate = "PUBLIC_HTTP_LIVE_SMOKE_DRY_RUN_REQUIRED" if live_smoke_authorized else "PUBLIC_HTTP_LIVE_SMOKE_EXPLICIT_APPROVAL_REQUIRED"

    return LiveSmokeExplicitApprovalReport(
        approval_schema=SCHEMA,
        approval_status=approval_status,
        model_blocked=model_blocked,
        manual_approval_required=cfg.manual_approval_required,
        manual_approval_granted=cfg.manual_approval_granted,
        explicit_approval_phrase_valid=explicit_phrase_valid,
        live_http_opt_in_enabled=cfg.live_http_opt_in_enabled,
        live_smoke_authorized=live_smoke_authorized,
        live_smoke_executed=live_smoke_executed,
        fixture_replay_used=cfg.fixture_replay_used,
        network_calls_executed=cfg.network_calls_executed,
        authenticated_connection_used=cfg.authenticated_connection_used,
        api_key_required=cfg.api_key_required,
        api_key_present=cfg.api_key_present,
        account_connection_required=cfg.account_connection_required,
        websocket_used=cfg.websocket_used,
        real_capital_used=cfg.real_capital_used,
        exchange_connected=cfg.exchange_connected,
        orders_generated=cfg.orders_generated,
        real_orders_generated=cfg.real_orders_generated,
        supported_exchanges=list(SUPPORTED_EXCHANGES),
        requested_exchanges=list(cfg.requested_exchanges),
        requested_exchanges_valid=requested_valid,
        safety_policy=SAFETY_POLICY,
        next_required_gate=next_gate,
        issues=issues,
        action=action,
    )


def export_report(report: LiveSmokeExplicitApprovalReport, out_dir: str | Path = "reports/sprint4h") -> dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    payload = asdict(report)
    json_path = out / "public_http_live_smoke_explicit_approval_report.json"
    txt_path = out / "public_http_live_smoke_explicit_approval_report.txt"
    json_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    lines = [
        "QRDS Sprint 4H - Public HTTP Live Smoke Explicit Approval Gate",
        f"Schema: {report.approval_schema}",
        f"Approval status: {report.approval_status}",
        f"Manual approval required: {report.manual_approval_required}",
        f"Manual approval granted: {report.manual_approval_granted}",
        f"Explicit approval phrase valid: {report.explicit_approval_phrase_valid}",
        f"Live HTTP opt-in enabled: {report.live_http_opt_in_enabled}",
        f"Live smoke authorized: {report.live_smoke_authorized}",
        f"Live smoke executed: {report.live_smoke_executed}",
        f"Fixture replay used: {report.fixture_replay_used}",
        f"Network calls executed: {report.network_calls_executed}",
        f"API key required: {report.api_key_required}",
        f"API key present: {report.api_key_present}",
        f"Account connection required: {report.account_connection_required}",
        f"WebSocket used: {report.websocket_used}",
        f"Real capital used: {report.real_capital_used}",
        f"Exchange connected: {report.exchange_connected}",
        f"Orders generated: {report.orders_generated}",
        f"Supported exchanges: {report.supported_exchanges}",
        f"Requested exchanges: {report.requested_exchanges}",
        f"Safety policy: {report.safety_policy}",
        f"Next required gate: {report.next_required_gate}",
        f"Issues: {report.issues if report.issues else 'none'}",
        f"Action: {report.action}",
    ]
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
