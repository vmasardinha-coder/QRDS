from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, List
import json
from pathlib import Path

SCHEMA = "qrds.public_live_data_pipeline_validation_report.v1"
SAFETY_POLICY = "PUBLIC_LIVE_DATA_PIPELINE_VALIDATION_NO_AUTH_NO_ORDERS_NO_REAL_CAPITAL"

@dataclass(frozen=True)
class ExchangeRoute:
    exchange: str
    role: str
    route: str
    active: bool
    pending: bool
    network_calls_executed: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    authenticated_connection_used: bool
    websocket_used: bool
    exchange_connected: bool
    orders_generated: bool
    real_capital_used: bool
    normalized_candles: int

@dataclass(frozen=True)
class PipelineValidationReport:
    schema: str
    pipeline_status: str
    validation_status: str
    model_blocked: bool
    validation_passed: bool
    safety_policy: str
    simulation_exchange: str
    binance_route_valid: bool
    okx_route_valid: bool
    bybit_pending_accepted: bool
    real_base_target_exchanges: List[str]
    real_base_active_now: List[str]
    real_base_pending: List[str]
    live_pipeline_enabled: bool
    fixture_replay_used: bool
    network_calls_executed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    normalized_candles_per_route: Dict[str, int]
    total_normalized_candles: int
    issues: List[str]
    action: str
    next_required_gate: str

    def to_dict(self):
        return asdict(self)


def default_routes() -> Dict[str, ExchangeRoute]:
    return {
        "binance": ExchangeRoute(
            exchange="binance",
            role="SIMULATION_ONLY_PUBLIC_DATA_ALLOWED",
            route="SIMULATION_FIXTURE_REPLAY",
            active=True,
            pending=False,
            network_calls_executed=False,
            api_key_required=False,
            api_key_present=False,
            account_connection_required=False,
            authenticated_connection_used=False,
            websocket_used=False,
            exchange_connected=False,
            orders_generated=False,
            real_capital_used=False,
            normalized_candles=5,
        ),
        "okx": ExchangeRoute(
            exchange="okx",
            role="REAL_BASE_CANDIDATE_PUBLIC_HTTP_OK",
            route="PUBLIC_HTTP_READY_FIXTURE_DEFAULT",
            active=True,
            pending=False,
            network_calls_executed=False,
            api_key_required=False,
            api_key_present=False,
            account_connection_required=False,
            authenticated_connection_used=False,
            websocket_used=False,
            exchange_connected=False,
            orders_generated=False,
            real_capital_used=False,
            normalized_candles=5,
        ),
        "bybit": ExchangeRoute(
            exchange="bybit",
            role="REAL_BASE_CANDIDATE_PENDING_403",
            route="PENDING_BLOCKED_BY_403",
            active=False,
            pending=True,
            network_calls_executed=False,
            api_key_required=False,
            api_key_present=False,
            account_connection_required=False,
            authenticated_connection_used=False,
            websocket_used=False,
            exchange_connected=False,
            orders_generated=False,
            real_capital_used=False,
            normalized_candles=0,
        ),
    }


def validate_routes(routes: Dict[str, ExchangeRoute] | None = None) -> PipelineValidationReport:
    routes = routes or default_routes()
    issues: List[str] = []

    binance = routes["binance"]
    okx = routes["okx"]
    bybit = routes["bybit"]

    binance_route_valid = (
        binance.role == "SIMULATION_ONLY_PUBLIC_DATA_ALLOWED"
        and binance.route == "SIMULATION_FIXTURE_REPLAY"
        and binance.active
        and not binance.network_calls_executed
        and not binance.api_key_required
        and not binance.account_connection_required
        and not binance.orders_generated
        and not binance.real_capital_used
    )
    if not binance_route_valid:
        issues.append("binance_route_policy_invalid")

    okx_route_valid = (
        okx.role == "REAL_BASE_CANDIDATE_PUBLIC_HTTP_OK"
        and okx.route == "PUBLIC_HTTP_READY_FIXTURE_DEFAULT"
        and okx.active
        and not okx.api_key_required
        and not okx.account_connection_required
        and not okx.orders_generated
        and not okx.real_capital_used
    )
    if not okx_route_valid:
        issues.append("okx_route_policy_invalid")

    bybit_pending_accepted = (
        bybit.role == "REAL_BASE_CANDIDATE_PENDING_403"
        and bybit.route == "PENDING_BLOCKED_BY_403"
        and bybit.pending
        and not bybit.active
        and not bybit.orders_generated
        and not bybit.real_capital_used
    )
    if not bybit_pending_accepted:
        issues.append("bybit_pending_policy_invalid")

    security_flags = [
        r.api_key_required or r.api_key_present or r.account_connection_required or r.authenticated_connection_used
        or r.websocket_used or r.exchange_connected or r.orders_generated or r.real_capital_used
        for r in routes.values()
    ]
    if any(security_flags):
        issues.append("security_exposure_detected")

    # Bybit pending is a known issue, but not blocking for this validation gate.
    issues.append("bybit_public_http_blocked_by_403_pending_not_blocking")

    total_candles = {
        "binance_simulation": binance.normalized_candles,
        "okx_public": okx.normalized_candles,
    }

    hard_issues = [i for i in issues if not i.endswith("pending_not_blocking")]
    validation_passed = not hard_issues

    return PipelineValidationReport(
        schema=SCHEMA,
        pipeline_status="PASS_WITH_PENDING_BYBIT" if validation_passed else "BLOCKED",
        validation_status="PASS_WITH_PENDING_BYBIT" if validation_passed else "BLOCKED",
        model_blocked=not validation_passed,
        validation_passed=validation_passed,
        safety_policy=SAFETY_POLICY,
        simulation_exchange="binance",
        binance_route_valid=binance_route_valid,
        okx_route_valid=okx_route_valid,
        bybit_pending_accepted=bybit_pending_accepted,
        real_base_target_exchanges=["okx", "bybit"],
        real_base_active_now=["okx"],
        real_base_pending=["bybit"],
        live_pipeline_enabled=False,
        fixture_replay_used=True,
        network_calls_executed=any(r.network_calls_executed for r in routes.values()),
        authenticated_connection_used=any(r.authenticated_connection_used for r in routes.values()),
        api_key_required=any(r.api_key_required for r in routes.values()),
        api_key_present=any(r.api_key_present for r in routes.values()),
        account_connection_required=any(r.account_connection_required for r in routes.values()),
        websocket_used=any(r.websocket_used for r in routes.values()),
        real_capital_used=any(r.real_capital_used for r in routes.values()),
        exchange_connected=any(r.exchange_connected for r in routes.values()),
        orders_generated=any(r.orders_generated for r in routes.values()),
        normalized_candles_per_route=total_candles,
        total_normalized_candles=sum(total_candles.values()),
        issues=issues,
        action="VALIDATE_OKX_PUBLIC_AND_BINANCE_SIMULATION_KEEP_BYBIT_PENDING",
        next_required_gate="OKX_PUBLIC_HTTP_LIVE_PIPELINE_MANUAL_APPROVAL_REQUIRED",
    )


def dirty_routes() -> Dict[str, ExchangeRoute]:
    routes = default_routes().copy()
    routes["binance"] = ExchangeRoute(
        exchange="binance",
        role="REAL_BASE_INVALID",
        route="LIVE_REAL_INVALID",
        active=True,
        pending=False,
        network_calls_executed=True,
        api_key_required=True,
        api_key_present=True,
        account_connection_required=True,
        authenticated_connection_used=True,
        websocket_used=True,
        exchange_connected=True,
        orders_generated=True,
        real_capital_used=True,
        normalized_candles=5,
    )
    return routes


def export_report(report: PipelineValidationReport, out_dir: str | Path = "reports/sprint4m") -> Dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    json_path = out / "public_live_data_pipeline_validation_report.json"
    txt_path = out / "public_live_data_pipeline_validation_report.txt"
    json_path.write_text(json.dumps(report.to_dict(), indent=2, sort_keys=True), encoding="utf-8")
    lines = [
        "QRDS Sprint 4M Public Live Data Pipeline Validation",
        f"schema: {report.schema}",
        f"pipeline_status: {report.pipeline_status}",
        f"validation_status: {report.validation_status}",
        f"simulation_exchange: {report.simulation_exchange}",
        f"binance_route_valid: {report.binance_route_valid}",
        f"okx_route_valid: {report.okx_route_valid}",
        f"bybit_pending_accepted: {report.bybit_pending_accepted}",
        f"issues: {report.issues}",
        f"action: {report.action}",
    ]
    txt_path.write_text("\n".join(lines), encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
