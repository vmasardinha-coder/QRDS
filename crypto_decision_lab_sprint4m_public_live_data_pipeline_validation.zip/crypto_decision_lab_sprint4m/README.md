# Crypto Decision Lab - Sprint 4M

Public Live Data Pipeline Validation.

This sprint validates the exchange-role routing policy:

- Binance remains simulation-only / fixture replay / public benchmark.
- OKX is the active public HTTP route candidate.
- Bybit remains pending due to HTTP 403 observed in Codespaces.
- No API key, real account, authenticated WebSocket, real order, leverage, or real capital.
