import pytest
from crypto_decision_lab.pipeline.exchange_role_policy import (
    default_routes,
    dirty_routes,
    validate_routes,
    export_report,
)


def test_default_report_pass_with_pending_bybit():
    r = validate_routes()
    assert r.pipeline_status == "PASS_WITH_PENDING_BYBIT"
    assert r.validation_status == "PASS_WITH_PENDING_BYBIT"
    assert r.model_blocked is False
    assert r.validation_passed is True


def test_role_policy_core():
    r = validate_routes()
    assert r.simulation_exchange == "binance"
    assert r.real_base_active_now == ["okx"]
    assert r.real_base_pending == ["bybit"]
    assert r.binance_route_valid is True
    assert r.okx_route_valid is True
    assert r.bybit_pending_accepted is True


def test_security_flags_default_false():
    r = validate_routes()
    assert r.live_pipeline_enabled is False
    assert r.network_calls_executed is False
    assert r.authenticated_connection_used is False
    assert r.api_key_required is False
    assert r.api_key_present is False
    assert r.account_connection_required is False
    assert r.websocket_used is False
    assert r.real_capital_used is False
    assert r.exchange_connected is False
    assert r.orders_generated is False


def test_candle_counts():
    r = validate_routes()
    assert r.normalized_candles_per_route == {"binance_simulation": 5, "okx_public": 5}
    assert r.total_normalized_candles == 10


def test_known_bybit_issue_not_blocking():
    r = validate_routes()
    assert "bybit_public_http_blocked_by_403_pending_not_blocking" in r.issues
    assert r.validation_passed is True


def test_dirty_routes_blocked():
    r = validate_routes(dirty_routes())
    assert r.validation_status == "BLOCKED"
    assert r.model_blocked is True
    assert r.validation_passed is False
    assert "security_exposure_detected" in r.issues


def test_export_report(tmp_path):
    r = validate_routes()
    paths = export_report(r, tmp_path)
    assert "json" in paths and "txt" in paths
    assert "public_live_data_pipeline_validation_report" in paths["json"]
    assert "public_live_data_pipeline_validation_report" in paths["txt"]


@pytest.mark.parametrize("exchange,expected_role", [
    ("binance", "SIMULATION_ONLY_PUBLIC_DATA_ALLOWED"),
    ("okx", "REAL_BASE_CANDIDATE_PUBLIC_HTTP_OK"),
    ("bybit", "REAL_BASE_CANDIDATE_PENDING_403"),
])
def test_exchange_roles(exchange, expected_role):
    assert default_routes()[exchange].role == expected_role


@pytest.mark.parametrize("exchange,expected_route", [
    ("binance", "SIMULATION_FIXTURE_REPLAY"),
    ("okx", "PUBLIC_HTTP_READY_FIXTURE_DEFAULT"),
    ("bybit", "PENDING_BLOCKED_BY_403"),
])
def test_exchange_routes(exchange, expected_route):
    assert default_routes()[exchange].route == expected_route


@pytest.mark.parametrize("exchange", ["binance", "okx", "bybit"])
def test_no_authentication_required(exchange):
    route = default_routes()[exchange]
    assert route.api_key_required is False
    assert route.api_key_present is False
    assert route.account_connection_required is False
    assert route.authenticated_connection_used is False


@pytest.mark.parametrize("exchange", ["binance", "okx", "bybit"])
def test_no_real_execution_flags(exchange):
    route = default_routes()[exchange]
    assert route.websocket_used is False
    assert route.exchange_connected is False
    assert route.orders_generated is False
    assert route.real_capital_used is False


@pytest.mark.parametrize("field", [
    "live_pipeline_enabled",
    "network_calls_executed",
    "authenticated_connection_used",
    "api_key_required",
    "api_key_present",
    "account_connection_required",
    "websocket_used",
    "real_capital_used",
    "exchange_connected",
    "orders_generated",
])
def test_report_safety_fields_false(field):
    r = validate_routes()
    assert getattr(r, field) is False


@pytest.mark.parametrize("field", [
    "schema",
    "pipeline_status",
    "validation_status",
    "safety_policy",
    "action",
    "next_required_gate",
])
def test_report_strings_non_empty(field):
    r = validate_routes()
    assert isinstance(getattr(r, field), str)
    assert getattr(r, field)


@pytest.mark.parametrize("field", [
    "binance_route_valid",
    "okx_route_valid",
    "bybit_pending_accepted",
    "validation_passed",
])
def test_validation_booleans_true(field):
    r = validate_routes()
    assert getattr(r, field) is True


@pytest.mark.parametrize("expected", [
    "VALIDATE_OKX_PUBLIC_AND_BINANCE_SIMULATION_KEEP_BYBIT_PENDING",
    "OKX_PUBLIC_HTTP_LIVE_PIPELINE_MANUAL_APPROVAL_REQUIRED",
])
def test_action_and_next_gate_expected(expected):
    r = validate_routes()
    assert expected in {r.action, r.next_required_gate}


def test_schema_exact():
    assert validate_routes().schema == "qrds.public_live_data_pipeline_validation_report.v1"


def test_safety_policy_exact():
    assert validate_routes().safety_policy == "PUBLIC_LIVE_DATA_PIPELINE_VALIDATION_NO_AUTH_NO_ORDERS_NO_REAL_CAPITAL"


def test_dirty_binance_invalid_role_detected():
    r = validate_routes(dirty_routes())
    assert "binance_route_policy_invalid" in r.issues


def test_dirty_action_blocked_by_validation_state():
    r = validate_routes(dirty_routes())
    assert r.action == "VALIDATE_OKX_PUBLIC_AND_BINANCE_SIMULATION_KEEP_BYBIT_PENDING"
    assert r.validation_passed is False


def test_bybit_pending_no_candles():
    assert default_routes()["bybit"].normalized_candles == 0


def test_okx_has_fixture_candles():
    assert default_routes()["okx"].normalized_candles == 5


def test_binance_has_fixture_candles():
    assert default_routes()["binance"].normalized_candles == 5


def test_to_dict_contains_schema():
    d = validate_routes().to_dict()
    assert d["schema"] == "qrds.public_live_data_pipeline_validation_report.v1"


def test_to_dict_contains_roles():
    d = validate_routes().to_dict()
    assert d["simulation_exchange"] == "binance"
    assert d["real_base_target_exchanges"] == ["okx", "bybit"]


def test_issues_only_known_nonblocking_in_default():
    r = validate_routes()
    assert r.issues == ["bybit_public_http_blocked_by_403_pending_not_blocking"]


def test_dirty_has_more_than_known_issue():
    r = validate_routes(dirty_routes())
    assert len(r.issues) > 1
