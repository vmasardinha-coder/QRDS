
from crypto_decision_lab.repo.readiness import build_repo_consolidation_readiness_report, validate_report
from crypto_decision_lab.export.artifacts import write_json_txt

report = build_repo_consolidation_readiness_report()
validate_report(report)
files = write_json_txt(report)

print("=== Sprint 5F Repo Consolidation Readiness Review ===")
print(f"Readiness schema: {report['schema']}")
print(f"Readiness status: {report['readiness_status']}")
print(f"Research allowed: {report['research_allowed']}")
print(f"Operational decision allowed: {report['operational_decision_allowed']}")
print(f"App mode: {report['app_mode']}")
print(f"Repo consolidation ready: {report['repo_consolidation_ready']}")
print(f"Binance route: {report['routes']['binance']}")
print(f"OKX route: {report['routes']['okx']}")
print(f"Bybit route: {report['routes']['bybit']}")
print(f"API key required: {report['safety']['api_key_required']}")
print(f"API key present: {report['safety']['api_key_present']}")
print(f"Account connection required: {report['safety']['account_connection_required']}")
print(f"Orders generated: {report['safety']['orders_generated']}")
print(f"Claude assessment: {report['claude_assessment']['status']}")
print(f"Issues: {report['issues']}")
print(f"Action: {report['action']}")
print(f"Next required gate: {report['next_required_gate']}")
print(f"Generated files: {files}")
