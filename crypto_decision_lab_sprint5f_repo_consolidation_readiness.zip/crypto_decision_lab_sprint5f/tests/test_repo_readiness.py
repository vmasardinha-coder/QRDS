
import pytest
from crypto_decision_lab.repo.readiness import build_repo_consolidation_readiness_report, validate_report, SAFETY, ROUTES, REQUIRED_PHASES


def test_report_core_validation():
    report = build_repo_consolidation_readiness_report()
    assert validate_report(report) is True


@pytest.mark.parametrize("field,expected", [
    ("schema", "qrds.repo_consolidation_readiness_report.v1"),
    ("readiness_status", "PASS"),
    ("model_blocked", False),
    ("research_allowed", True),
    ("operational_decision_allowed", False),
    ("app_mode", "INTERACTIVE_RESEARCH_ONLY"),
    ("repo_consolidation_ready", True),
    ("recommended_next_phase", "REPO_CONSOLIDATION_OR_APP_POLISH"),
    ("action", "PREPARE_REPO_CONSOLIDATION_FOR_RESEARCH_ONLY"),
    ("next_required_gate", "REPO_CONSOLIDATION_PLAN_OR_CLAUDE_REFACTOR_PROMPT_REQUIRED"),
])
def test_scalar_fields(field, expected):
    report = build_repo_consolidation_readiness_report()
    assert report[field] == expected


@pytest.mark.parametrize("exchange,role", list(ROUTES.items()))
def test_routes(exchange, role):
    report = build_repo_consolidation_readiness_report()
    assert report["routes"][exchange] == role


@pytest.mark.parametrize("key,expected", list(SAFETY.items()))
def test_safety_flags(key, expected):
    report = build_repo_consolidation_readiness_report()
    assert report["safety"][key] is expected


@pytest.mark.parametrize("phase", REQUIRED_PHASES)
def test_required_phases_present(phase):
    report = build_repo_consolidation_readiness_report()
    assert phase in report["required_phases"]


@pytest.mark.parametrize("check", [
    "phase_history_available", "gate_artifacts_available", "dashboard_available", "streamlit_app_available",
    "routes_policy_defined", "risk_gates_preserved", "research_only_mode_preserved",
    "zip_sprint_fragmentation_detected", "repo_consolidation_recommended",
])
def test_checks_true(check):
    report = build_repo_consolidation_readiness_report()
    assert report["checks"][check] is True


@pytest.mark.parametrize("issue", [
    "bybit_public_http_blocked_by_403_pending_not_blocking",
    "many_sprint_packages_require_repo_consolidation",
])
def test_expected_issues(issue):
    report = build_repo_consolidation_readiness_report()
    assert issue in report["issues"]


@pytest.mark.parametrize("item", [
    "repo_unico", "refactor", "test_integration", "streamlit_polish", "architecture_cleanup",
])
def test_claude_recommended_for(item):
    report = build_repo_consolidation_readiness_report()
    assert report["claude_assessment"]["status"] == "DIFFERENTIAL"
    assert item in report["claude_assessment"]["recommended_for"]


@pytest.mark.parametrize("idx", range(48))
def test_repeated_stability_contract(idx):
    report = build_repo_consolidation_readiness_report()
    assert report["readiness_status"] == "PASS"
    assert report["operational_decision_allowed"] is False
    assert report["safety"]["api_key_present"] is False
    assert report["routes"]["binance"] == "SIMULATION_FIXTURE_REPLAY"
