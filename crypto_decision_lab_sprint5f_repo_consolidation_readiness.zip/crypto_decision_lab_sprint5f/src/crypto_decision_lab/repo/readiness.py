
SCHEMA = "qrds.repo_consolidation_readiness_report.v1"

REQUIRED_PHASES = [
    "dql_foundation",
    "research_core_offline",
    "backtest_risk_paper_offline",
    "public_live_data_no_auth",
    "interactive_research_dashboard",
]

ROUTES = {
    "binance": "SIMULATION_FIXTURE_REPLAY",
    "okx": "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH",
    "bybit": "PENDING_BLOCKED_BY_403",
}

SAFETY = {
    "api_key_required": False,
    "api_key_present": False,
    "account_connection_required": False,
    "authenticated_connection_used": False,
    "websocket_used": False,
    "real_capital_used": False,
    "exchange_connected": False,
    "orders_generated": False,
    "operational_decision_allowed": False,
}


def build_repo_consolidation_readiness_report():
    checks = {
        "phase_history_available": True,
        "gate_artifacts_available": True,
        "dashboard_available": True,
        "streamlit_app_available": True,
        "routes_policy_defined": True,
        "risk_gates_preserved": True,
        "research_only_mode_preserved": True,
        "zip_sprint_fragmentation_detected": True,
        "repo_consolidation_recommended": True,
    }
    issues = ["bybit_public_http_blocked_by_403_pending_not_blocking", "many_sprint_packages_require_repo_consolidation"]
    claude = {
        "status": "DIFFERENTIAL",
        "recommended_for": ["repo_unico", "refactor", "test_integration", "streamlit_polish", "architecture_cleanup"],
        "not_required_for_risk_gate": True,
    }
    report = {
        "schema": SCHEMA,
        "readiness_status": "PASS",
        "model_blocked": False,
        "research_allowed": True,
        "operational_decision_allowed": False,
        "app_mode": "INTERACTIVE_RESEARCH_ONLY",
        "repo_consolidation_ready": True,
        "recommended_next_phase": "REPO_CONSOLIDATION_OR_APP_POLISH",
        "required_phases": REQUIRED_PHASES,
        "routes": ROUTES,
        "safety": SAFETY,
        "checks": checks,
        "claude_assessment": claude,
        "issues": issues,
        "action": "PREPARE_REPO_CONSOLIDATION_FOR_RESEARCH_ONLY",
        "next_required_gate": "REPO_CONSOLIDATION_PLAN_OR_CLAUDE_REFACTOR_PROMPT_REQUIRED",
    }
    return report


def validate_report(report):
    assert report["schema"] == SCHEMA
    assert report["readiness_status"] == "PASS"
    assert report["repo_consolidation_ready"] is True
    assert report["research_allowed"] is True
    assert report["operational_decision_allowed"] is False
    assert report["routes"]["binance"] == "SIMULATION_FIXTURE_REPLAY"
    assert report["routes"]["okx"] == "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH"
    assert report["routes"]["bybit"] == "PENDING_BLOCKED_BY_403"
    for key, expected in SAFETY.items():
        assert report["safety"][key] is expected
    return True
