# Crypto Decision Lab - Sprint 4A

Public Market Data Connector Skeleton Offline.

Scope:
- Binance / Bybit / OKX public market data adapter contracts.
- Offline fixtures only.
- No API key.
- No authenticated connection.
- No real account.
- No exchange network call.
- No real orders.
- No capital real.

Run:

```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_public_market_data_connector.py
```
