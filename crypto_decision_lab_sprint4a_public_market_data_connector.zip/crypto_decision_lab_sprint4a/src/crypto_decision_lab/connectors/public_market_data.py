from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from crypto_decision_lab.domain.models import NormalizedCandle, PublicConnectorConfig, NormalizedMarketDataSet

SUPPORTED_EXCHANGES = ["binance", "bybit", "okx"]


def _dt_from_ms(value: int | str) -> datetime:
    return datetime.fromtimestamp(int(value) / 1000, tz=timezone.utc)


def get_public_connector_config(exchange: str, symbol: str = "BTCUSDT", timeframe: str = "1h") -> PublicConnectorConfig:
    exchange = exchange.lower()
    if exchange not in SUPPORTED_EXCHANGES:
        raise ValueError(f"unsupported_exchange:{exchange}")
    return PublicConnectorConfig(exchange=exchange, symbol=symbol, timeframe=timeframe)


def assert_safe_public_config(config: PublicConnectorConfig) -> bool:
    if config.requires_api_key:
        raise ValueError("public_connector_must_not_require_api_key")
    if config.uses_account_connection:
        raise ValueError("public_connector_must_not_use_account_connection")
    if config.authenticated_connection:
        raise ValueError("public_connector_must_not_be_authenticated")
    if config.network_calls_enabled:
        raise ValueError("sprint4a_must_not_execute_network_calls")
    return True


class PublicMarketDataConnector:
    """Offline-only connector skeleton for public market data.

    This class intentionally does not perform HTTP requests. It validates public
    connector contracts and normalizes fixture payloads into a common candle schema.
    """

    def supported_exchanges(self) -> list[str]:
        return list(SUPPORTED_EXCHANGES)

    def load_fixture(self, exchange: str, path: str | Path) -> NormalizedMarketDataSet:
        exchange = exchange.lower()
        config = get_public_connector_config(exchange)
        assert_safe_public_config(config)
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        candles = self.normalize(exchange, raw, config.symbol, config.timeframe)
        return NormalizedMarketDataSet(exchange=exchange, symbol=config.symbol, timeframe=config.timeframe, candles=candles)

    def normalize(self, exchange: str, raw: object, symbol: str = "BTCUSDT", timeframe: str = "1h") -> list[NormalizedCandle]:
        exchange = exchange.lower()
        if exchange == "binance":
            rows = raw
            parsed = [self._normalize_row(exchange, symbol, timeframe, row[0], row[1], row[2], row[3], row[4], row[5]) for row in rows]
        elif exchange == "bybit":
            rows = raw["result"]["list"]
            parsed = [self._normalize_row(exchange, symbol, timeframe, row[0], row[1], row[2], row[3], row[4], row[5]) for row in rows]
        elif exchange == "okx":
            rows = raw["data"]
            parsed = [self._normalize_row(exchange, symbol, timeframe, row[0], row[1], row[2], row[3], row[4], row[5]) for row in rows]
        else:
            raise ValueError(f"unsupported_exchange:{exchange}")
        return sorted(parsed, key=lambda c: c.timestamp)

    def _normalize_row(self, exchange: str, symbol: str, timeframe: str, ts, open_, high, low, close, volume) -> NormalizedCandle:
        candle = NormalizedCandle(
            exchange=exchange,
            symbol=symbol,
            timeframe=timeframe,
            timestamp=_dt_from_ms(ts),
            open=float(open_),
            high=float(high),
            low=float(low),
            close=float(close),
            volume=float(volume),
        )
        if not (candle.low <= candle.open <= candle.high and candle.low <= candle.close <= candle.high):
            raise ValueError(f"invalid_ohlc:{exchange}:{ts}")
        if candle.volume < 0:
            raise ValueError(f"invalid_volume:{exchange}:{ts}")
        return candle


def fixture_path(exchange: str) -> Path:
    return Path("data/fixtures/public_market_data") / f"{exchange}_btcusdt_1h.json"
