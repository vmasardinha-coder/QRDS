from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from crypto_decision_lab.domain.models import PublicConnectorConfig, NormalizedMarketDataSet
from crypto_decision_lab.connectors.public_market_data import SUPPORTED_EXCHANGES

SCHEMA = "qrds.public_market_data_connector_report.v1"
NEXT_REQUIRED_GATE = "PUBLIC_MARKET_DATA_CONNECTOR_VALIDATION_REQUIRED"

@dataclass(frozen=True)
class PublicMarketDataConnectorReport:
    schema: str
    connector_status: str
    model_blocked: bool
    public_market_data_allowed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    account_connection_required: bool
    network_calls_executed: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    supported_exchanges: list[str]
    normalized_candles_per_exchange: dict[str, int]
    normalized_total_candles: int
    next_required_gate: str
    issues: list[str]
    action: str


def _timestamps_sorted(dataset: NormalizedMarketDataSet) -> bool:
    times = [c.timestamp for c in dataset.candles]
    return times == sorted(times)


def _unique_timestamps(dataset: NormalizedMarketDataSet) -> bool:
    times = [c.timestamp for c in dataset.candles]
    return len(times) == len(set(times))


def generate_public_market_data_connector_report(
    datasets: list[NormalizedMarketDataSet],
    configs: list[PublicConnectorConfig],
) -> PublicMarketDataConnectorReport:
    issues: list[str] = []
    data_by_exchange = {d.exchange: d for d in datasets}
    config_by_exchange = {c.exchange: c for c in configs}

    for exchange in SUPPORTED_EXCHANGES:
        if exchange not in data_by_exchange:
            issues.append(f"missing_dataset:{exchange}")
        if exchange not in config_by_exchange:
            issues.append(f"missing_config:{exchange}")

    api_key_required = any(c.requires_api_key for c in configs)
    account_connection_required = any(c.uses_account_connection for c in configs)
    authenticated_connection_used = any(c.authenticated_connection for c in configs)
    network_calls_executed = any(c.network_calls_enabled for c in configs)

    if api_key_required:
        issues.append("api_key_required")
    if account_connection_required:
        issues.append("account_connection_required")
    if authenticated_connection_used:
        issues.append("authenticated_connection_used")
    if network_calls_executed:
        issues.append("network_calls_executed")

    counts: dict[str, int] = {}
    for exchange, dataset in data_by_exchange.items():
        counts[exchange] = len(dataset.candles)
        if len(dataset.candles) == 0:
            issues.append(f"empty_dataset:{exchange}")
        if not _timestamps_sorted(dataset):
            issues.append(f"timestamps_not_sorted:{exchange}")
        if not _unique_timestamps(dataset):
            issues.append(f"duplicate_timestamps:{exchange}")
        for c in dataset.candles:
            if c.exchange != exchange:
                issues.append(f"exchange_mismatch:{exchange}")
            if c.open <= 0 or c.high <= 0 or c.low <= 0 or c.close <= 0:
                issues.append(f"non_positive_price:{exchange}")
            if c.volume < 0:
                issues.append(f"negative_volume:{exchange}")

    status = "PASS" if not issues else "BLOCKED"
    model_blocked = status != "PASS"
    return PublicMarketDataConnectorReport(
        schema=SCHEMA,
        connector_status=status,
        model_blocked=model_blocked,
        public_market_data_allowed=status == "PASS",
        authenticated_connection_used=authenticated_connection_used,
        api_key_required=api_key_required,
        account_connection_required=account_connection_required,
        network_calls_executed=network_calls_executed,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        supported_exchanges=list(SUPPORTED_EXCHANGES),
        normalized_candles_per_exchange=counts,
        normalized_total_candles=sum(counts.values()),
        next_required_gate=NEXT_REQUIRED_GATE,
        issues=issues,
        action="PUBLIC_DATA_RESEARCH_ONLY" if status == "PASS" else "NO_PUBLIC_CONNECTOR_BLOCKED",
    )


def report_to_dict(report: PublicMarketDataConnectorReport) -> dict:
    return asdict(report)


def export_public_connector_report(report: PublicMarketDataConnectorReport, out_dir: str | Path = "reports/sprint4a") -> dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    json_path = out / "public_market_data_connector_report.json"
    txt_path = out / "public_market_data_connector_report.txt"
    payload = report_to_dict(report)
    json_path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    txt_path.write_text("\n".join([
        "QRDS Sprint 4A Public Market Data Connector Report",
        f"Schema: {report.schema}",
        f"Connector status: {report.connector_status}",
        f"Model blocked: {report.model_blocked}",
        f"Supported exchanges: {report.supported_exchanges}",
        f"Normalized candles: {report.normalized_candles_per_exchange}",
        f"API key required: {report.api_key_required}",
        f"Authenticated connection used: {report.authenticated_connection_used}",
        f"Network calls executed: {report.network_calls_executed}",
        f"Next required gate: {report.next_required_gate}",
        f"Issues: {report.issues if report.issues else 'none'}",
    ]), encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
