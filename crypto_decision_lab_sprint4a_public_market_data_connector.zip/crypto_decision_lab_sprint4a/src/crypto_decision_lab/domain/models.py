from dataclasses import dataclass
from datetime import datetime

@dataclass(frozen=True)
class NormalizedCandle:
    exchange: str
    symbol: str
    timeframe: str
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float

@dataclass(frozen=True)
class PublicConnectorConfig:
    exchange: str
    symbol: str
    timeframe: str
    requires_api_key: bool = False
    uses_account_connection: bool = False
    authenticated_connection: bool = False
    network_calls_enabled: bool = False

@dataclass(frozen=True)
class NormalizedMarketDataSet:
    exchange: str
    symbol: str
    timeframe: str
    candles: list[NormalizedCandle]
