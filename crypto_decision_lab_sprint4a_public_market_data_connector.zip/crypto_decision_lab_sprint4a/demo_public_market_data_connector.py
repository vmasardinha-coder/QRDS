from crypto_decision_lab.connectors.public_market_data import PublicMarketDataConnector, get_public_connector_config, fixture_path
from crypto_decision_lab.domain.models import PublicConnectorConfig
from crypto_decision_lab.reports.public_connector_report import generate_public_market_data_connector_report, export_public_connector_report

connector = PublicMarketDataConnector()
configs = [get_public_connector_config(exchange) for exchange in connector.supported_exchanges()]
datasets = [connector.load_fixture(exchange, fixture_path(exchange)) for exchange in connector.supported_exchanges()]
report = generate_public_market_data_connector_report(datasets, configs)
files = export_public_connector_report(report)

dirty_configs = list(configs) + [
    PublicConnectorConfig(
        exchange="binance",
        symbol="BTCUSDT",
        timeframe="1h",
        requires_api_key=True,
        uses_account_connection=True,
        authenticated_connection=True,
        network_calls_enabled=True,
    )
]
dirty_report = generate_public_market_data_connector_report(datasets, dirty_configs)

print("=== Sprint 4A Public Market Data Connector Skeleton Offline ===")
print(f"Connector schema: {report.schema}")
print(f"Connector status: {report.connector_status}")
print(f"Model blocked: {report.model_blocked}")
print(f"Public market data allowed: {report.public_market_data_allowed}")
print(f"Authenticated connection used: {report.authenticated_connection_used}")
print(f"API key required: {report.api_key_required}")
print(f"Account connection required: {report.account_connection_required}")
print(f"Network calls executed: {report.network_calls_executed}")
print(f"Real capital used: {report.real_capital_used}")
print(f"Exchange connected: {report.exchange_connected}")
print(f"Orders generated: {report.orders_generated}")
print(f"Supported exchanges: {report.supported_exchanges}")
print(f"Normalized candles per exchange: {report.normalized_candles_per_exchange}")
print(f"Next required gate: {report.next_required_gate}")
print(f"Issues: {report.issues if report.issues else 'none'}")
print(f"Dirty connector status: {dirty_report.connector_status}")
print(f"Dirty action: {dirty_report.action}")
print(f"Generated files: {files}")
