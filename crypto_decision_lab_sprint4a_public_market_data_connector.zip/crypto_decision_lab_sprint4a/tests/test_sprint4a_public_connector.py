from pathlib import Path
import pytest
from crypto_decision_lab.connectors.public_market_data import (
    PublicMarketDataConnector,
    get_public_connector_config,
    assert_safe_public_config,
    fixture_path,
    SUPPORTED_EXCHANGES,
)
from crypto_decision_lab.domain.models import PublicConnectorConfig, NormalizedMarketDataSet, NormalizedCandle
from crypto_decision_lab.reports.public_connector_report import (
    generate_public_market_data_connector_report,
    export_public_connector_report,
    SCHEMA,
    NEXT_REQUIRED_GATE,
)


def build():
    c = PublicMarketDataConnector()
    configs = [get_public_connector_config(ex) for ex in c.supported_exchanges()]
    datasets = [c.load_fixture(ex, fixture_path(ex)) for ex in c.supported_exchanges()]
    report = generate_public_market_data_connector_report(datasets, configs)
    return c, configs, datasets, report


def test_01_supported_exchanges():
    assert SUPPORTED_EXCHANGES == ["binance", "bybit", "okx"]


def test_02_connector_supported_exchanges_copy():
    assert PublicMarketDataConnector().supported_exchanges() == ["binance", "bybit", "okx"]


def test_03_binance_config_safe():
    cfg = get_public_connector_config("binance")
    assert cfg.exchange == "binance" and not cfg.requires_api_key


def test_04_bybit_config_safe():
    cfg = get_public_connector_config("bybit")
    assert cfg.exchange == "bybit" and not cfg.uses_account_connection


def test_05_okx_config_safe():
    cfg = get_public_connector_config("okx")
    assert cfg.exchange == "okx" and not cfg.authenticated_connection


def test_06_unsupported_exchange_rejected():
    with pytest.raises(ValueError):
        get_public_connector_config("kraken")


def test_07_safe_config_assertion_returns_true():
    assert assert_safe_public_config(get_public_connector_config("binance")) is True


def test_08_api_key_config_rejected():
    with pytest.raises(ValueError):
        assert_safe_public_config(PublicConnectorConfig("binance", "BTCUSDT", "1h", requires_api_key=True))


def test_09_account_connection_config_rejected():
    with pytest.raises(ValueError):
        assert_safe_public_config(PublicConnectorConfig("binance", "BTCUSDT", "1h", uses_account_connection=True))


def test_10_authenticated_config_rejected():
    with pytest.raises(ValueError):
        assert_safe_public_config(PublicConnectorConfig("bybit", "BTCUSDT", "1h", authenticated_connection=True))


def test_11_network_config_rejected():
    with pytest.raises(ValueError):
        assert_safe_public_config(PublicConnectorConfig("okx", "BTCUSDT", "1h", network_calls_enabled=True))


def test_12_fixture_paths_exist():
    for ex in SUPPORTED_EXCHANGES:
        assert fixture_path(ex).exists()


def test_13_binance_fixture_loads():
    ds = PublicMarketDataConnector().load_fixture("binance", fixture_path("binance"))
    assert len(ds.candles) == 5


def test_14_bybit_fixture_loads():
    ds = PublicMarketDataConnector().load_fixture("bybit", fixture_path("bybit"))
    assert len(ds.candles) == 5


def test_15_okx_fixture_loads():
    ds = PublicMarketDataConnector().load_fixture("okx", fixture_path("okx"))
    assert len(ds.candles) == 5


def test_16_normalized_candle_types():
    ds = PublicMarketDataConnector().load_fixture("binance", fixture_path("binance"))
    assert isinstance(ds.candles[0], NormalizedCandle)


def test_17_normalized_dataset_type():
    ds = PublicMarketDataConnector().load_fixture("bybit", fixture_path("bybit"))
    assert isinstance(ds, NormalizedMarketDataSet)


def test_18_candles_are_sorted():
    ds = PublicMarketDataConnector().load_fixture("okx", fixture_path("okx"))
    assert [c.timestamp for c in ds.candles] == sorted(c.timestamp for c in ds.candles)


def test_19_ohlc_valid_for_all():
    _, _, datasets, _ = build()
    assert all(c.low <= c.open <= c.high and c.low <= c.close <= c.high for ds in datasets for c in ds.candles)


def test_20_volume_non_negative_for_all():
    _, _, datasets, _ = build()
    assert all(c.volume >= 0 for ds in datasets for c in ds.candles)


def test_21_symbols_standardized():
    _, _, datasets, _ = build()
    assert all(c.symbol == "BTCUSDT" for ds in datasets for c in ds.candles)


def test_22_timeframes_standardized():
    _, _, datasets, _ = build()
    assert all(c.timeframe == "1h" for ds in datasets for c in ds.candles)


def test_23_report_schema():
    *_, report = build()
    assert report.schema == SCHEMA


def test_24_report_status_pass():
    *_, report = build()
    assert report.connector_status == "PASS"


def test_25_report_not_blocked():
    *_, report = build()
    assert report.model_blocked is False


def test_26_public_market_data_allowed():
    *_, report = build()
    assert report.public_market_data_allowed is True


def test_27_no_authenticated_connection_used():
    *_, report = build()
    assert report.authenticated_connection_used is False


def test_28_no_api_key_required():
    *_, report = build()
    assert report.api_key_required is False


def test_29_no_account_connection_required():
    *_, report = build()
    assert report.account_connection_required is False


def test_30_no_network_calls_executed():
    *_, report = build()
    assert report.network_calls_executed is False


def test_31_no_real_capital_used():
    *_, report = build()
    assert report.real_capital_used is False


def test_32_no_exchange_connected():
    *_, report = build()
    assert report.exchange_connected is False


def test_33_no_orders_generated():
    *_, report = build()
    assert report.orders_generated is False


def test_34_candle_counts_per_exchange():
    *_, report = build()
    assert report.normalized_candles_per_exchange == {"binance": 5, "bybit": 5, "okx": 5}


def test_35_total_candles():
    *_, report = build()
    assert report.normalized_total_candles == 15


def test_36_next_required_gate():
    *_, report = build()
    assert report.next_required_gate == NEXT_REQUIRED_GATE


def test_37_dirty_config_blocks():
    _, configs, datasets, _ = build()
    dirty = list(configs) + [PublicConnectorConfig("binance", "BTCUSDT", "1h", requires_api_key=True, uses_account_connection=True, authenticated_connection=True, network_calls_enabled=True)]
    report = generate_public_market_data_connector_report(datasets, dirty)
    assert report.connector_status == "BLOCKED"
    assert report.action == "NO_PUBLIC_CONNECTOR_BLOCKED"


def test_38_export_report(tmp_path):
    *_, report = build()
    files = export_public_connector_report(report, tmp_path)
    assert Path(files["json"]).exists()
    assert Path(files["txt"]).exists()
