import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
from html import escape


def _to_plain(value):
    if is_dataclass(value):
        return _to_plain(asdict(value))
    if isinstance(value, dict):
        return {str(k): _to_plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_plain(v) for v in value]
    return value


def _flatten_lines(value, prefix=""):
    lines = []
    if isinstance(value, dict):
        for k, v in value.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            lines.extend(_flatten_lines(v, key))
    elif isinstance(value, list):
        lines.append(f"{prefix}: {value}")
    else:
        lines.append(f"{prefix}: {value}")
    return lines


def write_json_txt(payload, output_dir="reports/sprint5b", stem="interactive_research_dashboard_validation_report"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    plain = _to_plain(payload)
    json_path = out / f"{stem}.json"
    txt_path = out / f"{stem}.txt"
    json_path.write_text(json.dumps(plain, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    txt_path.write_text("\n".join(_flatten_lines(plain)) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}


def render_dashboard_html(report, validation, output_dir="reports/sprint5b/dashboard"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    r = _to_plain(report)
    v = _to_plain(validation)
    cards = [
        ("Validation", v["validation_status"]),
        ("Dashboard", r["dashboard_status"]),
        ("Quality", f'{r["quality_score"]:.4f}'),
        ("Research", str(r["research_allowed"])),
        ("Operational", str(r["operational_decision_allowed"])),
        ("App Mode", r["app_mode"]),
        ("OKX", r["okx_route"]),
        ("Binance", r["binance_route"]),
        ("Bybit", r["bybit_route"]),
        ("Safety", "No API key / No real account / No orders / No real capital"),
    ]
    card_html = "".join(f"<div class='card'><b>{escape(str(k))}</b><span>{escape(str(val))}</span></div>" for k, val in cards)
    html = f"""<!doctype html>
<html lang='pt-BR'>
<head><meta charset='utf-8'><title>QRDS/QOS Interactive Research Dashboard Validation</title>
<style>
body {{ font-family: Arial, sans-serif; background:#0f172a; color:#e5e7eb; margin:0; padding:24px; }}
h1 {{ margin-top:0; }}
.grid {{ display:grid; grid-template-columns: repeat(auto-fit,minmax(220px,1fr)); gap:12px; }}
.card {{ background:#111827; border:1px solid #334155; border-radius:12px; padding:16px; }}
.card b {{ display:block; color:#93c5fd; margin-bottom:8px; }}
.card span {{ font-size:14px; word-break:break-word; }}
pre {{ background:#020617; border:1px solid #334155; padding:16px; border-radius:12px; overflow:auto; }}
.ok {{ color:#86efac; }} .warn {{ color:#facc15; }}
</style></head>
<body>
<h1>QRDS/QOS - Interactive Research Dashboard</h1>
<p class='ok'>Research-only. No API key. No real account. No orders. No real capital.</p>
<div class='grid'>{card_html}</div>
<h2>Validation Payload</h2><pre>{escape(json.dumps(v, indent=2, ensure_ascii=False))}</pre>
<h2>Dashboard Payload</h2><pre>{escape(json.dumps(r, indent=2, ensure_ascii=False))}</pre>
</body></html>"""
    html_path = out / "index.html"
    html_path.write_text(html, encoding="utf-8")
    return str(html_path)
