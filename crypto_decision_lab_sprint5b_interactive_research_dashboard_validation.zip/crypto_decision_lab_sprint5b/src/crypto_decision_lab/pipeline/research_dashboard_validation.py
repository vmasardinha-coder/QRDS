from dataclasses import dataclass, asdict
from typing import Dict, List

@dataclass(frozen=True)
class DashboardReport:
    schema: str
    dashboard_status: str
    model_blocked: bool
    research_allowed: bool
    operational_decision_allowed: bool
    app_mode: str
    quality_score: float
    simulation_exchange: str
    binance_route: str
    okx_route: str
    bybit_route: str
    live_pipeline_enabled: bool
    network_calls_executed: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    total_normalized_candles: int
    feature_rows: int
    regime_variants: int
    last_regime_code: str
    issues: List[str]
    action: str
    next_required_gate: str
    widgets: Dict[str, object]

@dataclass(frozen=True)
class DashboardValidationReport:
    schema: str
    validation_status: str
    model_blocked: bool
    dashboard_status: str
    dashboard_contract_valid: bool
    html_artifact_expected: bool
    html_artifact_valid: bool
    kpi_panel_valid: bool
    route_panel_valid: bool
    safety_panel_valid: bool
    research_allowed: bool
    operational_decision_allowed: bool
    app_mode: str
    quality_score: float
    simulation_exchange: str
    binance_route: str
    okx_route: str
    bybit_route: str
    live_pipeline_enabled: bool
    network_calls_executed: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    total_normalized_candles: int
    feature_rows: int
    regime_variants: int
    last_regime_code: str
    issues: List[str]
    action: str
    next_required_gate: str


def build_dashboard_report() -> DashboardReport:
    return DashboardReport(
        schema="qrds.interactive_research_dashboard.v1",
        dashboard_status="PASS",
        model_blocked=False,
        research_allowed=True,
        operational_decision_allowed=False,
        app_mode="INTERACTIVE_RESEARCH_ONLY",
        quality_score=1.0,
        simulation_exchange="binance",
        binance_route="SIMULATION_FIXTURE_REPLAY",
        okx_route="PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH",
        bybit_route="PENDING_BLOCKED_BY_403",
        live_pipeline_enabled=False,
        network_calls_executed=False,
        api_key_required=False,
        api_key_present=False,
        account_connection_required=False,
        websocket_used=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        total_normalized_candles=10,
        feature_rows=10,
        regime_variants=3,
        last_regime_code="high_volatility|upper_close",
        issues=["bybit_public_http_blocked_by_403_pending_not_blocking"],
        action="OPEN_INTERACTIVE_RESEARCH_DASHBOARD_NO_OPERATIONAL_DECISION",
        next_required_gate="INTERACTIVE_RESEARCH_DASHBOARD_VALIDATION_REQUIRED",
        widgets={
            "kpis": {
                "quality_score": 1.0,
                "dql_status": "PASS",
                "feature_quality_status": "PASS",
                "regime_status": "PASS",
                "research_allowed": True,
                "operational_decision_allowed": False,
            },
            "routes": {
                "okx": "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH",
                "binance": "SIMULATION_FIXTURE_REPLAY",
                "bybit": "PENDING_BLOCKED_BY_403",
            },
            "safety": {
                "api_key_present": False,
                "api_key_required": False,
                "account_connection_required": False,
                "websocket_used": False,
                "orders_generated": False,
                "real_capital_used": False,
            },
        },
    )


def report_to_dict(report):
    return asdict(report)


def dashboard_contract_valid(report: DashboardReport) -> bool:
    if report.schema != "qrds.interactive_research_dashboard.v1":
        return False
    if report.dashboard_status != "PASS" or report.model_blocked:
        return False
    if not report.research_allowed or report.operational_decision_allowed:
        return False
    if report.app_mode != "INTERACTIVE_RESEARCH_ONLY":
        return False
    if report.quality_score < 0.95:
        return False
    if report.simulation_exchange != "binance":
        return False
    if report.binance_route != "SIMULATION_FIXTURE_REPLAY":
        return False
    if not report.okx_route.startswith("PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE"):
        return False
    if report.bybit_route != "PENDING_BLOCKED_BY_403":
        return False
    return True


def safety_valid(report: DashboardReport) -> bool:
    return not any([
        report.live_pipeline_enabled,
        report.network_calls_executed,
        report.api_key_required,
        report.api_key_present,
        report.account_connection_required,
        report.websocket_used,
        report.real_capital_used,
        report.exchange_connected,
        report.orders_generated,
    ])


def widget_contract_valid(report: DashboardReport) -> bool:
    return all([
        "kpis" in report.widgets,
        "routes" in report.widgets,
        "safety" in report.widgets,
        report.widgets["routes"].get("okx") == report.okx_route,
        report.widgets["routes"].get("binance") == report.binance_route,
        report.widgets["routes"].get("bybit") == report.bybit_route,
        report.widgets["safety"].get("api_key_present") is False,
        report.widgets["safety"].get("orders_generated") is False,
        report.widgets["kpis"].get("dql_status") == "PASS",
    ])


def validate_html_content(html: str) -> bool:
    required = [
        "QRDS/QOS", "Interactive Research Dashboard", "Research-only", "No API key",
        "No real account", "No orders", "No real capital", "OKX", "Binance", "Bybit",
        "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH", "SIMULATION_FIXTURE_REPLAY",
        "PENDING_BLOCKED_BY_403", "INTERACTIVE_RESEARCH_ONLY",
    ]
    return all(token in html for token in required)


def build_validation_report(report: DashboardReport, html: str) -> DashboardValidationReport:
    contract = dashboard_contract_valid(report)
    safety = safety_valid(report)
    widgets = widget_contract_valid(report)
    html_valid = validate_html_content(html)
    ok = contract and safety and widgets and html_valid
    issues = []
    if not contract: issues.append("dashboard_contract_invalid")
    if not safety: issues.append("safety_contract_invalid")
    if not widgets: issues.append("widget_contract_invalid")
    if not html_valid: issues.append("html_artifact_invalid")
    issues.extend(report.issues)
    return DashboardValidationReport(
        schema="qrds.interactive_research_dashboard_validation_report.v1",
        validation_status="PASS" if ok else "BLOCKED",
        model_blocked=not ok,
        dashboard_status=report.dashboard_status,
        dashboard_contract_valid=contract,
        html_artifact_expected=True,
        html_artifact_valid=html_valid,
        kpi_panel_valid=widgets and "kpis" in report.widgets,
        route_panel_valid=widgets and "routes" in report.widgets,
        safety_panel_valid=safety and widgets and "safety" in report.widgets,
        research_allowed=report.research_allowed,
        operational_decision_allowed=report.operational_decision_allowed,
        app_mode=report.app_mode,
        quality_score=report.quality_score,
        simulation_exchange=report.simulation_exchange,
        binance_route=report.binance_route,
        okx_route=report.okx_route,
        bybit_route=report.bybit_route,
        live_pipeline_enabled=report.live_pipeline_enabled,
        network_calls_executed=report.network_calls_executed,
        api_key_required=report.api_key_required,
        api_key_present=report.api_key_present,
        account_connection_required=report.account_connection_required,
        websocket_used=report.websocket_used,
        real_capital_used=report.real_capital_used,
        exchange_connected=report.exchange_connected,
        orders_generated=report.orders_generated,
        total_normalized_candles=report.total_normalized_candles,
        feature_rows=report.feature_rows,
        regime_variants=report.regime_variants,
        last_regime_code=report.last_regime_code,
        issues=issues,
        action="PROMOTE_INTERACTIVE_RESEARCH_DASHBOARD_FOR_RESEARCH_ONLY" if ok else "NO_DASHBOARD_PROMOTION_BLOCKED",
        next_required_gate="INTERACTIVE_RESEARCH_APP_STREAMLIT_OPTIONAL_REQUIRED" if ok else "INTERACTIVE_RESEARCH_DASHBOARD_FIX_REQUIRED",
    )
