from crypto_decision_lab.pipeline.research_dashboard_validation import build_dashboard_report, build_validation_report
from crypto_decision_lab.export.artifacts import render_dashboard_html

try:
    import streamlit as st
except Exception as exc:
    raise SystemExit("Install optional dashboard dependency with: python -m pip install -e '.[dashboard]'") from exc

report = build_dashboard_report()
html = "QRDS/QOS Interactive Research Dashboard Research-only No API key No real account No orders No real capital OKX Binance Bybit PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH SIMULATION_FIXTURE_REPLAY PENDING_BLOCKED_BY_403 INTERACTIVE_RESEARCH_ONLY"
validation = build_validation_report(report, html)

st.set_page_config(page_title="QRDS Research Dashboard", layout="wide")
st.title("QRDS/QOS - Interactive Research Dashboard")
st.caption("Research-only. No API key. No account. No orders. No real capital.")
cols = st.columns(4)
cols[0].metric("Validation", validation.validation_status)
cols[1].metric("Quality", f"{validation.quality_score:.4f}")
cols[2].metric("Research", str(validation.research_allowed))
cols[3].metric("Operational", str(validation.operational_decision_allowed))
st.subheader("Routes")
st.json({"OKX": validation.okx_route, "Binance": validation.binance_route, "Bybit": validation.bybit_route})
st.subheader("Safety")
st.json({"api_key_present": validation.api_key_present, "account_connection_required": validation.account_connection_required, "orders_generated": validation.orders_generated, "real_capital_used": validation.real_capital_used})
