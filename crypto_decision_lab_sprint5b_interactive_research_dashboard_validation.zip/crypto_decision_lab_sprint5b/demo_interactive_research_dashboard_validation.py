from pathlib import Path
from crypto_decision_lab.pipeline.research_dashboard_validation import (
    build_dashboard_report,
    build_validation_report,
)
from crypto_decision_lab.export.artifacts import write_json_txt, render_dashboard_html

report = build_dashboard_report()
# Create HTML first, then validate the produced artifact content.
placeholder_validation = build_validation_report(report, "")
html_path = render_dashboard_html(report, placeholder_validation, output_dir="reports/sprint5b/dashboard")
html = Path(html_path).read_text(encoding="utf-8")
validation = build_validation_report(report, html)
html_path = render_dashboard_html(report, validation, output_dir="reports/sprint5b/dashboard")
artifacts = write_json_txt(validation, output_dir="reports/sprint5b", stem="interactive_research_dashboard_validation_report")

print("=== Sprint 5B Interactive Research Dashboard Validation ===")
print(f"Validation schema: {validation.schema}")
print(f"Validation status: {validation.validation_status}")
print(f"Dashboard status: {validation.dashboard_status}")
print(f"Model blocked: {validation.model_blocked}")
print(f"Dashboard contract valid: {validation.dashboard_contract_valid}")
print(f"HTML artifact valid: {validation.html_artifact_valid}")
print(f"KPI panel valid: {validation.kpi_panel_valid}")
print(f"Route panel valid: {validation.route_panel_valid}")
print(f"Safety panel valid: {validation.safety_panel_valid}")
print(f"Research allowed: {validation.research_allowed}")
print(f"Operational decision allowed: {validation.operational_decision_allowed}")
print(f"App mode: {validation.app_mode}")
print(f"Quality score: {validation.quality_score:.4f}")
print(f"Binance route: {validation.binance_route}")
print(f"OKX route: {validation.okx_route}")
print(f"Bybit route: {validation.bybit_route}")
print(f"API key required: {validation.api_key_required}")
print(f"API key present: {validation.api_key_present}")
print(f"Account connection required: {validation.account_connection_required}")
print(f"Orders generated: {validation.orders_generated}")
print(f"Issues: {validation.issues}")
print(f"Action: {validation.action}")
print(f"Next required gate: {validation.next_required_gate}")
print(f"Generated files: {artifacts | {'html': html_path}}")
