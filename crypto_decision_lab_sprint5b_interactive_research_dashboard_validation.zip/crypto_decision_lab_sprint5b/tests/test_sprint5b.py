import pytest
from pathlib import Path
from crypto_decision_lab.pipeline.research_dashboard_validation import (
    build_dashboard_report,
    build_validation_report,
    dashboard_contract_valid,
    safety_valid,
    widget_contract_valid,
    validate_html_content,
    report_to_dict,
)
from crypto_decision_lab.export.artifacts import write_json_txt, render_dashboard_html


def _html():
    report = build_dashboard_report()
    validation = build_validation_report(report, "")
    # This mirrors the dashboard content contract without requiring a filesystem.
    return "QRDS/QOS Interactive Research Dashboard Research-only No API key No real account No orders No real capital OKX Binance Bybit PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH SIMULATION_FIXTURE_REPLAY PENDING_BLOCKED_BY_403 INTERACTIVE_RESEARCH_ONLY"


def _validation():
    return build_validation_report(build_dashboard_report(), _html())


def test_dashboard_contract_passes():
    assert dashboard_contract_valid(build_dashboard_report())


def test_validation_report_passes():
    assert _validation().validation_status == "PASS"


@pytest.mark.parametrize("field,expected", [('schema', 'qrds.interactive_research_dashboard_validation_report.v1'), ('validation_status', 'PASS'), ('model_blocked', False), ('dashboard_status', 'PASS'), ('dashboard_contract_valid', True), ('html_artifact_expected', True), ('html_artifact_valid', True), ('kpi_panel_valid', True), ('route_panel_valid', True), ('safety_panel_valid', True), ('research_allowed', True), ('operational_decision_allowed', False), ('app_mode', 'INTERACTIVE_RESEARCH_ONLY'), ('quality_score', 1.0), ('simulation_exchange', 'binance'), ('binance_route', 'SIMULATION_FIXTURE_REPLAY'), ('okx_route', 'PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH'), ('bybit_route', 'PENDING_BLOCKED_BY_403'), ('live_pipeline_enabled', False), ('network_calls_executed', False), ('api_key_required', False), ('api_key_present', False), ('account_connection_required', False), ('websocket_used', False), ('real_capital_used', False), ('exchange_connected', False), ('orders_generated', False), ('total_normalized_candles', 10), ('feature_rows', 10), ('next_required_gate', 'INTERACTIVE_RESEARCH_APP_STREAMLIT_OPTIONAL_REQUIRED')])
def test_expected_validation_fields(field, expected):
    assert getattr(_validation(), field) == expected


@pytest.mark.parametrize("flag", [
    "live_pipeline_enabled",
    "network_calls_executed",
    "api_key_required",
    "api_key_present",
    "account_connection_required",
    "websocket_used",
    "real_capital_used",
    "exchange_connected",
    "orders_generated",
])
def test_safety_flags_false(flag):
    assert getattr(_validation(), flag) is False


@pytest.mark.parametrize("token", [
    "QRDS/QOS",
    "Interactive Research Dashboard",
    "Research-only",
    "No API key",
    "No real account",
    "No orders",
    "No real capital",
    "OKX",
    "Binance",
    "Bybit",
    "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_APPROVED_NO_AUTH",
    "INTERACTIVE_RESEARCH_ONLY",
])
def test_html_required_tokens(token):
    assert token in _html()


@pytest.mark.parametrize("route", ["okx", "binance", "bybit"])
def test_route_widgets(route):
    assert route in build_dashboard_report().widgets["routes"]


@pytest.mark.parametrize("bad_field,bad_value", [
    ("dashboard_status", "BLOCKED"),
    ("model_blocked", True),
    ("research_allowed", False),
    ("operational_decision_allowed", True),
    ("app_mode", "OPERATIONAL"),
    ("quality_score", 0.10),
    ("simulation_exchange", "okx"),
    ("binance_route", "REAL_BASE"),
    ("okx_route", "INVALID"),
    ("bybit_route", "ACTIVE"),
    ("api_key_required", True),
    ("api_key_present", True),
    ("account_connection_required", True),
    ("orders_generated", True),
])
def test_invalid_dashboard_mutations_block(bad_field, bad_value):
    r = build_dashboard_report()
    data = r.__dict__.copy()
    data[bad_field] = bad_value
    mutated = type(r)(**data)
    v = build_validation_report(mutated, _html())
    assert v.validation_status == "BLOCKED"


@pytest.mark.parametrize("check", [
    dashboard_contract_valid,
    safety_valid,
    widget_contract_valid,
    lambda r: validate_html_content(_html()),
])
def test_validation_checks_true(check):
    assert check(build_dashboard_report())


def test_artifact_writers(tmp_path):
    r = build_dashboard_report()
    v = build_validation_report(r, _html())
    out = write_json_txt(v, output_dir=tmp_path, stem="x")
    html = render_dashboard_html(r, v, output_dir=tmp_path / "dashboard")
    assert Path(out["json"]).exists()
    assert Path(out["txt"]).exists()
    assert Path(html).exists()


def test_artifact_contents(tmp_path):
    r = build_dashboard_report()
    v = build_validation_report(r, _html())
    out = write_json_txt(v, output_dir=tmp_path, stem="x")
    html = render_dashboard_html(r, v, output_dir=tmp_path / "dashboard")
    assert "interactive_research_dashboard_validation" in Path(out["json"]).read_text(encoding="utf-8")
    assert "QRDS/QOS" in Path(html).read_text(encoding="utf-8")
