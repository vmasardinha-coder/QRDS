from pathlib import Path

from crypto_decision_lab.ingestion.binance_klines import load_binance_klines_csv
from crypto_decision_lab.dql.report import generate_data_quality_report


def main():
    path = Path("data/fixtures/BTCUSDT-1h-sample.csv")
    candles = load_binance_klines_csv(path)
    report = generate_data_quality_report(candles, expected_interval_seconds=3600)

    print("=== Data Quality Report Offline ===")
    print(f"Total candles: {report.total_candles}")
    print(f"DQS: {report.dqs:.4f}")
    print(f"Status: {report.status}")
    print(f"Duplicate timestamps: {report.duplicate_timestamps}")
    print(f"Gap count: {report.gap_count}")
    print(f"Invalid OHLC: {report.invalid_ohlc_count}")
    print(f"Invalid prices: {report.invalid_price_count}")
    print(f"Invalid volume: {report.invalid_volume_count}")
    print(f"Missing values: {report.missing_values_count}")

    if report.issues:
        print("Issues:")
        for issue in report.issues:
            print(f"- {issue}")
    else:
        print("Issues: none")


if __name__ == "__main__":
    main()
