from crypto_decision_lab.domain.models import DecisionRecord
from crypto_decision_lab.dql.score import is_model_blocked


def make_dummy_decision(
    dqs: float,
    expected_utility_long: float,
    expected_utility_short: float,
) -> DecisionRecord:
    if is_model_blocked(dqs):
        return DecisionRecord(
            decision="No Trade",
            reason="No Trade técnico — DQS abaixo do threshold",
            dqs=dqs,
        )

    if expected_utility_long > expected_utility_short and expected_utility_long > 0:
        return DecisionRecord(
            decision="Long",
            reason="Utilidade esperada Long > Short e positiva",
            dqs=dqs,
        )

    if expected_utility_short > expected_utility_long and expected_utility_short > 0:
        return DecisionRecord(
            decision="Short",
            reason="Utilidade esperada Short > Long e positiva",
            dqs=dqs,
        )

    return DecisionRecord(
        decision="No Trade",
        reason="No Trade econômico — nenhuma utilidade positiva dominante",
        dqs=dqs,
    )
