from dataclasses import dataclass
from typing import List

from crypto_decision_lab.config import DQS_THRESHOLD
from crypto_decision_lab.domain.models import MarketCandle
from crypto_decision_lab.dql.score import calculate_dqs
from crypto_decision_lab.dql.validators import (
    validate_ohlc,
    validate_timestamp_order,
    validate_missing_values,
    validate_positive_prices,
    validate_non_negative_volume,
)


@dataclass(frozen=True)
class DataQualityReport:
    total_candles: int
    duplicate_timestamps: int
    gap_count: int
    invalid_ohlc_count: int
    invalid_price_count: int
    invalid_volume_count: int
    missing_values_count: int
    dqs: float
    status: str
    issues: List[str]


def count_duplicate_timestamps(candles: List[MarketCandle]) -> int:
    seen = set()
    duplicates = 0
    for candle in candles:
        if candle.timestamp in seen:
            duplicates += 1
        seen.add(candle.timestamp)
    return duplicates


def count_gaps(candles: List[MarketCandle], expected_interval_seconds: int) -> int:
    if len(candles) < 2:
        return 0

    gaps = 0
    ordered = sorted(candles, key=lambda c: c.timestamp)
    for prev, current in zip(ordered, ordered[1:]):
        delta = int((current.timestamp - prev.timestamp).total_seconds())
        if delta != expected_interval_seconds:
            gaps += 1
    return gaps


def generate_data_quality_report(
    candles: List[MarketCandle],
    expected_interval_seconds: int,
) -> DataQualityReport:
    total = len(candles)
    issues = []

    if total == 0:
        return DataQualityReport(
            total_candles=0,
            duplicate_timestamps=0,
            gap_count=0,
            invalid_ohlc_count=0,
            invalid_price_count=0,
            invalid_volume_count=0,
            missing_values_count=0,
            dqs=0.0,
            status="BLOCKED",
            issues=["empty_dataset"],
        )

    duplicate_timestamps = count_duplicate_timestamps(candles)
    gap_count = count_gaps(candles, expected_interval_seconds)
    invalid_ohlc_count = sum(1 for c in candles if not validate_ohlc(c))
    invalid_price_count = sum(1 for c in candles if not validate_positive_prices(c))
    invalid_volume_count = sum(1 for c in candles if not validate_non_negative_volume(c))
    missing_values_count = 0 if validate_missing_values(candles) else 1
    timestamp_order_ok = validate_timestamp_order(candles)

    if duplicate_timestamps:
        issues.append("duplicate_timestamps")
    if gap_count:
        issues.append("timestamp_gaps")
    if invalid_ohlc_count:
        issues.append("invalid_ohlc")
    if invalid_price_count:
        issues.append("invalid_prices")
    if invalid_volume_count:
        issues.append("invalid_volume")
    if missing_values_count:
        issues.append("missing_values")
    if not timestamp_order_ok:
        issues.append("timestamp_order")

    completeness_penalty = (duplicate_timestamps + gap_count) / max(total, 1)
    consistency_penalty = (
        invalid_ohlc_count + invalid_price_count + invalid_volume_count + missing_values_count
    ) / max(total, 1)

    completeness = max(0.0, 1.0 - completeness_penalty)
    freshness = 1.0
    consistency = max(0.0, 1.0 - consistency_penalty)
    temporality = 1.0 if timestamp_order_ok and duplicate_timestamps == 0 else 0.0

    dqs = calculate_dqs(completeness, freshness, consistency, temporality)
    status = "PASS" if dqs >= DQS_THRESHOLD and not issues else "BLOCKED"

    return DataQualityReport(
        total_candles=total,
        duplicate_timestamps=duplicate_timestamps,
        gap_count=gap_count,
        invalid_ohlc_count=invalid_ohlc_count,
        invalid_price_count=invalid_price_count,
        invalid_volume_count=invalid_volume_count,
        missing_values_count=missing_values_count,
        dqs=dqs,
        status=status,
        issues=issues,
    )
