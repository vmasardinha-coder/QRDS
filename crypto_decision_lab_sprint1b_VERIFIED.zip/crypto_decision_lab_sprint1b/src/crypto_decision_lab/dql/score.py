from crypto_decision_lab.config import DQS_THRESHOLD


def calculate_dqs(
    completeness: float,
    freshness: float,
    consistency: float,
    temporality: float,
) -> float:
    values = [completeness, freshness, consistency, temporality]
    bounded = [max(0.0, min(1.0, float(v))) for v in values]
    return round(sum(bounded) / 4.0, 4)


def is_model_blocked(dqs: float) -> bool:
    return dqs < DQS_THRESHOLD
