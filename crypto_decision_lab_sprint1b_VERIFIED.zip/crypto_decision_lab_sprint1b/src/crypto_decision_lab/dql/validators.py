from typing import List

from crypto_decision_lab.domain.models import MarketCandle


def validate_ohlc(candle: MarketCandle) -> bool:
    return (
        candle.low <= candle.open <= candle.high
        and candle.low <= candle.close <= candle.high
        and candle.low <= candle.high
    )


def validate_timestamp_order(candles: List[MarketCandle]) -> bool:
    for i in range(1, len(candles)):
        if candles[i].timestamp <= candles[i - 1].timestamp:
            return False
    return True


def validate_missing_values(candles: List[MarketCandle]) -> bool:
    for c in candles:
        if any(
            v is None
            for v in (c.timestamp, c.open, c.high, c.low, c.close, c.volume)
        ):
            return False
    return True


def validate_positive_prices(candle: MarketCandle) -> bool:
    return all(
        v is not None and v > 0
        for v in (candle.open, candle.high, candle.low, candle.close)
    )


def validate_non_negative_volume(candle: MarketCandle) -> bool:
    return candle.volume is not None and candle.volume >= 0
