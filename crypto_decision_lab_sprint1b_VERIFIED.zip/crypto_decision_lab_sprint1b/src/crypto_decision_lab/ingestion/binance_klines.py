import csv
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import List

from crypto_decision_lab.domain.models import MarketCandle


def _timestamp_from_ms(ms: str) -> datetime:
    return datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc)


def _parse_row(row: list[str]) -> MarketCandle:
    return MarketCandle(
        timestamp=_timestamp_from_ms(row[0]),
        open=float(row[1]),
        high=float(row[2]),
        low=float(row[3]),
        close=float(row[4]),
        volume=float(row[5]),
    )


def load_binance_klines_csv(path: str | Path) -> List[MarketCandle]:
    path = Path(path)
    candles: List[MarketCandle] = []

    with path.open("r", newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            if not row:
                continue
            if row[0].lower() in {"open_time", "timestamp"}:
                continue
            candles.append(_parse_row(row))

    return candles


def load_binance_klines_zip(path: str | Path) -> List[MarketCandle]:
    path = Path(path)

    with zipfile.ZipFile(path) as zf:
        csv_names = [name for name in zf.namelist() if name.endswith(".csv")]
        if not csv_names:
            raise ValueError("ZIP não contém CSV.")
        with zf.open(csv_names[0], "r") as f:
            text = f.read().decode("utf-8").splitlines()
            reader = csv.reader(text)
            return [_parse_row(row) for row in reader if row and row[0].lower() not in {"open_time", "timestamp"}]
