from datetime import datetime, timedelta, timezone

from crypto_decision_lab.domain.models import MarketCandle
from crypto_decision_lab.dql.validators import (
    validate_ohlc,
    validate_timestamp_order,
    validate_missing_values,
    validate_positive_prices,
    validate_non_negative_volume,
)
from crypto_decision_lab.dql.score import calculate_dqs, is_model_blocked
from crypto_decision_lab.decision.dummy_decision import make_dummy_decision


def main():
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    candles = [
        MarketCandle(
            timestamp=base + timedelta(hours=i),
            open=50000.0 + i * 10,
            high=50100.0 + i * 10,
            low=49900.0 + i * 10,
            close=50050.0 + i * 10,
            volume=100.0 + i,
        )
        for i in range(5)
    ]

    print("=== Demo Sprint 0/1 fake ===")
    print(f"OHLC válido: {all(validate_ohlc(c) for c in candles)}")
    print(f"Timestamp order: {validate_timestamp_order(candles)}")
    print(f"Missing values: {validate_missing_values(candles)}")
    print(f"Positive prices: {all(validate_positive_prices(c) for c in candles)}")
    print(f"Non-negative volume: {all(validate_non_negative_volume(c) for c in candles)}")

    dqs = calculate_dqs(1.0, 1.0, 1.0, 1.0)
    print(f"DQS: {dqs}")
    print(f"Blocked: {is_model_blocked(dqs)}")

    decision = make_dummy_decision(dqs, 0.05, 0.02)
    print(decision)


if __name__ == "__main__":
    main()
