# Crypto Decision Lab — Sprint 1B

Sprint 1B: Data Quality Report Offline.

Escopo:
- Sem Binance live
- Sem API key
- Sem WebSocket
- Sem ordens
- Sem capital real
- Apenas CSV/ZIP local com dados históricos offline

Comandos:

```bash
pip install -r requirements.txt
pip install -e .
pytest tests/
python demo_data_quality_report.py
```
