from crypto_decision_lab.decision.dummy_decision import make_dummy_decision


def test_decisao_long():
    decision = make_dummy_decision(0.85, 0.05, 0.02)
    assert decision.decision == "Long"


def test_decisao_short():
    decision = make_dummy_decision(0.85, 0.02, 0.05)
    assert decision.decision == "Short"


def test_no_trade_tecnico():
    decision = make_dummy_decision(0.75, 0.05, 0.02)
    assert decision.decision == "No Trade"
    assert "técnico" in decision.reason


def test_no_trade_economico():
    decision = make_dummy_decision(0.85, 0.0, 0.0)
    assert decision.decision == "No Trade"
    assert "econômico" in decision.reason


def test_no_trade_economico_utilidades_negativas():
    decision = make_dummy_decision(0.85, -0.01, -0.02)
    assert decision.decision == "No Trade"
