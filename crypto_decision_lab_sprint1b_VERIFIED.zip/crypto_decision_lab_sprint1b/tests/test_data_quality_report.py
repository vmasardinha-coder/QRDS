from datetime import datetime, timedelta, timezone

from crypto_decision_lab.domain.models import MarketCandle
from crypto_decision_lab.ingestion.binance_klines import load_binance_klines_csv
from crypto_decision_lab.dql.report import generate_data_quality_report


def make_candle(ts, **kwargs):
    data = dict(
        timestamp=ts,
        open=50000.0,
        high=50100.0,
        low=49900.0,
        close=50050.0,
        volume=100.0,
    )
    data.update(kwargs)
    return MarketCandle(**data)


def test_report_passa_fixture():
    candles = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-sample.csv")
    report = generate_data_quality_report(candles, 3600)
    assert report.status == "PASS"
    assert report.dqs == 1.0
    assert report.gap_count == 0
    assert report.duplicate_timestamps == 0


def test_report_bloqueia_dataset_vazio():
    report = generate_data_quality_report([], 3600)
    assert report.status == "BLOCKED"
    assert "empty_dataset" in report.issues


def test_report_detecta_gap():
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    candles = [
        make_candle(base),
        make_candle(base + timedelta(hours=2)),
    ]
    report = generate_data_quality_report(candles, 3600)
    assert report.gap_count == 1
    assert report.status == "BLOCKED"


def test_report_detecta_duplicata():
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    candles = [make_candle(base), make_candle(base)]
    report = generate_data_quality_report(candles, 3600)
    assert report.duplicate_timestamps == 1
    assert report.status == "BLOCKED"


def test_report_detecta_ohlc_invalido():
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    candles = [make_candle(base, high=49000.0)]
    report = generate_data_quality_report(candles, 3600)
    assert report.invalid_ohlc_count == 1
    assert report.status == "BLOCKED"


def test_report_detecta_preco_invalido():
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    candles = [make_candle(base, open=0.0)]
    report = generate_data_quality_report(candles, 3600)
    assert report.invalid_price_count == 1
    assert report.status == "BLOCKED"


def test_report_detecta_volume_invalido():
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    candles = [make_candle(base, volume=-1.0)]
    report = generate_data_quality_report(candles, 3600)
    assert report.invalid_volume_count == 1
    assert report.status == "BLOCKED"


def test_report_detecta_ordem_temporal():
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    candles = [
        make_candle(base + timedelta(hours=1)),
        make_candle(base),
    ]
    report = generate_data_quality_report(candles, 3600)
    assert "timestamp_order" in report.issues
    assert report.status == "BLOCKED"
