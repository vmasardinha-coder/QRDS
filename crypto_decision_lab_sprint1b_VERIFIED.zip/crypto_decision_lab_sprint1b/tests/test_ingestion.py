from pathlib import Path
import zipfile

from crypto_decision_lab.ingestion.binance_klines import (
    load_binance_klines_csv,
    load_binance_klines_zip,
)


def test_load_fixture_csv():
    candles = load_binance_klines_csv(Path("data/fixtures/BTCUSDT-1h-sample.csv"))
    assert len(candles) == 5
    assert candles[0].open == 50000.0
    assert candles[-1].close == 50450.0


def test_load_csv_with_header(tmp_path):
    csv_path = tmp_path / "sample.csv"
    csv_path.write_text(
        "open_time,open,high,low,close,volume\n"
        "1704067200000,50000,50100,49900,50050,100\n"
    )
    candles = load_binance_klines_csv(csv_path)
    assert len(candles) == 1


def test_load_zip(tmp_path):
    csv_path = tmp_path / "sample.csv"
    zip_path = tmp_path / "sample.zip"
    csv_path.write_text("1704067200000,50000,50100,49900,50050,100\n")
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.write(csv_path, arcname="sample.csv")
    candles = load_binance_klines_zip(zip_path)
    assert len(candles) == 1


def test_timestamp_timezone_utc():
    candles = load_binance_klines_csv(Path("data/fixtures/BTCUSDT-1h-sample.csv"))
    assert candles[0].timestamp.tzinfo is not None
