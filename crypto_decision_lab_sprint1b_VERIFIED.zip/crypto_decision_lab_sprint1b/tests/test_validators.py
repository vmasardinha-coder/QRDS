from datetime import datetime, timezone

from crypto_decision_lab.domain.models import MarketCandle
from crypto_decision_lab.dql.validators import (
    validate_ohlc,
    validate_timestamp_order,
    validate_missing_values,
    validate_positive_prices,
    validate_non_negative_volume,
)


def make_candle(**kwargs):
    data = dict(
        timestamp=datetime(2024, 1, 1, tzinfo=timezone.utc),
        open=50000.0,
        high=50100.0,
        low=49900.0,
        close=50050.0,
        volume=100.0,
    )
    data.update(kwargs)
    return MarketCandle(**data)


def test_candle_ohlc_valido():
    assert validate_ohlc(make_candle()) is True


def test_candle_ohlc_invalido():
    assert validate_ohlc(make_candle(high=49900.0, low=50100.0)) is False


def test_timestamps_em_ordem():
    candles = [
        make_candle(timestamp=datetime(2024, 1, 1, tzinfo=timezone.utc)),
        make_candle(timestamp=datetime(2024, 1, 2, tzinfo=timezone.utc)),
    ]
    assert validate_timestamp_order(candles) is True


def test_timestamps_fora_de_ordem():
    candles = [
        make_candle(timestamp=datetime(2024, 1, 2, tzinfo=timezone.utc)),
        make_candle(timestamp=datetime(2024, 1, 1, tzinfo=timezone.utc)),
    ]
    assert validate_timestamp_order(candles) is False


def test_missing_values():
    assert validate_missing_values([make_candle()]) is True
    assert validate_missing_values([make_candle(volume=None)]) is False


def test_precos_positivos():
    assert validate_positive_prices(make_candle()) is True


def test_preco_zero_ou_negativo():
    assert validate_positive_prices(make_candle(open=0.0)) is False
    assert validate_positive_prices(make_candle(open=-100.0)) is False


def test_volume_nao_negativo():
    assert validate_non_negative_volume(make_candle(volume=0.0)) is True
    assert validate_non_negative_volume(make_candle(volume=-1.0)) is False
