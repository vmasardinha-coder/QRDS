# QRDS / QOS - Sprint 4J

Bybit Public HTTP Remediation Harness.

Scope:
- public HTTP only
- no API key
- no real account
- no WebSocket
- no orders
- no real capital
- tries Bybit public endpoints with fixture default and optional live public HTTP mode

Approval phrase required for live mode:

APROVO TESTE PUBLICO HTTP LIVE SEM API KEY, SEM CONTA REAL, SEM ORDEM E SEM CAPITAL REAL.
