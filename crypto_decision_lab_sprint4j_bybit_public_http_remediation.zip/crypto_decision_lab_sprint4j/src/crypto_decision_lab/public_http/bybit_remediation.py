from __future__ import annotations

import json
import os
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

APPROVAL_PHRASE = "APROVO TESTE PUBLICO HTTP LIVE SEM API KEY, SEM CONTA REAL, SEM ORDEM E SEM CAPITAL REAL."
BASE_URL = "https://api.bybit.com"
SAFETY_POLICY = "PUBLIC_ONLY_NO_AUTH_BYBIT_REMEDIATION"

FORBIDDEN_ENV_KEYS = (
    "BYBIT_API_KEY",
    "BYBIT_API_SECRET",
    "BYBIT_SECRET",
    "BYBIT_ACCESS_KEY",
    "BYBIT_PRIVATE_KEY",
)

@dataclass(frozen=True)
class BybitEndpointSpec:
    name: str
    path: str
    params: dict[str, str]
    expected_shape: str
    is_kline: bool = False

    @property
    def url(self) -> str:
        query = urllib.parse.urlencode(self.params)
        return f"{BASE_URL}{self.path}?{query}" if query else f"{BASE_URL}{self.path}"

@dataclass(frozen=True)
class PublicEndpointAttempt:
    exchange: str
    endpoint_name: str
    url_path: str
    success: bool
    http_status: int | None
    error: str | None
    response_shape_valid: bool
    normalized_candles: int

@dataclass(frozen=True)
class BybitRemediationReport:
    schema: str
    remediation_status: str
    model_blocked: bool
    manual_approval_required: bool
    manual_approval_granted: bool
    explicit_approval_phrase_valid: bool
    live_http_opt_in_enabled: bool
    live_remediation_executed: bool
    fixture_replay_used: bool
    network_calls_executed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    api_key_present: bool
    account_connection_required: bool
    websocket_used: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    supported_exchanges: list[str]
    requested_exchange: str
    safety_policy: str
    attempts: list[PublicEndpointAttempt]
    successful_endpoints: list[str]
    failed_endpoints: dict[str, str]
    kline_successful_endpoints: list[str]
    normalized_candles_total: int
    bybit_http_403_seen: bool
    remediation_notes: list[str]
    next_required_gate: str
    issues: list[str]
    action: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def build_bybit_endpoint_specs() -> list[BybitEndpointSpec]:
    return [
        BybitEndpointSpec("server_time", "/v5/market/time", {}, "time"),
        BybitEndpointSpec("ticker_spot", "/v5/market/tickers", {"category": "spot", "symbol": "BTCUSDT"}, "ticker"),
        BybitEndpointSpec("ticker_linear", "/v5/market/tickers", {"category": "linear", "symbol": "BTCUSDT"}, "ticker"),
        BybitEndpointSpec("kline_spot", "/v5/market/kline", {"category": "spot", "symbol": "BTCUSDT", "interval": "60", "limit": "5"}, "kline", True),
        BybitEndpointSpec("kline_linear", "/v5/market/kline", {"category": "linear", "symbol": "BTCUSDT", "interval": "60", "limit": "5"}, "kline", True),
    ]


def api_key_present() -> bool:
    return any(bool(os.environ.get(key)) for key in FORBIDDEN_ENV_KEYS)


def explicit_approval_valid(approval_phrase: str | None) -> bool:
    return (approval_phrase or "").strip() == APPROVAL_PHRASE


def fixture_payload(spec: BybitEndpointSpec) -> dict[str, Any]:
    if spec.expected_shape == "time":
        return {"retCode": 0, "retMsg": "OK", "result": {"timeSecond": "1700000000", "timeNano": "1700000000000000000"}}
    if spec.expected_shape == "ticker":
        return {"retCode": 0, "retMsg": "OK", "result": {"category": spec.params.get("category"), "list": [{"symbol": "BTCUSDT", "lastPrice": "50000.0"}]}}
    return {
        "retCode": 0,
        "retMsg": "OK",
        "result": {
            "category": spec.params.get("category"),
            "symbol": "BTCUSDT",
            "list": [
                ["1700000000000", "50000", "50100", "49900", "50050", "100", "5005000"],
                ["1700003600000", "50050", "50200", "50000", "50150", "101", "5065150"],
                ["1700007200000", "50150", "50300", "50100", "50250", "102", "5125500"],
                ["1700010800000", "50250", "50400", "50200", "50350", "103", "5186050"],
                ["1700014400000", "50350", "50500", "50300", "50450", "104", "5246800"],
            ],
        },
    }


def response_shape_valid(spec: BybitEndpointSpec, payload: dict[str, Any]) -> tuple[bool, int]:
    if payload.get("retCode") != 0:
        return False, 0
    result = payload.get("result")
    if not isinstance(result, dict):
        return False, 0
    if spec.expected_shape == "time":
        return "timeSecond" in result or "timeNano" in result, 0
    if spec.expected_shape == "ticker":
        items = result.get("list")
        return isinstance(items, list) and len(items) > 0, 0
    if spec.expected_shape == "kline":
        rows = result.get("list")
        if not isinstance(rows, list) or not rows:
            return False, 0
        normalized = 0
        for row in rows:
            if not isinstance(row, list) or len(row) < 6:
                return False, normalized
            int(row[0])
            float(row[1]); float(row[2]); float(row[3]); float(row[4]); float(row[5])
            normalized += 1
        return True, normalized
    return False, 0


def fetch_public_json(spec: BybitEndpointSpec, timeout_seconds: int = 8) -> tuple[int, dict[str, Any]]:
    request = urllib.request.Request(
        spec.url,
        headers={
            "User-Agent": "QRDS-QOS-public-http-smoke/1.0 (+no-auth; no-account; no-orders)",
            "Accept": "application/json",
            "Cache-Control": "no-cache",
        },
        method="GET",
    )
    with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
        status = int(response.status)
        raw = response.read().decode("utf-8")
        return status, json.loads(raw)


def build_attempt_from_payload(spec: BybitEndpointSpec, payload: dict[str, Any], http_status: int | None = 200) -> PublicEndpointAttempt:
    valid, normalized = response_shape_valid(spec, payload)
    return PublicEndpointAttempt(
        exchange="bybit",
        endpoint_name=spec.name,
        url_path=spec.path,
        success=valid,
        http_status=http_status,
        error=None if valid else "invalid_response_shape",
        response_shape_valid=valid,
        normalized_candles=normalized,
    )


def run_bybit_remediation(
    *,
    approval_phrase: str | None,
    live_http_opt_in_enabled: bool,
    fixture_replay_default: bool = True,
) -> BybitRemediationReport:
    manual_approval_required = True
    approval_ok = explicit_approval_valid(approval_phrase)
    key_present = api_key_present()
    issues: list[str] = []
    attempts: list[PublicEndpointAttempt] = []

    if key_present:
        issues.append("api_key_present_forbidden")
    if live_http_opt_in_enabled and not approval_ok:
        issues.append("explicit_approval_required")

    if issues:
        return BybitRemediationReport(
            schema="qrds.bybit_public_http_remediation_report.v1",
            remediation_status="BLOCKED",
            model_blocked=True,
            manual_approval_required=manual_approval_required,
            manual_approval_granted=approval_ok,
            explicit_approval_phrase_valid=approval_ok,
            live_http_opt_in_enabled=live_http_opt_in_enabled,
            live_remediation_executed=False,
            fixture_replay_used=True,
            network_calls_executed=False,
            authenticated_connection_used=False,
            api_key_required=False,
            api_key_present=key_present,
            account_connection_required=False,
            websocket_used=False,
            real_capital_used=False,
            exchange_connected=False,
            orders_generated=False,
            supported_exchanges=["binance", "bybit", "okx"],
            requested_exchange="bybit",
            safety_policy=SAFETY_POLICY,
            attempts=[],
            successful_endpoints=[],
            failed_endpoints={},
            kline_successful_endpoints=[],
            normalized_candles_total=0,
            bybit_http_403_seen=False,
            remediation_notes=[],
            next_required_gate="BYBIT_PUBLIC_HTTP_REMEDIATION_REVIEW_REQUIRED",
            issues=issues,
            action="NO_BYBIT_PUBLIC_HTTP_REMEDIATION_BLOCKED",
        )

    specs = build_bybit_endpoint_specs()
    use_fixture = fixture_replay_default and not live_http_opt_in_enabled

    for spec in specs:
        if use_fixture:
            attempts.append(build_attempt_from_payload(spec, fixture_payload(spec), 200))
            continue
        try:
            status, payload = fetch_public_json(spec)
            attempts.append(build_attempt_from_payload(spec, payload, status))
        except urllib.error.HTTPError as exc:
            attempts.append(PublicEndpointAttempt("bybit", spec.name, spec.path, False, int(exc.code), f"HTTPError:{exc}", False, 0))
        except Exception as exc:
            attempts.append(PublicEndpointAttempt("bybit", spec.name, spec.path, False, None, f"{exc.__class__.__name__}:{exc}", False, 0))

    successful = [a.endpoint_name for a in attempts if a.success]
    failed = {a.endpoint_name: (a.error or "unknown_error") for a in attempts if not a.success}
    kline_success = [a.endpoint_name for a in attempts if a.success and a.normalized_candles > 0]
    total_candles = sum(a.normalized_candles for a in attempts)
    http_403_seen = any(a.http_status == 403 for a in attempts)

    notes = [
        "public_http_only",
        "no_api_key",
        "no_account_connection",
        "no_websocket",
        "no_orders",
        "bybit_endpoint_fallback_chain_tested",
    ]
    if http_403_seen:
        notes.append("http_403_seen_consider_codespaces_ip_or_user_agent_or_regional_block")

    if kline_success:
        status = "PASS"
        action = "BYBIT_PUBLIC_HTTP_MARKET_DATA_AVAILABLE_REVIEW_REQUIRED"
    elif successful:
        status = "PARTIAL"
        action = "BYBIT_PUBLIC_HTTP_CONNECTIVITY_ONLY_REVIEW_REQUIRED"
        issues.append("bybit_public_kline_market_data_failed")
    else:
        status = "BLOCKED"
        action = "NO_BYBIT_PUBLIC_HTTP_ENDPOINT_AVAILABLE"
        issues.append("all_bybit_public_endpoints_failed")

    return BybitRemediationReport(
        schema="qrds.bybit_public_http_remediation_report.v1",
        remediation_status=status,
        model_blocked=False if status in {"PASS", "PARTIAL"} else True,
        manual_approval_required=manual_approval_required,
        manual_approval_granted=approval_ok,
        explicit_approval_phrase_valid=approval_ok,
        live_http_opt_in_enabled=live_http_opt_in_enabled,
        live_remediation_executed=live_http_opt_in_enabled,
        fixture_replay_used=use_fixture,
        network_calls_executed=live_http_opt_in_enabled,
        authenticated_connection_used=False,
        api_key_required=False,
        api_key_present=key_present,
        account_connection_required=False,
        websocket_used=False,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        supported_exchanges=["binance", "bybit", "okx"],
        requested_exchange="bybit",
        safety_policy=SAFETY_POLICY,
        attempts=attempts,
        successful_endpoints=successful,
        failed_endpoints=failed,
        kline_successful_endpoints=kline_success,
        normalized_candles_total=total_candles,
        bybit_http_403_seen=http_403_seen,
        remediation_notes=notes,
        next_required_gate="BYBIT_PUBLIC_HTTP_REMEDIATION_REVIEW_REQUIRED",
        issues=issues,
        action=action,
    )


def export_report(report: BybitRemediationReport, output_dir: str | Path = "reports/sprint4j") -> dict[str, str]:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    json_path = out / "bybit_public_http_remediation_report.json"
    txt_path = out / "bybit_public_http_remediation_report.txt"
    payload = report.to_dict()
    json_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    lines = [
        "QRDS Sprint 4J - Bybit Public HTTP Remediation Report",
        f"Status: {report.remediation_status}",
        f"Action: {report.action}",
        f"Live executed: {report.live_remediation_executed}",
        f"Network calls executed: {report.network_calls_executed}",
        f"API key required: {report.api_key_required}",
        f"API key present: {report.api_key_present}",
        f"Account connection required: {report.account_connection_required}",
        f"Orders generated: {report.orders_generated}",
        f"Successful endpoints: {report.successful_endpoints}",
        f"Failed endpoints: {report.failed_endpoints}",
        f"Kline successful endpoints: {report.kline_successful_endpoints}",
        f"Normalized candles total: {report.normalized_candles_total}",
        f"Issues: {report.issues if report.issues else 'none'}",
    ]
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
