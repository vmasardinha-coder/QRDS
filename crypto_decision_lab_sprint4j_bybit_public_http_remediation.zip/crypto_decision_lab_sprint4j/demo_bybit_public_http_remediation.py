import os
from crypto_decision_lab.public_http.bybit_remediation import export_report, run_bybit_remediation

approval = os.environ.get("QRDS_PUBLIC_HTTP_LIVE_SMOKE_APPROVAL", "")
live_enabled = os.environ.get("QRDS_BYBIT_PUBLIC_HTTP_REMEDIATION_LIVE", "0") == "1"

report = run_bybit_remediation(
    approval_phrase=approval,
    live_http_opt_in_enabled=live_enabled,
    fixture_replay_default=True,
)
files = export_report(report)

print("=== Sprint 4J Bybit Public HTTP Remediation ===")
print(f"Remediation schema: {report.schema}")
print(f"Remediation status: {report.remediation_status}")
print(f"Model blocked: {report.model_blocked}")
print(f"Manual approval required: {report.manual_approval_required}")
print(f"Manual approval granted: {report.manual_approval_granted}")
print(f"Explicit approval phrase valid: {report.explicit_approval_phrase_valid}")
print(f"Live HTTP opt-in enabled: {report.live_http_opt_in_enabled}")
print(f"Live remediation executed: {report.live_remediation_executed}")
print(f"Fixture replay used: {report.fixture_replay_used}")
print(f"Network calls executed: {report.network_calls_executed}")
print(f"Authenticated connection used: {report.authenticated_connection_used}")
print(f"API key required: {report.api_key_required}")
print(f"API key present: {report.api_key_present}")
print(f"Account connection required: {report.account_connection_required}")
print(f"WebSocket used: {report.websocket_used}")
print(f"Real capital used: {report.real_capital_used}")
print(f"Exchange connected: {report.exchange_connected}")
print(f"Orders generated: {report.orders_generated}")
print(f"Requested exchange: {report.requested_exchange}")
print(f"Supported exchanges: {report.supported_exchanges}")
print(f"Successful endpoints: {report.successful_endpoints}")
print(f"Failed endpoints: {report.failed_endpoints}")
print(f"Kline successful endpoints: {report.kline_successful_endpoints}")
print(f"Normalized candles total: {report.normalized_candles_total}")
print(f"Bybit HTTP 403 seen: {report.bybit_http_403_seen}")
print(f"Safety policy: {report.safety_policy}")
print(f"Next required gate: {report.next_required_gate}")
print(f"Issues: {report.issues if report.issues else 'none'}")
print(f"Action: {report.action}")
print(f"Generated files: {files}")
