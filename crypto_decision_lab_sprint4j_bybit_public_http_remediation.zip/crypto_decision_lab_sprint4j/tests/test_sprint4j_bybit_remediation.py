import pytest

from crypto_decision_lab.public_http.bybit_remediation import (
    APPROVAL_PHRASE,
    FORBIDDEN_ENV_KEYS,
    build_bybit_endpoint_specs,
    explicit_approval_valid,
    export_report,
    fixture_payload,
    response_shape_valid,
    run_bybit_remediation,
)


def clear_keys(monkeypatch):
    for key in FORBIDDEN_ENV_KEYS:
        monkeypatch.delenv(key, raising=False)


def fixture_report(monkeypatch):
    clear_keys(monkeypatch)
    return run_bybit_remediation(approval_phrase=APPROVAL_PHRASE, live_http_opt_in_enabled=False)


def test_endpoint_specs_count():
    assert len(build_bybit_endpoint_specs()) == 5


@pytest.mark.parametrize("expected", ["server_time", "ticker_spot", "ticker_linear", "kline_spot", "kline_linear"])
def test_endpoint_names_present(expected):
    assert expected in [s.name for s in build_bybit_endpoint_specs()]


@pytest.mark.parametrize("spec", build_bybit_endpoint_specs())
def test_endpoint_urls_are_bybit_public(spec):
    assert spec.url.startswith("https://api.bybit.com/v5/market/")


@pytest.mark.parametrize("spec", build_bybit_endpoint_specs())
def test_fixture_payloads_have_valid_shape(spec):
    valid, candles = response_shape_valid(spec, fixture_payload(spec))
    assert valid is True
    if spec.is_kline:
        assert candles == 5
    else:
        assert candles == 0


@pytest.mark.parametrize("spec", build_bybit_endpoint_specs())
def test_invalid_retcode_blocks_shape(spec):
    valid, candles = response_shape_valid(spec, {"retCode": 10001, "result": {}})
    assert valid is False
    assert candles == 0


@pytest.mark.parametrize("phrase,expected", [(APPROVAL_PHRASE, True), ("", False)])
def test_explicit_approval_phrase(phrase, expected):
    assert explicit_approval_valid(phrase) is expected


@pytest.mark.parametrize("key", FORBIDDEN_ENV_KEYS)
def test_forbidden_env_key_blocks(monkeypatch, key):
    clear_keys(monkeypatch)
    monkeypatch.setenv(key, "secret")
    report = run_bybit_remediation(approval_phrase=APPROVAL_PHRASE, live_http_opt_in_enabled=False)
    assert report.remediation_status == "BLOCKED"
    assert report.api_key_present is True
    assert "api_key_present_forbidden" in report.issues


def test_fixture_report_status_pass(monkeypatch):
    assert fixture_report(monkeypatch).remediation_status == "PASS"


def test_fixture_report_model_not_blocked(monkeypatch):
    assert fixture_report(monkeypatch).model_blocked is False


def test_fixture_report_uses_fixture(monkeypatch):
    assert fixture_report(monkeypatch).fixture_replay_used is True


def test_fixture_report_no_network(monkeypatch):
    assert fixture_report(monkeypatch).network_calls_executed is False


def test_fixture_report_no_auth(monkeypatch):
    assert fixture_report(monkeypatch).authenticated_connection_used is False


def test_fixture_report_no_api_key_required(monkeypatch):
    assert fixture_report(monkeypatch).api_key_required is False


def test_fixture_report_no_account_connection(monkeypatch):
    assert fixture_report(monkeypatch).account_connection_required is False


def test_fixture_report_no_orders(monkeypatch):
    assert fixture_report(monkeypatch).orders_generated is False


def test_fixture_report_successful_endpoints(monkeypatch):
    assert len(fixture_report(monkeypatch).successful_endpoints) == 5


def test_fixture_report_kline_success(monkeypatch):
    assert fixture_report(monkeypatch).kline_successful_endpoints == ["kline_spot", "kline_linear"]


def test_blocked_when_live_enabled_without_approval(monkeypatch):
    clear_keys(monkeypatch)
    r = run_bybit_remediation(approval_phrase="", live_http_opt_in_enabled=True)
    assert r.remediation_status == "BLOCKED"
    assert "explicit_approval_required" in r.issues


def test_export_report_writes_files(tmp_path, monkeypatch):
    r = fixture_report(monkeypatch)
    files = export_report(r, tmp_path)
    assert set(files) == {"json", "txt"}
    assert "bybit_public_http_remediation_report.json" in files["json"]


@pytest.mark.parametrize("attempt_name", ["server_time", "ticker_spot", "ticker_linear", "kline_spot", "kline_linear"])
def test_attempts_are_recorded(attempt_name, monkeypatch):
    r = fixture_report(monkeypatch)
    assert attempt_name in [a.endpoint_name for a in r.attempts]


def test_safety_flag_real_capital_false(monkeypatch):
    assert fixture_report(monkeypatch).real_capital_used is False


def test_safety_flag_exchange_connected_false(monkeypatch):
    assert fixture_report(monkeypatch).exchange_connected is False


def test_safety_flag_websocket_false(monkeypatch):
    assert fixture_report(monkeypatch).websocket_used is False


def test_safety_flag_requested_exchange_bybit(monkeypatch):
    assert fixture_report(monkeypatch).requested_exchange == "bybit"


def test_safety_policy_public_only(monkeypatch):
    assert "PUBLIC_ONLY" in fixture_report(monkeypatch).safety_policy


def test_next_gate_review_required(monkeypatch):
    assert fixture_report(monkeypatch).next_required_gate == "BYBIT_PUBLIC_HTTP_REMEDIATION_REVIEW_REQUIRED"


def test_no_issues_for_fixture(monkeypatch):
    assert fixture_report(monkeypatch).issues == []


def test_normalized_candles_total_fixture(monkeypatch):
    assert fixture_report(monkeypatch).normalized_candles_total == 10


def test_report_schema(monkeypatch):
    assert fixture_report(monkeypatch).schema == "qrds.bybit_public_http_remediation_report.v1"
