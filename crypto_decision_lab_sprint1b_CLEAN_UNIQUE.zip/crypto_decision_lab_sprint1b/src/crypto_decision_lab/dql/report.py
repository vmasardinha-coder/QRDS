"""Offline Data Quality Report for historical candles.

Sprint 1B scope:
- local historical candles only;
- no Binance API;
- no WebSocket;
- no database;
- no trading.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass, field

from crypto_decision_lab.config import DQS_THRESHOLD
from crypto_decision_lab.domain.models import MarketCandle
from crypto_decision_lab.dql.score import calculate_dqs, is_model_blocked
from crypto_decision_lab.dql.validators import (
    validate_missing_values,
    validate_non_negative_volume,
    validate_ohlc,
    validate_positive_prices,
    validate_timestamp_order,
)


@dataclass(frozen=True)
class DataQualityIssue:
    """One detected quality issue in an offline candle dataset."""

    issue_type: str
    severity: str
    message: str
    affected_records: int = 0


@dataclass(frozen=True)
class DataQualityReport:
    """Compact offline quality report for one candle window."""

    total_candles: int
    dqs: float
    blocked: bool
    completeness: float
    freshness: float
    consistency: float
    temporality: float
    expected_interval_seconds: int | None
    duplicate_timestamps: int
    gap_count: int
    issues: tuple[DataQualityIssue, ...] = field(default_factory=tuple)

    @property
    def status(self) -> str:
        return "BLOCKED" if self.blocked else "PASS"

    def to_lines(self) -> list[str]:
        """Human-readable report lines for CLI demos."""
        lines = [
            "=== Data Quality Report Offline ===",
            f"Total candles: {self.total_candles}",
            f"DQS: {self.dqs:.4f}",
            f"Status: {self.status}",
            f"Completeness: {self.completeness:.4f}",
            f"Freshness: {self.freshness:.4f}",
            f"Consistency: {self.consistency:.4f}",
            f"Temporality: {self.temporality:.4f}",
            f"Expected interval seconds: {self.expected_interval_seconds}",
            f"Duplicate timestamps: {self.duplicate_timestamps}",
            f"Gap count: {self.gap_count}",
        ]
        if self.issues:
            lines.append("Issues:")
            for issue in self.issues:
                lines.append(
                    f"- [{issue.severity}] {issue.issue_type}: "
                    f"{issue.message} ({issue.affected_records})"
                )
        else:
            lines.append("Issues: none")
        return lines


def infer_expected_interval_seconds(candles: Sequence[MarketCandle]) -> int | None:
    """Infer the most common positive candle interval, in seconds."""
    if len(candles) < 2:
        return None

    diffs: list[int] = []
    for i in range(1, len(candles)):
        diff = int((candles[i].timestamp - candles[i - 1].timestamp).total_seconds())
        if diff > 0:
            diffs.append(diff)

    if not diffs:
        return None

    return Counter(diffs).most_common(1)[0][0]


def _safe_ratio(valid_count: int, total_count: int) -> float:
    if total_count <= 0:
        return 0.0
    return round(valid_count / total_count, 4)


def _count_duplicate_timestamps(candles: Sequence[MarketCandle]) -> int:
    counts = Counter(candle.timestamp for candle in candles)
    return sum(count - 1 for count in counts.values() if count > 1)


def _count_gaps(
    candles: Sequence[MarketCandle], expected_interval_seconds: int | None
) -> int:
    if expected_interval_seconds is None or len(candles) < 2:
        return 0

    gaps = 0
    for i in range(1, len(candles)):
        diff = int((candles[i].timestamp - candles[i - 1].timestamp).total_seconds())
        if diff > expected_interval_seconds:
            missing_steps = max((diff // expected_interval_seconds) - 1, 1)
            gaps += missing_steps
    return gaps


def build_data_quality_report(
    candles: Sequence[MarketCandle],
    expected_interval_seconds: int | None = None,
) -> DataQualityReport:
    """Build an offline Data Quality Report for local candles.

    The report is intentionally simple. It does not certify live trading.
    """
    total = len(candles)
    if total == 0:
        raise ValueError("Cannot build Data Quality Report for an empty candle list")

    expected_interval_seconds = expected_interval_seconds or infer_expected_interval_seconds(candles)

    issues: list[DataQualityIssue] = []

    missing_ok = validate_missing_values(candles)
    missing_bad = 0 if missing_ok else 1
    if not missing_ok:
        issues.append(
            DataQualityIssue(
                issue_type="missing_values",
                severity="critical",
                message="At least one candle has a missing required value",
                affected_records=missing_bad,
            )
        )

    ohlc_bad = sum(1 for candle in candles if not validate_ohlc(candle))
    positive_price_bad = sum(1 for candle in candles if not validate_positive_prices(candle))
    negative_volume_bad = sum(1 for candle in candles if not validate_non_negative_volume(candle))

    if ohlc_bad:
        issues.append(
            DataQualityIssue(
                issue_type="invalid_ohlc",
                severity="critical",
                message="OHLC logical consistency failed",
                affected_records=ohlc_bad,
            )
        )

    if positive_price_bad:
        issues.append(
            DataQualityIssue(
                issue_type="non_positive_price",
                severity="critical",
                message="One or more prices are zero or negative",
                affected_records=positive_price_bad,
            )
        )

    if negative_volume_bad:
        issues.append(
            DataQualityIssue(
                issue_type="negative_volume",
                severity="high",
                message="One or more candles have negative volume",
                affected_records=negative_volume_bad,
            )
        )

    timestamp_order_ok = validate_timestamp_order(candles)
    duplicate_timestamps = _count_duplicate_timestamps(candles)
    gap_count = _count_gaps(candles, expected_interval_seconds)

    if not timestamp_order_ok:
        issues.append(
            DataQualityIssue(
                issue_type="timestamp_order",
                severity="critical",
                message="Timestamps are not strictly increasing",
                affected_records=1,
            )
        )

    if duplicate_timestamps:
        issues.append(
            DataQualityIssue(
                issue_type="duplicate_timestamps",
                severity="critical",
                message="Duplicate candle timestamps detected",
                affected_records=duplicate_timestamps,
            )
        )

    if gap_count:
        issues.append(
            DataQualityIssue(
                issue_type="time_gaps",
                severity="high",
                message="Missing candle intervals detected",
                affected_records=gap_count,
            )
        )

    completeness = 1.0 if missing_ok else 0.0

    valid_consistency_checks = 0
    for candle in candles:
        if (
            validate_ohlc(candle)
            and validate_positive_prices(candle)
            and validate_non_negative_volume(candle)
        ):
            valid_consistency_checks += 1
    consistency = _safe_ratio(valid_consistency_checks, total)

    # Historical offline data has no real-time freshness concept yet.
    freshness = 1.0

    temporal_penalties = duplicate_timestamps + gap_count + (0 if timestamp_order_ok else 1)
    temporality = max(0.0, round(1.0 - (temporal_penalties / max(total, 1)), 4))

    dqs = calculate_dqs(
        completeness=completeness,
        freshness=freshness,
        consistency=consistency,
        temporality=temporality,
    )

    # Critical data issues force block even if the average DQS is not yet below threshold.
    critical_issue = any(issue.severity == "critical" for issue in issues)
    blocked = is_model_blocked(dqs) or critical_issue

    return DataQualityReport(
        total_candles=total,
        dqs=dqs,
        blocked=blocked,
        completeness=completeness,
        freshness=freshness,
        consistency=consistency,
        temporality=temporality,
        expected_interval_seconds=expected_interval_seconds,
        duplicate_timestamps=duplicate_timestamps,
        gap_count=gap_count,
        issues=tuple(issues),
    )
