from datetime import datetime, timedelta, timezone

import pytest

from crypto_decision_lab.domain.models import MarketCandle
from crypto_decision_lab.dql.report import (
    build_data_quality_report,
    infer_expected_interval_seconds,
)


def _candle(ts, open_=100.0, high=110.0, low=90.0, close=105.0, volume=10.0):
    return MarketCandle(
        timestamp=ts,
        open=open_,
        high=high,
        low=low,
        close=close,
        volume=volume,
    )


def _clean_hourly_candles(count=5):
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    return [_candle(base + timedelta(hours=i)) for i in range(count)]


def test_infer_expected_interval_seconds_hourly():
    candles = _clean_hourly_candles()
    assert infer_expected_interval_seconds(candles) == 3600


def test_report_clean_dataset_passes():
    report = build_data_quality_report(_clean_hourly_candles(), expected_interval_seconds=3600)

    assert report.total_candles == 5
    assert report.dqs == 1.0
    assert report.blocked is False
    assert report.status == "PASS"
    assert report.issues == ()


def test_report_detects_duplicate_timestamp_and_blocks():
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    candles = [_candle(base), _candle(base)]

    report = build_data_quality_report(candles, expected_interval_seconds=3600)

    assert report.duplicate_timestamps == 1
    assert report.blocked is True
    assert any(issue.issue_type == "duplicate_timestamps" for issue in report.issues)


def test_report_detects_gap():
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    candles = [_candle(base), _candle(base + timedelta(hours=2))]

    report = build_data_quality_report(candles, expected_interval_seconds=3600)

    assert report.gap_count == 1
    assert report.blocked is False
    assert report.dqs < 1.0
    assert any(issue.issue_type == "time_gaps" for issue in report.issues)


def test_report_detects_invalid_ohlc_and_blocks():
    candles = _clean_hourly_candles()
    candles[1] = _candle(candles[1].timestamp, open_=100.0, high=90.0, low=110.0, close=105.0)

    report = build_data_quality_report(candles, expected_interval_seconds=3600)

    assert report.blocked is True
    assert any(issue.issue_type == "invalid_ohlc" for issue in report.issues)


def test_report_detects_negative_volume():
    candles = _clean_hourly_candles()
    candles[2] = _candle(candles[2].timestamp, volume=-1.0)

    report = build_data_quality_report(candles, expected_interval_seconds=3600)

    assert report.blocked is False
    assert report.dqs < 1.0
    assert any(issue.issue_type == "negative_volume" for issue in report.issues)


def test_report_empty_dataset_raises():
    with pytest.raises(ValueError):
        build_data_quality_report([])
