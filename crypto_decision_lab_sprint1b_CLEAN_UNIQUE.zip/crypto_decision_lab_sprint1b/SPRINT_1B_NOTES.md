# Sprint 1B — Data Quality Report Offline

Status: implementada e validada localmente.

## Escopo

- Arquivo local de klines já carregado pela Sprint 1A.
- Geração de relatório offline de qualidade de dados.
- Detecção básica de:
  - OHLC inválido;
  - preços zero/negativos;
  - volume negativo;
  - timestamps fora de ordem;
  - timestamps duplicados;
  - gaps de candles.
- Cálculo de DQS offline.
- Demo local `demo_data_quality_report.py`.
- Testes unitários.

## Fora do escopo

- Binance live.
- API key.
- WebSocket.
- Banco de dados.
- Ordens.
- Capital real.

## Critério de aprovação

- `pytest tests/` passa.
- `python demo_data_quality_report.py` roda.
- Nenhuma conexão externa é feita.
