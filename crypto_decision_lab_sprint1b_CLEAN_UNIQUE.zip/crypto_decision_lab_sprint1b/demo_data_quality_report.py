"""Sprint 1B demo: offline Data Quality Report.

No Binance, no API, no WebSocket, no trading.
"""

from pathlib import Path

from crypto_decision_lab.dql.report import build_data_quality_report
from crypto_decision_lab.ingestion.offline_klines import load_binance_klines


def main() -> None:
    fixture_path = Path(__file__).parent / "tests" / "fixtures" / "BTCUSDT-1h-sample.csv"
    candles = load_binance_klines(fixture_path)
    report = build_data_quality_report(candles, expected_interval_seconds=3600)

    for line in report.to_lines():
        print(line)


if __name__ == "__main__":
    main()
