from crypto_decision_lab.paper.report import (
    build_sample_risk_report,
    run_paper_trading_skeleton,
    report_to_dict,
    ledger_to_dicts,
)
from crypto_decision_lab.export.artifacts import write_json, write_txt

report, ledger = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
dirty_report, _ = run_paper_trading_skeleton(build_sample_risk_report("BLOCKED"))

payload = {
    "report": report_to_dict(report),
    "ledger": ledger_to_dicts(ledger),
}
paths = {
    "json": write_json("reports/sprint3c/paper_trading_report.json", payload),
    "txt": write_txt("reports/sprint3c/paper_trading_report.txt", [
        "Sprint 3C Paper Trading Skeleton Offline",
        f"Paper status: {report.paper_status}",
        f"Paper stage: {report.paper_stage}",
        f"Action: {report.action}",
        f"Initial equity: {report.initial_equity:.2f}",
        f"Final equity: {report.final_equity:.2f}",
        f"Total return pct: {report.total_return_pct:.6f}",
        f"Paper orders: {report.paper_orders}",
        f"Paper fills: {report.paper_fills}",
        f"Real capital used: {report.real_capital_used}",
        f"Exchange connected: {report.exchange_connected}",
        f"Real orders generated: {report.real_orders_generated}",
        f"Next required gate: {report.next_required_gate}",
    ]),
}

print("=== Sprint 3C Paper Trading Skeleton Offline ===")
print(f"Paper schema: {report.schema}")
print(f"Risk status: {report.risk_status}")
print(f"Paper status: {report.paper_status}")
print(f"Model blocked: {report.model_blocked}")
print(f"Research allowed: {report.research_allowed}")
print(f"Paper trading allowed: {report.paper_trading_allowed}")
print(f"Operational decision allowed: {report.operational_decision_allowed}")
print(f"Paper stage: {report.paper_stage}")
print(f"Action: {report.action}")
print(f"Initial equity: {report.initial_equity:.2f}")
print(f"Final equity: {report.final_equity:.2f}")
print(f"Total return pct: {report.total_return_pct:.6f}")
print(f"Max drawdown pct: {report.max_drawdown_pct:.6f}")
print(f"Paper orders: {report.paper_orders}")
print(f"Paper fills: {report.paper_fills}")
print(f"Rejected orders: {report.rejected_orders}")
print(f"Order ledger rows: {report.order_ledger_rows}")
print(f"Real capital used: {report.real_capital_used}")
print(f"Exchange connected: {report.exchange_connected}")
print(f"Real orders generated: {report.real_orders_generated}")
print(f"Orders generated: {report.orders_generated}")
print(f"Paper orders generated: {report.paper_orders_generated}")
print(f"Next required gate: {report.next_required_gate}")
print(f"Issues: {report.issues if report.issues else 'none'}")
print(f"Dirty paper status: {dirty_report.paper_status}")
print(f"Dirty action: {dirty_report.action}")
print(f"Dirty issues: {dirty_report.issues}")
print(f"Generated files: {paths}")
