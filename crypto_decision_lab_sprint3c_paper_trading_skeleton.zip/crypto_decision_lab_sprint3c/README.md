# Crypto Decision Lab - Sprint 3C

Paper Trading Skeleton Offline.

This sprint creates a paper-only execution layer:

- no real exchange connection
- no real API key
- no authenticated WebSocket
- no real orders
- no real capital
- no operational decision

Expected validation:

```bash
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_paper_trading_skeleton.py
```
