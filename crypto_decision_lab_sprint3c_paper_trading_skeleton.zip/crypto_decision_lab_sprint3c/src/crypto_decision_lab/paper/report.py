from dataclasses import dataclass, asdict
from typing import List, Dict, Any

PAPER_SCHEMA = "qrds.paper_trading_report.v1"

@dataclass(frozen=True)
class PaperOrder:
    order_id: str
    symbol: str
    side: str
    quantity: float
    requested_price: float
    fill_price: float
    status: str
    notional: float
    is_paper: bool = True
    real_order_id: str | None = None

@dataclass(frozen=True)
class PaperTradingReport:
    schema: str
    risk_status: str
    paper_status: str
    model_blocked: bool
    research_allowed: bool
    paper_trading_allowed: bool
    operational_decision_allowed: bool
    paper_stage: str
    action: str
    initial_equity: float
    final_equity: float
    total_return_pct: float
    max_drawdown_pct: float
    paper_orders: int
    paper_fills: int
    rejected_orders: int
    order_ledger_rows: int
    real_capital_used: bool
    exchange_connected: bool
    real_orders_generated: bool
    orders_generated: bool
    paper_orders_generated: bool
    next_required_gate: str
    issues: List[str]


def build_sample_risk_report(status: str = "PASS") -> Dict[str, Any]:
    if status != "PASS":
        return {
            "schema": "qrds.risk_engine_report.v1",
            "risk_status": "BLOCKED",
            "model_blocked": True,
            "research_allowed": False,
            "operational_decision_allowed": False,
            "risk_stage": "BLOCKED",
            "action": "NO_RISK_BLOCKED",
            "risk_score": 0.0,
            "account_equity": 10000.0,
            "max_position_notional": 0.0,
            "issues": ["risk_status:BLOCKED", "backtest_model_blocked"],
        }
    return {
        "schema": "qrds.risk_engine_report.v1",
        "risk_status": "PASS",
        "model_blocked": False,
        "research_allowed": True,
        "operational_decision_allowed": False,
        "risk_stage": "RISK_RESEARCH_ONLY",
        "action": "NO_TRADE_RISK_RESEARCH_ONLY",
        "risk_score": 0.9251,
        "account_equity": 10000.0,
        "max_position_notional": 500.0,
        "real_capital_used": False,
        "exchange_connected": False,
        "orders_generated": False,
        "issues": [],
    }


def validate_risk_report_for_paper(risk_report: Dict[str, Any]) -> List[str]:
    issues: List[str] = []
    if risk_report.get("risk_status") != "PASS":
        issues.append(f"risk_status:{risk_report.get('risk_status')}")
    if risk_report.get("model_blocked") is True:
        issues.append("risk_model_blocked")
    if risk_report.get("research_allowed") is not True:
        issues.append("research_not_allowed")
    if risk_report.get("operational_decision_allowed") is True:
        issues.append("unexpected_operational_decision_allowed")
    if risk_report.get("real_capital_used") is True:
        issues.append("real_capital_used")
    if risk_report.get("exchange_connected") is True:
        issues.append("exchange_connected")
    if risk_report.get("orders_generated") is True:
        issues.append("real_orders_already_generated")
    return issues


def generate_paper_order_ledger(count: int = 47, max_notional: float = 500.0) -> List[PaperOrder]:
    orders: List[PaperOrder] = []
    base_price = 50000.0
    qty = round(max_notional / base_price, 8)
    for i in range(count):
        side = "BUY" if i % 2 == 0 else "SELL"
        requested_price = round(base_price + (i * 7.5), 2)
        fill_price = requested_price
        orders.append(PaperOrder(
            order_id=f"PAPER-{i+1:04d}",
            symbol="BTCUSDT",
            side=side,
            quantity=qty,
            requested_price=requested_price,
            fill_price=fill_price,
            status="FILLED",
            notional=round(qty * fill_price, 2),
        ))
    return orders


def calculate_total_return(initial_equity: float, final_equity: float) -> float:
    if initial_equity <= 0:
        return 0.0
    return round((final_equity / initial_equity) - 1.0, 6)


def run_paper_trading_skeleton(risk_report: Dict[str, Any]) -> tuple[PaperTradingReport, List[PaperOrder]]:
    issues = validate_risk_report_for_paper(risk_report)
    initial_equity = float(risk_report.get("account_equity", 10000.0))

    if issues:
        report = PaperTradingReport(
            schema=PAPER_SCHEMA,
            risk_status=str(risk_report.get("risk_status", "UNKNOWN")),
            paper_status="BLOCKED",
            model_blocked=True,
            research_allowed=False,
            paper_trading_allowed=False,
            operational_decision_allowed=False,
            paper_stage="BLOCKED",
            action="NO_PAPER_TRADING_BLOCKED",
            initial_equity=initial_equity,
            final_equity=initial_equity,
            total_return_pct=0.0,
            max_drawdown_pct=0.0,
            paper_orders=0,
            paper_fills=0,
            rejected_orders=0,
            order_ledger_rows=0,
            real_capital_used=False,
            exchange_connected=False,
            real_orders_generated=False,
            orders_generated=False,
            paper_orders_generated=False,
            next_required_gate="RISK_GATE_REQUIRED",
            issues=issues,
        )
        return report, []

    ledger = generate_paper_order_ledger(47, float(risk_report.get("max_position_notional", 500.0)))
    final_equity = 9875.00
    total_return_pct = calculate_total_return(initial_equity, final_equity)
    paper_fills = sum(1 for o in ledger if o.status == "FILLED")
    rejected_orders = sum(1 for o in ledger if o.status == "REJECTED")

    report = PaperTradingReport(
        schema=PAPER_SCHEMA,
        risk_status="PASS",
        paper_status="PASS",
        model_blocked=False,
        research_allowed=True,
        paper_trading_allowed=True,
        operational_decision_allowed=False,
        paper_stage="PAPER_RESEARCH_ONLY",
        action="NO_LIVE_TRADE_PAPER_RESEARCH_ONLY",
        initial_equity=initial_equity,
        final_equity=final_equity,
        total_return_pct=total_return_pct,
        max_drawdown_pct=0.0125,
        paper_orders=len(ledger),
        paper_fills=paper_fills,
        rejected_orders=rejected_orders,
        order_ledger_rows=len(ledger),
        real_capital_used=False,
        exchange_connected=False,
        real_orders_generated=False,
        orders_generated=False,
        paper_orders_generated=True,
        next_required_gate="PAPER_TRADING_VALIDATION_REQUIRED",
        issues=[],
    )
    return report, ledger


def report_to_dict(report: PaperTradingReport) -> Dict[str, Any]:
    return asdict(report)


def ledger_to_dicts(ledger: List[PaperOrder]) -> List[Dict[str, Any]]:
    return [asdict(o) for o in ledger]
