from pathlib import Path
import json

from crypto_decision_lab.paper.report import (
    PAPER_SCHEMA,
    PaperOrder,
    build_sample_risk_report,
    validate_risk_report_for_paper,
    generate_paper_order_ledger,
    calculate_total_return,
    run_paper_trading_skeleton,
    report_to_dict,
    ledger_to_dicts,
)
from crypto_decision_lab.export.artifacts import write_json, write_txt


def test_01_schema_constant():
    assert PAPER_SCHEMA == "qrds.paper_trading_report.v1"


def test_02_clean_risk_report_pass():
    r = build_sample_risk_report("PASS")
    assert r["risk_status"] == "PASS"


def test_03_dirty_risk_report_blocked():
    r = build_sample_risk_report("BLOCKED")
    assert r["risk_status"] == "BLOCKED"


def test_04_clean_risk_has_no_issues():
    assert validate_risk_report_for_paper(build_sample_risk_report("PASS")) == []


def test_05_dirty_risk_has_issues():
    assert validate_risk_report_for_paper(build_sample_risk_report("BLOCKED"))


def test_06_operational_allowed_is_issue():
    r = build_sample_risk_report("PASS")
    r["operational_decision_allowed"] = True
    assert "unexpected_operational_decision_allowed" in validate_risk_report_for_paper(r)


def test_07_real_capital_is_issue():
    r = build_sample_risk_report("PASS")
    r["real_capital_used"] = True
    assert "real_capital_used" in validate_risk_report_for_paper(r)


def test_08_exchange_connected_is_issue():
    r = build_sample_risk_report("PASS")
    r["exchange_connected"] = True
    assert "exchange_connected" in validate_risk_report_for_paper(r)


def test_09_orders_generated_is_issue():
    r = build_sample_risk_report("PASS")
    r["orders_generated"] = True
    assert "real_orders_already_generated" in validate_risk_report_for_paper(r)


def test_10_ledger_count():
    assert len(generate_paper_order_ledger(47)) == 47


def test_11_ledger_order_type():
    assert isinstance(generate_paper_order_ledger(1)[0], PaperOrder)


def test_12_ledger_paper_only():
    assert all(o.is_paper for o in generate_paper_order_ledger(5))


def test_13_ledger_no_real_order_ids():
    assert all(o.real_order_id is None for o in generate_paper_order_ledger(5))


def test_14_ledger_filled():
    assert all(o.status == "FILLED" for o in generate_paper_order_ledger(5))


def test_15_ledger_alternates_sides():
    ledger = generate_paper_order_ledger(4)
    assert [o.side for o in ledger] == ["BUY", "SELL", "BUY", "SELL"]


def test_16_ledger_notional_positive():
    assert all(o.notional > 0 for o in generate_paper_order_ledger(5))


def test_17_total_return():
    assert calculate_total_return(10000, 9875) == -0.0125


def test_18_total_return_zero_initial():
    assert calculate_total_return(0, 100) == 0.0


def test_19_clean_report_pass():
    report, _ = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report.paper_status == "PASS"


def test_20_clean_report_schema():
    report, _ = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report.schema == PAPER_SCHEMA


def test_21_clean_report_no_model_block():
    report, _ = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report.model_blocked is False


def test_22_clean_report_research_allowed():
    report, _ = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report.research_allowed is True


def test_23_clean_report_paper_allowed():
    report, _ = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report.paper_trading_allowed is True


def test_24_clean_report_operational_not_allowed():
    report, _ = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report.operational_decision_allowed is False


def test_25_clean_report_action_safe():
    report, _ = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report.action == "NO_LIVE_TRADE_PAPER_RESEARCH_ONLY"


def test_26_clean_report_paper_orders():
    report, ledger = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report.paper_orders == len(ledger) == 47


def test_27_clean_report_no_real_capital():
    report, _ = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report.real_capital_used is False


def test_28_clean_report_no_exchange():
    report, _ = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report.exchange_connected is False


def test_29_clean_report_no_real_orders():
    report, _ = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report.real_orders_generated is False and report.orders_generated is False


def test_30_clean_report_next_gate():
    report, _ = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report.next_required_gate == "PAPER_TRADING_VALIDATION_REQUIRED"


def test_31_dirty_report_blocked():
    report, ledger = run_paper_trading_skeleton(build_sample_risk_report("BLOCKED"))
    assert report.paper_status == "BLOCKED" and ledger == []


def test_32_dirty_report_action():
    report, _ = run_paper_trading_skeleton(build_sample_risk_report("BLOCKED"))
    assert report.action == "NO_PAPER_TRADING_BLOCKED"


def test_33_report_to_dict_and_ledger_to_dicts():
    report, ledger = run_paper_trading_skeleton(build_sample_risk_report("PASS"))
    assert report_to_dict(report)["schema"] == PAPER_SCHEMA
    assert ledger_to_dicts(ledger)[0]["order_id"] == "PAPER-0001"


def test_34_export_json_and_txt(tmp_path):
    json_path = write_json(tmp_path / "x.json", {"a": 1})
    txt_path = write_txt(tmp_path / "x.txt", ["hello"])
    assert json.loads(Path(json_path).read_text())["a"] == 1
    assert Path(txt_path).read_text().strip() == "hello"
