import json
from pathlib import Path

from crypto_decision_lab.dql.report import generate_data_quality_report
from crypto_decision_lab.exporters.dql_artifacts import (
    DASHBOARD_PAYLOAD_SCHEMA_VERSION,
    DQL_ARTIFACT_SCHEMA_VERSION,
    build_dashboard_payload,
    export_artifact_json,
    export_artifact_txt,
    export_dashboard_payload,
    report_to_artifact,
)
from crypto_decision_lab.ingestion.binance_klines import load_binance_klines_csv


def _artifact(label, path):
    candles = load_binance_klines_csv(path)
    report = generate_data_quality_report(candles, 3600)
    return report_to_artifact(
        report,
        dataset_label=label,
        symbol="BTCUSDT",
        timeframe="1h",
        source_path=path,
        generated_at_utc="2026-01-01T00:00:00+00:00",
    )


def test_dql_artifact_schema_clean_pass():
    artifact = _artifact("clean-48h", "data/fixtures/BTCUSDT-1h-48h-clean.csv")
    assert artifact["schema_version"] == DQL_ARTIFACT_SCHEMA_VERSION
    assert artifact["metadata"]["sprint"] == "1D"
    assert artifact["gate"]["status"] == "PASS"
    assert artifact["gate"]["model_blocked"] is False
    assert artifact["scores"]["dqs"] == 1.0
    assert artifact["counts"]["total_candles"] == 48
    assert artifact["issues"] == []


def test_dql_artifact_schema_issues_blocked():
    artifact = _artifact("issues-48h", "data/fixtures/BTCUSDT-1h-48h-with-issues.csv")
    assert artifact["gate"]["status"] == "BLOCKED"
    assert artifact["gate"]["model_blocked"] is True
    assert artifact["scores"]["dqs"] < 1.0
    assert len(artifact["issues"]) >= 1
    assert artifact["gate"]["allowed_actions"] == []


def test_export_artifact_json_and_txt(tmp_path):
    artifact = _artifact("clean-48h", "data/fixtures/BTCUSDT-1h-48h-clean.csv")
    json_path = export_artifact_json(artifact, tmp_path / "clean.json")
    txt_path = export_artifact_txt(artifact, tmp_path / "clean.txt")
    loaded = json.loads(Path(json_path).read_text(encoding="utf-8"))
    txt = Path(txt_path).read_text(encoding="utf-8")
    assert loaded["schema_version"] == DQL_ARTIFACT_SCHEMA_VERSION
    assert loaded["gate"]["status"] == "PASS"
    assert "QRDS DQL Artifact" in txt
    assert "Status: PASS" in txt


def test_dashboard_payload_summary():
    clean = _artifact("clean-48h", "data/fixtures/BTCUSDT-1h-48h-clean.csv")
    issues = _artifact("issues-48h", "data/fixtures/BTCUSDT-1h-48h-with-issues.csv")
    payload = build_dashboard_payload([clean, issues], generated_at_utc="2026-01-01T00:00:00+00:00")
    assert payload["schema_version"] == DASHBOARD_PAYLOAD_SCHEMA_VERSION
    assert payload["summary"]["total_reports"] == 2
    assert payload["summary"]["pass_count"] == 1
    assert payload["summary"]["blocked_count"] == 1
    assert payload["summary"]["best_dqs"] == 1.0
    assert payload["summary"]["worst_dqs"] < 1.0
    assert len(payload["cards"]) == 2


def test_export_dashboard_payload(tmp_path):
    clean = _artifact("clean-48h", "data/fixtures/BTCUSDT-1h-48h-clean.csv")
    payload = build_dashboard_payload([clean], generated_at_utc="2026-01-01T00:00:00+00:00")
    path = export_dashboard_payload(payload, tmp_path / "dashboard_payload.json")
    loaded = json.loads(Path(path).read_text(encoding="utf-8"))
    assert loaded["summary"]["total_reports"] == 1
    assert loaded["cards"][0]["dataset_label"] == "clean-48h"


def test_empty_dashboard_payload():
    payload = build_dashboard_payload([], generated_at_utc="2026-01-01T00:00:00+00:00")
    assert payload["summary"]["total_reports"] == 0
    assert payload["summary"]["worst_dqs"] is None
    assert payload["cards"] == []
