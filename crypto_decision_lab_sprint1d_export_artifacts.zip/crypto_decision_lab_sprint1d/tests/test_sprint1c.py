from datetime import datetime, timedelta, timezone
import json
import zipfile

from crypto_decision_lab.decision.dummy_decision import make_dummy_decision
from crypto_decision_lab.domain.models import MarketCandle
from crypto_decision_lab.dql.report import (
    export_report_json,
    export_report_txt,
    generate_data_quality_report,
)
from crypto_decision_lab.dql.score import calculate_dqs, is_model_blocked
from crypto_decision_lab.dql.validators import (
    validate_non_negative_volume,
    validate_ohlc,
    validate_positive_prices,
    validate_timestamp_order,
)
from crypto_decision_lab.ingestion.binance_klines import (
    load_binance_klines_csv,
    load_binance_klines_zip,
)


def c(ts=None, **kw):
    d = dict(
        timestamp=ts or datetime(2024, 1, 1, tzinfo=timezone.utc),
        open=1.0,
        high=2.0,
        low=0.5,
        close=1.5,
        volume=10.0,
    )
    d.update(kw)
    return MarketCandle(**d)


def test_validators_basicos():
    assert validate_ohlc(c())
    assert not validate_ohlc(c(high=0.8))
    assert validate_positive_prices(c())
    assert not validate_positive_prices(c(open=0))
    assert validate_non_negative_volume(c(volume=0))
    assert not validate_non_negative_volume(c(volume=-1))


def test_timestamp_order():
    b = datetime(2024, 1, 1, tzinfo=timezone.utc)
    assert validate_timestamp_order([c(b), c(b + timedelta(hours=1))])
    assert not validate_timestamp_order([c(b + timedelta(hours=1)), c(b)])


def test_dqs():
    assert calculate_dqs(1, 1, 1, 1) == 1.0
    assert calculate_dqs(2, 1, -1, 1) == 0.75
    assert is_model_blocked(0.79)
    assert not is_model_blocked(0.80)


def test_decision():
    assert make_dummy_decision(0.7, 1, 0).decision == "No Trade"
    assert make_dummy_decision(0.9, 1, 0).decision == "Long"
    assert make_dummy_decision(0.9, 0, 1).decision == "Short"
    assert make_dummy_decision(0.9, 0, 0).decision == "No Trade"


def test_load_clean_large_csv():
    candles = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-48h-clean.csv")
    assert len(candles) == 48
    assert candles[0].timestamp.tzinfo is not None
    assert validate_timestamp_order(candles)


def test_load_zip(tmp_path):
    csv = tmp_path / "x.csv"
    z = tmp_path / "x.zip"
    csv.write_text("1704067200000,1,2,0.5,1.5,10\n")
    with zipfile.ZipFile(z, "w") as f:
        f.write(csv, "x.csv")
    assert len(load_binance_klines_zip(z)) == 1


def test_clean_report_pass():
    candles = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-48h-clean.csv")
    report = generate_data_quality_report(candles, 3600)
    assert report.status == "PASS"
    assert report.dqs == 1.0
    assert report.gap_count == 0
    assert report.duplicate_timestamps == 0
    assert report.issues == []


def test_issue_report_blocked():
    candles = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-48h-with-issues.csv")
    report = generate_data_quality_report(candles, 3600)
    assert report.status == "BLOCKED"
    assert report.dqs < 1.0
    assert report.gap_count >= 1
    assert report.duplicate_timestamps >= 1
    assert report.invalid_ohlc_count >= 1
    assert report.invalid_price_count >= 1
    assert report.invalid_volume_count >= 1
    assert "timestamp_gaps" in report.issues


def test_empty_report_blocked():
    report = generate_data_quality_report([], 3600)
    assert report.status == "BLOCKED"
    assert "empty_dataset" in report.issues


def test_export_report_files(tmp_path):
    candles = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-48h-clean.csv")
    report = generate_data_quality_report(candles, 3600)
    json_path = tmp_path / "report.json"
    txt_path = tmp_path / "report.txt"
    export_report_json(report, json_path)
    export_report_txt(report, txt_path)
    assert json.loads(json_path.read_text())["status"] == "PASS"
    assert "Data Quality Report Offline" in txt_path.read_text()
