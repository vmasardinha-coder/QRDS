from crypto_decision_lab.ingestion.binance_klines import load_binance_klines_csv
from crypto_decision_lab.dql.report import (
    export_report_json,
    export_report_txt,
    generate_data_quality_report,
)


def print_report(label, report):
    print(f"=== {label} ===")
    print(f"Total candles: {report.total_candles}")
    print(f"DQS: {report.dqs:.4f}")
    print(f"Status: {report.status}")
    print(f"Completeness: {report.completeness:.4f}")
    print(f"Freshness: {report.freshness:.4f}")
    print(f"Consistency: {report.consistency:.4f}")
    print(f"Temporality: {report.temporality:.4f}")
    print(f"Duplicate timestamps: {report.duplicate_timestamps}")
    print(f"Gap count: {report.gap_count}")
    print(f"Invalid OHLC: {report.invalid_ohlc_count}")
    print(f"Invalid prices: {report.invalid_price_count}")
    print(f"Invalid volume: {report.invalid_volume_count}")
    print(f"Missing values: {report.missing_values_count}")
    print(f"Issues: {report.issues if report.issues else 'none'}")
    print()


def main():
    clean = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-48h-clean.csv")
    dirty = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-48h-with-issues.csv")

    clean_report = generate_data_quality_report(clean, 3600)
    dirty_report = generate_data_quality_report(dirty, 3600)

    export_report_json(clean_report, "reports/dql_clean_report.json")
    export_report_txt(clean_report, "reports/dql_clean_report.txt")
    export_report_json(dirty_report, "reports/dql_issues_report.json")
    export_report_txt(dirty_report, "reports/dql_issues_report.txt")

    print_report("Clean dataset", clean_report)
    print_report("Dataset with issues", dirty_report)


if __name__ == "__main__":
    main()
