# Crypto Decision Lab — Sprint 1D

Sprint 1D: Export padronizado do DQL Report e base para dashboard interno.

Escopo permitido:
- CSV/ZIP local.
- Dataset offline clean e dataset offline com problemas controlados.
- Relatório DQL.
- Artefatos locais padronizados em JSON e TXT.
- Payload JSON para futuro dashboard interno.
- Testes unitários.

Ainda proibido:
- Binance live.
- API key.
- WebSocket.
- Ordens.
- Capital real.
- Alavancagem.

## Comando de validação

```bash
cd /workspaces/QRDS/crypto_decision_lab_sprint1d && \
python -m pip install -e . && \
PYTHONPATH="$(pwd)/src" pytest -q tests/ && \
PYTHONPATH="$(pwd)/src" python demo_export_dql_artifacts.py
```

Resultado esperado:
- Testes passando.
- Clean dataset com `Status: PASS`.
- Dataset com problemas com `Status: BLOCKED`.
- Arquivos gerados em `reports/sprint1d/`:
  - `clean_dql_artifact.json`
  - `clean_dql_artifact.txt`
  - `issues_dql_artifact.json`
  - `issues_dql_artifact.txt`
  - `dashboard_payload.json`

## Decisão de escopo

Esta sprint ainda não cria dashboard visual. Ela apenas cria o contrato de dados para alimentar dashboard futuro.
