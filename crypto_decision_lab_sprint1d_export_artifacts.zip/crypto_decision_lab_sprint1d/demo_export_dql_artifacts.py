from crypto_decision_lab.exporters.dql_artifacts import (
    build_dashboard_payload,
    export_artifact_json,
    export_artifact_txt,
    export_dashboard_payload,
    report_to_artifact,
)
from crypto_decision_lab.ingestion.binance_klines import load_binance_klines_csv
from crypto_decision_lab.dql.report import generate_data_quality_report


def build_artifact(label: str, path: str):
    candles = load_binance_klines_csv(path)
    report = generate_data_quality_report(candles, 3600)
    return report_to_artifact(
        report,
        dataset_label=label,
        symbol="BTCUSDT",
        timeframe="1h",
        source_path=path,
    )


def print_artifact(label: str, artifact: dict):
    print(f"=== {label} ===")
    print(f"Schema: {artifact['schema_version']}")
    print(f"Status: {artifact['gate']['status']}")
    print(f"Model blocked: {artifact['gate']['model_blocked']}")
    print(f"DQS: {artifact['scores']['dqs']:.4f}")
    print(f"Total candles: {artifact['counts']['total_candles']}")
    print(f"Issues: {artifact['issues'] if artifact['issues'] else 'none'}")
    print()


def main():
    clean_path = "data/fixtures/BTCUSDT-1h-48h-clean.csv"
    issues_path = "data/fixtures/BTCUSDT-1h-48h-with-issues.csv"

    clean_artifact = build_artifact("clean-48h", clean_path)
    issues_artifact = build_artifact("issues-48h", issues_path)
    dashboard_payload = build_dashboard_payload([clean_artifact, issues_artifact])

    export_artifact_json(clean_artifact, "reports/sprint1d/clean_dql_artifact.json")
    export_artifact_txt(clean_artifact, "reports/sprint1d/clean_dql_artifact.txt")
    export_artifact_json(issues_artifact, "reports/sprint1d/issues_dql_artifact.json")
    export_artifact_txt(issues_artifact, "reports/sprint1d/issues_dql_artifact.txt")
    export_dashboard_payload(dashboard_payload, "reports/sprint1d/dashboard_payload.json")

    print_artifact("Clean DQL artifact", clean_artifact)
    print_artifact("Issues DQL artifact", issues_artifact)
    print("=== Dashboard payload ===")
    print(f"Schema: {dashboard_payload['schema_version']}")
    print(f"Total reports: {dashboard_payload['summary']['total_reports']}")
    print(f"PASS: {dashboard_payload['summary']['pass_count']}")
    print(f"BLOCKED: {dashboard_payload['summary']['blocked_count']}")
    print(f"Worst DQS: {dashboard_payload['summary']['worst_dqs']:.4f}")
    print(f"Best DQS: {dashboard_payload['summary']['best_dqs']:.4f}")
    print("Generated files: reports/sprint1d/")


if __name__ == "__main__":
    main()
