from crypto_decision_lab.ingestion.binance_klines import load_binance_klines_csv
from crypto_decision_lab.dql.validators import validate_ohlc, validate_timestamp_order

candles = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-sample.csv")
print("=== Demo Ingestão Offline ===")
print(f"Candles carregados: {len(candles)}")
print(f"Primeiro candle: {candles[0]}")
print(f"Último candle: {candles[-1]}")
print(f"Validação OHLC: {all(validate_ohlc(c) for c in candles)}")
print(f"Timestamp order: {validate_timestamp_order(candles)}")
