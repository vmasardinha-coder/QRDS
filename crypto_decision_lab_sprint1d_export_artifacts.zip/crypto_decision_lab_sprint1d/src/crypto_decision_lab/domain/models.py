from dataclasses import dataclass, field
from datetime import datetime, timezone


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class MarketCandle:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    symbol: str = "BTCUSDT"
    timeframe: str = "1h"


@dataclass(frozen=True)
class DecisionRecord:
    decision: str
    reason: str
    dqs: float
    timestamp: datetime = field(default_factory=utc_now)


@dataclass(frozen=True)
class DataQualityEvent:
    event_type: str
    severity: str
    message: str
    timestamp: datetime = field(default_factory=utc_now)
