import csv
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from crypto_decision_lab.domain.models import MarketCandle


def _ts(ms: str) -> datetime:
    return datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc)


def _parse(row: list[str]) -> MarketCandle:
    return MarketCandle(
        timestamp=_ts(row[0]),
        open=float(row[1]),
        high=float(row[2]),
        low=float(row[3]),
        close=float(row[4]),
        volume=float(row[5]),
    )


def load_binance_klines_csv(path: str | Path) -> list[MarketCandle]:
    candles: list[MarketCandle] = []
    with Path(path).open("r", newline="") as f:
        for row in csv.reader(f):
            if not row or row[0].lower() in {"open_time", "timestamp"}:
                continue
            candles.append(_parse(row))
    return candles


def load_binance_klines_zip(path: str | Path) -> list[MarketCandle]:
    with zipfile.ZipFile(path) as zf:
        names = [n for n in zf.namelist() if n.endswith(".csv")]
        if not names:
            raise ValueError("ZIP não contém CSV")
        rows = zf.open(names[0]).read().decode("utf-8").splitlines()
        return [_parse(r) for r in csv.reader(rows) if r and r[0].lower() not in {"open_time", "timestamp"}]
