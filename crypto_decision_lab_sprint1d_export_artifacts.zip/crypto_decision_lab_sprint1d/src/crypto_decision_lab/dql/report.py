from dataclasses import asdict, dataclass
import json
from pathlib import Path

from crypto_decision_lab.config import DQS_THRESHOLD, DQS_WARN_THRESHOLD
from crypto_decision_lab.dql.score import calculate_dqs
from crypto_decision_lab.dql.validators import (
    validate_ohlc,
    validate_timestamp_order,
    validate_missing_values,
    validate_positive_prices,
    validate_non_negative_volume,
)
from crypto_decision_lab.domain.models import MarketCandle


@dataclass(frozen=True)
class DataQualityReport:
    total_candles: int
    expected_interval_seconds: int
    duplicate_timestamps: int
    gap_count: int
    invalid_ohlc_count: int
    invalid_price_count: int
    invalid_volume_count: int
    missing_values_count: int
    timestamp_order_ok: bool
    completeness: float
    freshness: float
    consistency: float
    temporality: float
    dqs: float
    status: str
    issues: list[str]


def count_duplicate_timestamps(candles: list[MarketCandle]) -> int:
    seen = set()
    dup = 0
    for c in candles:
        if c.timestamp in seen:
            dup += 1
        seen.add(c.timestamp)
    return dup


def count_gaps(candles: list[MarketCandle], expected_interval_seconds: int) -> int:
    ordered = sorted(candles, key=lambda c: c.timestamp)
    gaps = 0
    for a, b in zip(ordered, ordered[1:]):
        if int((b.timestamp - a.timestamp).total_seconds()) != expected_interval_seconds:
            gaps += 1
    return gaps


def _status_from(dqs: float, issues: list[str]) -> str:
    if dqs < DQS_THRESHOLD or issues:
        return "BLOCKED"
    if dqs < DQS_WARN_THRESHOLD:
        return "WARN"
    return "PASS"


def generate_data_quality_report(candles: list[MarketCandle], expected_interval_seconds: int) -> DataQualityReport:
    total = len(candles)
    if total == 0:
        return DataQualityReport(
            total_candles=0,
            expected_interval_seconds=expected_interval_seconds,
            duplicate_timestamps=0,
            gap_count=0,
            invalid_ohlc_count=0,
            invalid_price_count=0,
            invalid_volume_count=0,
            missing_values_count=0,
            timestamp_order_ok=False,
            completeness=0.0,
            freshness=0.0,
            consistency=0.0,
            temporality=0.0,
            dqs=0.0,
            status="BLOCKED",
            issues=["empty_dataset"],
        )

    dup = count_duplicate_timestamps(candles)
    gaps = count_gaps(candles, expected_interval_seconds)
    bad_ohlc = sum(1 for c in candles if not validate_ohlc(c))
    bad_price = sum(1 for c in candles if not validate_positive_prices(c))
    bad_volume = sum(1 for c in candles if not validate_non_negative_volume(c))
    missing = 0 if validate_missing_values(candles) else 1
    order_ok = validate_timestamp_order(candles)

    issues = []
    if dup: issues.append("duplicate_timestamps")
    if gaps: issues.append("timestamp_gaps")
    if bad_ohlc: issues.append("invalid_ohlc")
    if bad_price: issues.append("invalid_prices")
    if bad_volume: issues.append("invalid_volume")
    if missing: issues.append("missing_values")
    if not order_ok: issues.append("timestamp_order")

    completeness = max(0.0, 1.0 - ((dup + gaps) / total))
    freshness = 1.0
    consistency = max(0.0, 1.0 - ((bad_ohlc + bad_price + bad_volume + missing) / total))
    temporality = 1.0 if order_ok and dup == 0 else 0.0
    dqs = calculate_dqs(completeness, freshness, consistency, temporality)
    status = _status_from(dqs, issues)

    return DataQualityReport(
        total_candles=total,
        expected_interval_seconds=expected_interval_seconds,
        duplicate_timestamps=dup,
        gap_count=gaps,
        invalid_ohlc_count=bad_ohlc,
        invalid_price_count=bad_price,
        invalid_volume_count=bad_volume,
        missing_values_count=missing,
        timestamp_order_ok=order_ok,
        completeness=round(completeness, 4),
        freshness=round(freshness, 4),
        consistency=round(consistency, 4),
        temporality=round(temporality, 4),
        dqs=dqs,
        status=status,
        issues=issues,
    )


def export_report_json(report: DataQualityReport, path: str | Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(asdict(report), indent=2), encoding="utf-8")


def export_report_txt(report: DataQualityReport, path: str | Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "Data Quality Report Offline",
        f"Total candles: {report.total_candles}",
        f"DQS: {report.dqs:.4f}",
        f"Status: {report.status}",
        f"Completeness: {report.completeness:.4f}",
        f"Freshness: {report.freshness:.4f}",
        f"Consistency: {report.consistency:.4f}",
        f"Temporality: {report.temporality:.4f}",
        f"Duplicate timestamps: {report.duplicate_timestamps}",
        f"Gap count: {report.gap_count}",
        f"Invalid OHLC: {report.invalid_ohlc_count}",
        f"Invalid prices: {report.invalid_price_count}",
        f"Invalid volume: {report.invalid_volume_count}",
        f"Missing values: {report.missing_values_count}",
        f"Issues: {report.issues if report.issues else 'none'}",
    ]
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")
