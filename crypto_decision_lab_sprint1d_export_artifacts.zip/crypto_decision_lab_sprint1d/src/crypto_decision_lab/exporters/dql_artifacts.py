from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any

from crypto_decision_lab.dql.report import DataQualityReport

DQL_ARTIFACT_SCHEMA_VERSION = "qrds.dql_report.v1"
DASHBOARD_PAYLOAD_SCHEMA_VERSION = "qrds.dashboard_payload.v1"

PROHIBITED_ACTIONS = [
    "binance_live",
    "api_key",
    "websocket",
    "orders",
    "real_capital",
    "leverage",
]


def _utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_generated_at(value: str | datetime | None) -> str:
    if value is None:
        return _utc_iso()
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat()
    return value


def report_to_artifact(
    report: DataQualityReport,
    *,
    dataset_label: str,
    symbol: str,
    timeframe: str,
    source_path: str,
    sprint: str = "1D",
    generated_at_utc: str | datetime | None = None,
) -> dict[str, Any]:
    """Convert a DataQualityReport into a versioned QRDS artifact.

    The artifact is intentionally flat and explicit enough to be consumed by
    a future dashboard without needing access to Python objects.
    """
    model_blocked = report.status != "PASS"
    return {
        "schema_version": DQL_ARTIFACT_SCHEMA_VERSION,
        "metadata": {
            "project": "Crypto Decision Lab",
            "sprint": sprint,
            "dataset_label": dataset_label,
            "symbol": symbol,
            "timeframe": timeframe,
            "source_path": source_path,
            "generated_at_utc": _normalize_generated_at(generated_at_utc),
        },
        "gate": {
            "status": report.status,
            "model_blocked": model_blocked,
            "reason": "DQS PASS" if not model_blocked else "DQS blocked by data quality issues",
            "allowed_actions": ["offline_analysis"] if not model_blocked else [],
            "prohibited_actions": PROHIBITED_ACTIONS,
        },
        "scores": {
            "dqs": report.dqs,
            "completeness": report.completeness,
            "freshness": report.freshness,
            "consistency": report.consistency,
            "temporality": report.temporality,
        },
        "counts": {
            "total_candles": report.total_candles,
            "expected_interval_seconds": report.expected_interval_seconds,
            "duplicate_timestamps": report.duplicate_timestamps,
            "gap_count": report.gap_count,
            "invalid_ohlc_count": report.invalid_ohlc_count,
            "invalid_price_count": report.invalid_price_count,
            "invalid_volume_count": report.invalid_volume_count,
            "missing_values_count": report.missing_values_count,
            "timestamp_order_ok": report.timestamp_order_ok,
        },
        "issues": list(report.issues),
        "raw_report": asdict(report),
    }


def export_artifact_json(artifact: dict[str, Any], path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(artifact, indent=2, ensure_ascii=False), encoding="utf-8")
    return target


def export_artifact_txt(artifact: dict[str, Any], path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    metadata = artifact["metadata"]
    gate = artifact["gate"]
    scores = artifact["scores"]
    counts = artifact["counts"]
    issues = artifact["issues"] if artifact["issues"] else "none"
    lines = [
        "QRDS DQL Artifact",
        f"Schema: {artifact['schema_version']}",
        f"Sprint: {metadata['sprint']}",
        f"Dataset: {metadata['dataset_label']}",
        f"Symbol: {metadata['symbol']}",
        f"Timeframe: {metadata['timeframe']}",
        f"Source: {metadata['source_path']}",
        f"Generated UTC: {metadata['generated_at_utc']}",
        "",
        f"Status: {gate['status']}",
        f"Model blocked: {gate['model_blocked']}",
        f"Reason: {gate['reason']}",
        "",
        f"DQS: {scores['dqs']:.4f}",
        f"Completeness: {scores['completeness']:.4f}",
        f"Freshness: {scores['freshness']:.4f}",
        f"Consistency: {scores['consistency']:.4f}",
        f"Temporality: {scores['temporality']:.4f}",
        "",
        f"Total candles: {counts['total_candles']}",
        f"Duplicate timestamps: {counts['duplicate_timestamps']}",
        f"Gap count: {counts['gap_count']}",
        f"Invalid OHLC: {counts['invalid_ohlc_count']}",
        f"Invalid prices: {counts['invalid_price_count']}",
        f"Invalid volume: {counts['invalid_volume_count']}",
        f"Missing values: {counts['missing_values_count']}",
        f"Issues: {issues}",
    ]
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return target


def build_dashboard_payload(
    artifacts: list[dict[str, Any]],
    *,
    generated_at_utc: str | datetime | None = None,
) -> dict[str, Any]:
    if not artifacts:
        return {
            "schema_version": DASHBOARD_PAYLOAD_SCHEMA_VERSION,
            "generated_at_utc": _normalize_generated_at(generated_at_utc),
            "summary": {
                "total_reports": 0,
                "pass_count": 0,
                "blocked_count": 0,
                "worst_dqs": None,
                "best_dqs": None,
            },
            "cards": [],
        }

    cards = []
    for artifact in artifacts:
        metadata = artifact["metadata"]
        gate = artifact["gate"]
        scores = artifact["scores"]
        counts = artifact["counts"]
        cards.append(
            {
                "dataset_label": metadata["dataset_label"],
                "symbol": metadata["symbol"],
                "timeframe": metadata["timeframe"],
                "status": gate["status"],
                "model_blocked": gate["model_blocked"],
                "dqs": scores["dqs"],
                "total_candles": counts["total_candles"],
                "issues_count": len(artifact["issues"]),
                "issues": artifact["issues"],
            }
        )

    dqs_values = [card["dqs"] for card in cards]
    return {
        "schema_version": DASHBOARD_PAYLOAD_SCHEMA_VERSION,
        "generated_at_utc": _normalize_generated_at(generated_at_utc),
        "summary": {
            "total_reports": len(cards),
            "pass_count": sum(1 for card in cards if card["status"] == "PASS"),
            "blocked_count": sum(1 for card in cards if card["status"] == "BLOCKED"),
            "worst_dqs": min(dqs_values),
            "best_dqs": max(dqs_values),
        },
        "cards": cards,
    }


def export_dashboard_payload(payload: dict[str, Any], path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return target
