from crypto_decision_lab.ingestion.binance_klines import load_binance_klines_csv
from crypto_decision_lab.dql.report import generate_data_quality_report

candles = load_binance_klines_csv("data/fixtures/BTCUSDT-1h-sample.csv")
report = generate_data_quality_report(candles, 3600)
print("=== Data Quality Report Offline ===")
print(f"Total candles: {report.total_candles}")
print(f"DQS: {report.dqs:.4f}")
print(f"Status: {report.status}")
print(f"Issues: {report.issues if report.issues else 'none'}")
