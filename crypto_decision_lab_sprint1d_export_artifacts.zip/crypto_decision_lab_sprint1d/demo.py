from datetime import datetime, timedelta, timezone

from crypto_decision_lab.domain.models import MarketCandle
from crypto_decision_lab.dql.score import calculate_dqs, is_model_blocked
from crypto_decision_lab.decision.dummy_decision import make_dummy_decision

base = datetime(2024, 1, 1, tzinfo=timezone.utc)
candles = [
    MarketCandle(base + timedelta(hours=i), 50000 + i, 50100 + i, 49900 + i, 50050 + i, 100 + i)
    for i in range(5)
]
dqs = calculate_dqs(1, 1, 1, 1)
print("=== Demo fake ===")
print(f"Candles: {len(candles)}")
print(f"DQS: {dqs}")
print(f"Blocked: {is_model_blocked(dqs)}")
print(make_dummy_decision(dqs, 0.05, 0.02))
