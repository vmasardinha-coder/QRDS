
from pathlib import Path
from crypto_decision_lab.sprint4g.manual_approval import (
    APPROVAL_PHRASE,
    build_dirty_manual_approval_report,
    build_manual_approval_report,
    export_report,
)

report = build_manual_approval_report()
dirty = build_dirty_manual_approval_report()
paths = export_report(report, Path('/tmp/qrds_sprint4g_test_reports'))

def test_explicit_approval_phrase_authorizes_next_gate_only():
    r = build_manual_approval_report(APPROVAL_PHRASE, live_http_opt_in_enabled=True)
    assert r.approval_status == 'PASS'
    assert r.manual_approval_granted is True
    assert r.live_smoke_authorized is True
    assert r.live_smoke_executed is False
    assert r.network_calls_executed is False

def test_opt_in_without_approval_blocks():
    r = build_manual_approval_report('WRONG', live_http_opt_in_enabled=True)
    assert r.approval_status == 'BLOCKED'
    assert r.model_blocked is True
    assert 'live_opt_in_without_manual_approval' in r.issues

def test_case_01_assert_report_schema_____qrds_public_http_liv():
    assert report.schema == 'qrds.public_http_live_smoke_manual_approval_report.v1'

def test_case_02_assert_report_approval_status_____pass():
    assert report.approval_status == 'PASS'

def test_case_03_assert_report_model_blocked_is_false():
    assert report.model_blocked is False

def test_case_04_assert_report_manual_approval_required_is_tru():
    assert report.manual_approval_required is True

def test_case_05_assert_report_manual_approval_granted_is_fals():
    assert report.manual_approval_granted is False

def test_case_06_assert_report_live_smoke_authorized_is_false():
    assert report.live_smoke_authorized is False

def test_case_07_assert_report_live_http_opt_in_enabled_is_fal():
    assert report.live_http_opt_in_enabled is False

def test_case_08_assert_report_live_smoke_executed_is_false():
    assert report.live_smoke_executed is False

def test_case_09_assert_report_fixture_replay_used_is_true():
    assert report.fixture_replay_used is True

def test_case_10_assert_report_network_calls_executed_is_false():
    assert report.network_calls_executed is False

def test_case_11_assert_report_authenticated_connection_used_i():
    assert report.authenticated_connection_used is False

def test_case_12_assert_report_api_key_required_is_false():
    assert report.api_key_required is False

def test_case_13_assert_report_account_connection_required_is():
    assert report.account_connection_required is False

def test_case_14_assert_report_websocket_used_is_false():
    assert report.websocket_used is False

def test_case_15_assert_report_real_capital_used_is_false():
    assert report.real_capital_used is False

def test_case_16_assert_report_exchange_connected_is_false():
    assert report.exchange_connected is False

def test_case_17_assert_report_orders_generated_is_false():
    assert report.orders_generated is False

def test_case_18_assert_report_endpoint_specs_valid_is_true():
    assert report.endpoint_specs_valid is True

def test_case_19_assert_report_adapter_contract_valid_is_true():
    assert report.adapter_contract_valid is True

def test_case_20_assert_report_timestamp_order_valid_is_true():
    assert report.timestamp_order_valid is True

def test_case_21_assert_report_ohlcv_contract_valid_is_true():
    assert report.ohlcv_contract_valid is True

def test_case_22_assert_report_response_shape_valid_is_true():
    assert report.response_shape_valid is True

def test_case_23_assert_report_normalization_consistent_is_tru():
    assert report.normalization_consistent is True

def test_case_24_assert_report_supported_exchanges______binanc():
    assert report.supported_exchanges == ['binance', 'bybit', 'okx']

def test_case_25_assert_report_normalized_candles_per_exchange():
    assert report.normalized_candles_per_exchange == {'binance': 5, 'bybit': 5, 'okx': 5}

def test_case_26_assert_report_safety_policy_____public_only_n():
    assert report.safety_policy == 'PUBLIC_ONLY_NO_AUTH_MANUAL_APPROVAL_REQUIRED_FIXTURE_DEFAULT'

def test_case_27_assert_report_next_required_gate_____public_h():
    assert report.next_required_gate == 'PUBLIC_HTTP_LIVE_SMOKE_EXPLICIT_APPROVAL_REQUIRED'

def test_case_28_assert_report_issues():
    assert report.issues == []

def test_case_29_assert_report_action_____no_live_smoke_withou():
    assert report.action == 'NO_LIVE_SMOKE_WITHOUT_MANUAL_APPROVAL'

def test_case_30_assert_dirty_approval_status_____blocked():
    assert dirty.approval_status == 'BLOCKED'

def test_case_31_assert_dirty_model_blocked_is_true():
    assert dirty.model_blocked is True

def test_case_32_assert_dirty_live_smoke_executed_is_true():
    assert dirty.live_smoke_executed is True

def test_case_33_assert_dirty_network_calls_executed_is_true():
    assert dirty.network_calls_executed is True

def test_case_34_assert_dirty_authenticated_connection_used_is():
    assert dirty.authenticated_connection_used is True

def test_case_35_assert_dirty_api_key_required_is_true():
    assert dirty.api_key_required is True

def test_case_36_assert_dirty_account_connection_required_is_t():
    assert dirty.account_connection_required is True

def test_case_37_assert_dirty_websocket_used_is_true():
    assert dirty.websocket_used is True

def test_case_38_assert_dirty_real_capital_used_is_true():
    assert dirty.real_capital_used is True

def test_case_39_assert_dirty_exchange_connected_is_true():
    assert dirty.exchange_connected is True

def test_case_40_assert_dirty_orders_generated_is_true():
    assert dirty.orders_generated is True

def test_case_41_assert_dirty_endpoint_specs_valid_is_false():
    assert dirty.endpoint_specs_valid is False

def test_case_42_assert_dirty_adapter_contract_valid_is_false():
    assert dirty.adapter_contract_valid is False

def test_case_43_assert_dirty_timestamp_order_valid_is_false():
    assert dirty.timestamp_order_valid is False

def test_case_44_assert_dirty_ohlcv_contract_valid_is_false():
    assert dirty.ohlcv_contract_valid is False

def test_case_45_assert_dirty_response_shape_valid_is_false():
    assert dirty.response_shape_valid is False

def test_case_46_assert_dirty_normalization_consistent_is_fals():
    assert dirty.normalization_consistent is False

def test_case_47_assert_dirty_safety_policy_____invalid_live_e():
    assert dirty.safety_policy == 'INVALID_LIVE_EXPOSURE'

def test_case_48_assert_dirty_action_____no_public_live_smoke():
    assert dirty.action == 'NO_PUBLIC_LIVE_SMOKE_MANUAL_APPROVAL_BLOCKED'

