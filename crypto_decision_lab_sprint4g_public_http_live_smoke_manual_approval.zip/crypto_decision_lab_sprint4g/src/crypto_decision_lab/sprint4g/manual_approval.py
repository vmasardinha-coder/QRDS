from __future__ import annotations
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List
import json

APPROVAL_PHRASE = "I_APPROVE_PUBLIC_HTTP_NO_AUTH_SMOKE_TEST"
SUPPORTED_EXCHANGES = ["binance", "bybit", "okx"]

@dataclass(frozen=True)
class LiveSmokeManualApprovalReport:
    schema: str = "qrds.public_http_live_smoke_manual_approval_report.v1"
    approval_status: str = "PASS"
    model_blocked: bool = False
    manual_approval_required: bool = True
    manual_approval_granted: bool = False
    live_smoke_authorized: bool = False
    live_http_opt_in_enabled: bool = False
    live_smoke_executed: bool = False
    fixture_replay_used: bool = True
    network_calls_executed: bool = False
    authenticated_connection_used: bool = False
    api_key_required: bool = False
    account_connection_required: bool = False
    websocket_used: bool = False
    real_capital_used: bool = False
    exchange_connected: bool = False
    orders_generated: bool = False
    endpoint_specs_valid: bool = True
    adapter_contract_valid: bool = True
    timestamp_order_valid: bool = True
    ohlcv_contract_valid: bool = True
    response_shape_valid: bool = True
    normalization_consistent: bool = True
    supported_exchanges: List[str] = field(default_factory=lambda: list(SUPPORTED_EXCHANGES))
    normalized_candles_per_exchange: Dict[str, int] = field(default_factory=lambda: {"binance": 5, "bybit": 5, "okx": 5})
    safety_policy: str = "PUBLIC_ONLY_NO_AUTH_MANUAL_APPROVAL_REQUIRED_FIXTURE_DEFAULT"
    next_required_gate: str = "PUBLIC_HTTP_LIVE_SMOKE_EXPLICIT_APPROVAL_REQUIRED"
    issues: List[str] = field(default_factory=list)
    action: str = "NO_LIVE_SMOKE_WITHOUT_MANUAL_APPROVAL"

def build_manual_approval_report(approval_phrase: str | None = None, live_http_opt_in_enabled: bool = False) -> LiveSmokeManualApprovalReport:
    granted = approval_phrase == APPROVAL_PHRASE
    # Sprint 4G validates the manual approval gate only. Even when an approval phrase is supplied,
    # this sprint does not execute network calls. Execution is reserved for a later explicit smoke test sprint.
    authorized = bool(granted and live_http_opt_in_enabled)
    issues: List[str] = []
    if live_http_opt_in_enabled and not granted:
        issues.append("live_opt_in_without_manual_approval")
    return LiveSmokeManualApprovalReport(
        approval_status="PASS" if not issues else "BLOCKED",
        model_blocked=bool(issues),
        manual_approval_granted=granted,
        live_smoke_authorized=authorized,
        live_http_opt_in_enabled=live_http_opt_in_enabled,
        live_smoke_executed=False,
        fixture_replay_used=True,
        network_calls_executed=False,
        issues=issues,
        action="LIVE_SMOKE_AUTHORIZED_FOR_NEXT_GATE_ONLY" if authorized else "NO_LIVE_SMOKE_WITHOUT_MANUAL_APPROVAL",
    )

def build_dirty_manual_approval_report() -> LiveSmokeManualApprovalReport:
    return LiveSmokeManualApprovalReport(
        approval_status="BLOCKED",
        model_blocked=True,
        manual_approval_required=True,
        manual_approval_granted=False,
        live_smoke_authorized=False,
        live_http_opt_in_enabled=True,
        live_smoke_executed=True,
        fixture_replay_used=False,
        network_calls_executed=True,
        authenticated_connection_used=True,
        api_key_required=True,
        account_connection_required=True,
        websocket_used=True,
        real_capital_used=True,
        exchange_connected=True,
        orders_generated=True,
        endpoint_specs_valid=False,
        adapter_contract_valid=False,
        timestamp_order_valid=False,
        ohlcv_contract_valid=False,
        response_shape_valid=False,
        normalization_consistent=False,
        safety_policy="INVALID_LIVE_EXPOSURE",
        next_required_gate="BLOCKED",
        issues=[
            "live_smoke_executed_without_gate",
            "network_calls_executed",
            "authenticated_connection_used",
            "api_key_required",
            "account_connection_required",
            "websocket_used",
            "real_capital_used",
            "exchange_connected",
            "orders_generated",
        ],
        action="NO_PUBLIC_LIVE_SMOKE_MANUAL_APPROVAL_BLOCKED",
    )

def export_report(report: LiveSmokeManualApprovalReport, output_dir: str | Path = "reports/sprint4g") -> dict:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    payload = asdict(report)
    json_path = out / "public_http_live_smoke_manual_approval_report.json"
    txt_path = out / "public_http_live_smoke_manual_approval_report.txt"
    json_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    lines = [
        "Sprint 4G Public HTTP Live Smoke Manual Approval Gate",
        f"Schema: {report.schema}",
        f"Approval status: {report.approval_status}",
        f"Model blocked: {report.model_blocked}",
        f"Manual approval required: {report.manual_approval_required}",
        f"Manual approval granted: {report.manual_approval_granted}",
        f"Live smoke authorized: {report.live_smoke_authorized}",
        f"Live HTTP opt-in enabled: {report.live_http_opt_in_enabled}",
        f"Live smoke executed: {report.live_smoke_executed}",
        f"Fixture replay used: {report.fixture_replay_used}",
        f"Network calls executed: {report.network_calls_executed}",
        f"Authenticated connection used: {report.authenticated_connection_used}",
        f"API key required: {report.api_key_required}",
        f"Account connection required: {report.account_connection_required}",
        f"WebSocket used: {report.websocket_used}",
        f"Real capital used: {report.real_capital_used}",
        f"Exchange connected: {report.exchange_connected}",
        f"Orders generated: {report.orders_generated}",
        f"Supported exchanges: {report.supported_exchanges}",
        f"Safety policy: {report.safety_policy}",
        f"Next required gate: {report.next_required_gate}",
        f"Issues: {report.issues if report.issues else 'none'}",
    ]
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
