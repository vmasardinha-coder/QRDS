from crypto_decision_lab.sprint4g.manual_approval import (
    build_dirty_manual_approval_report,
    build_manual_approval_report,
    export_report,
)

def main():
    report = build_manual_approval_report()
    paths = export_report(report)
    dirty = build_dirty_manual_approval_report()
    print("=== Sprint 4G Public HTTP Live Smoke Manual Approval Gate ===")
    print(f"Approval schema: {report.schema}")
    print(f"Approval status: {report.approval_status}")
    print(f"Model blocked: {report.model_blocked}")
    print(f"Manual approval required: {report.manual_approval_required}")
    print(f"Manual approval granted: {report.manual_approval_granted}")
    print(f"Live smoke authorized: {report.live_smoke_authorized}")
    print(f"Live HTTP opt-in enabled: {report.live_http_opt_in_enabled}")
    print(f"Live smoke executed: {report.live_smoke_executed}")
    print(f"Fixture replay used: {report.fixture_replay_used}")
    print(f"Network calls executed: {report.network_calls_executed}")
    print(f"Authenticated connection used: {report.authenticated_connection_used}")
    print(f"API key required: {report.api_key_required}")
    print(f"Account connection required: {report.account_connection_required}")
    print(f"WebSocket used: {report.websocket_used}")
    print(f"Real capital used: {report.real_capital_used}")
    print(f"Exchange connected: {report.exchange_connected}")
    print(f"Orders generated: {report.orders_generated}")
    print(f"Supported exchanges: {report.supported_exchanges}")
    print(f"Safety policy: {report.safety_policy}")
    print(f"Next required gate: {report.next_required_gate}")
    print(f"Issues: {report.issues if report.issues else 'none'}")
    print(f"Dirty approval status: {dirty.approval_status}")
    print(f"Dirty action: {dirty.action}")
    print(f"Generated files: {paths}")

if __name__ == "__main__":
    main()
