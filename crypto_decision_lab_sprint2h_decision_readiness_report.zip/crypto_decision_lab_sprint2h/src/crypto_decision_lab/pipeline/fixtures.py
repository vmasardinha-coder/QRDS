from crypto_decision_lab.pipeline.contracts import GateReport, BaselineModelReport


def clean_gate_lineage() -> dict[str, GateReport]:
    return {
        "dql": GateReport("qrds.dql_report.v1", "PASS", False, 1.0000, []),
        "feature_quality": GateReport("qrds.feature_quality_report.v1", "PASS", False, 0.9905, []),
        "regime": GateReport("qrds.regime_diagnostics.v1", "PASS", False, 0.9583, []),
        "target_quality": GateReport("qrds.target_quality_report.v1", "PASS", False, 0.9306, []),
        "integrated": GateReport("qrds.integrated_research_dataset.v1", "PASS", False, 0.9756, []),
        "temporal": GateReport("qrds.temporal_validation_report.v1", "PASS", False, 1.0000, []),
    }


def dirty_gate_lineage() -> dict[str, GateReport]:
    return {
        "dql": GateReport("qrds.dql_report.v1", "BLOCKED", True, 0.6979, ["timestamp_gaps", "invalid_ohlc"]),
        "feature_quality": GateReport("qrds.feature_quality_report.v1", "BLOCKED", True, 0.0, ["blocked_by_dql"]),
        "regime": GateReport("qrds.regime_diagnostics.v1", "BLOCKED", True, 0.0, ["blocked_by_dql"]),
        "target_quality": GateReport("qrds.target_quality_report.v1", "BLOCKED", True, 0.0, ["blocked_by_dql"]),
        "integrated": GateReport("qrds.integrated_research_dataset.v1", "BLOCKED", True, 0.0, ["integrated_dataset_blocked_by_gate:dql=BLOCKED"]),
        "temporal": GateReport("qrds.temporal_validation_report.v1", "BLOCKED", True, 0.0, ["blocked_by_integrated_dataset"]),
    }


def clean_baseline_report() -> BaselineModelReport:
    return BaselineModelReport(
        schema="qrds.baseline_model_report.v1",
        model_status="PASS",
        model_blocked=False,
        decision_allowed=False,
        splits=3,
        horizons=[1, 3, 6],
        validation_rows=44,
        prediction_coverage=1.0000,
        model_accuracy=0.2955,
        majority_baseline_accuracy=0.1819,
        edge_vs_majority=0.1136,
        edge_status="RESEARCH_BASELINE_ONLY",
        issues=[],
    )


def dirty_baseline_report() -> BaselineModelReport:
    return BaselineModelReport(
        schema="qrds.baseline_model_report.v1",
        model_status="BLOCKED",
        model_blocked=True,
        decision_allowed=False,
        splits=0,
        horizons=[],
        validation_rows=0,
        prediction_coverage=0.0,
        model_accuracy=0.0,
        majority_baseline_accuracy=0.0,
        edge_vs_majority=0.0,
        edge_status="BLOCKED_BY_GATE",
        issues=["baseline_blocked_by_integrated_dataset"],
    )
