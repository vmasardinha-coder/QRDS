from dataclasses import dataclass, asdict
from typing import Any

@dataclass(frozen=True)
class GateReport:
    schema: str
    status: str
    model_blocked: bool
    quality_score: float
    issues: list[str]

@dataclass(frozen=True)
class BaselineModelReport:
    schema: str
    model_status: str
    model_blocked: bool
    decision_allowed: bool
    splits: int
    horizons: list[int]
    validation_rows: int
    prediction_coverage: float
    model_accuracy: float
    majority_baseline_accuracy: float
    edge_vs_majority: float
    edge_status: str
    issues: list[str]

@dataclass(frozen=True)
class DecisionReadinessReport:
    schema: str
    readiness_status: str
    model_blocked: bool
    research_allowed: bool
    operational_decision_allowed: bool
    decision_stage: str
    action: str
    edge_status: str
    next_required_gate: str
    quality_score: float
    gate_lineage: dict[str, str]
    issues: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
