from crypto_decision_lab.pipeline.contracts import BaselineModelReport, DecisionReadinessReport, GateReport

REQUIRED_GATES = ["dql", "feature_quality", "regime", "target_quality", "integrated", "temporal"]


def _gate_lineage_statuses(gates: dict[str, GateReport]) -> dict[str, str]:
    return {name: gates[name].status for name in REQUIRED_GATES if name in gates}


def validate_required_gates(gates: dict[str, GateReport]) -> list[str]:
    issues: list[str] = []
    for gate in REQUIRED_GATES:
        if gate not in gates:
            issues.append(f"missing_gate:{gate}")
        elif gates[gate].status != "PASS":
            issues.append(f"gate_blocked:{gate}={gates[gate].status}")
        elif gates[gate].model_blocked:
            issues.append(f"gate_model_blocked:{gate}")
    return issues


def validate_baseline(baseline: BaselineModelReport) -> list[str]:
    issues: list[str] = []
    if baseline.model_status != "PASS":
        issues.append(f"baseline_status:{baseline.model_status}")
    if baseline.model_blocked:
        issues.append("baseline_model_blocked")
    if baseline.prediction_coverage < 0.95:
        issues.append("low_prediction_coverage")
    if baseline.validation_rows < 30:
        issues.append("insufficient_validation_rows")
    if baseline.edge_status != "RESEARCH_BASELINE_ONLY":
        issues.append(f"unexpected_edge_status:{baseline.edge_status}")
    return issues


def calculate_readiness_quality(gates: dict[str, GateReport], baseline: BaselineModelReport) -> float:
    gate_scores = [gates[g].quality_score for g in REQUIRED_GATES if g in gates]
    if not gate_scores:
        return 0.0
    baseline_component = max(0.0, min(1.0, baseline.prediction_coverage))
    score = (sum(gate_scores) + baseline_component) / (len(gate_scores) + 1)
    return round(score, 4)


def build_decision_readiness_report(gates: dict[str, GateReport], baseline: BaselineModelReport) -> DecisionReadinessReport:
    issues = validate_required_gates(gates) + validate_baseline(baseline)
    quality_score = calculate_readiness_quality(gates, baseline)
    blocked = bool(issues)

    if blocked:
        return DecisionReadinessReport(
            schema="qrds.decision_readiness_report.v1",
            readiness_status="BLOCKED",
            model_blocked=True,
            research_allowed=False,
            operational_decision_allowed=False,
            decision_stage="BLOCKED",
            action="NO_DECISION_BLOCKED",
            edge_status=baseline.edge_status,
            next_required_gate="FIX_BLOCKING_GATES",
            quality_score=quality_score,
            gate_lineage=_gate_lineage_statuses(gates),
            issues=issues,
        )

    return DecisionReadinessReport(
        schema="qrds.decision_readiness_report.v1",
        readiness_status="PASS",
        model_blocked=False,
        research_allowed=True,
        operational_decision_allowed=False,
        decision_stage="RESEARCH_ONLY",
        action="NO_TRADE_RESEARCH_ONLY",
        edge_status=baseline.edge_status,
        next_required_gate="BACKTEST_REQUIRED",
        quality_score=quality_score,
        gate_lineage=_gate_lineage_statuses(gates),
        issues=[],
    )
