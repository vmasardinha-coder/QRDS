import json
from pathlib import Path
from typing import Any


def export_json(payload: dict[str, Any], path: str | Path) -> str:
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return str(out)


def export_txt(payload: dict[str, Any], path: str | Path) -> str:
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    for key in sorted(payload.keys()):
        lines.append(f"{key}: {payload[key]}")
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(out)


def export_decision_readiness(report, output_dir: str | Path = "reports/sprint2h") -> dict[str, str]:
    out_dir = Path(output_dir)
    payload = report.to_dict()
    return {
        "json": export_json(payload, out_dir / "decision_readiness_report.json"),
        "txt": export_txt(payload, out_dir / "decision_readiness_report.txt"),
    }
