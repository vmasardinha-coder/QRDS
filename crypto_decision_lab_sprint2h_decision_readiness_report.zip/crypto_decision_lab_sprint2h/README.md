# QRDS Core - Sprint 2H - Decision Readiness Report Offline

Objetivo: consolidar os gates offline anteriores em um relatório de prontidão de decisão de pesquisa, sem liberar sinal operacional, ordens, API real ou capital real.

## Escopo

- Consolida DQL, feature quality, regime diagnostics, target quality, integrated dataset, temporal validation e baseline model.
- Produz `qrds.decision_readiness_report.v1`.
- Permite apenas pesquisa offline (`research_allowed=True`).
- Mantém `operational_decision_allowed=False`.
- Próximo gate exigido: `BACKTEST_REQUIRED`.

## Teste

```bash
cd /workspaces/QRDS && \
ZIP="crypto_decision_lab_sprint2h_decision_readiness_report.zip" && \
if [ -f "$ZIP" ] && unzip -t "$ZIP" >/dev/null 2>&1; then \
  echo "ZIP local valido: $ZIP"; \
else \
  echo "ZIP local ausente ou invalido; guardando alteracoes e buscando via git pull"; \
  git stash push -u -m "backup local antes sprint2h $(date -Iseconds)" || true; \
  git pull; \
fi && \
ls -lh "$ZIP" && \
file "$ZIP" && \
unzip -t "$ZIP" && \
rm -rf crypto_decision_lab_sprint2h && \
unzip -o "$ZIP" && \
cd crypto_decision_lab_sprint2h && \
python -m pip install -e . && \
PYTHONPATH="$(pwd)/src" pytest -q tests/ && \
PYTHONPATH="$(pwd)/src" python demo_decision_readiness_report.py
```

## Proibido nesta sprint

- Binance real conectada
- API key real
- WebSocket autenticado
- Ordens
- Capital real
- Alavancagem
- Sinal operacional Long/Short
- Backtest financeiro
