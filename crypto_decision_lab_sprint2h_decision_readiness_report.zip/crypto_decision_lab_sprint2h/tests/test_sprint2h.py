import json
from pathlib import Path

from crypto_decision_lab.pipeline.contracts import BaselineModelReport, GateReport
from crypto_decision_lab.pipeline.decision_readiness import (
    REQUIRED_GATES,
    build_decision_readiness_report,
    calculate_readiness_quality,
    validate_baseline,
    validate_required_gates,
)
from crypto_decision_lab.pipeline.fixtures import (
    clean_baseline_report,
    clean_gate_lineage,
    dirty_baseline_report,
    dirty_gate_lineage,
)
from crypto_decision_lab.reports.exporters import export_decision_readiness, export_json, export_txt


def test_required_gates_list_has_expected_order():
    assert REQUIRED_GATES == ["dql", "feature_quality", "regime", "target_quality", "integrated", "temporal"]


def test_clean_gate_lineage_all_pass():
    gates = clean_gate_lineage()
    assert all(g.status == "PASS" for g in gates.values())


def test_dirty_gate_lineage_has_blocked_dql():
    gates = dirty_gate_lineage()
    assert gates["dql"].status == "BLOCKED"


def test_clean_baseline_report_contract():
    b = clean_baseline_report()
    assert b.schema == "qrds.baseline_model_report.v1"
    assert b.edge_status == "RESEARCH_BASELINE_ONLY"


def test_dirty_baseline_report_contract():
    b = dirty_baseline_report()
    assert b.model_status == "BLOCKED"
    assert b.model_blocked is True


def test_validate_required_gates_clean():
    assert validate_required_gates(clean_gate_lineage()) == []


def test_validate_required_gates_dirty():
    issues = validate_required_gates(dirty_gate_lineage())
    assert "gate_blocked:dql=BLOCKED" in issues


def test_validate_required_gates_missing_gate():
    gates = clean_gate_lineage()
    gates.pop("temporal")
    assert "missing_gate:temporal" in validate_required_gates(gates)


def test_validate_required_gates_model_blocked():
    gates = clean_gate_lineage()
    gates["dql"] = GateReport("x", "PASS", True, 1.0, [])
    assert "gate_model_blocked:dql" in validate_required_gates(gates)


def test_validate_baseline_clean():
    assert validate_baseline(clean_baseline_report()) == []


def test_validate_baseline_blocked():
    issues = validate_baseline(dirty_baseline_report())
    assert "baseline_status:BLOCKED" in issues
    assert "baseline_model_blocked" in issues


def test_validate_baseline_low_coverage():
    b = BaselineModelReport("x", "PASS", False, False, 3, [1], 44, 0.5, 0.3, 0.2, 0.1, "RESEARCH_BASELINE_ONLY", [])
    assert "low_prediction_coverage" in validate_baseline(b)


def test_validate_baseline_low_rows():
    b = BaselineModelReport("x", "PASS", False, False, 3, [1], 10, 1.0, 0.3, 0.2, 0.1, "RESEARCH_BASELINE_ONLY", [])
    assert "insufficient_validation_rows" in validate_baseline(b)


def test_validate_baseline_unexpected_edge_status():
    b = BaselineModelReport("x", "PASS", False, False, 3, [1], 44, 1.0, 0.3, 0.2, 0.1, "LIVE_EDGE", [])
    assert "unexpected_edge_status:LIVE_EDGE" in validate_baseline(b)


def test_calculate_readiness_quality_clean():
    score = calculate_readiness_quality(clean_gate_lineage(), clean_baseline_report())
    assert score == 0.9793


def test_calculate_readiness_quality_empty():
    assert calculate_readiness_quality({}, clean_baseline_report()) == 0.0


def test_build_clean_readiness_status():
    report = build_decision_readiness_report(clean_gate_lineage(), clean_baseline_report())
    assert report.readiness_status == "PASS"


def test_build_clean_readiness_not_model_blocked():
    report = build_decision_readiness_report(clean_gate_lineage(), clean_baseline_report())
    assert report.model_blocked is False


def test_build_clean_research_allowed():
    report = build_decision_readiness_report(clean_gate_lineage(), clean_baseline_report())
    assert report.research_allowed is True


def test_build_clean_operational_decision_not_allowed():
    report = build_decision_readiness_report(clean_gate_lineage(), clean_baseline_report())
    assert report.operational_decision_allowed is False


def test_build_clean_action():
    report = build_decision_readiness_report(clean_gate_lineage(), clean_baseline_report())
    assert report.action == "NO_TRADE_RESEARCH_ONLY"


def test_build_clean_next_gate():
    report = build_decision_readiness_report(clean_gate_lineage(), clean_baseline_report())
    assert report.next_required_gate == "BACKTEST_REQUIRED"


def test_build_dirty_readiness_blocked():
    report = build_decision_readiness_report(dirty_gate_lineage(), dirty_baseline_report())
    assert report.readiness_status == "BLOCKED"


def test_build_dirty_action():
    report = build_decision_readiness_report(dirty_gate_lineage(), dirty_baseline_report())
    assert report.action == "NO_DECISION_BLOCKED"


def test_build_dirty_issues_present():
    report = build_decision_readiness_report(dirty_gate_lineage(), dirty_baseline_report())
    assert report.issues


def test_report_to_dict_has_schema():
    report = build_decision_readiness_report(clean_gate_lineage(), clean_baseline_report())
    assert report.to_dict()["schema"] == "qrds.decision_readiness_report.v1"


def test_export_json_and_txt(tmp_path):
    payload = {"schema": "x", "status": "PASS"}
    j = export_json(payload, tmp_path / "x.json")
    t = export_txt(payload, tmp_path / "x.txt")
    assert json.loads(Path(j).read_text())["status"] == "PASS"
    assert "status: PASS" in Path(t).read_text()


def test_export_decision_readiness(tmp_path):
    report = build_decision_readiness_report(clean_gate_lineage(), clean_baseline_report())
    files = export_decision_readiness(report, tmp_path)
    assert Path(files["json"]).exists()
    assert Path(files["txt"]).exists()
