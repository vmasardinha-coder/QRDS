from crypto_decision_lab.pipeline.decision_readiness import build_decision_readiness_report
from crypto_decision_lab.pipeline.fixtures import (
    clean_baseline_report,
    clean_gate_lineage,
    dirty_baseline_report,
    dirty_gate_lineage,
)
from crypto_decision_lab.reports.exporters import export_decision_readiness

clean = build_decision_readiness_report(clean_gate_lineage(), clean_baseline_report())
dirty = build_decision_readiness_report(dirty_gate_lineage(), dirty_baseline_report())
files = export_decision_readiness(clean)

print("=== Sprint 2H Decision Readiness Report Offline ===")
print(f"Readiness schema: {clean.schema}")
print(f"Readiness status: {clean.readiness_status}")
print(f"Model blocked: {clean.model_blocked}")
print(f"Research allowed: {clean.research_allowed}")
print(f"Operational decision allowed: {clean.operational_decision_allowed}")
print(f"Decision stage: {clean.decision_stage}")
print(f"Action: {clean.action}")
print(f"Edge status: {clean.edge_status}")
print(f"Quality score: {clean.quality_score:.4f}")
print(f"Next required gate: {clean.next_required_gate}")
print(f"Issues: {clean.issues if clean.issues else 'none'}")
print(f"Dirty readiness status: {dirty.readiness_status}")
print(f"Dirty action: {dirty.action}")
print(f"Dirty issues: {dirty.issues}")
print(f"Generated files: {files}")
