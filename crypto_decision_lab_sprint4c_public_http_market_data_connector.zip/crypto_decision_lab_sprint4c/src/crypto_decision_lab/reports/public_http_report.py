from dataclasses import dataclass, asdict
import json
from pathlib import Path

from crypto_decision_lab.connectors.public_http import (
    SUPPORTED_EXCHANGES,
    PublicHttpMarketDataConnector,
    validate_ohlcv_contract,
    validate_timestamp_order,
)


@dataclass(frozen=True)
class PublicHttpMarketDataConnectorReport:
    schema: str
    connector_status: str
    model_blocked: bool
    public_http_market_data_allowed: bool
    authenticated_connection_used: bool
    api_key_required: bool
    account_connection_required: bool
    network_calls_executed: bool
    fixture_replay_used: bool
    endpoint_specs_valid: bool
    adapter_contract_valid: bool
    timestamp_order_valid: bool
    ohlcv_contract_valid: bool
    real_capital_used: bool
    exchange_connected: bool
    orders_generated: bool
    supported_exchanges: list[str]
    normalized_candles_per_exchange: dict[str, int]
    safety_policy: str
    next_required_gate: str
    action: str
    issues: list[str]


def generate_public_http_market_data_connector_report(dirty: bool = False) -> PublicHttpMarketDataConnectorReport:
    if dirty:
        return PublicHttpMarketDataConnectorReport(
            schema="qrds.public_http_market_data_connector_report.v1",
            connector_status="BLOCKED",
            model_blocked=True,
            public_http_market_data_allowed=False,
            authenticated_connection_used=True,
            api_key_required=True,
            account_connection_required=True,
            network_calls_executed=True,
            fixture_replay_used=False,
            endpoint_specs_valid=False,
            adapter_contract_valid=False,
            timestamp_order_valid=False,
            ohlcv_contract_valid=False,
            real_capital_used=True,
            exchange_connected=True,
            orders_generated=True,
            supported_exchanges=SUPPORTED_EXCHANGES,
            normalized_candles_per_exchange={},
            safety_policy="INVALID_AUTHENTICATED_EXPOSURE",
            next_required_gate="BLOCKED_BY_SAFETY_GATE",
            action="NO_PUBLIC_HTTP_CONNECTOR_BLOCKED",
            issues=[
                "authenticated_connection_used",
                "api_key_required",
                "account_connection_required",
                "network_call_executed",
                "real_capital_used",
                "exchange_connected",
                "orders_generated",
            ],
        )

    connector = PublicHttpMarketDataConnector()
    counts: dict[str, int] = {}
    timestamp_checks = []
    ohlcv_checks = []
    spec_checks = []
    for exchange in SUPPORTED_EXCHANGES:
        spec = connector.build_request_spec(exchange)
        spec_checks.append(
            spec.method == "GET"
            and bool(spec.endpoint.startswith("https://"))
            and not spec.api_key_required
            and not spec.account_connection_required
            and not spec.authenticated_connection_used
        )
        candles = connector.fetch_public_klines_fixture(exchange)
        counts[exchange] = len(candles)
        timestamp_checks.append(validate_timestamp_order(candles))
        ohlcv_checks.append(validate_ohlcv_contract(candles))

    endpoint_specs_valid = all(spec_checks)
    timestamp_order_valid = all(timestamp_checks)
    ohlcv_contract_valid = all(ohlcv_checks)
    adapter_contract_valid = endpoint_specs_valid and timestamp_order_valid and ohlcv_contract_valid and all(v == 5 for v in counts.values())
    issues = []
    if not endpoint_specs_valid:
        issues.append("endpoint_specs_invalid")
    if not timestamp_order_valid:
        issues.append("timestamp_order_invalid")
    if not ohlcv_contract_valid:
        issues.append("ohlcv_contract_invalid")
    if connector.http_client.network_calls_executed:
        issues.append("network_call_executed")

    connector_status = "PASS" if adapter_contract_valid and not issues else "BLOCKED"
    return PublicHttpMarketDataConnectorReport(
        schema="qrds.public_http_market_data_connector_report.v1",
        connector_status=connector_status,
        model_blocked=connector_status != "PASS",
        public_http_market_data_allowed=connector_status == "PASS",
        authenticated_connection_used=False,
        api_key_required=False,
        account_connection_required=False,
        network_calls_executed=connector.http_client.network_calls_executed,
        fixture_replay_used=True,
        endpoint_specs_valid=endpoint_specs_valid,
        adapter_contract_valid=adapter_contract_valid,
        timestamp_order_valid=timestamp_order_valid,
        ohlcv_contract_valid=ohlcv_contract_valid,
        real_capital_used=False,
        exchange_connected=False,
        orders_generated=False,
        supported_exchanges=SUPPORTED_EXCHANGES,
        normalized_candles_per_exchange=counts,
        safety_policy="PUBLIC_ONLY_NO_AUTH_FIXTURE_REPLAY",
        next_required_gate="PUBLIC_HTTP_MARKET_DATA_CONNECTOR_VALIDATION_REQUIRED",
        action="ALLOW_PUBLIC_HTTP_CONNECTOR_RESEARCH_ONLY",
        issues=issues,
    )


def export_report(report: PublicHttpMarketDataConnectorReport, output_dir: str | Path = "reports/sprint4c") -> dict[str, str]:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    json_path = out / "public_http_market_data_connector_report.json"
    txt_path = out / "public_http_market_data_connector_report.txt"
    payload = asdict(report)
    json_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    txt_lines = [
        "Public HTTP Market Data Connector Report",
        f"Schema: {report.schema}",
        f"Connector status: {report.connector_status}",
        f"Model blocked: {report.model_blocked}",
        f"Public HTTP market data allowed: {report.public_http_market_data_allowed}",
        f"Authenticated connection used: {report.authenticated_connection_used}",
        f"API key required: {report.api_key_required}",
        f"Account connection required: {report.account_connection_required}",
        f"Network calls executed: {report.network_calls_executed}",
        f"Fixture replay used: {report.fixture_replay_used}",
        f"Supported exchanges: {report.supported_exchanges}",
        f"Normalized candles per exchange: {report.normalized_candles_per_exchange}",
        f"Next required gate: {report.next_required_gate}",
        f"Issues: {report.issues if report.issues else 'none'}",
    ]
    txt_path.write_text("\n".join(txt_lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
