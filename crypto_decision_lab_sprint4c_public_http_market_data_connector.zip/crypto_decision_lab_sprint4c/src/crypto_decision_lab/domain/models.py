from dataclasses import dataclass
from datetime import datetime, timezone


@dataclass(frozen=True)
class MarketCandle:
    exchange: str
    symbol: str
    timeframe: str
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float

    def is_ohlcv_valid(self) -> bool:
        return (
            self.low <= self.open <= self.high
            and self.low <= self.close <= self.high
            and self.low <= self.high
            and self.open > 0
            and self.high > 0
            and self.low > 0
            and self.close > 0
            and self.volume >= 0
            and self.timestamp.tzinfo is not None
        )


def ms_to_utc(ms: int | str) -> datetime:
    return datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc)
