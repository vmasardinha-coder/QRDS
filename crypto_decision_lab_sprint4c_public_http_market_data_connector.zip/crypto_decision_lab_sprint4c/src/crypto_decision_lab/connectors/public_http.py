from dataclasses import dataclass
from typing import Any

from crypto_decision_lab.domain.models import MarketCandle, ms_to_utc

SUPPORTED_EXCHANGES = ["binance", "bybit", "okx"]


@dataclass(frozen=True)
class PublicHttpRequestSpec:
    exchange: str
    endpoint: str
    method: str
    symbol: str
    timeframe: str
    limit: int
    params: dict[str, Any]
    api_key_required: bool = False
    account_connection_required: bool = False
    authenticated_connection_used: bool = False


class StaticFixtureHttpClient:
    """Deterministic fixture/replay client.

    Sprint 4C intentionally executes no real network call. This class mimics
    a public HTTP client boundary while keeping network_calls_executed=False.
    """

    def __init__(self) -> None:
        self.network_calls_executed = False

    def get_json(self, spec: PublicHttpRequestSpec) -> Any:
        if spec.exchange == "binance":
            return BINANCE_FIXTURE
        if spec.exchange == "bybit":
            return BYBIT_FIXTURE
        if spec.exchange == "okx":
            return OKX_FIXTURE
        raise ValueError(f"unsupported_exchange:{spec.exchange}")


class PublicHttpMarketDataConnector:
    def __init__(self, http_client: StaticFixtureHttpClient | None = None) -> None:
        self.http_client = http_client or StaticFixtureHttpClient()

    def build_request_spec(self, exchange: str, symbol: str = "BTCUSDT", timeframe: str = "1h", limit: int = 5) -> PublicHttpRequestSpec:
        exchange = exchange.lower()
        if exchange not in SUPPORTED_EXCHANGES:
            raise ValueError(f"unsupported_exchange:{exchange}")
        endpoint_map = {
            "binance": "https://fapi.binance.com/fapi/v1/klines",
            "bybit": "https://api.bybit.com/v5/market/kline",
            "okx": "https://www.okx.com/api/v5/market/candles",
        }
        params_map = {
            "binance": {"symbol": symbol, "interval": timeframe, "limit": limit},
            "bybit": {"category": "linear", "symbol": symbol, "interval": "60", "limit": limit},
            "okx": {"instId": "BTC-USDT-SWAP", "bar": timeframe, "limit": limit},
        }
        return PublicHttpRequestSpec(
            exchange=exchange,
            endpoint=endpoint_map[exchange],
            method="GET",
            symbol=symbol,
            timeframe=timeframe,
            limit=limit,
            params=params_map[exchange],
        )

    def fetch_public_klines_fixture(self, exchange: str, symbol: str = "BTCUSDT", timeframe: str = "1h", limit: int = 5) -> list[MarketCandle]:
        spec = self.build_request_spec(exchange, symbol, timeframe, limit)
        payload = self.http_client.get_json(spec)
        return normalize_public_payload(spec, payload)


def normalize_public_payload(spec: PublicHttpRequestSpec, payload: Any) -> list[MarketCandle]:
    if spec.exchange == "binance":
        candles = [
            MarketCandle(spec.exchange, spec.symbol, spec.timeframe, ms_to_utc(row[0]), float(row[1]), float(row[2]), float(row[3]), float(row[4]), float(row[5]))
            for row in payload
        ]
    elif spec.exchange == "bybit":
        rows = payload["result"]["list"]
        candles = [
            MarketCandle(spec.exchange, spec.symbol, spec.timeframe, ms_to_utc(row[0]), float(row[1]), float(row[2]), float(row[3]), float(row[4]), float(row[5]))
            for row in rows
        ]
    elif spec.exchange == "okx":
        rows = payload["data"]
        candles = [
            MarketCandle(spec.exchange, spec.symbol, spec.timeframe, ms_to_utc(row[0]), float(row[1]), float(row[2]), float(row[3]), float(row[4]), float(row[5]))
            for row in rows
        ]
    else:
        raise ValueError(f"unsupported_exchange:{spec.exchange}")
    return sorted(candles, key=lambda c: c.timestamp)


def validate_timestamp_order(candles: list[MarketCandle]) -> bool:
    return all(candles[i].timestamp > candles[i - 1].timestamp for i in range(1, len(candles)))


def validate_ohlcv_contract(candles: list[MarketCandle]) -> bool:
    return bool(candles) and all(c.is_ohlcv_valid() for c in candles)


BINANCE_FIXTURE = [
    [1704067200000, "50000", "50100", "49900", "50050", "100"],
    [1704070800000, "50050", "50200", "50000", "50150", "101"],
    [1704074400000, "50150", "50300", "50100", "50250", "102"],
    [1704078000000, "50250", "50400", "50200", "50350", "103"],
    [1704081600000, "50350", "50500", "50300", "50450", "104"],
]

# Reverse order on purpose; normalizer must sort ascending.
BYBIT_FIXTURE = {"retCode": 0, "result": {"list": [
    ["1704081600000", "50350", "50500", "50300", "50450", "104", "0"],
    ["1704078000000", "50250", "50400", "50200", "50350", "103", "0"],
    ["1704074400000", "50150", "50300", "50100", "50250", "102", "0"],
    ["1704070800000", "50050", "50200", "50000", "50150", "101", "0"],
    ["1704067200000", "50000", "50100", "49900", "50050", "100", "0"],
]}}

OKX_FIXTURE = {"code": "0", "data": [
    ["1704081600000", "50350", "50500", "50300", "50450", "104", "0"],
    ["1704078000000", "50250", "50400", "50200", "50350", "103", "0"],
    ["1704074400000", "50150", "50300", "50100", "50250", "102", "0"],
    ["1704070800000", "50050", "50200", "50000", "50150", "101", "0"],
    ["1704067200000", "50000", "50100", "49900", "50050", "100", "0"],
]}
