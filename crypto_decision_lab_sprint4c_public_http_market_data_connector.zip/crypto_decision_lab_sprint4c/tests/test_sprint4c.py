import json
from pathlib import Path

import pytest

from crypto_decision_lab.connectors.public_http import (
    SUPPORTED_EXCHANGES,
    PublicHttpMarketDataConnector,
    StaticFixtureHttpClient,
    validate_ohlcv_contract,
    validate_timestamp_order,
)
from crypto_decision_lab.reports.public_http_report import generate_public_http_market_data_connector_report, export_report


@pytest.fixture()
def connector():
    return PublicHttpMarketDataConnector()


@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_supported_exchanges_have_specs(connector, exchange):
    spec = connector.build_request_spec(exchange)
    assert spec.exchange == exchange
    assert spec.method == "GET"


@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_request_specs_public_only(connector, exchange):
    spec = connector.build_request_spec(exchange)
    assert spec.endpoint.startswith("https://")
    assert spec.api_key_required is False
    assert spec.account_connection_required is False
    assert spec.authenticated_connection_used is False


@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_fixture_client_returns_payloads(exchange):
    client = StaticFixtureHttpClient()
    spec = PublicHttpMarketDataConnector(client).build_request_spec(exchange)
    payload = client.get_json(spec)
    assert payload
    assert client.network_calls_executed is False


@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_connector_normalizes_five_candles(connector, exchange):
    candles = connector.fetch_public_klines_fixture(exchange)
    assert len(candles) == 5


@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_normalized_candles_are_timestamp_ordered(connector, exchange):
    candles = connector.fetch_public_klines_fixture(exchange)
    assert validate_timestamp_order(candles)


@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_normalized_candles_have_valid_ohlcv(connector, exchange):
    candles = connector.fetch_public_klines_fixture(exchange)
    assert validate_ohlcv_contract(candles)


@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_all_candles_keep_exchange_name(connector, exchange):
    candles = connector.fetch_public_klines_fixture(exchange)
    assert all(c.exchange == exchange for c in candles)


@pytest.mark.parametrize("exchange", SUPPORTED_EXCHANGES)
def test_report_candle_counts_per_exchange(exchange):
    report = generate_public_http_market_data_connector_report()
    assert report.normalized_candles_per_exchange[exchange] == 5


def test_report_pass():
    report = generate_public_http_market_data_connector_report()
    assert report.connector_status == "PASS"


def test_dirty_report_blocked():
    report = generate_public_http_market_data_connector_report(dirty=True)
    assert report.connector_status == "BLOCKED"


def test_unsupported_exchange_raises(connector):
    with pytest.raises(ValueError):
        connector.build_request_spec("kraken")


def test_no_network_calls_executed():
    report = generate_public_http_market_data_connector_report()
    assert report.network_calls_executed is False


def test_no_authenticated_connection_used():
    report = generate_public_http_market_data_connector_report()
    assert report.authenticated_connection_used is False


def test_no_api_key_required():
    report = generate_public_http_market_data_connector_report()
    assert report.api_key_required is False


def test_no_account_connection_required():
    report = generate_public_http_market_data_connector_report()
    assert report.account_connection_required is False


def test_no_real_capital_used():
    report = generate_public_http_market_data_connector_report()
    assert report.real_capital_used is False


def test_no_orders_generated():
    report = generate_public_http_market_data_connector_report()
    assert report.orders_generated is False


def test_fixture_replay_used():
    report = generate_public_http_market_data_connector_report()
    assert report.fixture_replay_used is True


def test_endpoint_specs_valid():
    report = generate_public_http_market_data_connector_report()
    assert report.endpoint_specs_valid is True


def test_adapter_contract_valid():
    report = generate_public_http_market_data_connector_report()
    assert report.adapter_contract_valid is True


def test_next_gate_correct():
    report = generate_public_http_market_data_connector_report()
    assert report.next_required_gate == "PUBLIC_HTTP_MARKET_DATA_CONNECTOR_VALIDATION_REQUIRED"


def test_export_writes_files(tmp_path):
    report = generate_public_http_market_data_connector_report()
    paths = export_report(report, tmp_path)
    assert Path(paths["json"]).exists()
    assert Path(paths["txt"]).exists()


def test_txt_export_includes_status(tmp_path):
    report = generate_public_http_market_data_connector_report()
    paths = export_report(report, tmp_path)
    assert "Connector status: PASS" in Path(paths["txt"]).read_text()


def test_report_json_roundtrip(tmp_path):
    report = generate_public_http_market_data_connector_report()
    paths = export_report(report, tmp_path)
    payload = json.loads(Path(paths["json"]).read_text())
    assert payload["schema"] == "qrds.public_http_market_data_connector_report.v1"


def test_safety_policy():
    report = generate_public_http_market_data_connector_report()
    assert report.safety_policy == "PUBLIC_ONLY_NO_AUTH_FIXTURE_REPLAY"


def test_model_blocked_false_on_pass():
    report = generate_public_http_market_data_connector_report()
    assert report.model_blocked is False
