# Sprint 4C - Public HTTP Market Data Connector Skeleton

Public HTTP market data connector skeleton for Binance, Bybit and OKX.

Safety constraints:

- No API key.
- No real account connection.
- No authenticated WebSocket.
- No orders.
- No real capital.
- No real network calls by default.
- Fixture/replay mode only in this sprint.

Run:

```bash
python -m pip install -e .
PYTHONPATH="$(pwd)/src" pytest -q tests/
PYTHONPATH="$(pwd)/src" python demo_public_http_market_data_connector.py
```
