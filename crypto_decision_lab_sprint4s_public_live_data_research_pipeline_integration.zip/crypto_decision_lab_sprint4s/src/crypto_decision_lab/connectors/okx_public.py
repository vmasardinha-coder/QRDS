import json
import urllib.request
from crypto_decision_lab.domain import Candle

OKX_CANDLES_ENDPOINT = "https://www.okx.com/api/v5/market/candles"


def normalize_okx_candles(payload, symbol="BTC-USDT", timeframe="1H"):
    rows = payload.get("data", []) if isinstance(payload, dict) else []
    candles = []
    for row in rows[:5]:
        ts, o, h, l, c, vol = row[0], row[1], row[2], row[3], row[4], row[5]
        candles.append(Candle(
            exchange="okx",
            route="PUBLIC_HTTP_LIVE",
            timestamp_ms=int(ts),
            open=float(o), high=float(h), low=float(l), close=float(c), volume=float(vol),
            symbol=symbol, timeframe=timeframe,
        ))
    candles.sort(key=lambda candle: candle.timestamp_ms)
    return candles


def fetch_okx_public_candles(symbol="BTC-USDT", timeframe="1H", limit=5, timeout=10):
    url = f"{OKX_CANDLES_ENDPOINT}?instId={symbol}&bar={timeframe}&limit={int(limit)}"
    req = urllib.request.Request(url, headers={"User-Agent": "QRDS-QOS-PublicData/1.0", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        raw = response.read().decode("utf-8")
    payload = json.loads(raw)
    return normalize_okx_candles(payload, symbol=symbol, timeframe=timeframe)
