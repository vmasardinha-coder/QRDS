from crypto_decision_lab.domain import Candle


def binance_simulation_candles():
    base_ts = 1704067200000
    rows = []
    for i in range(5):
        close = 50050.0 + i * 100.0
        rows.append(Candle(
            exchange="binance",
            route="SIMULATION_FIXTURE_REPLAY",
            timestamp_ms=base_ts + i * 3600_000,
            open=50000.0 + i * 100.0,
            high=50100.0 + i * 100.0,
            low=49900.0 + i * 100.0,
            close=close,
            volume=100.0 + i,
            symbol="BTC-USDT",
            timeframe="1H",
        ))
    return rows


def okx_fixture_candles():
    base_ts = 1704067200000
    rows = []
    for i in range(5):
        rows.append(Candle(
            exchange="okx",
            route="PUBLIC_HTTP_LIVE_FIXTURE",
            timestamp_ms=base_ts + i * 3600_000,
            open=51000.0 + i * 90.0,
            high=51100.0 + i * 90.0,
            low=50900.0 + i * 90.0,
            close=51050.0 + i * 90.0,
            volume=95.0 + i,
            symbol="BTC-USDT",
            timeframe="1H",
        ))
    return rows
