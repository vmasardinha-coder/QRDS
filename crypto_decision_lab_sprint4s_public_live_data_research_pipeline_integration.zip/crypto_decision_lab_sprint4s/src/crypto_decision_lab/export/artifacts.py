import json
from dataclasses import asdict, is_dataclass
from pathlib import Path


def _to_plain(value):
    if is_dataclass(value):
        return _to_plain(asdict(value))
    if isinstance(value, dict):
        return {str(k): _to_plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_plain(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    return value


def _flatten_lines(value, prefix=""):
    lines = []
    if isinstance(value, dict):
        for k, v in value.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            lines.extend(_flatten_lines(v, key))
    elif isinstance(value, list):
        lines.append(f"{prefix}: {value}")
    else:
        lines.append(f"{prefix}: {value}")
    return lines


def write_json_txt(payload, output_dir="reports/sprint4s", stem="public_live_research_pipeline_report"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    plain = _to_plain(payload)
    json_path = out / f"{stem}.json"
    txt_path = out / f"{stem}.txt"
    json_path.write_text(json.dumps(plain, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    txt_path.write_text("\n".join(_flatten_lines(plain)) + "\n", encoding="utf-8")
    return {"json": str(json_path), "txt": str(txt_path)}
