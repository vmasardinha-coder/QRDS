def build_regime_report(feature_rows):
    regimes = []
    for row in feature_rows:
        range_pct = row.get("range_pct") or 0.0
        close_position = row.get("close_position") or 0.5
        volatility = "high_volatility" if range_pct > 0.003 else "normal_volatility"
        candle = "upper_close" if close_position > 0.66 else "lower_close" if close_position < 0.33 else "balanced_candle"
        regimes.append(f"{volatility}|{candle}")
    status = "PASS" if regimes else "BLOCKED"
    return {"regime_status": status, "regime_variants": len(set(regimes)), "last_regime_code": regimes[-1] if regimes else None}
