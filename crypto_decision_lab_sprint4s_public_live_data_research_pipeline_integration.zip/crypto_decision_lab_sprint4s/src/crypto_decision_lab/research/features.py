def build_feature_rows(candles):
    rows = []
    by_route = {}
    for c in candles:
        by_route.setdefault(c.route, []).append(c)
    for route, items in by_route.items():
        items = sorted(items, key=lambda c: c.timestamp_ms)
        prev_close = None
        for c in items:
            simple_return = None if prev_close is None else (c.close / prev_close) - 1.0
            range_pct = (c.high - c.low) / c.close if c.close else None
            close_position = (c.close - c.low) / (c.high - c.low) if c.high != c.low else 0.5
            rows.append({
                "exchange": c.exchange,
                "route": route,
                "timestamp_ms": c.timestamp_ms,
                "close": c.close,
                "volume": c.volume,
                "simple_return_1": simple_return,
                "range_pct": range_pct,
                "close_position": close_position,
            })
            prev_close = c.close
    return rows


def feature_quality_report(rows):
    required = {"exchange", "route", "timestamp_ms", "close", "volume", "range_pct", "close_position"}
    valid = all(required.issubset(row.keys()) for row in rows) and len(rows) >= 10
    finite_like = all(row["close"] > 0 and row["volume"] >= 0 for row in rows)
    status = "PASS" if valid and finite_like else "BLOCKED"
    return {"feature_quality_status": status, "feature_rows": len(rows), "required_features_present": valid, "finite_ratio": 1.0 if finite_like else 0.0}
