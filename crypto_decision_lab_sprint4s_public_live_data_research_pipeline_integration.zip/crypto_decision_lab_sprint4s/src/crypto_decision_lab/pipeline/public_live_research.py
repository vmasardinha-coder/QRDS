import os
from crypto_decision_lab.connectors.fixtures import binance_simulation_candles, okx_fixture_candles
from crypto_decision_lab.connectors.okx_public import fetch_okx_public_candles, OKX_CANDLES_ENDPOINT
from crypto_decision_lab.dql.report import dql_report
from crypto_decision_lab.research.features import build_feature_rows, feature_quality_report
from crypto_decision_lab.research.regime import build_regime_report

APPROVAL = "APROVO OKX PUBLIC HTTP LIVE PIPELINE SEM API KEY, SEM CONTA REAL, SEM ORDEM E SEM CAPITAL REAL."


def run_public_live_research_pipeline():
    enabled = os.getenv("QRDS_OKX_PUBLIC_LIVE_RESEARCH_PIPELINE_ENABLED") == "1"
    approval = os.getenv("QRDS_OKX_PUBLIC_LIVE_RESEARCH_PIPELINE_APPROVAL") == APPROVAL
    network_calls = False
    okx_live_error = None
    fixture_replay = not (enabled and approval)

    if enabled and approval:
        try:
            okx_candles = fetch_okx_public_candles()
            network_calls = True
        except Exception as exc:
            okx_candles = []
            okx_live_error = f"{type(exc).__name__}:{exc}"
            network_calls = True
    else:
        okx_candles = okx_fixture_candles()

    binance_candles = binance_simulation_candles()
    all_candles = okx_candles + binance_candles
    dql = dql_report(all_candles, bybit_pending=True)
    features = build_feature_rows(all_candles) if dql["dql_status"] == "PASS" else []
    fq = feature_quality_report(features) if features else {"feature_quality_status": "BLOCKED", "feature_rows": 0, "required_features_present": False, "finite_ratio": 0.0}
    regime = build_regime_report(features) if fq["feature_quality_status"] == "PASS" else {"regime_status": "BLOCKED", "regime_variants": 0, "last_regime_code": None}

    pipeline_status = "PASS" if dql["dql_status"] == fq["feature_quality_status"] == regime["regime_status"] == "PASS" else "BLOCKED"
    issues = list(dql["issues"])
    if okx_live_error:
        issues.append(f"okx_public_live_error:{okx_live_error}")
    if pipeline_status != "PASS":
        issues.append("research_pipeline_integration_blocked")

    return {
        "research_pipeline_schema": "qrds.public_live_data_research_pipeline_report.v1",
        "pipeline_status": pipeline_status,
        "dql_status": dql["dql_status"],
        "feature_quality_status": fq["feature_quality_status"],
        "regime_status": regime["regime_status"],
        "model_blocked": pipeline_status != "PASS",
        "research_allowed": pipeline_status == "PASS",
        "operational_decision_allowed": False,
        "simulation_exchange": "binance",
        "binance_route": "SIMULATION_FIXTURE_REPLAY",
        "okx_route": "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_EXECUTED_NO_AUTH" if network_calls and okx_candles else "PUBLIC_HTTP_LIVE_RESEARCH_PIPELINE_FIXTURE_OR_BLOCKED",
        "bybit_route": "PENDING_BLOCKED_BY_403",
        "real_base_target_exchanges": ["okx", "bybit"],
        "real_base_active_now": ["okx"] if okx_candles else [],
        "real_base_pending": ["bybit"] + ([] if okx_candles else ["okx"]),
        "live_pipeline_enabled": enabled,
        "manual_approval_granted": approval,
        "fixture_replay_used": fixture_replay,
        "network_calls_executed": network_calls,
        "authenticated_connection_used": False,
        "api_key_required": False,
        "api_key_present": False,
        "account_connection_required": False,
        "websocket_used": False,
        "real_capital_used": False,
        "exchange_connected": False,
        "orders_generated": False,
        "endpoint": OKX_CANDLES_ENDPOINT,
        "instrument": "BTC-USDT",
        "okx_candles_normalized": dql["okx_candles_normalized"],
        "binance_simulation_candles_normalized": dql["binance_simulation_candles_normalized"],
        "total_normalized_candles": dql["total_normalized_candles"],
        "timestamp_order_valid": dql["timestamp_order_valid"],
        "ohlcv_contract_valid": dql["ohlcv_contract_valid"],
        "feature_rows": fq["feature_rows"],
        "regime_variants": regime["regime_variants"],
        "last_regime_code": regime["last_regime_code"],
        "quality_score": 1.0 if pipeline_status == "PASS" else 0.0,
        "safety_policy": "PUBLIC_LIVE_DATA_RESEARCH_PIPELINE_NO_AUTH_NO_ORDERS_NO_REAL_CAPITAL",
        "issues": issues,
        "action": "PROMOTE_PUBLIC_LIVE_DATA_RESEARCH_PIPELINE_FOR_RESEARCH_ONLY" if pipeline_status == "PASS" else "NO_RESEARCH_PIPELINE_BLOCKED",
        "next_required_gate": "PUBLIC_LIVE_RESEARCH_PIPELINE_REVIEW_REQUIRED" if pipeline_status == "PASS" else "PUBLIC_LIVE_RESEARCH_PIPELINE_REMEDIATION_REQUIRED",
    }
