from dataclasses import dataclass

@dataclass(frozen=True)
class Candle:
    exchange: str
    route: str
    timestamp_ms: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    symbol: str = "BTC-USDT"
    timeframe: str = "1H"
