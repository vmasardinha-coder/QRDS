def timestamp_order_valid(candles):
    by_route = {}
    for c in candles:
        by_route.setdefault(c.route, []).append(c)
    return all(all(items[i].timestamp_ms > items[i - 1].timestamp_ms for i in range(1, len(items))) for items in by_route.values())


def ohlcv_contract_valid(candles):
    for c in candles:
        if not (c.low <= c.open <= c.high and c.low <= c.close <= c.high):
            return False
        if min(c.open, c.high, c.low, c.close) <= 0:
            return False
        if c.volume < 0:
            return False
    return True


def dql_report(candles, bybit_pending=True):
    total = len(candles)
    order = timestamp_order_valid(candles)
    ohlcv = ohlcv_contract_valid(candles)
    okx_count = sum(1 for c in candles if c.exchange == "okx")
    binance_count = sum(1 for c in candles if c.exchange == "binance")
    quality = 1.0 if total >= 10 and order and ohlcv and okx_count >= 5 and binance_count >= 5 else 0.0
    status = "PASS" if quality == 1.0 else "BLOCKED"
    issues = []
    if bybit_pending:
        issues.append("bybit_public_http_blocked_by_403_pending_not_blocking")
    if status != "PASS":
        issues.append("public_live_data_dql_failed")
    return {
        "dql_status": status,
        "quality_score": quality,
        "timestamp_order_valid": order,
        "ohlcv_contract_valid": ohlcv,
        "okx_candles_normalized": okx_count,
        "binance_simulation_candles_normalized": binance_count,
        "total_normalized_candles": total,
        "issues": issues,
    }
