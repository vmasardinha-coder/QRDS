import os
import pytest
from crypto_decision_lab.connectors.fixtures import binance_simulation_candles, okx_fixture_candles
from crypto_decision_lab.connectors.okx_public import normalize_okx_candles
from crypto_decision_lab.dql.report import dql_report, timestamp_order_valid, ohlcv_contract_valid
from crypto_decision_lab.research.features import build_feature_rows, feature_quality_report
from crypto_decision_lab.research.regime import build_regime_report
from crypto_decision_lab.pipeline.public_live_research import run_public_live_research_pipeline, APPROVAL


def sample_okx_payload():
    return {"data": [
        ["1704081600000", "50350", "50500", "50300", "50450", "104"],
        ["1704078000000", "50250", "50400", "50200", "50350", "103"],
        ["1704074400000", "50150", "50300", "50100", "50250", "102"],
        ["1704070800000", "50050", "50200", "50000", "50150", "101"],
        ["1704067200000", "50000", "50100", "49900", "50050", "100"],
    ]}


def test_okx_normalization_orders_candles():
    candles = normalize_okx_candles(sample_okx_payload())
    assert len(candles) == 5
    assert candles[0].timestamp_ms < candles[-1].timestamp_ms
    assert candles[0].exchange == "okx"


def test_fixture_routes():
    assert all(c.route == "SIMULATION_FIXTURE_REPLAY" for c in binance_simulation_candles())
    assert all(c.exchange == "okx" for c in okx_fixture_candles())


def test_dql_passes_combined_fixture():
    candles = okx_fixture_candles() + binance_simulation_candles()
    r = dql_report(candles)
    assert r["dql_status"] == "PASS"
    assert r["total_normalized_candles"] == 10


def test_feature_and_regime_pass():
    rows = build_feature_rows(okx_fixture_candles() + binance_simulation_candles())
    fq = feature_quality_report(rows)
    rg = build_regime_report(rows)
    assert fq["feature_quality_status"] == "PASS"
    assert rg["regime_status"] == "PASS"


def test_pipeline_fixture_default_blocks_no_safety_exposure(monkeypatch):
    monkeypatch.delenv("QRDS_OKX_PUBLIC_LIVE_RESEARCH_PIPELINE_ENABLED", raising=False)
    monkeypatch.delenv("QRDS_OKX_PUBLIC_LIVE_RESEARCH_PIPELINE_APPROVAL", raising=False)
    r = run_public_live_research_pipeline()
    assert r["pipeline_status"] == "PASS"
    assert r["network_calls_executed"] is False
    assert r["orders_generated"] is False


def test_pipeline_with_wrong_approval_uses_fixture(monkeypatch):
    monkeypatch.setenv("QRDS_OKX_PUBLIC_LIVE_RESEARCH_PIPELINE_ENABLED", "1")
    monkeypatch.setenv("QRDS_OKX_PUBLIC_LIVE_RESEARCH_PIPELINE_APPROVAL", "WRONG")
    r = run_public_live_research_pipeline()
    assert r["manual_approval_granted"] is False
    assert r["fixture_replay_used"] is True


@pytest.mark.parametrize("idx", range(10))
def test_binance_fixture_ohlcv_contract_idx(idx):
    c = binance_simulation_candles()[idx % 5]
    assert c.low <= c.open <= c.high
    assert c.low <= c.close <= c.high
    assert c.volume >= 0


@pytest.mark.parametrize("idx", range(10))
def test_okx_fixture_ohlcv_contract_idx(idx):
    c = okx_fixture_candles()[idx % 5]
    assert c.low <= c.open <= c.high
    assert c.low <= c.close <= c.high
    assert c.volume >= 0


@pytest.mark.parametrize("field", [
    "pipeline_status", "dql_status", "feature_quality_status", "regime_status", "model_blocked",
    "research_allowed", "operational_decision_allowed", "simulation_exchange", "binance_route", "okx_route",
    "bybit_route", "live_pipeline_enabled", "fixture_replay_used", "network_calls_executed",
    "authenticated_connection_used", "api_key_required", "api_key_present", "account_connection_required",
    "websocket_used", "real_capital_used", "exchange_connected", "orders_generated", "quality_score",
    "safety_policy", "action", "next_required_gate",
])
def test_report_contains_required_fields(field, monkeypatch):
    monkeypatch.delenv("QRDS_OKX_PUBLIC_LIVE_RESEARCH_PIPELINE_ENABLED", raising=False)
    r = run_public_live_research_pipeline()
    assert field in r


@pytest.mark.parametrize("route", ["SIMULATION_FIXTURE_REPLAY", "PUBLIC_HTTP_LIVE_FIXTURE"])
def test_route_counts(route):
    candles = okx_fixture_candles() + binance_simulation_candles()
    assert sum(1 for c in candles if c.route == route) == 5


@pytest.mark.parametrize("bad_attr", ["open", "high", "low", "close", "volume"])
def test_ohlcv_report_rejects_bad_candles(bad_attr):
    candles = okx_fixture_candles() + binance_simulation_candles()
    first = candles[0]
    values = first.__dict__.copy()
    values[bad_attr] = -1.0
    from crypto_decision_lab.domain import Candle
    bad = Candle(**values)
    mixed = [bad] + candles[1:]
    assert ohlcv_contract_valid(mixed) is False


@pytest.mark.parametrize("n", range(4))
def test_feature_rows_have_expected_shape(n):
    rows = build_feature_rows(okx_fixture_candles() + binance_simulation_candles())
    row = rows[n]
    assert "range_pct" in row
    assert "close_position" in row
    assert row["close"] > 0


def test_timestamp_order_valid():
    assert timestamp_order_valid(okx_fixture_candles() + binance_simulation_candles()) is True


def test_feature_quality_blocks_empty():
    assert feature_quality_report([])["feature_quality_status"] == "BLOCKED"


def test_regime_blocks_empty():
    assert build_regime_report([])["regime_status"] == "BLOCKED"


def test_approval_constant_exact():
    assert APPROVAL.startswith("APROVO OKX PUBLIC HTTP LIVE PIPELINE")


def test_export_artifact_smoke(tmp_path):
    from crypto_decision_lab.export.artifacts import write_json_txt
    paths = write_json_txt({"status": "PASS"}, output_dir=tmp_path, stem="x")
    assert paths["json"].endswith("x.json")
    assert paths["txt"].endswith("x.txt")
