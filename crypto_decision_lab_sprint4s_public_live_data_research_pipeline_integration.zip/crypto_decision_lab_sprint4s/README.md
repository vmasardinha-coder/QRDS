# Crypto Decision Lab - Sprint 4S

Public Live Data Research Pipeline Integration.

Scope:
- OKX public HTTP live market data, no API key.
- Binance simulation / fixture replay only.
- Bybit pending due to HTTP 403 in Codespaces.
- DQL + feature engineering + regime diagnostics integrated for research only.

Forbidden:
- API key, real account, authenticated WebSocket, orders, real capital, leverage, operational execution.
